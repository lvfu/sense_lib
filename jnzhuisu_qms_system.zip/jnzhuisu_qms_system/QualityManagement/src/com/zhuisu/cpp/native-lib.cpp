#include <jni.h>
#include <string>
#include <stdio.h>

static JavaVM *JVM;
static jobject objectMainActivity;
static jmethodID methodCallMeBaby;


extern "C" JNIEXPORT jstring JNICALL
Java_com_sense_nativemodel_MainActivity_stringFromJNI(
        JNIEnv *env,
        jobject /* this */) {
    std::string hello = "Hello from C++";
    return env->NewStringUTF(hello.c_str());
}


extern "C"
JNIEXPORT jstring JNICALL
Java_com_zhuisu_suppliermanagement_fragment_PersonFragment_stringFromJNI(JNIEnv *env,jobject thiz) {
    std::string hello = "丢雷楼某";
    return env->NewStringUTF(hello.c_str());
}extern "C"
JNIEXPORT jint JNICALL
Java_com_zhuisu_suppliermanagement_fragment_PersonFragment_addNumber(JNIEnv *env, jobject thiz,jint x, jint y) {
    return x + y;
}

extern "C"
JNIEXPORT void JNICALL
Java_com_zhuisu_suppliermanagement_fragment_PersonFragment_syncCallJava(JNIEnv *env, jobject thiz) {

    jclass jcls = env->FindClass("com/zhuisu/suppliermanagement/fragment/PersonFragment");
    jmethodID methodId = env -> GetMethodID(jcls,"showText","(Ljava/lang/String;)V");
    std::string message = "我来自C++,主动调用Java方法";

    env -> CallVoidMethod(thiz,methodId,env -> NewStringUTF(message.c_str()));

}extern "C"
JNIEXPORT void JNICALL
Java_com_zhuisu_suppliermanagement_fragment_PersonFragment_syncCallJava1(JNIEnv *env,jobject thiz) {

    jclass  jclass1 = env->FindClass("com/zhuisu/suppliermanagement/fragment/PersonFragment");
    jmethodID  method1 = env -> GetMethodID(jclass1,"showText1","(ZIF[B)V");
    std::string result = "result:";
    env ->CallVoidMethod(thiz,method1, false,18,12.2f,env -> NewByteArray(12));
}

extern "C"
JNIEXPORT void JNICALL
Java_com_zhuisu_suppliermanagement_fragment_PersonFragment_init(JNIEnv *env, jobject thiz) {
    //获取jvm
    env -> GetJavaVM(&JVM);
    //获取Java对象并做static强引用
    objectMainActivity = env->NewGlobalRef(thiz);
    //获取该对象的Java类
    jclass clazz = env->GetObjectClass(objectMainActivity);
    methodCallMeBaby = env->GetMethodID(clazz, "showText", "(Ljava/lang/String;)V");
}

JNIEnv *getCurrentJNIEnv() {
    if (JVM != NULL) {
        JNIEnv *env_new;
        JVM->AttachCurrentThread(&env_new, NULL);
        return env_new;
    } else {
        return NULL;
    }
}