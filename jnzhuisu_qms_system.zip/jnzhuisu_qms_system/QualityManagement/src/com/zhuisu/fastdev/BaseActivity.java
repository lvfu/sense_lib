package com.zhuisu.fastdev;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.Snackbar;
import android.support.v4.app.FragmentActivity;
import android.util.Base64;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.DatePicker;
import android.widget.TextView;

import com.google.gson.Gson;
import com.zhuisu.fastdev.dialog.BasePopupWindowDialog;
import com.zhuisu.suppliermanagement.util.ToastUtils;
import com.zhuisu.suppliermanagement.util.Util;

import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import okhttp3.MediaType;

/**
 * @author cxh
 * @description
 * @date 2020/10/12.
 */
public abstract class BaseActivity extends FragmentActivity {
    public static final MediaType JSON = MediaType.parse("application/json; charset=utf-8");
    //    public static final MediaType URL_ENCODEING = MediaType.parse("application/x-www-form-urlencoded");
    public static final String TAG = "TAG";
    public Context context = this;
    public Gson gson = new Gson();
    private Dialog dialog;
    private Dialog saveDialog;
    private Dialog loadingDialog;
    private BasePopupWindowDialog basePopupWindowDialog;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(getResId());
        dialog = Util.createLoadingDialog(this, "正在提交");
        saveDialog = Util.createLoadingDialog(this, "正在保存");
        loadingDialog = Util.createLoadingDialog(this, "正在请求数据...");
        initViews();
    }

    protected abstract void initViews();

    protected abstract int getResId();

    /**
     * bitmap转为base64
     */
    public static String bitmapToBase64(Bitmap bitmap) {

        String result = null;
        ByteArrayOutputStream baos = null;
        try {
            if (bitmap != null) {
                baos = new ByteArrayOutputStream();
                bitmap.compress(Bitmap.CompressFormat.JPEG, 10, baos);

                baos.flush();
                baos.close();

                byte[] bitmapBytes = baos.toByteArray();
                result = Base64.encodeToString(bitmapBytes, Base64.DEFAULT);
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (baos != null) {
                    baos.flush();
                    baos.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return result;
    }


    public void showCommitDialog() {
        if (dialog != null && (!(this.isDestroyed())) && (!this.isFinishing())) {
            if (dialog.isShowing()) return;
            dialog.show();
        }
    }

    public void showSaveDialog() {
        if (saveDialog != null && (!(this.isDestroyed())) && (!this.isFinishing())) {
            if (saveDialog.isShowing()) return;
            saveDialog.show();
        }
    }


//    private float lastX = 0;
//    private float firstX = 0;
//    @Override
//    public boolean dispatchTouchEvent(MotionEvent ev) {
//        switch (ev.getAction()){
//
//            case MotionEvent.ACTION_DOWN:
//                firstX = ev.getX();
//                break;
//            case MotionEvent.ACTION_MOVE:
//                float x = ev.getX();
//                lastX = x;
//                Log.e("---x",""+x);
//                break;
//
//            case MotionEvent.ACTION_UP:
//                if (lastX - firstX > 300)
////                    finish();
//                break;
//        }
//        return super.dispatchTouchEvent(ev);
//    }

    public void showLoadingDialog() {
        if (loadingDialog != null && (!(this.isDestroyed())) && (!this.isFinishing())) {
            if (loadingDialog.isShowing()) return;
            loadingDialog.show();
        }
    }


    public void showFailureMessageDialog(Object message) {
        basePopupWindowDialog = new BasePopupWindowDialog();
        Bundle bundle = new Bundle();
        bundle.putString(BasePopupWindowDialog.ACTION_VALUE_TITLE, "提示");
        bundle.putString(BasePopupWindowDialog.ACTION_VALUE_MESSAGE, message.toString());
        basePopupWindowDialog.setArguments(bundle);
        basePopupWindowDialog.show(getSupportFragmentManager(), "");
        basePopupWindowDialog.setOnConfirmClickListener(() -> basePopupWindowDialog.dismiss());
    }

    public void hideFailureMessageDialog() {
        if (basePopupWindowDialog != null && basePopupWindowDialog.isResumed()) {
            basePopupWindowDialog.dismiss();
        }
    }

    public void cancelDialog() {
        if (dialog != null) {
            if (!dialog.isShowing()) return;
            dialog.dismiss();
        }
    }

    public void canceSavelDialog() {
        if (saveDialog != null) {
            if (!saveDialog.isShowing()) return;
            saveDialog.dismiss();
        }
    }


    public void cancelLoadingDialog() {
        if (loadingDialog != null) {
            if (!loadingDialog.isShowing()) return;
            loadingDialog.dismiss();
        }
    }

    @Override
    protected void onDestroy() {
        if (dialog != null) {
            dialog.dismiss();
        }

        if (saveDialog != null) {
            saveDialog.dismiss();
        }
        super.onDestroy();
    }

    /**
     * 加载本地图片
     */
    public static Bitmap getLoacalBitmap(String url) {
        try {
            FileInputStream fis = new FileInputStream(url);
            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inPreferredConfig = Bitmap.Config.RGB_565;
            options.inSampleSize = 2;
            return BitmapFactory.decodeStream(fis, null, options); /// 把流转化为Bitmap图片
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            return null;
        }
    }


    public Bitmap base64ToBitmap(String string) {
        Bitmap bitmap;
        try {
            byte[] bitmapArray = Base64.decode(string, Base64.DEFAULT);
            bitmap = BitmapFactory.decodeByteArray(bitmapArray, 0, bitmapArray.length);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
        return bitmap;
    }


    //需求日期
    public class DateClickListener implements View.OnClickListener {
        TextView dateTv;

        public DateClickListener(TextView dateTv) {
            this.dateTv = dateTv;
        }

        @Override
        public void onClick(View v) {
            Date mydate = new Date(); // 获取当前日期Date对象
            Calendar mycalendar = Calendar.getInstance(Locale.CHINA);
            mycalendar.setTime(mydate);// //为Calendar对象设置时间为当前日期

            int year = mycalendar.get(Calendar.YEAR); // 获取Calendar对象中的年
            int month = mycalendar.get(Calendar.MONTH);// 获取Calendar对象中的月
            int day = mycalendar.get(Calendar.DAY_OF_MONTH);// 获取这个月的第几天

            Dialog d1 = new DatePickerDialog(context, AlertDialog.THEME_DEVICE_DEFAULT_LIGHT, mDateSetListener, year, month, day);
            d1.show();
        }

        DatePickerDialog.OnDateSetListener mDateSetListener = new DatePickerDialog.OnDateSetListener() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onDateSet(DatePicker arg0, int year, int month, int day) {
                dateTv.setText(year + "-" + ((month + 1) < 10 ? ("0" + (month + 1)) : ((month + 1) + "")) + "-" + (day < 10 ? ("0" + day) : (day + "")));
            }
        };
    }

    public void showEmptyMessage() {
        ToastUtils.show("暂无数据");
    }

    public void showSnackbar(View view, String action, String content) {
        Snackbar.make(view, content, Snackbar.LENGTH_SHORT).setAction(action, v -> {
            Log.e("showSnackbar", "---->");
        });
    }

    public void showNetErrorMessage() {
        ToastUtils.show("网络异常");
    }


    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        if (ev.getAction() == MotionEvent.ACTION_DOWN) {

            //拦截两次时间差小于RESTRICT_TIME
            if (isFrequentlyClick()) {
                //可以在这里给点提示
//                Log.d("dispatchTouchEvent", "111");
//                ToastUtils.show("不要频繁点击！");
                return true;
            }
        }
        return super.dispatchTouchEvent(ev);
    }


    private long lastClickTime = 0;
    //设置拦截的时间间隔 1000毫秒
    private long RESTRICT_TIME = 350;

    public boolean isFrequentlyClick() {
        long clickTime = System.currentTimeMillis();
        long value = clickTime - lastClickTime;
        lastClickTime = clickTime;

        Log.d("dispatchTouchEvent", value + "==" + RESTRICT_TIME);
        return value <= RESTRICT_TIME;
    }

}
