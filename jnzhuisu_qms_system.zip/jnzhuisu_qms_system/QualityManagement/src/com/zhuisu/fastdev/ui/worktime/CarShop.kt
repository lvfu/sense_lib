package com.zhuisu.fastdev.ui.worktime

/**
 * @author cxh
 * @description
 * @date 2021/3/12.
 */
data class CarShop(var id : String?,var pnode : String?,var node : String?,var nodetxt : String,var tabtxt: String?,var gb :String?,var pname : String?,var parentId : String?){
    override fun toString(): String {
        return if (tabtxt == null) "" else tabtxt!!
    }
}
