package com.zhuisu.fastdev.ui.jieche;

import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.ArrayMap;
import android.util.Log;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.zhuisu.fastdev.BaseActivity;
import com.zhuisu.fastdev.adapter.registercar.RegisterCarConfigChangeAdapter;
import com.zhuisu.fastdev.beans.RegisterCarConfigChangeBean;
import com.zhuisu.fastdev.beans.registercar.RegisterCarDetails;
import com.zhuisu.fastdev.beans.registercar.RegisterCarListBean;
import com.zhuisu.qualityManagement.R;
import com.zhuisu.suppliermanagement.util.GlobalVar;
import com.zhuisu.suppliermanagement.util.ToastUtils;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 * @author cxh
 * @description
 * @date 2020/10/21.
 */
public class RegisterCarConfigChangeActivity  extends BaseActivity {
    private RegisterCarConfigChangeAdapter adapter;
    private List<RegisterCarConfigChangeBean> list;
    public static final String ACTION_DATA = "action_data_register_config_change";
    private RegisterCarDetails registerCarDetails;


    @Override
    protected void initViews() {
        RecyclerView recyclerView = findViewById(R.id.rv_list);
        list = new ArrayList<>();
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(context);
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        recyclerView.setLayoutManager(linearLayoutManager);
        adapter = new RegisterCarConfigChangeAdapter(context,list);
        recyclerView.setAdapter(adapter);

        if (getIntent() != null && getIntent().hasExtra(ACTION_DATA) ){
            registerCarDetails = getIntent().getParcelableExtra(ACTION_DATA);
            query();
        }
    }

    /**
     * 查询
     * */
    private void query() {

        ArrayMap<String, String> map = new ArrayMap<>();
        map.put("flowCarNo", registerCarDetails.getFlowCarNo());
        map.put("pageNo", "1");
        map.put("pageSize","100");
        String param = gson.toJson(map);
        OkHttpClient client = new OkHttpClient();
        Log.e("--->",param);
//        RequestBody requestBody = RequestBody.create(JSON, param);
        RequestBody requestBody = RequestBody.create(JSON,param);
        Request request = new Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/offlinedebuggingstatus/qmsOfflineStatus/api/configChangeList")
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                Log.d(TAG, "onFailure: 失败");
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                final String result = response.body().string();
                runOnUiThread(() -> showData(result));
            }
        });
    }

    private void showData(String result) {
        Log.d(TAG, "onResponse: 配置变更数据" + result);
        list.clear();
        try {
            JSONObject jsonObject = new JSONObject(result);
            if (jsonObject.optString("status").equals("0")){
                list.addAll(new Gson().fromJson(jsonObject.optJSONObject("data").optString("list"),new TypeToken<List<RegisterCarConfigChangeBean>>(){}.getType()));
                adapter.notifyDataSetChanged();
            }else{
                ToastUtils.show(jsonObject.optString("msg"));
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }


    @Override
    protected int getResId() {
        return R.layout.activity_register_car_config_change;
    }
}
