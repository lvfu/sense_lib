package com.zhuisu.fastdev.ui.gracelog;

import java.io.Serializable;

public class FilePathBean implements Serializable {

    /**
     * fileName  :  Screenshot_20220112_214730.jpg
     * fileextent :  jpg
     * filePath  : D:/userfiles/reviewAftesaleZeroProblemFile/220113/Screenshot_20220112_214730_20220113094406583.jpg
     * retCode  : 0
     * fileStr :
     */

    private String fileName;
    private String fileextent;
    private String filePath;
    private String retCode;
    private String fileStr;

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getFileextent() {
        return fileextent;
    }

    public void setFileextent(String fileextent) {
        this.fileextent = fileextent;
    }

    public String getFilePath() {
        return filePath;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }

    public String getRetCode() {
        return retCode;
    }

    public void setRetCode(String retCode) {
        this.retCode = retCode;
    }

    public String getFileStr() {
        return fileStr;
    }

    public void setFileStr(String fileStr) {
        this.fileStr = fileStr;
    }
}
