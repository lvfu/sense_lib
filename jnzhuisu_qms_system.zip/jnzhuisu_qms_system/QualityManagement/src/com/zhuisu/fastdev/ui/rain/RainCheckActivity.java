package com.zhuisu.fastdev.ui.rain;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.ArrayMap;
import android.util.Log;
import android.widget.EditText;
import android.widget.TextView;

import com.google.gson.reflect.TypeToken;
import com.zhuisu.fastdev.BaseActivity;
import com.zhuisu.fastdev.adapter.rain.RainCheckAdapter;
import com.zhuisu.fastdev.beans.rain.RainListBean;
import com.zhuisu.fastdev.ui.util.BroadCastConfig;
import com.zhuisu.qualityManagement.R;
import com.zhuisu.suppliermanagement.base.CaptureActivity;
import com.zhuisu.suppliermanagement.util.GlobalVar;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 * @author cxh
 * @description
 * @date 2020/10/21.
 * 淋雨检验
 */
public class RainCheckActivity extends BaseActivity {

    private EditText et_scanf_car_number;
    private List<RainListBean> list;
    private RecyclerView recyclerview;
    private RainCheckAdapter adapter;

    BroadCastChange broadCast  = new BroadCastChange();
    IntentFilter filter  = new IntentFilter(BroadCastConfig.BROADCAST_ACTION);

    class BroadCastChange extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent != null && intent.getAction() != null && intent.getAction().equals(BroadCastConfig.BROADCAST_ACTION)){
                et_scanf_car_number.setText(intent.getExtras().getString(BroadCastConfig.BROADCAST_ACTION_TAG));
                et_scanf_car_number.setSelection(et_scanf_car_number.getText().toString().length());
                query();
            }
        }
    }

    @Override
    protected void initViews() {
        et_scanf_car_number = findViewById(R.id.et_scanf_car_number);
        recyclerview = findViewById(R.id.recyclerview);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(context);
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        recyclerview.setLayoutManager(linearLayoutManager);

        list = new ArrayList<>();
        adapter = new RainCheckAdapter(list, context);
        recyclerview.setAdapter(adapter);
        adapter.setOnPrintCommitClickListener(position -> {
            Intent intent = new Intent(context,RainCheckDetailActivity.class);
            intent.putExtra(RainDetailActivity.ACTION_VALUE_DATA,list.get(position));
            startActivity(intent);
        });

        findViewById(R.id.btn_query).setOnClickListener(v -> query());

        TextView tv_user_name = findViewById(R.id.tv_user_name);
        tv_user_name.setText("\t" + GlobalVar.realname);


        findViewById(R.id.tv_scanf).setOnClickListener(arg0 -> {
            Intent intent = new Intent();
            intent.setClass(context, CaptureActivity.class);
            startActivityForResult(intent, 1073);
        });

        filter.setPriority(Integer.MAX_VALUE);
        registerReceiver(broadCast,filter);

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        unregisterReceiver(broadCast);
    }

    @Override
    protected void onResume() {
        super.onResume();
        query();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1073 && resultCode == Activity.RESULT_OK) {
            et_scanf_car_number.setText(data.getStringExtra("encoderesult"));
            query();
        }
    }


    @Override
    protected int getResId() {
        return R.layout.activity_rain_check;
    }


    private void query() {
        ArrayMap<String, String> map = new ArrayMap<>();
        map.put("flowCarNo", "");
        map.put("carFarmeNo", et_scanf_car_number.getText().toString());
        map.put("status", "submitcheck");
        map.put("pageNo", "1");
        map.put("pageSize", "11111");
        map.put("submitCheckOperType", "rain");
        map.put("rainStatus","pendingPass");

        String param = gson.toJson(map);
        OkHttpClient client = new OkHttpClient();
        RequestBody requestBody = RequestBody.create(JSON, param);
        Request request = new Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/offlinedebuggingstatus/qmsOfflineStatus/api/list")
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                Log.d(TAG, "onFailure: 失败");
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                final String result = response.body().string();
                runOnUiThread(() -> showData(result));
            }
        });
    }


    //展示数据
    private void showData(String result) {
        Log.d(TAG, "onResponse: 淋雨列表" + result);
        list.clear();
        try {
            JSONObject jsonObject = new JSONObject(result);
            if (jsonObject.optString("status").equals("0")) {

                if (jsonObject.optJSONObject("data").optString("list") != null){
                    list.addAll(gson.fromJson(jsonObject.optJSONObject("data").optString("list"), new TypeToken<List<RainListBean>>() {}.getType()));
                    if (list == null || list.isEmpty()){
                        showEmptyMessage();
                    }
                    adapter.notifyDataSetChanged();
                }else{
                   showEmptyMessage();
                }

            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

    }

}
