package com.zhuisu.fastdev.ui.payask

import android.content.Intent
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.util.ArrayMap
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import com.google.gson.reflect.TypeToken
import com.zhuisu.fastdev.BaseActivity
import com.zhuisu.fastdev.adapter.payask.PayAskQueryAdapter
import com.zhuisu.fastdev.beans.PayAskQueryListBean
import com.zhuisu.qualityManagement.R
import com.zhuisu.suppliermanagement.util.GlobalVar
import com.zhuisu.suppliermanagement.util.ToastUtils
import okhttp3.*
import org.json.JSONObject
import java.io.IOException

/**
 * @author cxh
 * @description
 * @date 2021/4/9.
 */
class PayAskQueryActivity : BaseActivity() {
    private var adapter: PayAskQueryAdapter? = null
    private var list: ArrayList<PayAskQueryListBean> = ArrayList()

    override fun initViews() {

        val recyclerView: RecyclerView = findViewById(R.id.recyclerview)
        val manager = LinearLayoutManager(context)
        adapter = PayAskQueryAdapter(list, context)
        manager.orientation = LinearLayoutManager.VERTICAL
        recyclerView.layoutManager = manager
        recyclerView.adapter = adapter
        adapter!!.onItemclick = object : PayAskQueryAdapter.OnItemClickListener {
            override fun onItemClick(position: Int) {
                //点击详情
                val intent = Intent(context,PayTaskDetailActivity::class.java)
                intent.putExtra(PayTaskDetailActivity.ID,list[position].id)
                startActivity(intent)
            }
        }

        findViewById<Button>(R.id.btn_query).setOnClickListener {
            query()
        }
    }

    override fun getResId(): Int {
        return R.layout.activity_pay_ask_query
    }

    private fun query() {
        list.clear()
        adapter?.notifyDataSetChanged()

        val etDhdh = findViewById<EditText>(R.id.et_dhdh)
        val etGongYing = findViewById<EditText>(R.id.et_gongyings)
        val etWuliao = findViewById<EditText>(R.id.et_wuliao)
        val etCheckPeople = findViewById<EditText>(R.id.et_check_people)
        val tvStart = findViewById<TextView>(R.id.tv_start)
        val tvEnd = findViewById<TextView>(R.id.tv_end)
        tvStart.setOnClickListener(DateClickListener(tvStart))
        tvEnd.setOnClickListener(DateClickListener(tvEnd))

        val map = ArrayMap<String, Any>()
        map["userName"] = GlobalVar.username
        map["pageNo"] = 1
        map["pageSize"] = 30
        map["material"] = etWuliao.text.toString()
        map["supplier"] = etGongYing.text.toString()
        map["billCode"] = etDhdh.text.toString()
        map["checkPerson"] = etCheckPeople.text.toString()
        map["checkTimeStart"] = tvStart.text.toString()
        map["checkTimeEnd"] = tvEnd.text.toString()

        val param = gson.toJson(map)
        showLoadingDialog()
        Log.e("查询", param)
        val client = OkHttpClient()
        val requestBody = RequestBody.create(JSON, param)
        val request = Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/nonconforming/qmsPurchasecheckUnqualifiedRecord/api/getUnqualifyRecordList")
                .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread {
                    ToastUtils.show("请求失败")
                    cancelLoadingDialog()
                }
            }

            override fun onResponse(call: Call, response: Response) {
                val result = response.body()!!.string()
                runOnUiThread {
                    Log.e("result", result)
                    cancelLoadingDialog()
                    val json = JSONObject(result)
                    if (json.optString("retCode").equals("0") && json.optJSONObject("data") != null && !json.optJSONObject("data").optString("list").isEmpty()) {
                        var temp : ArrayList<PayAskQueryListBean> = gson.fromJson(json.optJSONObject("data").optString("list"),object : TypeToken<List<PayAskQueryListBean>>(){}.type)
                        list.addAll(temp)
                        adapter!!.notifyDataSetChanged()
                    }
                }
            }

        })

    }
}