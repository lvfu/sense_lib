package com.zhuisu.fastdev.ui.problem;

/**
 * @author cxh
 * @description
 * @date 2021/3/8.
 */
public class DeptLocationPeopleListBean {
    private String name;
    private String longinName;

    public void setName(String name) {
        this.name = name;
    }

    public void setLonginName(String longinName) {
        this.longinName = longinName;
    }

    public String getName() {
        return name;
    }

    public String getLonginName() {
        return longinName;
    }

    @Override
    public String toString(){
        return name;
    }
}
