package com.zhuisu.fastdev.ui.lownumber;

/**
 * @author cxh
 * @description
 * @date 2020/12/31.
 */
public class LackCommitCarListBean {
    private String name;

}
