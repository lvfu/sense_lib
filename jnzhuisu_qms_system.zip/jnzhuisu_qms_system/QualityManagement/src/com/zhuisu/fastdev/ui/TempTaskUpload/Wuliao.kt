package com.zhuisu.fastdev.ui.TempTaskUpload

/**
 * @author cxh
 * @description
 * @date 2021/2/4.
 */
data class Wuliao(var createDate : String ,var materielId : String?,var materielIdOld : String,var materielName : String?,var barCode : String?,var supplierNo : String? ,var supplierName : String?,var unit : String?){
    override fun toString(): String {
        return materielName!!
    }
}
