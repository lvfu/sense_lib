package com.zhuisu.fastdev.ui.problemquery

import android.content.Intent
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.text.TextUtils
import android.util.ArrayMap
import android.util.Log
import android.view.View
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import com.google.gson.reflect.TypeToken
import com.zhuisu.fastdev.BaseActivity
import com.zhuisu.fastdev.adapter.problemquery.ProblemQueryQualityAdapter
import com.zhuisu.fastdev.beans.ProblemCloseBean
import com.zhuisu.fastdev.beans.consolework.ConsoleProjectList
import com.zhuisu.fastdev.beans.xiaxian.XiaXianWeiJianXiangQingBuMenList
import com.zhuisu.fastdev.beans.zhuangpei.CarFrameProList
import com.zhuisu.fastdev.ui.problem.CarFrameProblemDetailActivity
import com.zhuisu.fastdev.ui.problem.ProblemDetailActivity
import com.zhuisu.qualityManagement.R
import com.zhuisu.suppliermanagement.base.CaptureActivity
import com.zhuisu.suppliermanagement.util.GlobalVar
import com.zhuisu.suppliermanagement.util.ToastUtils
import okhttp3.*
import org.json.JSONException
import org.json.JSONObject
import java.io.IOException
import java.util.*

/**
 * @author cxh
 * @description
 * @date 2020/11/2.
 */
class ProblemQueryForDoorLJHTQualityActivity : BaseActivity() {
    private var recyclerView: RecyclerView? = null
    private var tv_cjh: EditText? = null
    private var adapter: ProblemQueryQualityAdapter? = null
    private var listBeans: MutableList<ProblemCloseBean>? = null
    private var isFirst = true
    private var isFinishJump = false
    private var tvStartTime: TextView? = null
    private var tvEndTime: TextView? = null
    private var etPerson: EditText? = null
    private var spClass: Spinner? = null
    private var etTitle: EditText? = null
    private var carFrameNo: String? = null
    private var data: String? = null

    override fun initViews() {
        data = intent.getStringExtra("data")
        listBeans = ArrayList()
        recyclerView = findViewById(R.id.recyclerview_lack)
        val linearLayoutManager = LinearLayoutManager(context)
        linearLayoutManager.orientation = LinearLayoutManager.VERTICAL
        recyclerView!!.layoutManager = linearLayoutManager
        adapter = ProblemQueryQualityAdapter(listBeans, context)
        recyclerView!!.adapter = adapter

        adapter!!.setOnCloseMenuClickListener { position: Int ->
            isFirst = false
//            val intent = Intent(context, ProblemDetailActivity::class.java)
//            intent.putExtra(ProblemDetailActivity.REQUEST_DATA, listBeans!![position])
//            intent.putExtra(ProblemDetailActivity.DORM_QUERY, true)
//            startActivity(intent)

            val currentData : CarFrameProList = CarFrameProList()
            currentData.problemSource = listBeans!![position].problemSource
            currentData.problemId = listBeans!![position].id

            val intent = Intent(context, CarFrameProblemDetailActivity::class.java)
            intent.putExtra(CarFrameProblemDetailActivity.REQUEST_DATA, currentData)
            intent.putExtra(CarFrameProblemDetailActivity.ACTION_FINISH_CHECK_JUMP, true)
            intent.putExtra(CarFrameProblemDetailActivity.DORM_QUERY, true)
            startActivity(intent)
        }


        carFrameNo = intent.getStringExtra("data")
        tv_cjh = findViewById(R.id.tv_cjh)
        tvStartTime = findViewById(R.id.tv_start_time)
        tvEndTime = findViewById(R.id.tv_end_time)
        etPerson = findViewById(R.id.et_log_person)
        spClass = findViewById(R.id.sp_banzu)
        etTitle = findViewById(R.id.et_title)


        tvStartTime?.setOnClickListener(DateClickListener(tvStartTime))//选择时间
        tvEndTime?.setOnClickListener(DateClickListener(tvEndTime))

        findViewById<View>(R.id.btn_query).setOnClickListener {
            isFirst = false

        }

        val tv_user_name = findViewById<TextView>(R.id.tv_user_name)
        tv_user_name.text = "\t" + GlobalVar.realname
        findViewById<View>(R.id.tv_scanf).setOnClickListener { arg0: View? ->
            val intent = Intent()
            intent.setClass(context, CaptureActivity::class.java)
            startActivityForResult(intent, 1073)
        }

        if (intent != null && intent.getStringExtra(ACTION_PARAMS) != null) {
            tv_cjh!!.setText(intent.getStringExtra(ACTION_PARAMS))
            isFinishJump = true
        }

        queryUnCloseAsk()
    }


    override fun getResId(): Int {
        return R.layout.activity_problem_query_quality_test
    }

    /**
     * 查询详情
     */
    private fun queryUnCloseAsk() {

        val map = ArrayMap<String, Any>()
        map["carframeNo"] = data!! //offLineCheck
        val param = gson.toJson(map)
        Log.e("未关闭问题参数", param)
        val client = OkHttpClient()
        val requestBody = RequestBody.create(JSON, param)
        val request = Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/checkfaildflow/qmsManufactureCjProblemflow/api/getProblemByCarFrameNo")
                .build()
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.d(TAG, "onFailure: 失败")
            }

            @Throws(IOException::class)
            override fun onResponse(call: Call, response: Response) {
                val result = response.body()!!.string()
                runOnUiThread {
                    try {
                        Log.e("未关闭问题数据", result)
                        val jsonObject = JSONObject(result)
                        if (jsonObject.optString("retCode") == "0") {
                            if (jsonObject.optString("data") != null && jsonObject.optString("data").isNotEmpty()) {
                                val jsonArray = jsonObject.optJSONArray("data")
                                        ?: return@runOnUiThread
                                for (i in 0 until jsonArray.length()) {
                                    val problemData = jsonArray.optJSONObject(i)
                                    val bean = ProblemCloseBean()
                                    bean.peoblemTitle = problemData.optString("problemTitle")
                                    bean.problemDesc = problemData.optString("problemDesc")
                                    bean.id = problemData.optString("problemId")
                                    bean.createBy = problemData.optString("createBy")
                                    if (TextUtils.isEmpty(problemData.optString("problemSource"))) {
                                        bean.problemSource = "assemble_quality_door"
                                        Log.e("--->","assemble_quality_door")
                                    } else {
                                        bean.problemSource = problemData.optString("problemSource")
                                        Log.e("-->",problemData.optString("problemSource"))
                                    }

                                    bean.isClose = problemData.optString("flowStatus")
                                    listBeans!!.add(bean)
                                }
                            } else {
                                ToastUtils.show("暂无数据")
                            }
                            adapter!!.notifyDataSetChanged()
                        } else {
                            ToastUtils.show(jsonObject.optString("retMessage"))
                        }
                    } catch (jsonException: Exception) {
                        jsonException.printStackTrace()
                    }
                }
            }
        })
    }


    companion object {
        const val ACTION_PARAMS = "action_params"
    }
}