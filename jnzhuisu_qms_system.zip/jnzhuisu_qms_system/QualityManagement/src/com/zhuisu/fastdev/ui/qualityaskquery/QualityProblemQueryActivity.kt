package com.zhuisu.fastdev.ui.qualityaskquery

import android.content.Intent
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.text.TextUtils
import android.util.ArrayMap
import android.util.Log
import android.view.View
import android.widget.*
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.zhuisu.fastdev.BaseActivity
import com.zhuisu.fastdev.ui.aftermarket.AfterMarketSourceListBean
import com.zhuisu.fastdev.ui.util.LogUtils
import com.zhuisu.qualityManagement.R
import com.zhuisu.suppliermanagement.util.GlobalVar
import com.zhuisu.suppliermanagement.util.ToastUtils
import okhttp3.*
import org.json.JSONObject
import java.io.IOException

/**
 * @author cxh
 * @description 质量部问题查询
 * @date 2021/3/1.
 */
class QualityProblemQueryActivity : BaseActivity(), QualityAfterPeoblemQueryAdapter.OnItemClickListener {

    private var spSource: Spinner? = null
    private var startDate: TextView? = null
    private var endDate: TextView? = null
    private var etInfo: EditText? = null
    private var adapter: QualityAfterPeoblemQueryAdapter? = null
    private var list: ArrayList<AfterQualityProblemListBean> = ArrayList()
    private var rvList: RecyclerView? = null


    override fun initViews() {
        spSource = findViewById(R.id.sp_source)
        rvList = findViewById(R.id.rv_list)
        startDate = findViewById(R.id.tv_create_date_start)
        startDate!!.setOnClickListener(DateClickListener(startDate))

        endDate = findViewById(R.id.tv_create_date_end)
        endDate!!.setOnClickListener(DateClickListener(endDate))

        etInfo = findViewById(R.id.et_info)

        findViewById<Button>(R.id.btn_query).setOnClickListener {
            query()
        }

        adapter = QualityAfterPeoblemQueryAdapter(list, this)

        val manager = LinearLayoutManager(this)
        manager.orientation = LinearLayoutManager.VERTICAL
        rvList!!.layoutManager = manager
        rvList!!.adapter = adapter
        adapter!!.onItemClickListener = this
        querySource()
    }

    override fun getResId(): Int {
        return R.layout.activity_quality_problem_query
    }


    //查询数据
    private fun query() {
        list.clear()
        adapter!!.notifyDataSetChanged()

        val map = ArrayMap<String, String>()
        map["problemSource"] = if (sourceListBean.isEmpty()) "" else sourceListBean[spSource!!.selectedItemPosition].value
        map["pageSize"] = "100"
        map["pageNo"] = "1"
        map["startDate"] = startDate!!.text.toString()
        map["endDate"] = endDate!!.text.toString()
        map["problemDesc"] = etInfo!!.text.toString()

        val param = gson.toJson(map)
        Log.e("查询参数--->",param)
        val client = OkHttpClient()
        val requestBody = RequestBody.create(JSON, param)
        val request = Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/zerokmproblem/qmsImprovementZeroKmProblem/api/getProblemList")
                .build()
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.d(TAG, "onFailure: 失败")
            }

            @Throws(IOException::class)
            override fun onResponse(call: Call, response: Response) {
                val result = response.body()!!.string()
                runOnUiThread {
                    LogUtils.printDebug("获取问题列表: $result")
                    val jsonData = JSONObject(result)
                    if (jsonData.optString("retCode") == "0" && !TextUtils.isEmpty(jsonData.optString("data")) && !TextUtils.isEmpty(jsonData.optJSONObject("data").optString("list"))) {
                        val listType = object : TypeToken<java.util.ArrayList<AfterQualityProblemListBean>>() {}.type
                        val temp: ArrayList<AfterQualityProblemListBean> = Gson().fromJson(jsonData.optJSONObject("data").optString("list"), listType)
                        list.clear()
                        list.addAll(temp)
                        adapter!!.notifyDataSetChanged()
                    }else{
                        ToastUtils.show("未查询到数据")
                    }
                }
            }
        })
    }

    /**
     * 获取问题来源
     * */
    private var sourceListBean: ArrayList<AfterMarketSourceListBean> = ArrayList()
    private fun querySource() {
        val map = ArrayMap<String, String>()
        val param = gson.toJson(map)
        val client = OkHttpClient()
        val requestBody = RequestBody.create(JSON, param)
        val request = Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/zerokmproblem/qmsImprovementZeroKmProblem/api/getSelectData")
                .build()
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.d(TAG, "onFailure: 失败")
            }

            @Throws(IOException::class)
            override fun onResponse(call: Call, response: Response) {
                val result = response.body()!!.string()
                runOnUiThread {
                    LogUtils.printDebug("获取来源: $result")
                    val jsonData = JSONObject(result)
                    if (jsonData.optString("retCode") == "0" && !TextUtils.isEmpty(jsonData.optString("data"))) {
                        val listType = object : TypeToken<java.util.ArrayList<AfterMarketSourceListBean>>() {}.type
                        val temp: ArrayList<AfterMarketSourceListBean> = Gson().fromJson(jsonData.optString("data"), listType)
                        sourceListBean.clear()
                        sourceListBean.addAll(temp)

                        val registerFormAdapter = ArrayAdapter(context!!, R.layout.simple_textview1, sourceListBean)
                        spSource!!.adapter = registerFormAdapter

                        spSource!!.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                            override fun onItemSelected(parent: AdapterView<*>?, view: View, position: Int, id: Long) {

                            }

                            override fun onNothingSelected(parent: AdapterView<*>?) {}
                        }

                    } else {
                        ToastUtils.show("获取来源失败")
                    }
                }
            }
        })
    }


    //点击了条目
    override fun onItemClickListener(position: Int) {
        val intent = Intent(this,AfterQualityProblemDetailActivity::class.java)
        intent.putExtra(AfterQualityProblemDetailActivity.PARAMS_DATA,list[position])
        startActivity(intent)
    }
}