package com.zhuisu.fastdev.ui.test

import android.support.annotation.FloatRange
import android.util.Log
import com.zhuisu.fastdev.BaseActivity
import com.zhuisu.qualityManagement.R

/**
 * @author cxh
 * @description
 * @date 2020/11/22.
 */
class TestActivity : BaseActivity() {
    override fun initViews() {
        val result = number(1, 1)
//        val str = getStr("陆小凤")


        val numberString = "18"
        val numberInt = numberString.toInt()
        //可以toInt toShort toDouble 等等

        val number1 = 18
        val number1Str: String = number1.toString()


        //字符串比较equals 可以用 == 表示   内容是否相等

        val person1 = Person()
        val person2 = Person()

        // $ 字符串模板 ${表达式  语句 }
        Log.e("tag", "==比较两个对象  ${person1 == person2}")

        //用? 表示如果对象为空 会返回null 程序不会崩溃掉   如果用!!表示信任不为空 一旦为空会崩溃掉
        Log.e("tag", getToken()?.length.toString())


        //数组
        val intArr = intArrayOf(1, 2, 3, 4, 5, 6)
        val flotArr = floatArrayOf(12f, 0f, 11f, 0f, 18.0f)
        val doubleArr = doubleArrayOf(12.0, 18.0, 14.0)

        //String
        val stringArr = arrayOf("陆小凤", "花满楼", "西门崔雪")

        for (value in stringArr.indices) {
            println(value)
        }

        for (value in IntRange(0, stringArr.size - 1)) {
            println(value)
        }

        for (value in 0..stringArr.size - 1) {
            println(value)
        }


        for (i in 4 downTo 1) {
            //downTo 表示倒叙迭代
            println(i)
        }

        for (i in 4 downTo 1 step 2) {
            //每次迭代修改值
            println(i)
        }

    }

    fun lambda() {
        val stringArr = arrayOf("陆小凤", "花满楼", "西门崔雪")
        stringArr.filter { it.isNotEmpty() }.forEach { println(it) }
        stringArr.filter { it.isNotEmpty() }.forEach { ::printNumber }

        val numer = 1
       val str =  when(numer){
            1 ->{
                 "1"
            }

           2 -> "2"
           else -> ""
       }

//        val per1 = PersonConst()
//        per1.name = "陆小凤"
//        per1.age = 18
        //private set 相当于方法私有化 不允许set  默认是protected



    }

    fun printNumber(str: String){
        println(str)
    }

    override fun getResId(): Int {
        return R.layout.activity_test
    }

    val number = fun(num1: Int, num2: Int): Int {
        Log.e("tag", "num1: $num1 num2: $num2  num1+1:{$num1+1}")
        Log.e("tag", "$$num1 \$str") // \转义字符
        return num1 + num2
    }

    val number2 = { num1: Int, num2: Int -> num1 * num2 }

    val getStr = { str: String -> str.substring(0, 2) }


    class Person {



    }

    class PersonConst( name : String,age :Int)
    {
         var name : String? = null  //默认情况有get 和 set方法 同IOS一样

        var age : Int = 0
        get() {
            return if (age < 0) 0 else field
        }

        init {
            this.name = name
            this.age = age
        }



        //构造方法

    }

    fun  test1(){

        //可以使用默认值 ,然后具体某个参数就是指定参数名称和值  具名参数 具体名称
        getStringFormAlign(cache = true)
        println(canChangeParams(1,2,3,4))
    }

    //还可以有方法的签名   默认参数
    fun getStringFormAlign(str: String = "result",cache : Boolean = false){
        println(str in "result1")  //in = contains
        if (str in "result") println("result in") else println("result not in")

        println(cache)
    }


    //可变长度参数
    fun canChangeParams(vararg sum : Int) : Int{
        var num = 0
        sum.forEach { num += it }
        return num
    }


    //调用匿名内部类
    fun callAnnimous (){
        val call = object : HttpCallBack{
            override fun onSuccess(result: String) {

            }

            override fun onFailure(message: String) {

            }

        }
    }

    interface HttpCallBack{
        fun onSuccess(result : String)
        fun onFailure(message : String)
    }

    abstract class HttpUtils{
       abstract fun get(callback : HttpCallBack)
    }

    fun getToken(): String? {
        return null
    }
}