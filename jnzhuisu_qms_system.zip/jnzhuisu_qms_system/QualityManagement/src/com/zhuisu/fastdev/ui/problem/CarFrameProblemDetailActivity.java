package com.zhuisu.fastdev.ui.problem;


import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.v4.content.FileProvider;
import android.text.TextUtils;
import android.util.ArrayMap;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.zhuisu.fastdev.BaseActivity;
import com.zhuisu.fastdev.beans.ProelemDetailBean;
import com.zhuisu.fastdev.beans.zhuangpei.CarFrameProList;
import com.zhuisu.fastdev.dialog.BasePopupWindowDialog;
import com.zhuisu.fastdev.view.FastTitleLayout;
import com.zhuisu.fastdev.view.SmartTextView;
import com.zhuisu.qualityManagement.R;
import com.zhuisu.suppliermanagement.ui.ShowImageDisplayActivity;
import com.zhuisu.suppliermanagement.util.FileUtil;
import com.zhuisu.suppliermanagement.util.GlobalVar;
import com.zhuisu.suppliermanagement.util.ToastUtils;
import com.zhuisu.suppliermanagement.util.Util;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 * @author cxh
 * @description
 * @date 2020/11/2.
 */
public class CarFrameProblemDetailActivity extends BaseActivity {

    public static final String REQUEST_DATA = "request_data";
    public static final String DORM_QUERY = "dorm_query";
    public static final String ACTION_FINISH_CHECK_JUMP = "action_finish_check_jump";

    private CarFrameProList mData;
    private ProelemDetailBean data;
    private EditText et_info;
    private ImageView showimage;
    private Button btnSubmit;
    private Button btnSave;
    private SmartTextView tvErrorCode;//故障编码
    private SmartTextView tvRandom;//随车单号
    private SmartTextView tv_input_time, tv_problem_source, tv_close_user, tv_close_time, tv_depts;//录入时间

    @Override
    protected void initViews() {
        btnSave = findViewById(R.id.btn_save);
        btnSave.setOnClickListener(v -> {
            submit();
        });

        et_info = findViewById(R.id.et_info);
        showimage = findViewById(R.id.showimage);
        findViewById(R.id.iv_select_image).setOnClickListener(view -> selectImage());
        btnSubmit = findViewById(R.id.btn_submit);
        tvErrorCode = findViewById(R.id.tv_error_coder);
        tvRandom = findViewById(R.id.tv_suichedanhao);
        tv_input_time = findViewById(R.id.tv_input_time);
        tv_close_time = findViewById(R.id.tv_close_time);
        tv_close_user = findViewById(R.id.tv_close_user);
        tv_depts = findViewById(R.id.tv_depts);
        tv_problem_source = findViewById(R.id.tv_problem_source);

        mData = getIntent().getParcelableExtra(REQUEST_DATA);
        Log.e("----->", (mData != null && mData.getFlowStatus() != null) + "");


        if (getIntent() != null && getIntent().getBooleanExtra(ACTION_FINISH_CHECK_JUMP, false)) {
            //从整车初验跳转
            findViewById(R.id.ll_input_time).setVisibility(View.VISIBLE);
            findViewById(R.id.ll_close_user).setVisibility(View.VISIBLE);
            findViewById(R.id.ll_close_time).setVisibility(View.VISIBLE);
        }

        if (getIntent() != null && getIntent().getBooleanExtra(DORM_QUERY, false)) {
            findViewById(R.id.ll_close).setVisibility(View.VISIBLE);

            findViewById(R.id.iv_select_image).setVisibility(View.GONE);
            btnSubmit.setText("返回");
            btnSubmit.setOnClickListener(v -> finish());

            findViewById(R.id.ll_photo).setVisibility(View.GONE);
            findViewById(R.id.view_line).setVisibility(View.GONE);
            FastTitleLayout fastTitleLayout = findViewById(R.id.ftl);
            fastTitleLayout.setTitle("问题详情");

            findViewById(R.id.ll_random_number).setVisibility(View.VISIBLE);//随车单号
            findViewById(R.id.ll_error_code).setVisibility(View.VISIBLE);//故障编码
            findViewById(R.id.ll_input_time).setVisibility(View.VISIBLE);
            findViewById(R.id.ll_problem_form).setVisibility(View.VISIBLE);
        } else {

            btnSubmit.setOnClickListener(v -> {
                BasePopupWindowDialog dialog = new BasePopupWindowDialog();
                Bundle bundle = new Bundle();
                bundle.putString(BasePopupWindowDialog.ACTION_VALUE_TITLE, "确定要执行该操作吗?");
                dialog.setArguments(bundle);
                dialog.show(getSupportFragmentManager(), "");
                dialog.setOnConfirmClickListener(() -> {
                    dialog.dismiss();
                    submit();
                });
            });
        }
        et_info.setEnabled(true);
        et_info.setClickable(true);

        query();
    }

    /**
     * 提交数据
     */
    private void submit() {
        ArrayMap<String, Object> map = new ArrayMap<>();
        map.put("problemSource", data.getProblemSource());
        map.put("id", data.getId());
        map.put("closeUser", GlobalVar.username);
        map.put("procInsId", data.getProcInsId() == null ? "" : data.getProcInsId());
        map.put("closeRemark", et_info.getText().toString());
        map.put("imgStr", uploadFilePath == null ? "" : uploadFilePath.isEmpty() ? "" : bitmapToBase64(getLoacalBitmap(uploadFilePath)));

        String param = gson.toJson(map);
        Log.e("参数", param);
        showCommitDialog();

        OkHttpClient client = new OkHttpClient();
        RequestBody requestBody = RequestBody.create(JSON, param);
        Request request = new Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/checkfaildflow/qmsManufactureCjProblemflow/api/closeProblem")
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                runOnUiThread(() -> {
                    showNetErrorMessage();
                    cancelDialog();
                });
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                assert response.body() != null;
                final String result = response.body().string();
                runOnUiThread(() -> {
                    try {
                        cancelDialog();
                        Log.e("--->", result);
                        JSONObject jsonObject = new JSONObject(result);
                        if (jsonObject.optString("retCode").equals("0")) {
                            ToastUtils.show("成功");
                            finish();
                        } else {
                            ToastUtils.show(jsonObject.optString("retMessage"));
                        }
                    } catch (JSONException jsonException) {
                        jsonException.printStackTrace();
                    }
                });
            }
        });
    }

    /**
     * 选择照片
     */
    AlertDialog alertdialog;
    public static String fileDir = Environment.getExternalStorageDirectory().getAbsolutePath() + "/qualitymanagement/files/media/";
    String uploadFilePath;
    Uri imageUri;
    private final int IMAGE_CODE = 200; // 这里的IMAGE_CODE是自己任意定义的

    private void selectImage() {
        alertdialog = Util.getDialog(context, "选择图像", 0, (arg0, view, position, arg3) -> {
            if (alertdialog.isShowing()) {
                alertdialog.dismiss();
            }

            File f;

            switch (position) {
                case 0:
                    String fileName;
                    Intent capimgIntent = new Intent();
                    fileName = new SimpleDateFormat("yyyyMMddHHmmss", Locale.CHINA).format(new Date()) + ".jpg";
                    FileUtil.checkDir(fileDir + "_/");
                    f = new File(fileDir + "_", fileName);
                    uploadFilePath = fileDir + "_/" + fileName;
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                        imageUri = FileProvider.getUriForFile(context, "com.jnqms.fileprovider", f);
                        capimgIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    } else {
                        imageUri = Uri.fromFile(f);
                    }
                    capimgIntent.putExtra(MediaStore.EXTRA_OUTPUT, imageUri);
                    capimgIntent.setAction(MediaStore.ACTION_IMAGE_CAPTURE);
                    capimgIntent.addCategory(Intent.CATEGORY_DEFAULT);

                    startActivityForResult(capimgIntent, 1);
                    break;
                case 1:// 添加文件
                    Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                    intent.setType("image/*");
                    intent.addCategory(Intent.CATEGORY_OPENABLE);

                    try {

                        startActivityForResult(Intent.createChooser(intent, "Select a File to Upload"),
                                IMAGE_CODE);
                    } catch (android.content.ActivityNotFoundException ex) {
                        Toast.makeText(context, "Please install a File Manager.", Toast.LENGTH_SHORT)
                                .show();
                    }
                    break;
                default:
                    break;
            }
        }, new String[]{"拍照", "文件"}, new Integer[]{R.drawable.i_camera, R.drawable.i_image});
        alertdialog.show();
    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == Activity.RESULT_OK && requestCode == IMAGE_CODE) {
            // 选择文件
            String path;
            if (data == null)
                return;
            path = FileUtil.getImageAbsolutePath((Activity) context, data);
            if (path == null) {
                return;
            }
            uploadFilePath = path;
            Glide.with(context).load(path).into(showimage);

        } else if (requestCode == 1 && resultCode == Activity.RESULT_OK) {
            Glide.with(context).load(uploadFilePath).into(showimage);
        }
    }


    @Override
    protected int getResId() {
        return R.layout.activity_car_frame_problem_close_detail;
    }

    private void query() {
        ArrayMap<String, Object> map = new ArrayMap<>();
        map.put("problemSource", mData.getProblemSource() == null ? "assemble_quality_door" : mData.getProblemSource());
        map.put("id", mData.getProblemId());

        String param = gson.toJson(map);

        Log.e("参数", param);
        OkHttpClient client = new OkHttpClient();
        RequestBody requestBody = RequestBody.create(JSON, param);
        Request request = new Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/checkfaildflow/qmsManufactureCjProblemflow/api/problemInfo")
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                Log.d(TAG, "onFailure: 失败");
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                final String result = response.body() != null ? response.body().string() : null;
                runOnUiThread(() -> showData(result));
            }
        });
    }

    private void showData(String result) {
        Log.e("--->问题详情", result);
        try {
            JSONObject jsonObject = new JSONObject(result);

            if (jsonObject.optString("retCode").equals("0")) {
                data = gson.fromJson(jsonObject.optString("data"), ProelemDetailBean.class);
                SmartTextView tv_create_number;
                SmartTextView tv_confirm_number;
                SmartTextView tv_wl_name;
                SmartTextView tv_duct_number;
                SmartTextView tv_remark_lack;
                SmartTextView tv_level;
                SmartTextView tvCloseState, tv_create_user;


                tv_create_number = findViewById(R.id.tv_create_number);
                tv_confirm_number = findViewById(R.id.tv_confirm_number);
                tv_wl_name = findViewById(R.id.tv_wl_name);
                tv_duct_number = findViewById(R.id.tv_duct_number);
                tv_remark_lack = findViewById(R.id.tv_remark_lack);
                tv_level = findViewById(R.id.tv_level);
                tvCloseState = findViewById(R.id.tv_close_state);
                tv_create_user = findViewById(R.id.tv_create_user);

                if (data.getCloseDateStr() == null || data.getCloseDateStr().isEmpty()){
                    tv_close_time.setText(data.getCloseDate() == null ? "": data.getCloseDate());//关闭时间
                }else{
                    tv_close_time.setText(data.getCloseDateStr() == null ?  ""  : data.getCloseDateStr());//关闭时间
                }

                tv_close_user.setText(data.getCloseUser() == null ? "" : data.getCloseUser()); //关闭人
                tv_depts.setText(data.getDepts() == null ? "" : data.getDepts()); //责任部门
                String title = data.getPeoblemTitle();
//                if (data.getPeoblemTitle().contains(" ")){
//                    title = data.getPeoblemTitle().substring(0,data.getPeoblemTitle().indexOf(" "));
//                    if (data.getFaultDesc() != null){
//                        title += data.getFaultDesc();
//                    }
//                }
                tv_create_number.setText(title);

                tv_confirm_number.setText(data.getCarFrameNo());
                tv_wl_name.setText(data.getCarModelNo());
                tv_duct_number.setText(String.valueOf(data.getCheckItemName() == null ? "" : data.getCheckItemName()));
                tv_remark_lack.setText(data.getProblemDesc());
                tv_level.setText(data.getProblemLevel());
                tvErrorCode.setText(data.getMalfunctionCode());
                tvRandom.setText(data.getFlowCarNo());
                tv_input_time.setText(data.getCreateDate());
                et_info.setText(data.getCloseRemark() == null ? "" : data.getCloseRemark());
                et_info.setSelection(et_info.getText().toString().length());

                if (data.getProblemSource() != null) {
                    String showResult = "";
                    switch (data.getProblemSource()) {
                        case "assemble_routing_check":
                            showResult = "装配巡检";
                            break;
                        case "offLineCheck":
                            showResult = "下线质检";
                            break;
                        case "assemble_station":
                            showResult = "装配工位";
                            break;
                        case "car_frame_station":
                            showResult = "车架工位";
                            break;
                        case "missing_parts":
                            showResult = "缺件管理";
                            break;
                        case "car_frame_quality_door":
                            showResult = "车架质量门";
                            break;
                        case "car_body_quality_door":
                            showResult = "车身质量门";
                            break;
                        case "assemble_quality_door":
                            showResult = "装配质量门";
                            break;
                        case "car_body_station":
                            showResult = "车身工位";
                            break;
                    }
                    tv_problem_source.setText(showResult);
                }


                findViewById(R.id.ll_create_user).setVisibility(View.VISIBLE);
                if (data.getIsClose() != null && !TextUtils.isEmpty(data.getIsClose()) && TextUtils.equals("9", data.getIsClose())) {
                    //关闭
                    tvCloseState.setText("已关闭");
                    btnSave.setVisibility(View.GONE);
                    findViewById(R.id.ll_info).setVisibility(View.GONE);
                    findViewById(R.id.view_line).setVisibility(View.GONE);
                    findViewById(R.id.ll_photo).setVisibility(View.GONE);
                    findViewById(R.id.btn_submit).setVisibility(View.GONE);
                    btnSubmit.setVisibility(View.VISIBLE);
                    btnSubmit.setText("返回");
                    btnSubmit.setOnClickListener(v -> finish());
                } else {
                    if (data.getStatus() != null && TextUtils.equals("closed", data.getStatus())) {
                        tvCloseState.setText("已关闭");
                        btnSave.setVisibility(View.GONE);
                        findViewById(R.id.ll_info).setVisibility(View.GONE);
                        findViewById(R.id.view_line).setVisibility(View.GONE);
                        findViewById(R.id.ll_photo).setVisibility(View.GONE);
                        findViewById(R.id.btn_submit).setVisibility(View.GONE);
                        btnSubmit.setVisibility(View.VISIBLE);
                        btnSubmit.setText("返回");
                        btnSubmit.setOnClickListener(v -> finish());
                    } else {
                        tvCloseState.setText("未关闭");
                        btnSubmit.setVisibility(View.VISIBLE);
                    }

                }

                //录入人
                tv_create_user.setText(data.getCreateByName() == null ? "" : data.getCreateByName());


                ImageView iv_image = findViewById(R.id.iv_image);
                if (data.getImgStr() != null && !TextUtils.isEmpty(data.getImgStr())) {
                    if (base64ToBitmap(data.getImgStr()) != null) {
                        iv_image.setImageBitmap(base64ToBitmap(data.getImgStr()));
                        iv_image.setOnClickListener(v -> {
                            Intent intent = new Intent(context, ShowImageDisplayActivity.class);
                            GlobalVar.IMGBASE64 = data.getImgStr();
                            startActivity(intent);
                        });
                    }
                }

            }
        } catch (JSONException jsonException) {
            ToastUtils.show("数据解析异常");
            jsonException.printStackTrace();
        }

    }
}
