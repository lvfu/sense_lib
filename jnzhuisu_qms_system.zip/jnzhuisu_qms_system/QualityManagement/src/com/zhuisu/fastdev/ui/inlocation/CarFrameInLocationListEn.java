package com.zhuisu.fastdev.ui.inlocation;

import java.util.List;

/**
 * @author cxh
 * @description
 * @date 2021/1/21.
 */

public class CarFrameInLocationListEn {

    /**
     * retCode : 0
     * data : [{"outDh":"CC100119102300004","fldWlBh":"WG9725729020/1      ","fldWlMc":"危险货物车辆标志灯(BⅢ)(青岛利发)                 ","scdw":"37.02.0TG46","outSfsl":"0.000","outJssl":"0.000"},{"outDh":"CC100119102300004","fldWlBh":"WG9725729023/1      ","fldWlMc":"BⅢ危险标志灯用前拉攀(青岛利发)                   ","scdw":"37.02.0TG46","outSfsl":"0.000","outJssl":"0.000"},{"outDh":"CC100119102300004","fldWlBh":"WG9725729024/1      ","fldWlMc":"BⅢ危险标志灯用中间拉攀(青岛利发)                 ","scdw":"37.02.0TG46","outSfsl":"0.000","outJssl":"0.000"},{"outDh":"CC100119102300004","fldWlBh":"WG9725729025/1      ","fldWlMc":"BⅢ危险标志灯用后拉攀(青岛利发)                   ","scdw":"37.02.0TG46","outSfsl":"0.000","outJssl":"0.000"}]
     */


    /**
     * outDh : CC100119102300004
     * fldWlBh : WG9725729020/1
     * fldWlMc : 危险货物车辆标志灯(BⅢ)(青岛利发)
     * scdw : 37.02.0TG46
     * outSfsl : 0.000
     * outJssl : 0.000
     */

    private String outDh;
    private String fldWlBh;
    private String fldWlMc;
    private String scdw;
    private String outSfsl;
    private String outJssl;
    private String jssl;

    public void setJssl(String jssl) {
        this.jssl = jssl;
    }

    public String getJssl() {
        return jssl;
    }

    public void setOutDh(String outDh) {
        this.outDh = outDh;
    }

    public void setFldWlBh(String fldWlBh) {
        this.fldWlBh = fldWlBh;
    }

    public void setFldWlMc(String fldWlMc) {
        this.fldWlMc = fldWlMc;
    }

    public void setScdw(String scdw) {
        this.scdw = scdw;
    }

    public void setOutSfsl(String outSfsl) {
        this.outSfsl = outSfsl;
    }

    public void setOutJssl(String outJssl) {
        this.outJssl = outJssl;
    }

    public String getOutDh() {
        return outDh;
    }

    public String getFldWlBh() {
        return fldWlBh;
    }

    public String getFldWlMc() {
        return fldWlMc;
    }

    public String getScdw() {
        return scdw;
    }

    public String getOutSfsl() {
        return outSfsl;
    }

    public String getOutJssl() {
        return outJssl;
    }
}
