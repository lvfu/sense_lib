package com.zhuisu.fastdev.ui.rain.raindetal

/**
 * @author cxh
 * @description
 * @date 2020/12/22.
 */


data class RainFailureBean(var remarks : String?,var part : String?,var partNo : String?,var remark : String?,var yesNo : String?,var imgStr : String?)