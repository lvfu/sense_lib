package com.zhuisu.fastdev.ui.xiaxian;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.provider.MediaStore;
import android.support.v4.content.FileProvider;
import android.util.ArrayMap;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.zhuisu.fastdev.BaseActivity;
import com.zhuisu.fastdev.beans.xiaxian.XiaXianWeiJianFirstBean;
import com.zhuisu.fastdev.beans.xiaxian.XiaXianWeiJianMingXiListBean;
import com.zhuisu.fastdev.ui.util.LogUtils;
import com.zhuisu.qualityManagement.R;
import com.zhuisu.suppliermanagement.util.FileUtil;
import com.zhuisu.suppliermanagement.util.GlobalVar;
import com.zhuisu.suppliermanagement.util.ToastUtils;
import com.zhuisu.suppliermanagement.util.Util;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 * 下线未检明细
 * */
public class XiaXianWeiJianMingXingActivity extends BaseActivity {
    public static final String ACTION_DETAIL_DATA = "action_detail_data";
    public static final String ACTION_CHECKSUCCESS = "action_checksuccess";
    private XiaXianWeiJianFirstBean data;
    private TextView tv_name1;
    private TextView tv_name2;
    private TextView tv_name3;
    private TextView tv_name4;
    private TextView tv_name5;
    private TextView tv_name6;
    private TextView tv_name7;
    private TextView tv_name8;
    private TextView tv_name9;
    private TextView tv_name10;
    private TextView tv_name11;
    private TextView tv_name12;
    private TextView tv_name13;
    private TextView tv_name14;
    private TextView tv_name15;
    private EditText et_check_number;//检验值
    private EditText et_check_info;//检验备注

    private ImageView iv_select_image;//选择照片
    private ImageView showimage;//显示的照片
    private boolean isFinished = false;//是否是已检查
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    protected void initViews() {
        if (getIntent() != null && getIntent().hasExtra(ACTION_DETAIL_DATA)){
            data = getIntent().getParcelableExtra(ACTION_DETAIL_DATA);
            tv_name1 = findViewById(R.id.tv_name1);
            tv_name2 = findViewById(R.id.tv_name2);
            tv_name3 = findViewById(R.id.tv_name3);
            tv_name4 = findViewById(R.id.tv_name4);
            tv_name5 = findViewById(R.id.tv_name5);
            tv_name6 = findViewById(R.id.tv_name6);
            tv_name7 = findViewById(R.id.tv_name7);
            tv_name8 = findViewById(R.id.tv_name8);
            tv_name9 = findViewById(R.id.tv_name9);
            tv_name10 = findViewById(R.id.tv_name10);
            tv_name11 = findViewById(R.id.tv_name11);
            tv_name12 = findViewById(R.id.tv_name12);
            tv_name13 = findViewById(R.id.tv_name13);
            tv_name14 = findViewById(R.id.tv_name14);
            tv_name15 = findViewById(R.id.tv_name15);
            et_check_number = findViewById(R.id.et_check_number);
            showimage = findViewById(R.id.showimage);
            et_check_info = findViewById(R.id.et_check_info);


            queryData();
        }

        if (getIntent() != null && getIntent().hasExtra(ACTION_CHECKSUCCESS)){
            isFinished = getIntent().getBooleanExtra(ACTION_CHECKSUCCESS,false);
            if (isFinished){
                et_check_number.setEnabled(false);
                et_check_number.setClickable(false);
                et_check_info.setClickable(false);
                et_check_info.setEnabled(false);
                findViewById(R.id.btn_submit_result).setVisibility(View.GONE);
            }else{
                findViewById(R.id.iv_select_image).setOnClickListener(view -> selectImage());
                findViewById(R.id.btn_submit_result).setOnClickListener(view -> submitData());
            }
        }
    }


    /**
     * 选择照片
     * */
    Uri imageUri;
    AlertDialog alertdialog;
    public static String fileDir = Environment.getExternalStorageDirectory().getAbsolutePath() +"/qualitymanagement/files/media/";
    String uploadFilePath;
    private final int IMAGE_CODE = 200; // 这里的IMAGE_CODE是自己任意定义的
    private void selectImage() {
        alertdialog = Util.getDialog(context, "选择图像", 0, (arg0, view, position, arg3) -> {
            if (alertdialog.isShowing()) {
                alertdialog.dismiss();
            }

            File f = null;
            Uri uri = null;

            switch (position) {
                case 0:
                    String fileName = "";
                    Intent capimgIntent = new Intent();
                    fileName = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date()) + ".jpg";
                    FileUtil.checkDir(fileDir + "_/");
                    f = new File(fileDir + "_", fileName);
                    uploadFilePath = fileDir + "_/" + fileName;
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                        // 7.0+以上版本
                        //与manifest中定义的provider中的authorities="cn.wlantv.kznk.fileprovider"保持一致
                        imageUri = FileProvider.getUriForFile(context, "com.jnqms.fileprovider", f);
                        capimgIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    }else{
                        imageUri = Uri.fromFile(f);
                    }
                    capimgIntent.putExtra(MediaStore.EXTRA_OUTPUT, imageUri);
                    capimgIntent.setAction(MediaStore.ACTION_IMAGE_CAPTURE);
                    capimgIntent.addCategory(Intent.CATEGORY_DEFAULT);

                    startActivityForResult(capimgIntent, 1);
                    break;
                case 1:// 添加文件
                    Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                    intent.setType("image/*");
                    intent.addCategory(Intent.CATEGORY_OPENABLE);

                    try {

                        startActivityForResult(Intent.createChooser(intent, "Select a File to Upload"),
                                IMAGE_CODE);
                    } catch (android.content.ActivityNotFoundException ex) {
                        Toast.makeText(context, "Please install a File Manager.", Toast.LENGTH_SHORT)
                                .show();
                    }
                    break;
                default:
                    break;
            }
        }, new String[] { "拍照", "文件" }, new Integer[] { R.drawable.i_camera, R.drawable.i_image });
        alertdialog.show();
    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == Activity.RESULT_OK && requestCode == IMAGE_CODE) {
            // 选择文件
            String path = null;
            if (data == null)
                return;
            path = FileUtil.getImageAbsolutePath((Activity) context, data);
            if (path == null) {
                return;
            }
            uploadFilePath = path;
            Glide.with(context).load(path).into(showimage);

        } else if (requestCode == 1 && resultCode == Activity.RESULT_OK) {
            Glide.with(context).load(uploadFilePath).into(showimage);
        }
    }


    /***
     * 提交检验结果
     *
     */
    private void submitData() {
        ArrayMap<String,String> map = new ArrayMap<>();
        map.put("id", data.getId());
        map.put("checkValue",et_check_number.getText().toString());
        map.put("checkRemarks",et_check_info.getText().toString());
        if (uploadFilePath == null || uploadFilePath.isEmpty()){
            map.put("imgStr","");
        }else{
            map.put("imgStr",bitmapToBase64(getLoacalBitmap(uploadFilePath)));
        }

        String param= gson.toJson(map);

        LogUtils.printDebug(param);
        showCommitDialog();


        OkHttpClient client = new OkHttpClient();
        RequestBody requestBody = RequestBody.create(JSON, param);
        Request request = new Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/prduictionrelation/qmsManufactureProductionplanrelation/api/updateCheckValueById")
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                Log.d(TAG, "onFailure: 失败");
                runOnUiThread(()->{
                    showNetErrorMessage();
                    cancelDialog();
                });
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                final String result = response.body().string();
                Log.d(TAG, "onResponse: 明细" + result);
                runOnUiThread(() -> {
                    try {
                        cancelDialog();
                        JSONObject jsonObject = new JSONObject(result);
                        if (jsonObject.optString("retCode").equals("0")){
                            ToastUtils.show("成功");
                            new Handler().postDelayed(()->finish(),1500);
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                });
            }
        });
    }


    private void queryData() {
        ArrayMap<String,String> map = new ArrayMap<>();
        map.put("id", data.getId());
        String param= gson.toJson(map);
        OkHttpClient client = new OkHttpClient();
        RequestBody requestBody = RequestBody.create(JSON, param);
        Request request = new Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/prduictionrelation/qmsManufactureProductionplanrelation/api/getCheckItemDetail")
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                Log.d(TAG, "onFailure: 失败");
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                final String result = response.body().string();
                Log.d(TAG, "onResponse: 明细" + result);
                runOnUiThread(() -> showData(result));
            }
        });

    }

    private void showData(String result) {

        try {
            JSONObject jsonObject = new JSONObject(result);
            if (jsonObject.optString("retCode").equals("0")){
                //成功
                XiaXianWeiJianMingXiListBean bean = gson.fromJson(jsonObject.optString("data"),XiaXianWeiJianMingXiListBean.class);
                tv_name1.setText("车架号: "+bean.getCarframeNo());
                tv_name2.setText("随车单号: "+bean.getFlowcarNo());
                tv_name3.setText("车型号: "+bean.getCarModelNo());
                tv_name4.setText("产品类型: "+bean.getProductModel());
                tv_name5.setText("检验人员: "+bean.getCheckedBy());
                tv_name6.setText("检验时间: "+bean.getCheckedDate());
                tv_name7.setText("检验结果: "+("" + (bean.getStatus().equals("passed") ? "合格" : bean.getStatus().equals("failed") ? "不合格" : "待检验")));
                tv_name8.setText("项目名称: "+bean.getOpnm());
                tv_name9.setText("项目编码: "+bean.getOpno());
                tv_name10.setText("控制点技术要求: "+bean.getMation());


                if (bean.getCheckValue() != null){
                    et_check_number.setText(String.valueOf(bean.getCheckValue()));
                }

                if (bean.getCheckRemarks() != null){
                    et_check_info.setText(String.valueOf(bean.getCheckRemarks()));
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }


    @Override
    protected int getResId() {
        return R.layout.activity_xia_xian_wei_jian_ming_xing;
    }
}