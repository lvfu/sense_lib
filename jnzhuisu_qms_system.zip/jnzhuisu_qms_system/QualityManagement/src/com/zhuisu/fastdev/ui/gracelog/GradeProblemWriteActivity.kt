package com.zhuisu.fastdev.ui.gracelog

import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.DialogInterface
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Parcelable
import android.provider.MediaStore
import android.support.v4.content.FileProvider
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.text.TextUtils
import android.util.ArrayMap
import android.util.Log
import android.view.MotionEvent
import android.view.View
import android.widget.*
import android.widget.AdapterView.OnItemSelectedListener
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.zhuisu.fastdev.BaseActivity
import com.zhuisu.fastdev.beans.xiaxian.*
import com.zhuisu.fastdev.beans.zhuangpei.ZhuangPeiWeiJianGuZhangXinxiBean
import com.zhuisu.fastdev.ui.util.LogUtils
import com.zhuisu.fastdev.ui.zhuangpei.SelectItemActivity
import com.zhuisu.qualityManagement.R
import com.zhuisu.suppliermanagement.base.CaptureActivity
import com.zhuisu.suppliermanagement.util.FileUtil
import com.zhuisu.suppliermanagement.util.GlobalVar
import com.zhuisu.suppliermanagement.util.ToastUtils
import com.zhuisu.suppliermanagement.util.Util
import okhttp3.*
import org.json.JSONException
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.*
import kotlin.collections.ArrayList


/**
 * @author cxh
 * @description  评审问题录入
 * @date 2021/2/25.
 */
class GradeProblemWriteActivity : BaseActivity(),PictureAdapter.OnItemClickListener{

    private var etCarNumber: EditText? = null
    private var spProject: Spinner? = null
    private var spxiangmuleixing: Spinner? = null
    private var tvErrorCode: TextView? = null
    private var tvErrorName: TextView? = null
    private var tvErrorLevel: TextView? = null
    private var tvErrorType: TextView? = null
    private var spDept: Spinner? = null
    private var spBuhege: Spinner? = null
    private var sp_projectname:Spinner? = null;
    private var spshifoumax: Spinner? = null
    private var sp_chanpinbianhao: Spinner? = null
    private var showimage: ImageView? = null
    private var etInfo: EditText? = null
    private var tv_error_number: EditText? = null
    var maxList: ArrayList<MaxBean> = ArrayList()
    private var photolist: ArrayList<String>? = null
    private var picadapter: PictureAdapter? = null
    private var postion = 0

    @SuppressLint("ClickableViewAccessibility")
    override fun initViews() {
        //ZoomMediaLoader.getInstance().init(ImagePreViewLoader())
        etCarNumber = findViewById(R.id.et_car_frame_number)
        spProject = findViewById(R.id.sp_project)
        spxiangmuleixing = findViewById(R.id.xiangmuleixing)

        photolist = ArrayList()
        picadapter = PictureAdapter(photolist!!, context)
        val manager = LinearLayoutManager(context)
        manager.orientation = LinearLayoutManager.HORIZONTAL
        val rvList: RecyclerView = findViewById(R.id.rv_list)
        rvList.layoutManager = manager
        rvList.adapter = picadapter
        picadapter!!.onItenClick = this

        etCarNumber!!.setOnTouchListener { _, event ->
            var endX = 0.0f
            when (event.action) {
                MotionEvent.ACTION_UP -> {
                    endX = event.rawX
                    Log.e("--->", "" + endX)
                    if (endX > 520) {
                        showMutilDialog()
                        true
                    }
                }
            }
            false
        }


        findViewById<TextView>(R.id.tv_scanf).setOnClickListener {
            val intent = Intent(context, CaptureActivity::class.java)
            startActivityForResult(intent, 1073)
        }

        tvErrorCode = findViewById(R.id.tv_error_coder)
        tvErrorName = findViewById(R.id.tv_error_name)
        tvErrorLevel = findViewById(R.id.tv_error_level)
        tvErrorType = findViewById(R.id.tv_error_type)
        showimage = findViewById(R.id.showimage)
        spDept = findViewById(R.id.sp_dept)
        spBuhege = findViewById(R.id.buhexiangfenlei)
        etInfo = findViewById(R.id.et_info)
        spshifoumax = findViewById(R.id.shifoumax)
        sp_projectname = findViewById(R.id.sp_projectname)
        sp_chanpinbianhao = findViewById(R.id.sp_chanpinbianhao)
        tv_error_number = findViewById(R.id.tv_error_number)

        var maxBean1: MaxBean = MaxBean()
        maxBean1.code = 0
        maxBean1.codeName ="否"

        var maxBean2: MaxBean = MaxBean()
        maxBean2.code = 1
        maxBean2.codeName ="是"
        maxList.add(maxBean1)
        maxList.add(maxBean2)
        val maxAdapter = ArrayAdapter(context!!, R.layout.simple_textview1, maxList)
        spshifoumax!!.adapter = maxAdapter

        tvErrorCode!!.setOnClickListener {
            val intent = Intent(context, SelectItemActivity::class.java)
            startActivityForResult(intent, 0x11)
        }

        findViewById<View>(R.id.btn_submit).setOnClickListener {
            submit("1")
        }
        findViewById<View>(R.id.btn_save).setOnClickListener {
            submit("")
        }
        findViewById<View>(R.id.iv_select_image).setOnClickListener { view: View? -> selectImage() }
        //queryGradeType()
        queryDept()
        queryBuhege()
        queryxiangmuleixing()
    }

    override fun getResId(): Int {
        return R.layout.activity_grade_problem_write
    }

    private fun showMutilDialog() {
        if (carNumberList.isEmpty()) {
            return
        }
        val builder = AlertDialog.Builder(this, R.style.MyAlertDialogStyle)
        builder.setTitle("请选择车架号")
        val items = arrayOfNulls<String>(carNumberList.size)
        for (i in carNumberList.indices) {
            items[i] = carNumberList[i]
        }
        var whtch = 0
        builder.setSingleChoiceItems(items, 0) { _, w ->
            whtch = w
        }
        builder.setPositiveButton("确定") { dialog: DialogInterface, which: Int ->
            etCarNumber!!.setText(carNumberList[whtch])
            dialog.dismiss()
        }
        builder.show()
    }

    /**
     * 获取计划类型
     * */
    private var projectList: ArrayList<GradeProblemProjectListBean> = ArrayList()
    private fun queryGradeType() {
        val map = ArrayMap<String, String>()
        val param = gson.toJson(map)
        val client = OkHttpClient()
        val requestBody = RequestBody.create(JSON, param)
        val request = Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/reviewprojectproblem/qmsImprovementReviewProjectProblem/api/getReviewProjects")
                .build()
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.d(TAG, "onFailure: 失败")
            }

            @Throws(IOException::class)
            override fun onResponse(call: Call, response: Response) {
                val result = response.body()!!.string()
                runOnUiThread {
                    LogUtils.printDebug("获取评审项目: $result")
                    val jsonData = JSONObject(result)
                    if (jsonData.optString("retCode") == "0" && !TextUtils.isEmpty(jsonData.optString("data"))) {
                        val listType = object : TypeToken<java.util.ArrayList<GradeProblemProjectListBean>>() {}.type
                        val temp: ArrayList<GradeProblemProjectListBean> = Gson().fromJson(jsonData.optString("data"), listType)
                        projectList.clear()
                        projectList.addAll(temp)

                        val registerFormAdapter = ArrayAdapter(context!!, R.layout.simple_textview1, projectList)
                        spProject!!.adapter = registerFormAdapter

                        spProject!!.onItemSelectedListener = object : OnItemSelectedListener {
                            override fun onItemSelected(parent: AdapterView<*>?, view: View, position: Int, id: Long) {
                                queryCarNumbers(projectList[spProject!!.selectedItemPosition].reviewProjectNo)
                            }

                            override fun onNothingSelected(parent: AdapterView<*>?) {}
                        }

                    } else {
                        ToastUtils.show("获取评审项目失败")
                    }
                }
            }
        })
    }

    private var carNumberList: ArrayList<String> = ArrayList()
    private fun queryCarNumbers(reviewProjectNo: String) {
        val map = ArrayMap<String, String>()
        map["reviewProjectNo"] = reviewProjectNo
        val param = gson.toJson(map)
        val client = OkHttpClient()
        val requestBody = RequestBody.create(JSON, param)
        val request = Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/reviewprojectproblem/qmsImprovementReviewProjectProblem/api/getReviewProjectCarFrameNos")
                .build()
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.d(TAG, "onFailure: 失败")
            }

            @Throws(IOException::class)
            override fun onResponse(call: Call, response: Response) {
                val result = response.body()!!.string()
                runOnUiThread {
                    LogUtils.printDebug("获取车架号: $result")
                    val jsonData = JSONObject(result)
                    if (jsonData.optString("retCode") == "0" && !TextUtils.isEmpty(jsonData.optString("data"))) {
                        val listType = object : TypeToken<java.util.ArrayList<String>>() {}.type
                        val temp: ArrayList<String> = Gson().fromJson(jsonData.optString("data"), listType)
                        carNumberList.clear()
                        carNumberList.addAll(temp)
                    } else {
                        ToastUtils.show("获取车架号失败")
                    }
                }
            }
        })
    }

    /**
     * 查询不合格项分类
     * */
    private var buhegeList: ArrayList<BuHeGeFenLei.DataBean> = ArrayList()
    private fun queryBuhege() {
        val map = ArrayMap<String, String>()
        val client = OkHttpClient()
        val requestBody = RequestBody.create(JSON, "")
        val request = Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/problem/qmsReviewAftesaleZeroProblem/api/unqualifiedSort")
                .build()
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.d(TAG, "onFailure: 失败")
            }

            @Throws(IOException::class)
            override fun onResponse(call: Call, response: Response) {
                val result = response.body()!!.string()
                runOnUiThread {
                    try {
                        val jsonObject = JSONObject(result)
                        buhegeList = gson.fromJson(jsonObject.optString("data"), object : TypeToken<List<BuHeGeFenLei.DataBean?>?>() {}.type)
                        val arrayAdapter = ArrayAdapter(context, R.layout.simple_textview1, buhegeList)
                        spBuhege!!.adapter = arrayAdapter
                    } catch (e: JSONException) {
                        e.printStackTrace()
                    }
                }
            }
        })
    }

    /**
     * 获取产品编号
     * */
    private var projectbianhaoList: ArrayList<ProjectbianhaoBean.DataBean> = ArrayList()
    private fun queryprojectBianhao(reviewProjectNo: String, reviewType: String) {
        val map = ArrayMap<String, String>()
        map["reviewProjectNo"] = reviewProjectNo
        map["reviewType"] = reviewType
        val param = gson.toJson(map)
        val client = OkHttpClient()
        val requestBody = RequestBody.create(JSON, param)
        val request = Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/reviewprojectproblem/qmsImprovementReviewProjectProblem/api/findCarFrameNoByReviewProject")
                .build()
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.d(TAG, "onFailure: 失败")
            }

            @Throws(IOException::class)
            override fun onResponse(call: Call, response: Response) {
                val result = response.body()!!.string()
                runOnUiThread {
                    try {
                        val jsonObject = JSONObject(result)
                        if (jsonObject.optString("retCode").equals("-1")) {
                            projectbianhaoList = ArrayList()
                        } else {
                            projectbianhaoList = gson.fromJson(jsonObject.optString("data"), object : TypeToken<List<ProjectbianhaoBean.DataBean?>?>() {}.type)
                        }
                        val arrayAdapter = ArrayAdapter(context, R.layout.simple_textview1, projectbianhaoList)
                        sp_chanpinbianhao!!.adapter = arrayAdapter
                    } catch (e: JSONException) {
                        e.printStackTrace()
                    }
                }
            }
        })
    }

    /**
     * 获取项目名称
     * */
    private var projectnameList: ArrayList<ProjectNameBean.DataBean> = ArrayList()
    private fun queryprojectName(valye: String) {
        val map = ArrayMap<String, String>()
        map["reviewType"] = valye
        val param = gson.toJson(map)
        val client = OkHttpClient()
        val requestBody = RequestBody.create(JSON, param)
        val request = Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/reviewprojectproblem/qmsImprovementReviewProjectProblem/api/findreviewProjectTypeReviewProjectNo")
                .build()
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.d(TAG, "onFailure: 失败")
            }

            @Throws(IOException::class)
            override fun onResponse(call: Call, response: Response) {
                val result = response.body()!!.string()
                runOnUiThread {
                    try {
                        val jsonObject = JSONObject(result)
                        if (jsonObject.optString("retCode").equals("-1")) {
                            projectnameList = ArrayList()
                        } else {
                            projectnameList = gson.fromJson(jsonObject.optString("data"), object : TypeToken<List<ProjectNameBean.DataBean?>?>() {}.type)

                        }
                        val arrayAdapter = ArrayAdapter(context, R.layout.simple_textview1, projectnameList)
                        sp_projectname!!.adapter = arrayAdapter
                        sp_projectname!!.onItemSelectedListener = object : OnItemSelectedListener {
                            override fun onItemSelected(parent: AdapterView<*>?, view: View, position: Int, id: Long) {
                                queryprojectBianhao(projectnameList[sp_projectname!!.selectedItemPosition].reviewProjectNo, projectnameList[sp_projectname!!.selectedItemPosition].reviewType)
                            }

                            override fun onNothingSelected(parent: AdapterView<*>?) {}
                        }
                    } catch (e: JSONException) {
                        e.printStackTrace()
                    }
                }
            }
        })
    }

    /**
     * 查询项目类型
     * */
    private var leixingList: ArrayList<XiangmuLeiXingBean.DataBean> = ArrayList()
    private fun queryxiangmuleixing() {

        val map = ArrayMap<String, String>()
        val client = OkHttpClient()
        val requestBody = RequestBody.create(JSON, "")
        val request = Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/problem/qmsReviewAftesaleZeroProblem/api/reviewProjectSources")
                .build()
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.d(TAG, "onFailure: 失败")

            }

            @Throws(IOException::class)
            override fun onResponse(call: Call, response: Response) {
                val result = response.body()!!.string()
                runOnUiThread {
                    try {
                        val jsonObject = JSONObject(result)
                        leixingList = gson.fromJson(jsonObject.optString("data"), object : TypeToken<List<XiangmuLeiXingBean.DataBean?>?>() {}.type)
                        val arrayAdapter = ArrayAdapter(context, R.layout.simple_textview1, leixingList)
                        spxiangmuleixing!!.adapter = arrayAdapter
                        spxiangmuleixing!!.onItemSelectedListener = object : OnItemSelectedListener {
                            override fun onItemSelected(parent: AdapterView<*>?, view: View, position: Int, id: Long) {
                                queryprojectName(leixingList[spxiangmuleixing!!.selectedItemPosition].value)
                            }

                            override fun onNothingSelected(parent: AdapterView<*>?) {}
                        }
                    } catch (e: JSONException) {
                        e.printStackTrace()
                    }
                }
            }
        })
    }

    /**
     * 查询部门
     */
    private var deptList: ArrayList<XiaXianWeiJianXiangQingBuMenList> = ArrayList()
    private fun queryDept() {
        val map = ArrayMap<String, String>()
        val client = OkHttpClient()
        val requestBody = RequestBody.create(JSON, "")
        val request = Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/problem/qmsReviewAftesaleZeroProblem/api/officeList")
                .build()
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.d(TAG, "onFailure: 失败")
            }

            @Throws(IOException::class)
            override fun onResponse(call: Call, response: Response) {
                val result = response.body()!!.string()
                runOnUiThread {
                    Log.d(TAG, "onResponse: 部门$result")
                    try {
                        val jsonObject = JSONObject(result)
                        deptList = gson.fromJson(jsonObject.optString("data"), object : TypeToken<List<XiaXianWeiJianXiangQingBuMenList?>?>() {}.type)
                        val arrayAdapter = ArrayAdapter(context, R.layout.simple_textview1, deptList)
                        spDept!!.adapter = arrayAdapter
                    } catch (e: JSONException) {
                        e.printStackTrace()
                    }
                }
            }
        })
    }

    private var zhuangPeiWeiJianGuZhangXinxiBean: ZhuangPeiWeiJianGuZhangXinxiBean? = null
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (resultCode == 0x18) {
            if (data!!.getParcelableExtra<Parcelable?>("data") != null) {
                zhuangPeiWeiJianGuZhangXinxiBean = data.getParcelableExtra("data")
                tvErrorCode!!.text = zhuangPeiWeiJianGuZhangXinxiBean!!.malfunctionNo
                tvErrorName!!.text = zhuangPeiWeiJianGuZhangXinxiBean!!.malfunctionName
                tvErrorLevel!!.text = zhuangPeiWeiJianGuZhangXinxiBean!!.malfunctionLevel
                tvErrorType!!.text = zhuangPeiWeiJianGuZhangXinxiBean!!.malfunctionType
            }
        } else {
            if (resultCode == RESULT_OK && requestCode == IMAGE_CODE) {
                // 选择文件
                var path: String? = null
                if (data == null) return
                path = FileUtil.getImageAbsolutePath(context as Activity, data)
                if (path == null) {
                    return
                }
                uploadFilePath = path
                photolist!!.add(uploadFilePath!!)
                picadapter!!.notifyDataSetChanged()
                //Glide.with(context).load(path).into(showimage)
            } else if (requestCode == 1 && resultCode == RESULT_OK) {
                //Glide.with(context).load(uploadFilePath).into(showimage)
                photolist!!.add(uploadFilePath!!)
                picadapter!!.notifyDataSetChanged()
            } else if (data != null) {
                val str = data.getStringExtra("encoderesult").toString()
                etCarNumber!!.setText(str)
            }
        }
        super.onActivityResult(requestCode, resultCode, data)
    }

    var alertdialog: AlertDialog? = null
    var fileDir = Environment.getExternalStorageDirectory().absolutePath + "/qualitymanagement/files/media/"
    var uploadFilePath: String? = null
    var imageUri: Uri? = null
    private val IMAGE_CODE = 200 // 这里的IMAGE_CODE是自己任意定义的

    private fun selectImage() {
        alertdialog = Util.getDialog(context, "选择图像", 0, { arg0, view, position, arg3 ->
            if (alertdialog!!.isShowing) {
                alertdialog!!.dismiss()
            }
            var f: File? = null
            val uri: Uri? = null
            when (position) {
                0 -> {
                    var fileName = ""
                    val capimgIntent = Intent()
                    fileName = SimpleDateFormat("yyyyMMddHHmmss").format(Date()) + ".jpg"
                    FileUtil.checkDir(fileDir + "_/")
                    f = File(fileDir + "_", fileName)
                    uploadFilePath = fileDir + "_/" + fileName
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                        // 7.0+以上版本
                        //与manifest中定义的provider中的authorities="cn.wlantv.kznk.fileprovider"保持一致
                        imageUri = FileProvider.getUriForFile(context, "com.jnqms.fileprovider", f)
                        capimgIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    } else {
                        imageUri = Uri.fromFile(f)
                    }
                    capimgIntent.putExtra(MediaStore.EXTRA_OUTPUT, imageUri)
                    capimgIntent.action = MediaStore.ACTION_IMAGE_CAPTURE
                    capimgIntent.addCategory(Intent.CATEGORY_DEFAULT)
                    startActivityForResult(capimgIntent, 1)
                }
                1 -> {
                    val intent = Intent(Intent.ACTION_GET_CONTENT)
                    intent.type = "image/*"
                    intent.addCategory(Intent.CATEGORY_OPENABLE)
                    try {
                        startActivityForResult(Intent.createChooser(intent, "Select a File to Upload"),
                                IMAGE_CODE)
                    } catch (ex: ActivityNotFoundException) {
                        Toast.makeText(context, "Please install a File Manager.", Toast.LENGTH_SHORT)
                                .show()
                    }
                }
                else -> {
                }
            }
        }, arrayOf("拍照", "文件"), arrayOf(R.drawable.i_camera, R.drawable.i_image))
        alertdialog!!.show()
    }

    override fun onItemClickListener(position: Int) {
        commitFile(photolist!![position])
        this.postion = position
    }

    private var filepathList: ArrayList<FilePathBean> = ArrayList()
    private fun commitFile(imagePath: String) {
        showLoadingDialog()
        val client = OkHttpClient()
        var file = File(imagePath)
        val image = RequestBody.create(MediaType.parse("image/png"), file)
        var requestBody = MultipartBody.Builder()
                .setType(MultipartBody.FORM)
                .addFormDataPart("file", imagePath, image)
                .build()

        val request = Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/problem/qmsReviewAftesaleZeroProblemFile/uploadFile")
                .build()
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.d(TAG, "onFailure: 失败")
                cancelLoadingDialog()
                ToastUtils.show("图片上传失败")
            }

            @Throws(IOException::class)
            override fun onResponse(call: Call, response: Response) {
                cancelLoadingDialog()
                val result = response.body()!!.string()
                runOnUiThread {
                    val jsonObject = JSONObject(result)
                    try {
                        if (jsonObject.optString("retCode").equals("-1")) {
                            ToastUtils.show("图片上传失败")
                        } else {
                            ToastUtils.show("图片上传成功")
                            var filePathBean:FilePathBean = gson.fromJson(result, object : TypeToken<FilePathBean?>() {}.type)
                            filepathList.add(filePathBean)
                        }
                    } catch (e: JSONException) {
                        e.printStackTrace()
                    }
                }
            }
        })
    }

    //提交数据
    private fun submit(state: String) {
        showLoadingDialog()
        /*if (TextUtils.isEmpty(etCarNumber!!.text.toString())) {
            ToastUtils.show("车架号不能为空")
            return
        }
        if (zhuangPeiWeiJianGuZhangXinxiBean == null) {
            ToastUtils.show("请选择故障编码")
            return
        }*/

        /*if (projectList.isEmpty()){
            ToastUtils.show("请选择评审项")
            return
        }*/

        /*val map = ArrayMap<String, String>()
        map["isStartProcess"] = state
        map["mobileCreateLoginName"] = GlobalVar.username
        map["mobileStartProcessLoginName"] = if (TextUtils.isEmpty(state)) "" else GlobalVar.username*/
        /**
         * 新增
         * */
        /*map["problemType"] = "review"
        map["reviewProjectType"] = if (leixingList[spxiangmuleixing!!.selectedItemPosition].value == null) "" else leixingList[spxiangmuleixing!!.selectedItemPosition].value
        map["reviewProject"] = if (projectnameList[sp_projectname!!.selectedItemPosition].reviewProjectNo == null) "" else projectnameList[sp_projectname!!.selectedItemPosition].reviewProjectNo
        map["carFrameNo"] = if (projectbianhaoList[sp_chanpinbianhao!!.selectedItemPosition].prototypeCarFrames == null) "" else projectbianhaoList[sp_chanpinbianhao!!.selectedItemPosition].prototypeCarFrames
        map["unqualifiedSort"] = if (buhegeList[spBuhege!!.selectedItemPosition].value == null) "" else buhegeList[spBuhege!!.selectedItemPosition].value
        map["isMax"] = (maxList[spshifoumax!!.selectedItemPosition].code).toString()
        map["happenNum"] = tv_error_number?.text.toString()
        map["responsibleDepartment"] = if (deptList[spDept!!.selectedItemPosition].dept == null) "" else deptList[spDept!!.selectedItemPosition].dept
        map["faultCode"] = zhuangPeiWeiJianGuZhangXinxiBean!!.malfunctionNo
        map["faultName"] = zhuangPeiWeiJianGuZhangXinxiBean!!.malfunctionName
        map["faultType"] = zhuangPeiWeiJianGuZhangXinxiBean!!.malfunctionType
        map["faultLevel"] = zhuangPeiWeiJianGuZhangXinxiBean!!.malfunctionLevel
        map["faultDes"] = etInfo!!.text.toString()
        map["imgStr"] = if (uploadFilePath != null) bitmapToBase64(getLoacalBitmap(uploadFilePath)) else ""*/
        var commitBean: CommitBean = CommitBean()
        commitBean.isStartProcess = state
        commitBean.mobileCreateLoginName = GlobalVar.username
        commitBean.mobileStartProcessLoginName = if (TextUtils.isEmpty(state)) "" else GlobalVar.username
        commitBean.problemType = "review"
        commitBean.reviewProjectType = if (leixingList[spxiangmuleixing!!.selectedItemPosition].value == null) "" else leixingList[spxiangmuleixing!!.selectedItemPosition].value
        commitBean.reviewProject = if (projectnameList[sp_projectname!!.selectedItemPosition].reviewProjectNo == null) "" else projectnameList[sp_projectname!!.selectedItemPosition].reviewProjectNo
        commitBean.carFrameNo = if (projectbianhaoList[sp_chanpinbianhao!!.selectedItemPosition].prototypeCarFrames == null) "" else projectbianhaoList[sp_chanpinbianhao!!.selectedItemPosition].prototypeCarFrames
        commitBean.unqualifiedSort = if (buhegeList[spBuhege!!.selectedItemPosition].value == null) "" else buhegeList[spBuhege!!.selectedItemPosition].value
        commitBean.isMax = (maxList[spshifoumax!!.selectedItemPosition].code).toString()
        commitBean.happenNum = tv_error_number?.text.toString()
        commitBean.responsibleDepartment = if (deptList[spDept!!.selectedItemPosition].dept == null) "" else deptList[spDept!!.selectedItemPosition].dept
        commitBean.faultCode = zhuangPeiWeiJianGuZhangXinxiBean!!.malfunctionNo
        commitBean.faultName = zhuangPeiWeiJianGuZhangXinxiBean!!.malfunctionName
        commitBean.faultType = zhuangPeiWeiJianGuZhangXinxiBean!!.malfunctionType
        commitBean.faultLevel = zhuangPeiWeiJianGuZhangXinxiBean!!.malfunctionLevel
        commitBean.problemDesc = etInfo!!.text.toString()
        commitBean.listFile = filepathList
        commitBean.loginName = GlobalVar.username

        //a/reviewprojectproblem/qmsImprovementReviewProjectProblem/api/save
        val param = gson.toJson(commitBean)
        Log.e("--->", param)
        val client = OkHttpClient()
        val requestBody = RequestBody.create(JSON, param)
        val request = Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/problem/qmsReviewAftesaleZeroProblem/api/save")
                .build()
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.d(TAG, "onFailure: 失败")
                cancelLoadingDialog()
            }

            @Throws(IOException::class)
            override fun onResponse(call: Call, response: Response) {
                cancelLoadingDialog()
                val result = response.body()!!.string()
                runOnUiThread {
                    LogUtils.printDebug("提交评审项目: $result")
                    val jsonData = JSONObject(result)
                    if (jsonData.optString("retCode") == "0") {
                        ToastUtils.show("提交成功")
                        photolist!!.clear()
                        filepathList.clear()
                        picadapter!!.list?.clear()
                        picadapter!!.notifyDataSetChanged()
                        zhuangPeiWeiJianGuZhangXinxiBean = null
                        tvErrorCode!!.text = ""
                        tvErrorName!!.text = ""
                        tvErrorLevel!!.text = ""
                        tvErrorType!!.text = ""
                        etInfo!!.text = null
                        tv_error_number!!.text = null
                        //Handler().postDelayed({ finish() }, 1000)
                    } else {
                        ToastUtils.show(jsonData.optString("retMessage"))
                    }
                }
            }
        })
    }
}