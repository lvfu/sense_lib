package com.zhuisu.fastdev.ui.outtask;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Handler;
import android.util.ArrayMap;
import android.util.Log;

import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.zhuisu.fastdev.BaseActivity;
import com.zhuisu.fastdev.ui.util.BroadCastConfig;
import com.zhuisu.fastdev.view.FastTitleLayout;
import com.zhuisu.qualityManagement.R;
import com.zhuisu.suppliermanagement.base.CaptureActivity;

import com.zhuisu.suppliermanagement.ui.UnCheckAdapter;
import com.zhuisu.suppliermanagement.ui.UnCheckListData;
import com.zhuisu.suppliermanagement.util.GlobalVar;
import com.zhuisu.suppliermanagement.util.StatusBarColorUtils;

import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class UnCheckTaskListActivity extends BaseActivity {

    private List<UnCheckListData> list;
    private UnCheckAdapter adapter;
    private EditText etCode;
    public static final String ACTION_STATE = "action_state";
    private boolean isLoadChecked = false;
    private boolean isLookSelf = true;

    BroadCastChange broadCast = new BroadCastChange();
    IntentFilter Brofilter = new IntentFilter(BroadCastConfig.BROADCAST_ACTION);

    class BroadCastChange extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent != null && intent.getAction() != null && intent.getAction().equals(BroadCastConfig.BROADCAST_ACTION)) {
                etCode.setText(intent.getExtras().getString(BroadCastConfig.BROADCAST_ACTION_TAG));
                etCode.setSelection(etCode.getText().toString().length());
                query();
            }
        }
    }


    @Override
    protected void initViews() {
        etCode = findViewById(R.id.et_car_number);

        findViewById(R.id.tv_scanf).setOnClickListener(arg0 -> {
            Intent intent = new Intent();
            intent.setClass(UnCheckTaskListActivity.this, CaptureActivity.class);
            startActivityForResult(intent, 1073);
        });

        TextView tv_search = findViewById(R.id.tv_search);
        tv_search.setOnClickListener(arg0 -> query());

        if (getIntent() != null) {
            isLoadChecked = getIntent().getBooleanExtra(ACTION_STATE, false);
            TextView textView = (TextView) findViewById(R.id.tv_title);
            if (isLoadChecked) {
                textView.setText("外检任务已检");
            } else {
                textView.setText("外检任务未检");
            }
        }

        StatusBarColorUtils.setStatusBar(this);
        ListView lv_list = findViewById(R.id.lv_list);
        list = new ArrayList<>();

        adapter = new UnCheckAdapter(list, this);
        lv_list.setAdapter(adapter);
        lv_list.setOnItemClickListener((arg0, arg1, arg2, arg3) -> {
            Intent intent = new Intent(UnCheckTaskListActivity.this, UnCheckTaskLineDetailActivity.class);
            intent.putExtra(UnCheckTaskLineDetailActivity.ACTION_DATA, list.get(arg2));
            intent.putExtra(UnCheckTaskLineDetailActivity.ACTION_STATE, isLoadChecked);
            startActivity(intent);
        });

        receiver = new DecodeWedgeIntentReceiver();
        IntentFilter filter = new IntentFilter();
        filter.addAction(ACTION_BROADCAST_RECEIVER);
        filter.addCategory(CATEGORY_BROADCAST_RECEIVER);
        context.registerReceiver(receiver, filter);

        TextView tv_user_name = findViewById(R.id.tv_user_name);
        tv_user_name.setText("\t" + GlobalVar.realname);

        FastTitleLayout fastTitleLayout = findViewById(R.id.ftl_uncheck_list);
        fastTitleLayout.setOnRightClickListener(view -> {
            isLookSelf = !isLookSelf;
            if (isLookSelf) {
                tv_search.setText("查询");
            } else {
                tv_search.setText("全部");
            }
            query();
        });
        filter.setPriority(Integer.MAX_VALUE);
        registerReceiver(broadCast, Brofilter);
    }

    @Override
    protected int getResId() {
        return R.layout.activity_un_check_task_list;
    }

    public static final String ACTION_BROADCAST_RECEIVER = "com.android.decodewedge.decode_action";
    public static final String CATEGORY_BROADCAST_RECEIVER = "com.android.decodewedge.decode_category";
    public static final String EXTRA_BARCODE_STRING = "com.android.decode.intentwedge.barcode_string";
    private BroadcastReceiver receiver = null;


    /**
     * 广播
     */
    public class DecodeWedgeIntentReceiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent wedgeIntent) {
            String action = wedgeIntent.getAction();
            if (action != null) {
                Log.i(this.getClass().getName(), "action = " + action);
                if (action.equals(ACTION_BROADCAST_RECEIVER)) {

                    String barcodestring = wedgeIntent.getStringExtra(EXTRA_BARCODE_STRING);
                    if (barcodestring != null) {
                        Log.i(this.getClass().getName(), barcodestring);
                        if (barcodestring.contains("\n")) {
                            // 扫描
                            String oldDeliveryNo = barcodestring.replaceAll("\n", "").replaceAll(" ", "");
                            etCode.setText(oldDeliveryNo);
                            etCode.setSelection(oldDeliveryNo.length());
                            query();
                        }
                    }
                }
            }

        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        new Handler().postDelayed(this::query, 300);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1073 && resultCode == Activity.RESULT_OK) {
            etCode.setText(data.getStringExtra("encoderesult"));
        }
    }


    private void query() {
        ArrayMap<String, Object> params = new ArrayMap<>();
        params.put("checkUser", isLookSelf ? GlobalVar.username : "");
        params.put("pageNo", 1);
        params.put("pageSize", 100);
        params.put("userName", GlobalVar.username);
        params.put("checkState", "0");
        params.put("queryCode", etCode.getText().toString());

        if (list != null) {
            list.clear();
            if (adapter != null) {
                adapter.notifyDataSetChanged();
            }
        }
        String param = gson.toJson(params);

        Log.e("参数", param);
        OkHttpClient client = new OkHttpClient();
        RequestBody requestBody = RequestBody.create(JSON, param);
        Request request = new Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/checktask/qmsPurchasecheckChecktask/api/getChecktasklist")
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                Log.d(TAG, "onFailure: 失败");
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                final String result = response.body().string();
                runOnUiThread(() -> {
                    try {
                        Log.e("---->", result);
                        JSONObject jsonObject2 = new JSONObject(result);
                        String issuccess = jsonObject2.getString("retCode");
                        String meesage = jsonObject2.getString("retMessage");
                        if ("0".equals(issuccess) && jsonObject2.optJSONObject("data") != null && !jsonObject2.optJSONObject("data").optString("list").isEmpty()) {
                            List<UnCheckListData> temp = new Gson().fromJson(jsonObject2.optJSONObject("data").optString("list"),
                                    new TypeToken<List<UnCheckListData>>() {
                                    }.getType());

                            list.addAll(temp);
                            if (list == null || list.isEmpty()) {
                                showEmptyMessage();
                            }
                            adapter.notifyDataSetChanged();
                        } else {
                            showEmptyMessage();
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                });
            }
        });
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (receiver != null) {
            unregisterReceiver(receiver);
        }

        if (broadCast != null) {
            unregisterReceiver(broadCast);
        }

    }
}
