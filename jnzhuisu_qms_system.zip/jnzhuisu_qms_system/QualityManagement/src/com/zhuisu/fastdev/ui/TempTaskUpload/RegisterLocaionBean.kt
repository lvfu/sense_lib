package com.zhuisu.fastdev.ui.TempTaskUpload

/**
 * @author cxh
 * @description
 * @date 2021/2/4.
 */
data class RegisterLocaionBean(var warehousecode : String? ,var warehousename: String?,var ssdw : String?,var codename : String?,var datasource : String?){
    override fun toString(): String {
        return warehousecode!! + warehousename!!
    }
}
