package com.zhuisu.fastdev.ui.problem

import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.content.*
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Parcelable
import android.provider.MediaStore
import android.support.v4.content.FileProvider
import android.text.TextUtils
import android.util.ArrayMap
import android.util.Log
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.*
import com.bumptech.glide.Glide
import com.google.gson.reflect.TypeToken
import com.zhuisu.fastdev.BaseActivity
import com.zhuisu.fastdev.beans.xiaxian.XiaXianWeiJianXiangQingBuMenList
import com.zhuisu.fastdev.beans.zhuangpei.ErrorCodeListBean
import com.zhuisu.fastdev.beans.zhuangpei.ZhuangPeiWeiJianXiangQingWuLiaoList
import com.zhuisu.fastdev.ui.util.BroadCastConfig
import com.zhuisu.fastdev.ui.zhuangpei.CarSelectCodeActivity
import com.zhuisu.fastdev.ui.zhuangpei.SelectWuLiaoActivity
import com.zhuisu.qualityManagement.R
import com.zhuisu.suppliermanagement.base.CaptureActivity
import com.zhuisu.suppliermanagement.util.FileUtil
import com.zhuisu.suppliermanagement.util.GlobalVar
import com.zhuisu.suppliermanagement.util.ToastUtils
import com.zhuisu.suppliermanagement.util.Util
import okhttp3.*
import org.json.JSONException
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.*
import kotlin.collections.ArrayList
import kotlin.system.exitProcess

/**
 * @author cxh
 * @description
 * @date 2020/10/23.
 */
class CarFrameProblemActivity : BaseActivity() {
    private var ivShow: ImageView? = null
    private var etCarFrame: EditText? = null
    private var etProNumber: TextView? = null //编号
    private var et_product_name: TextView? = null
    private var tvCarNumbers: TextView? = null
    private var etTitle: EditText? = null
    val broadCast: BroadCastChange = BroadCastChange()
    val filter: IntentFilter = IntentFilter(BroadCastConfig.BROADCAST_ACTION)
    private var zhuangPeiWeiJianXiangQingWuLiaoList: ZhuangPeiWeiJianXiangQingWuLiaoList? = null
    private var change: Switch? = null
    private var strArr: List<String>? = null
    private var etInfo: EditText? = null
    private var spDept: Spinner? = null
    private var spLocation : Spinner? = null
    private var spPeople : Spinner? = null




    @SuppressLint("SetTextI18n", "ClickableViewAccessibility")
    override fun initViews() {
        tvCarNumbers = findViewById(R.id.tv_detail3)
        etTitle = findViewById(R.id.et_input_title) //标题
        spDept = findViewById(R.id.sp_dept)
        spLocation = findViewById(R.id.sp_dept_location)
        spPeople = findViewById(R.id.sp_dept_location_people)

//        etTitle!!.setOnTouchListener { v, event ->
//            val touchX = v.right - event.x.toInt()
//            Log.e("--->", touchX.toString())
//            if (touchX < 260){
//
//               true
//            }else{
//                false
//            }
//
//        }

        findViewById<ImageView>(R.id.iv_select).setOnClickListener {
            val intent = Intent(context, CarSelectCodeActivity::class.java)
            startActivityForResult(intent, 0x11)
        }

        findViewById<View>(R.id.iv_select_image).setOnClickListener { selectImage() }
        etCarFrame = findViewById(R.id.et_car_frame_number)
        etInfo = findViewById(R.id.et_info) //描述
        ivShow = findViewById(R.id.showimage)
        val tvName = findViewById<TextView>(R.id.tv_user_name)
        tvName.text = "\t" + GlobalVar.realname
        findViewById<TextView>(R.id.tv_scanf).setOnClickListener {
            val intent = Intent(context, CaptureActivity::class.java)
            startActivityForResult(intent, 0x66)
        }

        etProNumber = findViewById(R.id.et_product_number) //产品编号
        et_product_name = findViewById(R.id.et_product_name) //产品名称
        etProNumber!!.setOnClickListener {
            val intent = Intent(context, SelectWuLiaoActivity::class.java)
            intent.putExtra(SelectWuLiaoActivity.ACTION_PARAMS, true)
            startActivityForResult(intent, 0x13)
        }

        if (intent != null && intent.hasCategory(ACTION_CAR_NUMBER)) {
            val carFrameNumber = intent.getStringExtra(ACTION_CAR_NUMBER)
            etCarFrame!!.setText(carFrameNumber)
        }

        filter.priority = Int.MAX_VALUE
        registerReceiver(broadCast, filter)

        change = findViewById(R.id.switch1)
        change!!.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                queryCarNumber()
            }
        }

        findViewById<View>(R.id.btn_submit).setOnClickListener {
            if (change!!.isChecked) {
                if (checkCarNumberStr!!.isNotBlank()) {
                    strArr = checkCarNumberStr!!.split(",")
                    for (i in strArr!!.indices) {
                        Log.e("---> $i", strArr!![i])
                        submit(strArr!![i], i)
                    }
                } else {
                    ToastUtils.show("根据订单号提交需要选择车架号")
                }
            } else {
                submit(etCarFrame!!.text.toString(), -1)
            }

        }

        queryDept()
    }

    /**
     * 查询部门
     */
    private var deptList: ArrayList<XiaXianWeiJianXiangQingBuMenList> = ArrayList()
    private fun queryDept() {
        val map = ArrayMap<String, String>()
        val client = OkHttpClient()
        val requestBody = RequestBody.create(JSON, "")
        val request = Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/sys/office/api/getOfficeList")
                .build()
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.d(TAG, "onFailure: 失败")
            }

            @Throws(IOException::class)
            override fun onResponse(call: Call, response: Response) {
                val result = response.body()!!.string()
                runOnUiThread {
                    Log.d(TAG, "onResponse: 部门$result")
                    try {
                        val jsonObject = JSONObject(result)
                        deptList = gson.fromJson(jsonObject.optString("data"), object : TypeToken<List<XiaXianWeiJianXiangQingBuMenList?>?>() {}.type)
                        val arrayAdapter = ArrayAdapter(context, R.layout.simple_textview1, deptList)
                        spDept!!.adapter = arrayAdapter
                        spDept!!.onItemSelectedListener = object : AdapterView.OnItemSelectedListener{
                            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                                if (null != deptList[position].dept){
                                    queryDeptLocation(deptList[position].dept)
                                }

                                deptLocationList.clear()
                                peopleList.clear()
                                deptLocationAdapter?.notifyDataSetChanged()
                                peopleAdapter?.notifyDataSetChanged()

                            }

                            override fun onNothingSelected(parent: AdapterView<*>?) {

                            }

                        }
                    } catch (e: JSONException) {
                        e.printStackTrace()
                    }
                }
            }
        })
    }

    /**
     * 查询工位
     */
    private var deptLocationAdapter : ArrayAdapter<DeptLocationListBean>? = null
    private var deptLocationList: ArrayList<DeptLocationListBean> = ArrayList()
    private fun queryDeptLocation(code : String) {
        if (TextUtils.isEmpty(code)) return
        val map = ArrayMap<String, String>()
        map["dept"] = code

        val params = gson.toJson(map)
        Log.e("-->",params)
        val client = OkHttpClient()
        val requestBody = RequestBody.create(JSON, params)
        val request = Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/prostation/qmsFacorg/api/qryResponsibilityStation")
                .build()
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.d(TAG, "onFailure: 失败")
            }

            @Throws(IOException::class)
            override fun onResponse(call: Call, response: Response) {
                val result = response.body()!!.string()
                runOnUiThread {
                    Log.d(TAG, "onResponse: 工位$result")
                    try {
                        val jsonObject = JSONObject(result)
                        if (TextUtils.isEmpty(jsonObject.optString("data"))){
                            return@runOnUiThread
                        }
                        deptLocationList = gson.fromJson(jsonObject.optString("data"), object : TypeToken<List<DeptLocationListBean?>?>() {}.type)
                        deptLocationAdapter  = ArrayAdapter(context, R.layout.simple_textview1, deptLocationList)
                        spLocation!!.adapter = deptLocationAdapter
                        spLocation!!.onItemSelectedListener = object : AdapterView.OnItemSelectedListener{
                            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                                queryDeptLocationPeople(deptLocationList[position].id)
                            }

                            override fun onNothingSelected(parent: AdapterView<*>?) {

                            }

                        }

                    } catch (e: JSONException) {
                        e.printStackTrace()
                    }
                }
            }
        })
    }


    /**
     * 查询责任人
     */
    private var peopleAdapter : ArrayAdapter<DeptLocationPeopleListBean>? = null
    private var peopleList: ArrayList<DeptLocationPeopleListBean> = ArrayList()
    private fun queryDeptLocationPeople(code : String) {
        if (TextUtils.isEmpty(code)) return
        val map = ArrayMap<String, String>()
        map["station"] = code

        val params = gson.toJson(map)
        Log.e("-->",params)
        val client = OkHttpClient()
        val requestBody = RequestBody.create(JSON, params)
        val request = Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/carworkingschedule/qmsCarWorkingSchedule/api/qryResponsibilityUserByStation")
                .build()
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.d(TAG, "onFailure: 失败")
            }

            @Throws(IOException::class)
            override fun onResponse(call: Call, response: Response) {
                val result = response.body()!!.string()
                runOnUiThread {
                    Log.d(TAG, "onResponse: 责任人$result")
                    try {
                        val jsonObject = JSONObject(result)
                        if (TextUtils.isEmpty(jsonObject.optString("data"))){
                            return@runOnUiThread
                        }
                        peopleList = gson.fromJson(jsonObject.optString("data"), object : TypeToken<List<DeptLocationPeopleListBean?>?>() {}.type)
                        peopleAdapter   = ArrayAdapter(context, R.layout.simple_textview1, peopleList)
                        spPeople!!.adapter = peopleAdapter

                    } catch (e: JSONException) {
                        e.printStackTrace()
                    }
                }
            }
        })
    }

    /**
     * 根据订单号查询车架号列表
     */
    private fun queryCarNumber() {
        if (etCarFrame!!.text.toString().isBlank()) {
            return
        }
        lackCommitCarListBeans.clear()
        showLoadingDialog()
        val map = ArrayMap<String, String>()
        map["orderNo"] = etCarFrame!!.text.toString()
        val param = gson.toJson(map)
        Log.e("参数--->", param)
        val client = OkHttpClient()
        val requestBody = RequestBody.create(JSON, param)
        val request = Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/missingpartsmgr/qmsManufactureMissingparts/api/getCarFrameNosByOrderNo")
                .build()
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                cancelLoadingDialog()
                Log.d(TAG, "onFailure: 失败")
            }

            @Throws(IOException::class)
            override fun onResponse(call: Call, response: Response) {
                val result = response.body()!!.string()
                runOnUiThread {
                    cancelLoadingDialog()
                    try {
                        Log.e("--->", result)
                        val jsonObject = JSONObject(result)
                        if (jsonObject.optString("retCode") == "0" && !TextUtils.isEmpty(jsonObject.optString("data"))) {
                            lackCommitCarListBeans.addAll(gson.fromJson(jsonObject.optString("data"), object : TypeToken<List<String?>?>() {}.type))
                            showMutilDialog()
                        } else {
                            ToastUtils.show(jsonObject.optString("retMessage"))
                        }

                    } catch (jsonException: JSONException) {
                        jsonException.printStackTrace()
                    }
                }
            }
        })
    }


    /**
     * 展示车架号
     */
    var lackCommitCarListBeans: ArrayList<String> = ArrayList()
    var checkCarNumber: java.lang.StringBuilder? = null
    var checkCarNumberStr: String? = null
    private fun showMutilDialog() {
        if (lackCommitCarListBeans.isEmpty()) {
            return
        }
        val builder = AlertDialog.Builder(this, R.style.MyAlertDialogStyle)
        builder.setTitle("请选择车架号")
        val items = arrayOfNulls<String>(lackCommitCarListBeans!!.size)
        val checkedItems = BooleanArray(lackCommitCarListBeans!!.size)
        for (i in lackCommitCarListBeans.indices) {
            items[i] = lackCommitCarListBeans[i]
            checkedItems[i] = true
        }
        builder.setMultiChoiceItems(items, checkedItems) { dialog: DialogInterface?, which: Int, isChecked: Boolean -> }
        builder.setPositiveButton("确定") { dialog: DialogInterface, which: Int ->
            checkCarNumber = StringBuilder()
            for (i in checkedItems.indices) {
                if (checkedItems[i]) {
                    for (j in 0 until lackCommitCarListBeans.size) {
                        if (lackCommitCarListBeans[j] == items[i]) {
                            val fruit = items[i]
                            checkCarNumber!!.append(fruit).append(",")
                        }
                    }
                }
            }
            if (checkCarNumber!!.toString().isNotEmpty() && checkCarNumber!!.toString().length > 1) {
                checkCarNumberStr = checkCarNumber.toString().substring(0, checkCarNumber!!.length - 1)
            }

            Log.e("checkCar", checkCarNumberStr)
            tvCarNumbers!!.text = checkCarNumberStr
            dialog.dismiss()
        }
        builder.show()
    }

    inner class BroadCastChange : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent != null && intent.action != null && intent.action == BroadCastConfig.BROADCAST_ACTION) {
                etCarFrame!!.setText(intent.extras!!.getString(BroadCastConfig.BROADCAST_ACTION_TAG))
                etCarFrame!!.setSelection(etCarFrame!!.text.toString().length)
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        unregisterReceiver(broadCast)
    }

    /**
     * 提交数据
     */
    @SuppressLint("SimpleDateFormat")
    private fun submit(carFrameNo: String, position: Int) {

        if (etTitle!!.text.toString().isBlank()) {
            ToastUtils.show("问题标题不能为空")
            return
        }


        if (etInfo!!.text.toString().isBlank()) {
            ToastUtils.show("问题描述不能为空")
            return
        }

        val etNumber = findViewById<TextView>(R.id.et_number) //数量
        val map = ArrayMap<String, String>()

        map["carFrameNo"] = carFrameNo
        map["peoblemTitle"] = etTitle!!.text.toString() //问题标题
        map["isOnlyForm"] = "1"
        map["problemSource"] = "car_frame_station" //问题来源
        map["occurTimeStr"] = SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(Date(System.currentTimeMillis()))
        map["malfunctionNumber"] = etNumber.text.toString() //故障数量
        map["problemDesc"] = etInfo!!.text.toString() //问题描述
        if (uploadFilePath != null && uploadFilePath!!.isNotEmpty()) {
            map["imgStr"] = bitmapToBase64(getLoacalBitmap(uploadFilePath)) //图片
        } else {
            map["imgStr"] = "" //图片
        }

        if (zhuangPeiWeiJianXiangQingWuLiaoList == null) {
            map["materiel"] = "" //物料号
        } else {
            map["materiel"] = zhuangPeiWeiJianXiangQingWuLiaoList!!.materielId //物料号
        }
        if (deptList.isNotEmpty()){
            map["depts"] = deptList[spDept!!.selectedItemPosition].code //责任部门
        }else{
            map["depts"] = ""
        }

        map["operType"] = "app" //固定 app
        map["currentUserLoginName"] = GlobalVar.username //登录人

        if (deptLocationList.isNotEmpty()){
            map["responsebilityStationName"] = deptLocationList[spLocation!!.selectedItemPosition].nodetxt //责任工位
            map["responsebilityStationId"] = deptLocationList[spLocation!!.selectedItemPosition].id //责任id
        }

        if (peopleList.isNotEmpty()){
            map["responsibilityName"] = peopleList[spPeople!!.selectedItemPosition].name //责任人名称
            map["responsibilityId"] = peopleList[spPeople!!.selectedItemPosition].longinName //责任人id
        }

        val param = gson.toJson(map)
        Log.e("参数", param)
        showCommitDialog()
        val client = OkHttpClient()
        val requestBody = RequestBody.create(JSON, param)
        val request = Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/checkfaildflow/qmsManufactureCjProblemflow/api/saveAsyn")
                .build()
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.d(TAG, "onFailure: 失败")
                runOnUiThread {
                    showNetErrorMessage()
                    cancelDialog()
                }
            }

            @Throws(IOException::class)
            override fun onResponse(call: Call, response: Response) {
                val result = response.body()!!.string()
                runOnUiThread {
                    Log.d(TAG, "onResponse: 提交数据$result")
                    try {
                        cancelDialog()
                        val jsonObject = JSONObject(result)
                        if (jsonObject.optString("retCode") == "0") {
                            if (position == -1) {
                                ToastUtils.show("提交成功")
                                Handler().postDelayed({ finish() }, 1500)
                            } else {
                                Log.e("size ==${strArr!!.size - 1}", "position= $position")
                                if ((strArr!!.size - 1) == position) {
                                    ToastUtils.show("提交成功")
                                    Handler().postDelayed({ finish() }, 1500)
                                }
                            }
                        } else {
                            ToastUtils.show(jsonObject.optString("retMessage"))
                        }
                    } catch (e: JSONException) {
                        e.printStackTrace()
                        ToastUtils.show("数据解析异常")
                    }
                }
            }
        })
    }

    /**
     * 选择照片
     */
    var uploadFilePath: String? = null
    private val CODE = 200 // 这里的IMAGE_CODE是自己任意定义的
    private fun selectImage() {
        var dialog: AlertDialog? = null
        var imageUri: Uri?
        dialog = Util.getDialog(context, "选择图像", 0, { _, _, position, _ ->
            if (dialog!!.isShowing) {
                dialog!!.dismiss()
            }
            val f: File?
            when (position) {
                0 -> {
                    val capimgIntent = Intent()
                    val fileName: String = SimpleDateFormat("yyyyMMddHHmmss", Locale.CHINA).format(Date()) + ".jpg"
                    FileUtil.checkDir(fileDir + "_/")
                    f = File(fileDir + "_", fileName)
                    uploadFilePath = fileDir + "_/" + fileName
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                        imageUri = FileProvider.getUriForFile(this, "com.jnqms.fileprovider", f)
                        capimgIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    } else {
                        imageUri = Uri.fromFile(f)
                    }
                    capimgIntent.putExtra(MediaStore.EXTRA_OUTPUT, imageUri)
                    capimgIntent.action = MediaStore.ACTION_IMAGE_CAPTURE
                    capimgIntent.addCategory(Intent.CATEGORY_DEFAULT)

                    startActivityForResult(capimgIntent, 1)
                }
                1 -> {
                    val intent = Intent(Intent.ACTION_GET_CONTENT)
                    intent.type = "image/*"
                    intent.addCategory(Intent.CATEGORY_OPENABLE)
                    try {
                        startActivityForResult(Intent.createChooser(intent, "Select a File to Upload"), CODE)
                    } catch (ex: ActivityNotFoundException) {
                        Toast.makeText(context, "Please install a File Manager.", Toast.LENGTH_SHORT).show()
                    }
                }
                else -> {
                }
            }
        }, arrayOf("拍照", "文件"), arrayOf(R.drawable.i_camera, R.drawable.i_image))
        dialog.show()
    }

    public override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (resultCode == RESULT_OK && requestCode == CODE) {
            // 选择文件
            if (data == null) return
            val path: String = FileUtil.getImageAbsolutePath(context as Activity, data) ?: return
            uploadFilePath = path
            Glide.with(context).load(path).into(ivShow!!)
        } else if (requestCode == 1 && resultCode == RESULT_OK) {
            Glide.with(context).load(uploadFilePath).into(ivShow!!)
        } else if (requestCode == 0x66 && resultCode == RESULT_OK) {
            etCarFrame!!.setText(data!!.getStringExtra("encoderesult").toString())
            val imm: InputMethodManager = etTitle?.context?.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.toggleSoftInput(0, InputMethodManager.SHOW_FORCED)
            etTitle?.requestFocus()
            if (change!!.isChecked) {
                queryCarNumber()
            }
        } else if (resultCode == 0x19) {
            if (data!!.getParcelableExtra<Parcelable?>("data") != null) {
                zhuangPeiWeiJianXiangQingWuLiaoList = data.getParcelableExtra("data")
                etProNumber!!.text = zhuangPeiWeiJianXiangQingWuLiaoList!!.materielId
                et_product_name!!.text = zhuangPeiWeiJianXiangQingWuLiaoList!!.materielName
            }
        } else if (resultCode == 0x18) {
            if (data!!.getParcelableExtra<Parcelable?>("data") != null) {
                code = data.getParcelableExtra("data")
                Log.e("获取数据", code!!.projectTypeName!!)
                etTitle!!.setText(code!!.faultDesc!!)
//                etInfo!!.setText(code!!.faultDesc!!)
            }
        }
    }

    var code: ErrorCodeListBean? = null
    override fun getResId(): Int {
        return R.layout.activity_car_frame_problem
    }

    companion object {
        var fileDir = Environment.getExternalStorageDirectory().absolutePath + "/qualitymanagement/files/media/"
        const val ACTION_CAR_NUMBER: String = "action_car_frame_number"
    }
}