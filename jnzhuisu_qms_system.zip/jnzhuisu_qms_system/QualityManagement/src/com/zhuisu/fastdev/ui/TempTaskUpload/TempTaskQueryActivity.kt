package com.zhuisu.fastdev.ui.TempTaskUpload

import android.content.Intent
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.util.ArrayMap
import android.util.Log
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.zhuisu.fastdev.BaseActivity
import com.zhuisu.fastdev.adapter.temptask.TempTaskQueryAdapter
import com.zhuisu.fastdev.adapter.temptask.TempTaskQueryListBean
import com.zhuisu.fastdev.ui.util.LogUtils
import com.zhuisu.qualityManagement.R
import com.zhuisu.suppliermanagement.util.GlobalVar
import com.zhuisu.suppliermanagement.util.ToastUtils
import okhttp3.*
import org.json.JSONObject
import java.io.IOException

/**
 * @author cxh
 * @description
 * @date 2021/2/20.
 */
class TempTaskQueryActivity : BaseActivity(), TempTaskQueryAdapter.OnItemDetailClickListener {

    var etNumber : EditText? = null
    var etMetaName : EditText? = null
    var tvStartTime : TextView? = null
    var tvEndTime : TextView? = null
    var etTaskNumber : EditText? = null
    var etCreatePeople : EditText? = null
    var etBanzu : EditText? = null
    var spState : Spinner? = null
    private var typeList : ArrayList<TypeListBean> = ArrayList()
    private var adapter : TempTaskQueryAdapter? = null
    private val listBeans: ArrayList<TempTaskQueryListBean> = ArrayList()

    override fun initViews() {
        val rvQuery : RecyclerView = findViewById(R.id.rv_query)
        val manger = LinearLayoutManager(this)
        rvQuery.layoutManager = manger
        adapter = TempTaskQueryAdapter(this,listBeans)
        adapter!!.onItemDetailClickListener = this
        rvQuery.adapter = adapter
        etBanzu = findViewById(R.id.et_banzu)
        etBanzu!!.setText(GlobalVar.officeName)

        etNumber = findViewById(R.id.tv_cjh)
        etMetaName = findViewById(R.id.et_wlmc)
        tvStartTime = findViewById(R.id.tv_date_start)
        tvEndTime = findViewById(R.id.tv_end_time)
        etTaskNumber = findViewById(R.id.et_task_number)
        etCreatePeople = findViewById(R.id.et_create_people)
        spState = findViewById(R.id.sp_state)

        tvStartTime!!.setOnClickListener(DateClickListener(tvStartTime))
        tvEndTime!!.setOnClickListener(DateClickListener(tvEndTime))
        queryState()
        findViewById<TextView>(R.id.tv_scanf).setOnClickListener {
            query()
        }
    }

    override fun getResId(): Int {
        return R.layout.activity_temp_task_query
    }


    /**
     * 查询
    */
    private fun query(){
        showLoadingDialog()
        val map = ArrayMap<String, String>()
        listBeans.clear()
        if (adapter != null){
            adapter!!.notifyDataSetChanged()
        }
        map["materialcode"] = etNumber!!.text.toString()
        map["materialname"] = etMetaName!!.text.toString()
        map["createDateStart"] = tvStartTime!!.text.toString()
        map["createDateEnd"] = tvEndTime!!.text.toString()
        map["plancode"] = etTaskNumber!!.text.toString()
        map["createbyName"] = etCreatePeople!!.text.toString()
        map["status"] = if (typeList == null) "" else typeList[spState!!.selectedItemPosition].value
        map["officecode"] = etBanzu!!.text.toString()

        val param = gson.toJson(map)
        Log.e("查询列表参数:-->", param)
        val client = OkHttpClient()
        val requestBody = RequestBody.create(JSON, param)
        val request = Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/tempplan/qmsMaterialTempplan/api/queryTempplan")
                .build()
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.d(TAG, "onFailure: 失败")
                runOnUiThread {
                    cancelLoadingDialog()
                }
            }

            @Throws(IOException::class)
            override fun onResponse(call: Call, response: Response) {
                val result = response.body()!!.string()
                runOnUiThread {
                    LogUtils.printDebug("查询列表: $result")
                    cancelLoadingDialog()
                    val jsonData = JSONObject(result)
                    if (jsonData.optString("retCode") == "0" && jsonData.optString("data") != null && jsonData.optString("data").isNotEmpty()) {
                        val listType = object : TypeToken<java.util.ArrayList<TempTaskQueryListBean>>() {}.type
                        val temp: ArrayList<TempTaskQueryListBean> = Gson().fromJson(jsonData.optString("data"), listType)
                        listBeans.addAll(temp)
                        adapter!!.notifyDataSetChanged()
                    }else{
                        ToastUtils.show("暂无数据")
                    }
                }
            }
        })
    }
    private fun queryState(){
        val map = ArrayMap<String, String>()
        map["type"] = "qms_tempplan_status"
        val param = gson.toJson(map)
        val client = OkHttpClient()
        val requestBody = RequestBody.create(JSON, param)
        val request = Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/common/util/api/getDict")
                .build()
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.d(TAG, "onFailure: 失败")
            }

            @Throws(IOException::class)
            override fun onResponse(call: Call, response: Response) {
                val result = response.body()!!.string()
                runOnUiThread {
                    LogUtils.printDebug("查询状态: $result")
                    val jsonData = JSONObject(result)
                    if (jsonData.optString("retCode") == "0") {
                        val listType = object : TypeToken<java.util.ArrayList<TypeListBean>>() {}.type
                        val temp: ArrayList<TypeListBean> = Gson().fromJson(jsonData.optString("data"), listType)
                        val te = TypeListBean()
                        te.isChecked = false
                        te.label = "全部"
                        te.id = ""
                        te.parentId = ""
                        te.value =""
                        typeList.addAll(temp)
                        typeList.add(0,te)
                        val stateAdapter = ArrayAdapter(context!!, R.layout.simple_textview1, typeList)
                        spState!!.adapter = stateAdapter
                    }
                }
            }
        })
    }


    override fun onDetailClickListener(adapterPosition: Int) {
        val intent  = Intent(context,TempQueryDetailActivity::class.java)
        intent.putExtra("id",listBeans[adapterPosition].id)
        startActivity(intent)
    }
}