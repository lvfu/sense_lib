package com.zhuisu.fastdev.ui.shengchanqingkuanggenzong

import android.app.Dialog
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Bundle
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.text.TextUtils
import android.util.ArrayMap
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.zhuisu.fastdev.BaseActivity
import com.zhuisu.fastdev.dialog.BasePopupWindowDialog
import com.zhuisu.fastdev.ui.util.BroadCastConfig
import com.zhuisu.qualityManagement.R
import com.zhuisu.suppliermanagement.base.CaptureActivity
import com.zhuisu.suppliermanagement.util.GlobalVar
import com.zhuisu.suppliermanagement.util.ToastUtils
import com.zhuisu.suppliermanagement.util.Util
import okhttp3.*
import org.json.JSONException
import org.json.JSONObject
import java.io.IOException

class shengchanqingkuanggenzong : BaseActivity(), shengchanAdapter.FirstSuccess {
    var etCarNumber: EditText? = null
    var recyclerView: RecyclerView? = null
    var list: ArrayList<ShengchanList>? = null
    private var adapter: shengchanAdapter? = null
    private var loadingdialog: Dialog? = null;

    private val broadCast: BroadCastChange = BroadCastChange()
    val filter: IntentFilter = IntentFilter(BroadCastConfig.BROADCAST_ACTION)

    inner class BroadCastChange : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent != null && intent.action != null && intent.action == BroadCastConfig.BROADCAST_ACTION) {
                etCarNumber!!.setText(intent.extras!!.getString(BroadCastConfig.BROADCAST_ACTION_TAG))
                etCarNumber!!.setSelection(etCarNumber!!.text.toString().length)
                query()
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        unregisterReceiver(broadCast)
    }

    override fun initViews() {

        val tvUserName: TextView = findViewById(R.id.tv_user_name)
        recyclerView = findViewById(R.id.recyclerview)
        list = ArrayList();
        etCarNumber = findViewById(R.id.tv_cjh)
        tvUserName.text = "\t" + GlobalVar.realname
        val manager = LinearLayoutManager(context)
        manager.orientation = LinearLayoutManager.VERTICAL
        recyclerView!!.layoutManager = manager
        adapter = shengchanAdapter(list!!, context!!)
        recyclerView!!.adapter = adapter
        adapter?.firstSuccess = this
        loadingdialog = Util.createLoadingDialog(this, "正在查询...")


        findViewById<TextView>(R.id.tv_scanf).setOnClickListener {
            val intent = Intent(context, CaptureActivity::class.java)
            startActivityForResult(intent, 1073)
        }

        findViewById<Button>(R.id.btn_query).setOnClickListener {
            query()
        }


        filter.priority = Int.MAX_VALUE
        registerReceiver(broadCast, filter)
    }

    fun query() {
        loadingdialog?.show();
        list!!.clear()
        adapter!!.notifyDataSetChanged()
        val map = ArrayMap<String, String>()
        map["carFarmeNo"] = etCarNumber!!.text.toString()
        map["pageNo"] = "1"
        map["pageSize"] = "100"

        val param = gson.toJson(map)
        Log.e("参数", param)
        val client = OkHttpClient()
        val requestBody = RequestBody.create(JSON, param)
        val request = Request.Builder()
            .post(requestBody)
            .url(GlobalVar.url + "a/offlinedebuggingstatus/qmsOfflineStatus/api/OffLineStatusHistoryList")
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread {
                    Log.d(TAG, "onFailure: 失败")
                    loadingdialog?.dismiss()
                }
            }

            override fun onResponse(call: Call, response: Response) {
                loadingdialog?.dismiss()
                val result = response.body()!!.string()
                runOnUiThread {
                    try {
                        Log.e("--->列表", result)
                        val jsonObject = JSONObject(result)
                        if (TextUtils.equals(jsonObject.optString("retCode"), "0")) {
                            val listType = object : TypeToken<ArrayList<ShengchanList>>() {}.type
                            //jsonObject.optJSONObject("data")
                            val temp: ArrayList<ShengchanList> =
                                Gson().fromJson(jsonObject.opt("data").toString(), listType)
                            list!!.addAll(temp)
                            adapter!!.notifyDataSetChanged()
                            if (list != null && list!!.isEmpty()) {
                                showEmptyMessage()
                            }
                        } else {
                            ToastUtils.show(jsonObject.optString("msg"))
                        }

                    } catch (jsonException: JSONException) {
                        jsonException.printStackTrace()
                    }
                }
            }
        })
    }


    override fun getResId(): Int {
        return R.layout.activity_shengchanqingkuang
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (data != null) {
            val str = data!!.getStringExtra("encoderesult").toString()
            etCarNumber!!.setText(str)
            query()

        }
        super.onActivityResult(requestCode, resultCode, data)
    }

    override fun firstSuccess(position: Int) {

        val dialog = BasePopupWindowDialog()
        val arguments = Bundle()
        arguments.putString(BasePopupWindowDialog.ACTION_VALUE_TITLE, "提示")
        arguments.putString(BasePopupWindowDialog.ACTION_VALUE_MESSAGE, "是否初验完成?")
        dialog.arguments = arguments

        dialog.setOnConfirmClickListener {
            dialog.dismiss()
        }
        dialog.show(supportFragmentManager, "")

    }
}