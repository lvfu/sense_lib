package com.zhuisu.fastdev.ui.worktime

import android.content.Intent
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.text.TextUtils
import android.util.ArrayMap
import android.util.Log
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.TextView
import com.google.gson.reflect.TypeToken
import com.zhuisu.fastdev.BaseActivity
import com.zhuisu.fastdev.beans.xunjian.XunJianWeiJianXiangQingBuMenList
import com.zhuisu.fastdev.ui.zhiliangmen.DeptUserBean
import com.zhuisu.qualityManagement.R
import com.zhuisu.suppliermanagement.base.CaptureActivity
import com.zhuisu.suppliermanagement.util.GlobalVar
import com.zhuisu.suppliermanagement.util.ToastUtils
import okhttp3.*
import org.json.JSONException
import org.json.JSONObject
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit
import kotlin.collections.ArrayList

/**
 * @author cxh
 * @description
 * @date 2021/3/12.
 */
class WorkTimeHistoryActivity : BaseActivity() {

    private var recyclerView : RecyclerView? = null
    private var tvCarNumber: EditText? = null
    private var etLineNumber: EditText? = null //条码
    private var etSup: EditText? = null
    private var adapter : WorkTimeAdapter? = null
    private var etUser : EditText? = null
    private var tvStartTime : TextView? = null
    private var endTime : TextView? = null

    override fun initViews() {
        tvCarNumber = findViewById(R.id.tv_cjh)
        etLineNumber = findViewById(R.id.et_wltm)
        etSup = findViewById(R.id.et_suppude)
        etUser = findViewById(R.id.et_createuser)
        tvStartTime = findViewById(R.id.tv_starttime)
        endTime = findViewById(R.id.tv_endtime)
        etUser!!.setText(GlobalVar.realname)
        tvStartTime!!.setText(SimpleDateFormat("yyyy-MM-dd", Locale.CHINA).format(Date(System.currentTimeMillis())))
        endTime!!.setText(SimpleDateFormat("yyyy-MM-dd", Locale.CHINA).format(Date(System.currentTimeMillis())))
        tvStartTime!!.setOnClickListener(DateClickListener(tvStartTime))
        endTime!!.setOnClickListener(DateClickListener(endTime))

        recyclerView = findViewById(R.id.recycler)
        val manager : LinearLayoutManager = LinearLayoutManager(this)
        manager.orientation = LinearLayoutManager.VERTICAL
        recyclerView!!.layoutManager = manager
        adapter = WorkTimeAdapter(list,context)
        recyclerView!!.adapter = adapter
        adapter!!.onItemCLickListener  = object : WorkTimeAdapter.OnItemCLickListener{
            override fun onItemClickListener(position: Int) {
                val intent = Intent(context,WorkTimeDetailActivity::class.java)
                intent.putExtra("id",list[position].id)
                startActivity(intent)
            }

        }

        findViewById<View>(R.id.btn_query).setOnClickListener {
            query()
        }

        findViewById<View>(R.id.tv_scanf).setOnClickListener {
            val intent = Intent()
            intent.setClass(context, CaptureActivity::class.java)
            startActivityForResult(intent, 1073)
        }

        findViewById<View>(R.id.tv_scanf_wl).setOnClickListener {
            val intent = Intent()
            intent.setClass(context, CaptureActivity::class.java)
            startActivityForResult(intent, 1074)
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1073 && resultCode == RESULT_OK) {
            tvCarNumber?.setText(data!!.getStringExtra("encoderesult"))
        }
        if (requestCode == 1074 && resultCode == RESULT_OK) {
            etLineNumber?.setText(data!!.getStringExtra("encoderesult"))
        }
    }

    override fun onResume() {
        super.onResume()
        query()
    }


    /**
     * 查询部门
     */
    private var list : ArrayList<WorkTimeListBean> = ArrayList()
    private fun query() {
        list.clear()
        adapter?.notifyDataSetChanged()
        showLoadingDialog()
        val map = ArrayMap<String, Any>()
        map["carFrameNo"] = tvCarNumber!!.text.toString()
        map["productNo"] = etLineNumber!!.text.toString()
        map["startTime"] = tvStartTime!!.text.toString()
        map["endTime"] = endTime!!.text.toString()
        map["responseDepartment"] = ""
        map["createUserStr"] = etUser!!.text.toString()
        map["pageNo"] = "1"
        map["pageSize"] = "100"
        map["currentLoginUser"] = GlobalVar.realname
        val params = gson.toJson(map)
        Log.e("查询-->",params)
        val client = OkHttpClient.Builder().connectTimeout(20000,TimeUnit.SECONDS).readTimeout(20000,TimeUnit.SECONDS).writeTimeout(20000,TimeUnit.SECONDS).build()
        val requestBody = RequestBody.create(JSON, params)
        val request = Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/materielreplacerecord/qmsManufactureMaterielReplaceRecord/api/getDataList")
                .build()
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.d(TAG, "onFailure: 失败")
                runOnUiThread {
                    cancelLoadingDialog()
                }
            }

            @Throws(IOException::class)
            override fun onResponse(call: Call, response: Response) {
                val result = response.body()!!.string()
                runOnUiThread {
                    cancelLoadingDialog()
                    Log.d(TAG, "onResponse: 列表$result")
                    val jsonObject : JSONObject = JSONObject(result)
                    if (jsonObject.optString("retCode").equals("0") && !TextUtils.isEmpty(jsonObject.optString("data")) &&
                            !TextUtils.isEmpty(jsonObject.optJSONObject("data").optString("list"))){
                        var temp : ArrayList<WorkTimeListBean>  = gson.fromJson(jsonObject.optJSONObject("data").optString("list"), object : TypeToken<List<WorkTimeListBean?>?>() {}.type)
                        list.addAll(temp)
                        adapter!!.notifyDataSetChanged()
                    }else{
                        ToastUtils.show("暂无数据")
                    }

                }
            }
        })
    }


    override fun getResId(): Int {
       return R.layout.activity_work_time_history
    }
}