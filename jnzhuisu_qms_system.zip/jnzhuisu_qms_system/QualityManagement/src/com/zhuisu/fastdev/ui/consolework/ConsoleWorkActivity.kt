package com.zhuisu.fastdev.ui.consolework

import android.annotation.SuppressLint
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.text.TextUtils
import android.util.ArrayMap
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.zhuisu.fastdev.BaseActivity
import com.zhuisu.fastdev.adapter.consolework.ConsoleWorkAdapter
import com.zhuisu.fastdev.beans.consolework.ConsoleProjectActivity
import com.zhuisu.fastdev.beans.consolework.ConsoleWorkList
import com.zhuisu.fastdev.ui.util.BroadCastConfig
import com.zhuisu.qualityManagement.R
import com.zhuisu.suppliermanagement.base.CaptureActivity
import com.zhuisu.suppliermanagement.util.GlobalVar
import com.zhuisu.suppliermanagement.util.ToastUtils
import okhttp3.*
import org.json.JSONException
import org.json.JSONObject
import java.io.IOException

/**
 * @author cxh
 * @description
 * @date 2020/11/13.
 */
class ConsoleWorkActivity : BaseActivity(), ConsoleWorkAdapter.OnItemClickListener {

    var etCarNumber: EditText? = null
    var list : ArrayList<ConsoleWorkList>? = null
    var adapter : ConsoleWorkAdapter? = null

    private val broadCast : BroadCastChange = BroadCastChange()
    val filter : IntentFilter = IntentFilter(BroadCastConfig.BROADCAST_ACTION)

    inner class BroadCastChange : BroadcastReceiver(){
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent != null && intent.action != null && intent.action == BroadCastConfig.BROADCAST_ACTION){
                etCarNumber!!.setText(intent.extras!!.getString(BroadCastConfig.BROADCAST_ACTION_TAG))
                etCarNumber!!.setSelection(etCarNumber!!.text.toString().length)
                query()
            }
        }
    }

    @SuppressLint("SetTextI18n")
    override fun initViews() {
        etCarNumber = findViewById(R.id.tv_cjh)
        list = ArrayList()
        adapter = ConsoleWorkAdapter(list!!,context)

        findViewById<TextView>(R.id.tv_scanf).setOnClickListener {
            val intent = Intent(context, CaptureActivity::class.java)
            startActivityForResult(intent, 1073)
        }

        findViewById<Button>(R.id.btn_query).setOnClickListener{
            query()
        }

        val rvList : RecyclerView = findViewById(R.id.rv_list)
        val layoutManager  = LinearLayoutManager(context)
        layoutManager.orientation = LinearLayoutManager.VERTICAL
        rvList.layoutManager = layoutManager
        rvList.adapter = adapter
        adapter!!.onItemCLick = this


        val tvUserName: TextView = findViewById(R.id.tv_user_name)
        tvUserName.text = "\t" + GlobalVar.realname

        filter.priority = Int.MAX_VALUE
        registerReceiver(broadCast,filter)
        query()
    }

    override fun onDestroy() {
        super.onDestroy()
        unregisterReceiver(broadCast)
    }


    fun query() {
        list!!.clear()
        val map = ArrayMap<String, String>()
        map["flowCarNo"] = ""
        map["carFarmeNo"] = etCarNumber!!.text.toString()
        map["status"] = "debug"
        map["pageNo"] = "1"
        map["pageSize"] = "100"

        val param = gson.toJson(map)
        Log.e("参数", param)
        val client = OkHttpClient()
        val requestBody = RequestBody.create(JSON, param)
        val request = Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/offlinedebuggingstatus/qmsOfflineStatus/api/list")
                .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread {
                    Log.d(TAG, "onFailure: 失败")
                }
            }

            override fun onResponse(call: Call, response: Response) {
                val result = response.body()!!.string()
                runOnUiThread {
                    try {
                        Log.e("--->", result)
                        val jsonObject = JSONObject(result)
                        if (TextUtils.equals(jsonObject.optString("status"), "0")) {
                            val listType = object : TypeToken<ArrayList<ConsoleWorkList>>() {}.type
                            val temp: ArrayList<ConsoleWorkList> = Gson().fromJson(jsonObject.optJSONObject("data").optString("list"), listType)
                            list!!.addAll(temp)
                            adapter!!.notifyDataSetChanged()

                            if (list!!.isEmpty()){
                                ToastUtils.show("暂无数据")
                            }
                        } else
                            showEmptyMessage()

                    } catch (jsonException: JSONException) {
                        jsonException.printStackTrace()
                    }
                }
            }
        })
    }

    override fun getResId(): Int {
        return R.layout.activity_console_work
    }


    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (data != null) {
            etCarNumber!!.setText(data.getStringExtra("encoderesult"))
            query()
        }
        super.onActivityResult(requestCode, resultCode, data)
    }

    override fun OnItemClicked(position: Int) {
        val currentIntent = Intent(context, ConsoleProjectActivity::class.java)
        currentIntent.putExtra(ConsoleProjectActivity.ACTION_VALUE,list!![position])
        startActivity(currentIntent)
    }
}