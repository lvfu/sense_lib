package com.zhuisu.fastdev.ui.problem;

/**
 * @author cxh
 * @description
 * @date 2021/3/8.
 */
public class DeptLocationListBean {
    private String nodetxt;
    private String id;
    private String parentId;


    public void setNodetxt(String nodetxt) {
        this.nodetxt = nodetxt;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setParentId(String parentId) {
        this.parentId = parentId;
    }

    public String getNodetxt() {
        return nodetxt;
    }

    public String getId() {
        return id;
    }

    public String getParentId() {
        return parentId;
    }

    @Override
    public String toString() {
        return nodetxt;
    }
}
