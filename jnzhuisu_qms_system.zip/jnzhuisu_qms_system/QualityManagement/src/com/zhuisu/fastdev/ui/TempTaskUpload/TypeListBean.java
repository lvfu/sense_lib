package com.zhuisu.fastdev.ui.TempTaskUpload;

/**
 * @author cxh
 * @description
 * @date 2021/2/4.
 */
public class TypeListBean {
    private String value;
    private String label;
    private String parentId;
    private String id;
    private boolean isChecked = false;


    public void setChecked(boolean checked) {
        isChecked = checked;
    }

    public boolean isChecked() {
        return isChecked;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public void setParentId(String parentId) {
        this.parentId = parentId;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getValue() {
        return value;
    }

    public String getLabel() {
        return label;
    }

    public String getParentId() {
        return parentId;
    }

    public String getId() {
        return id;
    }

    @Override
    public String toString() {
        return label;
    }
}
