package com.zhuisu.fastdev.ui.finishcheck

import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Parcelable
import android.provider.MediaStore
import android.support.v4.content.FileProvider
import android.util.ArrayMap
import android.util.Log
import android.view.View
import android.widget.*
import com.bumptech.glide.Glide
import com.google.gson.Gson
import com.zhuisu.fastdev.BaseActivity
import com.zhuisu.fastdev.beans.FinishCheckList
import com.zhuisu.fastdev.beans.zhuangpei.ZhuangPeiWeiJianGuZhangXinxiBean
import com.zhuisu.fastdev.beans.zhuangpei.ZhuangPeiWeiJianXiangQingWuLiaoList
import com.zhuisu.fastdev.ui.finishcheck.FinishCheckAskInputActivity.Companion.ACTION_FINISHCHECKLIST
import com.zhuisu.fastdev.ui.problem.OffLineProblemListActivity
import com.zhuisu.fastdev.ui.zhuangpei.SelectItemActivity
import com.zhuisu.fastdev.ui.zhuangpei.SelectWuLiaoActivity
import com.zhuisu.qualityManagement.R
import com.zhuisu.suppliermanagement.base.CaptureActivity
import com.zhuisu.suppliermanagement.util.FileUtil
import com.zhuisu.suppliermanagement.util.GlobalVar
import com.zhuisu.suppliermanagement.util.ToastUtils
import com.zhuisu.suppliermanagement.util.Util
import okhttp3.*
import org.json.JSONException
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.*

class CarPartsAskInputActivity : BaseActivity(){
    private var showimage //显示的照片
            : ImageView? = null
    private var et_car_frame_number: EditText? = null
    private var et_product_number: TextView? = null //编号
    private var et_product_name: TextView? = null
    private var  etTitle : TextView? = null
    private var zhuangPeiWeiJianXiangQingWuLiaoList: ZhuangPeiWeiJianXiangQingWuLiaoList? = null
    private var etLevel : EditText? = null
    private var etErrorCode : EditText? = null
    private var isJump = false
    private var status = ""
    private var finishCheckList : FinishCheckList? = null
    var gson = Gson()


    @SuppressLint("SetTextI18n")
    override fun initViews() {
        etTitle  = findViewById(R.id.et_input_title) //标题
        etLevel = findViewById(R.id.et_level)
        etErrorCode = findViewById(R.id.et_gz_code)
        findViewById<View>(R.id.btn_submit).setOnClickListener { v: View? -> submit() }
        findViewById<View>(R.id.iv_select_image).setOnClickListener { view: View? -> selectImage() }
        et_car_frame_number = findViewById(R.id.et_car_frame_number)
        showimage = findViewById(R.id.showimage)
        val tv_user_name = findViewById<TextView>(R.id.tv_user_name)
        tv_user_name.text = "\t" + GlobalVar.realname
        findViewById<TextView>(R.id.tv_scanf).setOnClickListener {
            val intent = Intent(context, CaptureActivity::class.java)
            startActivityForResult(intent, 0x66)
        }

        et_product_number = findViewById(R.id.et_product_number) //产品编号
        et_product_name = findViewById(R.id.et_product_name) //产品名称

        et_product_number!!.setOnClickListener {
            val intent = Intent(context, SelectWuLiaoActivity::class.java)
            intent.putExtra(SelectWuLiaoActivity.ACTION_PARAMS, true)
            startActivityForResult(intent, 0x13)
        }

        if (intent != null && intent.hasCategory(ACTION_CAR_NUMBER)) {
            val carFrameNumber = intent.getStringExtra(ACTION_CAR_NUMBER)
            et_car_frame_number!!.setText(carFrameNumber)
            et_car_frame_number!!.isEnabled = false
            et_car_frame_number!!.isClickable = false
            isJump = true
        }

        if (intent != null) {
            finishCheckList = intent.getSerializableExtra(ACTION_FINISHCHECKLIST) as FinishCheckList
        }

        var opno = ""
        if (intent != null && intent.hasCategory(ACTION_OPNO)) {
            opno = intent.getStringExtra(ACTION_OPNO)
        }


        if (intent != null && intent.getStringExtra(ACTION_STATUS) != null){
            status = intent.getStringExtra(ACTION_STATUS)
            Log.e("--->", status)
        }

        etTitle!!.setOnClickListener {
            val intent = Intent(context, SelectItemActivity::class.java)
            startActivityForResult(intent, 0x11)
        }

        //问题列表
        findViewById<Button>(R.id.btn_ask_list).setOnClickListener {
            val intent = Intent(context, OffLineProblemListActivity::class.java)
            intent.putExtra(OffLineProblemListActivity.ACTION_PARAMS, et_car_frame_number!!.text.toString())
            intent.putExtra(OffLineProblemListActivity.ACTION_ID, opno)
            startActivity(intent)
        }
    }


    /**
     * 提交数据
     */
    private fun submit() {

        if (etTitle!!.text.toString().isBlank()) {
            ToastUtils.show("问题标题不能为空")
            return
        }

        val etInfo = findViewById<TextView>(R.id.et_info) //描述
        if (!isJump){
            if (etInfo.text.toString().isBlank()) {
                ToastUtils.show("问题描述不能为空")
                return
            }
        }

        val et_number = findViewById<TextView>(R.id.et_number) //数量
        val map = ArrayMap<String, String>()
        map["carFrameNo"] = et_car_frame_number!!.text.toString()
        map["peoblemTitle"] = etTitle!!.text.toString() //问题标题
        map["problemLevel"] = etLevel!!.text.toString() //问题级别
        map["malfunctionCode"] = etErrorCode!!.text.toString()
        map["problemSource"] = "offLineCheck" //问题来源
        map["isFinalCheck"] = "1"
        map["offLineStatus"] = "submitcheck"
        map["occurTimeStr"] = SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(Date(System.currentTimeMillis()))
        map["malfunctionNumber"] = et_number.text.toString() //故障数量
        map["problemDesc"] = etInfo.text.toString() //问题描述
        if (uploadFilePath != null && !uploadFilePath!!.isEmpty()) {
            map["imgStr"] = bitmapToBase64(getLoacalBitmap(uploadFilePath)) //图片
        } else {
            map["imgStr"] = "" //图片
        }

        if (zhuangPeiWeiJianXiangQingWuLiaoList == null) {
            map["materiel"] = "" //物料号
        } else {
            map["materiel"] = zhuangPeiWeiJianXiangQingWuLiaoList!!.materielId //物料号
        }
        map["depts"] = "" //责任部门
        map["operType"] = "app" //固定 app
        map["currentUserLoginName"] = GlobalVar.username //登录人
        map["offLineStatus"] = status
        map["testProect"] = gson.toJson(finishCheckList!!.listZcproject)

        val param = gson.toJson(map)
        Log.e("参数", param)
        showCommitDialog()
        val client = OkHttpClient()
        val requestBody = RequestBody.create(JSON, param)
        val request = Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/checkfaildflow/qmsManufactureProblemflow/api/saveAsyns")
                .build()
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.d(TAG, "onFailure: 失败")
                runOnUiThread {
                    showNetErrorMessage()
                    cancelDialog()
                }
            }

            @Throws(IOException::class)
            override fun onResponse(call: Call, response: Response) {
                val result = response.body()!!.string()
                runOnUiThread {
                    Log.d(TAG, "onResponse: 提交数据$result")
                    try {
                        cancelDialog()
                        val jsonObject = JSONObject(result)
                        if (jsonObject.optString("retCode") == "0") {
                            ToastUtils.show("提交成功")
//                            Handler().postDelayed({ finish() }, 1500)
                            zhuangPeiWeiJianGuZhangXinxiBean = null
                            zhuangPeiWeiJianXiangQingWuLiaoList = null
                            etTitle?.text = ""
                            etErrorCode?.setText("")
                            etLevel?.setText("")
                            etInfo?.text = ""
                            showimage?.visibility = View.GONE
                            uploadFilePath = ""
                            zhuangPeiWeiJianXiangQingWuLiaoList = null
                            et_product_number!!.text = ""
                            et_product_name!!.text = ""
                            et_number!!.text = ""
                            showimage?.visibility = View.GONE

                        } else {
                            ToastUtils.show(jsonObject.optString("retMessage"))
                        }
                    } catch (e: JSONException) {
                        e.printStackTrace()
                        ToastUtils.show("数据解析异常")
                    }
                }
            }
        })
    }

    /**
     * 选择照片
     */
    var uploadFilePath: String? = null
    private val IMAGE_CODE = 200 // 这里的IMAGE_CODE是自己任意定义的
    @SuppressLint("SimpleDateFormat")
    private fun selectImage() {
        var alertdialog: AlertDialog? = null
        var imageUri : Uri?
        alertdialog = Util.getDialog(context, "选择图像", 0, { arg0, view, position, arg3 ->
            if (alertdialog!!.isShowing) {
                alertdialog!!.dismiss()
            }
            val f: File?
            when (position) {
                0 -> {
                    var fileName = ""
                    val capimgIntent = Intent()
                    fileName = SimpleDateFormat("yyyyMMddHHmmss").format(Date()) + ".jpg"
                    FileUtil.checkDir(fileDir + "_/")
                    f = File(fileDir + "_", fileName)
                    uploadFilePath = fileDir + "_/" + fileName
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                        // 7.0+以上版本
                        imageUri = FileProvider.getUriForFile(this, "com.jnqms.fileprovider", f)
                        capimgIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    } else {
                        imageUri = Uri.fromFile(f)
                    }
                    capimgIntent.putExtra(MediaStore.EXTRA_OUTPUT, imageUri)
                    capimgIntent.action = MediaStore.ACTION_IMAGE_CAPTURE
                    capimgIntent.addCategory(Intent.CATEGORY_DEFAULT)

                    startActivityForResult(capimgIntent, 1)
                }
                1 -> {
                    val intent = Intent(Intent.ACTION_GET_CONTENT)
                    intent.type = "image/*"
                    intent.addCategory(Intent.CATEGORY_OPENABLE)
                    try {
                        startActivityForResult(Intent.createChooser(intent, "Select a File to Upload"),
                                IMAGE_CODE)
                    } catch (ex: ActivityNotFoundException) {
                        Toast.makeText(context, "Please install a File Manager.", Toast.LENGTH_SHORT)
                                .show()
                    }
                }
                else -> {
                }
            }
        }, arrayOf("拍照", "文件"), arrayOf(R.drawable.i_camera, R.drawable.i_image))
        alertdialog.show()
    }

    private var zhuangPeiWeiJianGuZhangXinxiBean: ZhuangPeiWeiJianGuZhangXinxiBean? = null
    public override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (resultCode == RESULT_OK && requestCode == IMAGE_CODE) {
            // 选择文件
            if (data == null) return
            val path: String = FileUtil.getImageAbsolutePath(context as Activity, data) ?: return
            uploadFilePath = path
            showimage?.visibility = View.VISIBLE
            Glide.with(context).load(path).into(showimage!!)
        } else if (requestCode == 1 && resultCode == RESULT_OK) {
            showimage?.visibility = View.VISIBLE
            Glide.with(context).load(uploadFilePath).into(showimage!!)
        } else if (requestCode == 0x66 && resultCode == RESULT_OK) {
            et_car_frame_number!!.setText(data!!.getStringExtra("encoderesult").toString())
        } else if (resultCode == 0x19) {
            if (data!!.getParcelableExtra<Parcelable?>("data") != null) {
                zhuangPeiWeiJianXiangQingWuLiaoList = data.getParcelableExtra("data")
                et_product_number!!.text = zhuangPeiWeiJianXiangQingWuLiaoList!!.materielId
                et_product_name!!.text = zhuangPeiWeiJianXiangQingWuLiaoList!!.materielName

            }
        } else if (resultCode == 0x18) {
            if (data!!.getParcelableExtra<Parcelable?>("data") != null) {
                zhuangPeiWeiJianGuZhangXinxiBean = data.getParcelableExtra("data")
                Log.e("获取数据", zhuangPeiWeiJianGuZhangXinxiBean!!.malfunctionName)
                etTitle!!.setText(zhuangPeiWeiJianGuZhangXinxiBean!!.malfunctionName)
                etLevel!!.setText(zhuangPeiWeiJianGuZhangXinxiBean!!.malfunctionLevel)
                etErrorCode?.setText(zhuangPeiWeiJianGuZhangXinxiBean!!.malfunctionNo)
            }
        }
    }


    companion object {
        var fileDir = Environment.getExternalStorageDirectory().absolutePath + "/qualitymanagement/files/media/"
        const val ACTION_CAR_NUMBER: String = "action_car_frame_number"
        const val ACTION_STATUS : String = "action_status";
        const val ACTION_OPNO : String = "action_opno"
    }

    override fun getResId(): Int {
        return R.layout.activity_finish_check_input_problem

    }
}