package com.zhuisu.fastdev.ui.rain.raindetal

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.support.v7.widget.RecyclerView
import android.text.TextUtils
import android.util.Base64
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import com.zhuisu.qualityManagement.R
import com.zhuisu.suppliermanagement.ui.ShowImageDisplayActivity
import com.zhuisu.suppliermanagement.util.GlobalVar

/**
 * @author cxh
 * @description
 * @date 2020/12/22.
 */
class RainFailureDetailAdapter(context: Context, list: ArrayList<RainFailureBean>) : RecyclerView.Adapter<RainFailureDetailAdapter.VH>() {

    var context : Context? = null
    var list : ArrayList<RainFailureBean>? = null
    init {
        this.context = context
        this.list = list
    }
    class VH(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvPart : TextView = itemView.findViewById(R.id.tv_car_number)
        val tvInfo : TextView = itemView.findViewById(R.id.tv_car_type)
        val tvNo : TextView = itemView.findViewById(R.id.tv_info)
        val ivImage : ImageView = itemView.findViewById(R.id.iv_image)

    }

    override fun onCreateViewHolder(p0: ViewGroup, p1: Int): VH {
        return VH(((context?.getSystemService(Context.LAYOUT_INFLATER_SERVICE)) as LayoutInflater).inflate(R.layout.item_rain_failure_detai, p0, false))
    }

    private fun base64ToBitmap(string: String?): Bitmap? {
        var bitmap: Bitmap? = null
        bitmap = try {
            val bitmapArray = Base64.decode(string, Base64.DEFAULT)
            BitmapFactory.decodeByteArray(bitmapArray, 0, bitmapArray.size)
        } catch (e: Exception) {
            e.printStackTrace()
            return null
        }
        return bitmap
    }

    override fun onBindViewHolder(p0: VH, p1: Int) {
        p0.tvPart.text = list?.get(p1)?.part
        p0.tvInfo.text = list?.get(p1)?.remark
        p0.tvNo.text = list?.get(p1)?.partNo

        try {
            if (list != null && list?.get(p1) != null && list?.get(p1)?.imgStr !=  null && !TextUtils.isEmpty(list?.get(p1)?.imgStr)){
                p0.ivImage.setImageBitmap(base64ToBitmap(list?.get(p1)?.imgStr))
                p0.ivImage.setOnClickListener{
                    val intent = Intent(context, ShowImageDisplayActivity::class.java)
                    GlobalVar.IMGBASE64 = list?.get(p1)?.imgStr
                    context?.startActivity(intent)
                }
            }
        }catch (e : java.lang.Exception){
            e.printStackTrace()
        }
        p0.ivImage
    }

    override fun getItemCount(): Int {
        return if (list == null) 0 else list!!.size
    }
}