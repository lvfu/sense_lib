package com.zhuisu.fastdev.ui.finishcheck;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;

public class JobService extends Service {
    public JobService() {
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}