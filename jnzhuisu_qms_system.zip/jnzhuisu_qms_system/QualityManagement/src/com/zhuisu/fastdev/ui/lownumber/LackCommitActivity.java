package com.zhuisu.fastdev.ui.lownumber;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.text.TextUtils;
import android.util.ArrayMap;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;

import com.google.gson.reflect.TypeToken;
import com.zhuisu.fastdev.BaseActivity;
import com.zhuisu.fastdev.beans.LackCommitDetailListBean;
import com.zhuisu.fastdev.beans.lack.LackCommitBean;
import com.zhuisu.fastdev.beans.xiaxian.XiaXianWeiJianXiangQingongNengMok;
import com.zhuisu.fastdev.ui.util.BroadCastConfig;
import com.zhuisu.qualityManagement.R;
import com.zhuisu.suppliermanagement.base.CaptureActivity;
import com.zhuisu.suppliermanagement.util.GlobalVar;
import com.zhuisu.suppliermanagement.util.ToastUtils;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 * @author cxh
 * @description 缺件提交
 * @date 2020/10/27.
 */
public class LackCommitActivity extends BaseActivity {
    private EditText tv_cjh;
    private TextView tv_detail1;
    private TextView tv_detail2;
    private TextView tv_wlh;
    private Spinner tv_qjyy;
    private TextView tv_wlmc;
    private EditText et_qjsl;//缺件数量
    private Switch checkstate;
    private EditText etRemark;
    public static final String ACTION_EXT_DATA = "action_ext_data";
    private LackCommitDetailListBean lackCommitDetailListBean;

    private String commitResult = "carFrameNo";
    private String cjh;
    private String lockNumber = null;//生产订单号
    private String orderNo;//订单号
    private TextView tvCarNumberList;
    private boolean isCarNumber = true;


    BroadCastChange broadCast = new BroadCastChange();
    IntentFilter filter = new IntentFilter(BroadCastConfig.BROADCAST_ACTION);

    class BroadCastChange extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent != null && intent.getAction() != null && intent.getAction().equals(BroadCastConfig.BROADCAST_ACTION)) {
                tv_cjh.setText(intent.getExtras().getString(BroadCastConfig.BROADCAST_ACTION_TAG));
                tv_cjh.setSelection(tv_cjh.getText().toString().length());
                query();
            }
        }
    }

    @SuppressLint("SetTextI18n")
    @Override
    protected void initViews() {
        tvCarNumberList = findViewById(R.id.tv_detail3);
        tv_cjh = findViewById(R.id.tv_cjh);
        etRemark = findViewById(R.id.et_remark);
        tv_detail1 = findViewById(R.id.tv_detail1);
        tv_detail2 = findViewById(R.id.tv_detail2);
        tv_wlh = findViewById(R.id.tv_wlh);
        tv_wlmc = findViewById(R.id.et_wl_name);
        et_qjsl = findViewById(R.id.et_qjsl);
        checkstate = findViewById(R.id.switch1);
        Switch mSwitch = findViewById(R.id.switch2);
        TextView tvShowName = findViewById(R.id.tv_showname);
        mSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                isCarNumber = false;
                tvShowName.setText("机体号:");
                queryNo();
            } else {
                isCarNumber = true;
                tvShowName.setText("车架号:");
            }
        });

        //缺件提交
        tv_qjyy = findViewById(R.id.tv_qjyy);
        queryFunction();


        findViewById(R.id.btn_query).setOnClickListener(v -> query());
        tv_wlh.setOnClickListener(v -> {
            Intent intent = new Intent(context, QueryResouceActivity.class);
            startActivityForResult(intent, 0x06);
        });

        findViewById(R.id.submit).setOnClickListener(v -> submit());

        TextView tv_user_name = findViewById(R.id.tv_user_name);
        tv_user_name.setText("\t" + GlobalVar.realname);

        findViewById(R.id.tv_scanf).setOnClickListener(arg0 -> {
            Intent intent = new Intent();
            intent.setClass(context, CaptureActivity.class);
            startActivityForResult(intent, 1073);
        });

        checkstate.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                commitResult = "orderNo";
                queryCarNumber();
            } else {
                commitResult = "carFrameNo";
            }
        });

        filter.setPriority(Integer.MAX_VALUE);
        registerReceiver(broadCast, filter);
    }


    private List<XiaXianWeiJianXiangQingongNengMok> qingongNengMokList;//功能模块

    /**
     * 查询功能模块
     */
    private void queryFunction() {
        ArrayMap<String, String> map = new ArrayMap<>();
        map.put("type", "missReason");
        String param = gson.toJson(map);
        OkHttpClient client = new OkHttpClient();
        RequestBody requestBody = RequestBody.create(JSON, param);
        Request request = new Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/common/util/api/getDict")
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                Log.d(TAG, "onFailure: 失败");
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                final String result = response.body().string();
                runOnUiThread(() -> {
                    Log.d(TAG, "onResponse: 功能模块" + result);
                    try {
                        JSONObject jsonObject = new JSONObject(result);
                        qingongNengMokList = gson.fromJson(jsonObject.optString("data"), new TypeToken<List<XiaXianWeiJianXiangQingongNengMok>>() {
                        }.getType());
                        if (qingongNengMokList == null) return;
                        ArrayAdapter<XiaXianWeiJianXiangQingongNengMok> arrayAdapter = new ArrayAdapter<>(context, R.layout.simple_textview1, qingongNengMokList);
                        tv_qjyy.setAdapter(arrayAdapter);

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                });
            }
        });
    }


    /**
     * 根据订单号查询车架号列表
     */
    private void queryNo() {
        lackCommitCarListBeans.clear();
        ArrayMap<String, String> map = new ArrayMap<>();
        if (TextUtils.isEmpty(tv_cjh.getText().toString())) {
            ToastUtils.show("请扫描或输入机体号");
            return;
        }
        showLoadingDialog();
        map.put("carBodyNo", tv_cjh.getText().toString());

        String param = gson.toJson(map);
        Log.e("--->", param);
        OkHttpClient client = new OkHttpClient();
        RequestBody requestBody = RequestBody.create(JSON, param);
        Request request = new Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/nscs/qmsManufactureNscsProductionplan/api/getFlowCarNoByCarFramno")
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                cancelLoadingDialog();
                Log.d(TAG, "onFailure: 失败");
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                final String result = response.body().string();
                runOnUiThread(() -> {
                    cancelLoadingDialog();
                    try {
                        Log.e("--->", result);
                        JSONObject jsonObject = new JSONObject(result);
                        if (jsonObject.optString("retCode").equals("0") && !TextUtils.isEmpty(jsonObject.optString("data"))) {
                            lackCommitCarListBeans.addAll(gson.fromJson(jsonObject.optString("data"), new TypeToken<List<String>>() {
                            }.getType()));
                            showMutilDialog();
                        } else {
                            ToastUtils.show("暂无数据");
                        }
                    } catch (JSONException jsonException) {
                        jsonException.printStackTrace();
                    }

                });
            }
        });
    }


    /**
     * 根据订单号查询车架号列表
     */
    private void queryCarNumber() {
        lackCommitCarListBeans.clear();
        ArrayMap<String, String> map = new ArrayMap<>();
        if (orderNo == null) {
            ToastUtils.show("请扫描或输入车架号查询订单号");
//            checkstate.setChecked(false);
            return;
        }
        showLoadingDialog();
        map.put("orderNo", orderNo);

        String param = gson.toJson(map);
        Log.e("--->", param);
        OkHttpClient client = new OkHttpClient();
        RequestBody requestBody = RequestBody.create(JSON, param);
        Request request = new Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/missingpartsmgr/qmsManufactureMissingparts/api/getCarFrameNosByOrderNo")
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                cancelLoadingDialog();
                Log.d(TAG, "onFailure: 失败");
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                final String result = response.body().string();
                runOnUiThread(() -> {
                    cancelLoadingDialog();
                    try {
                        Log.e("--->", result);
                        JSONObject jsonObject = new JSONObject(result);
                        if (jsonObject.optString("retCode").equals("0") && !TextUtils.isEmpty(jsonObject.optString("data"))) {
                            lackCommitCarListBeans.addAll(gson.fromJson(jsonObject.optString("data"), new TypeToken<List<String>>() {
                            }.getType()));
                            showMutilDialog();
                        } else {
                            ToastUtils.show("暂无数据");
                        }
                    } catch (JSONException jsonException) {
                        jsonException.printStackTrace();
                    }

                });
            }
        });
    }

    /**
     * 展示车架号
     */
    ArrayList<String> lackCommitCarListBeans = new ArrayList<>();
    java.lang.StringBuilder checkCarNumber = null;
    String checkCarNumberStr = null;

    private void showMutilDialog() {
        if (lackCommitCarListBeans == null || lackCommitCarListBeans.isEmpty()) {
            return;
        }
        AlertDialog.Builder builder = new AlertDialog.Builder(this, R.style.MyAlertDialogStyle);
        builder.setTitle(isCarNumber ? "请选择车架号" : "请选择机体号");
        String[] items = new String[lackCommitCarListBeans.size()];
        boolean[] checkedItems = new boolean[lackCommitCarListBeans.size()];
        for (int i = 0; i < lackCommitCarListBeans.size(); i++) {
            items[i] = lackCommitCarListBeans.get(i);
            checkedItems[i] = true;
        }
        builder.setMultiChoiceItems(items, checkedItems, (dialog, which, isChecked) -> {

        });
        builder.setPositiveButton("确定", (dialog, which) -> {
            checkCarNumber = new StringBuilder();
            for (int i = 0; i < checkedItems.length; i++) {
                if (checkedItems[i]) {
                    for (int j = 0; j < lackCommitCarListBeans.size(); j++) {
                        if (lackCommitCarListBeans.get(j).equals(items[i])) {
                            String fruit = items[i];
                            checkCarNumber.append(fruit).append(",");
                        }
                    }
                }
            }
            if (!checkCarNumber.toString().isEmpty() && checkCarNumber.toString().length() > 1) {
                checkCarNumberStr = checkCarNumber.toString().substring(0, checkCarNumber.length() - 1);
            }

            Log.e("checkCar", checkCarNumberStr);
            tvCarNumberList.setText(checkCarNumberStr);
            dialog.dismiss();
        });

        builder.show();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        unregisterReceiver(broadCast);
    }

    /**
     * 提交数据
     */
    private void submit() {

        String qjyyId = qingongNengMokList.get(tv_qjyy.getSelectedItemPosition()).getValue();

        Log.d("onResponse",""+qjyyId);

        if (lackCommitDetailListBean == null) {
            ToastUtils.show("请选择物料");
            return;
        }


        if (TextUtils.isEmpty(qjyyId)) {
            ToastUtils.show("请选择缺件原因");
            return;
        }


        if (lockNumber == null) {
            if (!(tv_cjh.getText().toString().length() == 22) && !(checkstate.isChecked()) && isCarNumber) {
                ToastUtils.show("暂无数据可以提交");
                return;
            }
        }

        try {
            LackCommitBean bean = new LackCommitBean();
            Log.e("--->", commitResult);
            if (checkstate.isChecked()) {
//                bean.setAddSource("orderNo");
                bean.setAddSource("carFrameNo");
                bean.setRecordUser(GlobalVar.username);
                List<LackCommitBean.InnerBean> innerBeans = new ArrayList<>();
                if (checkCarNumberStr != null && !checkCarNumberStr.isEmpty()) {
                    String[] strArr = checkCarNumberStr.split(",");
                    for (String s : strArr) {
                        Log.e("---> $i", s);
                        LackCommitBean.InnerBean innerBean = new LackCommitBean.InnerBean();
                        innerBean.setProductOrder(lockNumber);
                        innerBean.setCarFrameNo(s);
                        innerBean.setOrderNo(orderNo);
                        innerBean.setStatus("confirmed");
                        innerBean.setQuantity(et_qjsl.getText().toString());
                        innerBean.setBomId(lackCommitDetailListBean.getMaterielId());
                        innerBean.setBomName(lackCommitDetailListBean.getMaterielName());
                        innerBean.setProductModel("zc");
                        innerBean.setAddRemarks(etRemark.getText().toString());
                        innerBean.setMissReason(qjyyId);
                        innerBeans.add(innerBean);
                    }
                } else {
                    ToastUtils.show("根据订单号提交需要选择车架号");
                    return;
                }

                bean.setQmsManufactureMissingPartsList(innerBeans);
            } else if (!isCarNumber) {
                //机体号
                bean.setAddSource("carBodyNo");
                bean.setRecordUser(GlobalVar.username);
                List<LackCommitBean.InnerBean> innerBeans = new ArrayList<>();
                if (checkCarNumberStr != null && !checkCarNumberStr.isEmpty()) {
                    String[] strArr = checkCarNumberStr.split(",");
                    for (String s : strArr) {
                        Log.e("---> $i", s);
                        LackCommitBean.InnerBean innerBean = new LackCommitBean.InnerBean();
                        innerBean.setProductOrder(lockNumber);
                        innerBean.setCarFrameNo(s);
                        innerBean.setOrderNo(orderNo);
                        innerBean.setStatus("confirmed");
                        innerBean.setQuantity(et_qjsl.getText().toString());
                        innerBean.setBomId(lackCommitDetailListBean.getMaterielId());
                        innerBean.setBomName(lackCommitDetailListBean.getMaterielName());
                        innerBean.setProductModel("nscs");
                        innerBean.setAddRemarks(etRemark.getText().toString());
                        innerBean.setMissReason(qjyyId);
                        innerBeans.add(innerBean);
                    }
                } else {
                    ToastUtils.show("根据订单号提交需要选择车架号");
                    return;
                }
                bean.setQmsManufactureMissingPartsList(innerBeans);
            } else {
                bean.setAddSource("carFrameNo");
                bean.setRecordUser(GlobalVar.username);
                List<LackCommitBean.InnerBean> innerBeans = new ArrayList<>();
                LackCommitBean.InnerBean innerBean = new LackCommitBean.InnerBean();

                innerBean.setProductOrder(lockNumber);
                innerBean.setCarFrameNo(cjh == null ? tv_cjh.getText().toString() : cjh);
                innerBean.setOrderNo(orderNo == null ? "" : orderNo);
                innerBean.setStatus("confirmed");
                innerBean.setQuantity(et_qjsl.getText().toString());
                innerBean.setBomId(lackCommitDetailListBean.getMaterielId());
                innerBean.setBomName(lackCommitDetailListBean.getMaterielName());
                innerBean.setProductModel("zc");
                innerBeans.add(innerBean);
                innerBean.setAddRemarks(etRemark.getText().toString());
                innerBean.setMissReason(qjyyId);
                bean.setQmsManufactureMissingPartsList(innerBeans);
            }

            OkHttpClient client = new OkHttpClient();
            String params = gson.toJson(bean);
            Log.e("参数", params);
            showCommitDialog();


            RequestBody requestBody = RequestBody.create(JSON, params);
            Request request = new Request.Builder()
                    .post(requestBody)
                    .url(GlobalVar.url + "a/missingpartsmgr/qmsManufactureMissingparts/api/save")
                    .build();

            client.newCall(request).enqueue(new Callback() {
                @Override
                public void onFailure(Call call, IOException e) {
                    runOnUiThread(() -> {
                        showNetErrorMessage();
                        cancelDialog();
                    });
                }

                @Override
                public void onResponse(Call call, Response response) throws IOException {
                    final String result = response.body().string();
                    Log.e("result", result);
                    runOnUiThread(() -> {
                        try {
                            cancelDialog();
                            JSONObject jsonObject = new JSONObject(result);
                            if (jsonObject.optString("retCode").equals("0")) {
                                ToastUtils.show("提交成功");
                                finish();
                            } else {
                                showFailureMessageDialog(jsonObject.optString("retMessage"));
                                ToastUtils.show(jsonObject.optString("retMessage"));
                            }
                        } catch (JSONException jsonException) {
                            jsonException.printStackTrace();
                        }
                    });
                }
            });

        } catch (Exception jsonException) {
            jsonException.printStackTrace();
        }

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (data != null && requestCode == 0x06) {
            if (data.getParcelableExtra(ACTION_EXT_DATA) != null) {
                lackCommitDetailListBean = data.getParcelableExtra(ACTION_EXT_DATA);
                tv_wlh.setText(lackCommitDetailListBean.getMaterielId());
                tv_wlmc.setText(lackCommitDetailListBean.getMaterielName());
            }
        }

        if (requestCode == 1073 && resultCode == Activity.RESULT_OK) {
            tv_cjh.setText(data.getStringExtra("encoderesult"));
            if (isCarNumber) {
                //车架号
                query();
            } else {
                queryNo();
            }
        }
    }

    private void query() {
        ArrayMap<String, String> map = new ArrayMap<>();
        map.put("carFrameNo", tv_cjh.getText().toString());

        String param = gson.toJson(map);
        OkHttpClient client = new OkHttpClient();
        RequestBody requestBody = RequestBody.create(JSON, param);
        Request request = new Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/prduictionrelation/qmsManufactureProductionplanrelation/api/getCheckItemInfoByCarFrameNo")
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                Log.d(TAG, "onFailure: 失败");
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                final String result = response.body().string();
                runOnUiThread(() -> showData(result));
            }
        });
    }

    @SuppressLint("SetTextI18n")
    private void showData(String result) {
        Log.e("-->根据车架号获取详情", result);
        try {
            JSONObject jsonObject = new JSONObject(result);
            if (TextUtils.equals(jsonObject.optString("retCode"), "0")) {
                JSONObject jsonData = jsonObject.optJSONObject("data");
                tv_detail1.setText("订单号: " + jsonData.optString("orderNo"));
                orderNo = jsonData.optString("orderNo");
                tv_detail2.setText("车架号: " + jsonData.optString("carFrameNo"));
                cjh = jsonData.optString("carFrameNo");

                lockNumber = jsonData.optString("productOrder");

            } else {
                ToastUtils.show(jsonObject.optString("retMessage"));
                lockNumber = null;
            }
        } catch (JSONException jsonException) {
            lockNumber = null;
            jsonException.printStackTrace();
        }
    }

    @Override
    protected int getResId() {
        return R.layout.activity_lack;
    }
}
