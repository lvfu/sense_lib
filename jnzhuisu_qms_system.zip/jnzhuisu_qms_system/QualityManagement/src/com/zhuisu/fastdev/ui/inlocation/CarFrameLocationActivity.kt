package com.zhuisu.fastdev.ui.inlocation

import android.annotation.SuppressLint
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.text.TextUtils
import android.util.ArrayMap
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.zhuisu.fastdev.BaseActivity
import com.zhuisu.fastdev.adapter.inlocation.CarFrameInLocationAdapter
import com.zhuisu.fastdev.ui.util.BroadCastConfig
import com.zhuisu.qualityManagement.R
import com.zhuisu.suppliermanagement.base.CaptureActivity
import com.zhuisu.suppliermanagement.util.GlobalVar
import com.zhuisu.suppliermanagement.util.ToastUtils
import okhttp3.*
import org.json.JSONException
import org.json.JSONObject
import java.io.IOException

/**
 * @author cxh
 * @description 故障排除作业
 * @date 2020/11/13.
 */
class CarFrameLocationActivity : BaseActivity(), CarFrameInLocationAdapter.OnItemClickListener {

    private var etCarNumber: EditText? = null
    private var list: ArrayList<CarFrameInLocationListEn>? = null
    private var adapter: CarFrameInLocationAdapter? = null
    private val broadCast : BroadCastChange = BroadCastChange()
    private val filter : IntentFilter = IntentFilter(BroadCastConfig.BROADCAST_ACTION)

    inner class BroadCastChange : BroadcastReceiver(){
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent != null && intent.action != null && intent.action == BroadCastConfig.BROADCAST_ACTION){
                etCarNumber!!.setText(intent.extras!!.getString(BroadCastConfig.BROADCAST_ACTION_TAG))
                etCarNumber!!.setSelection(etCarNumber!!.text.toString().length)
                query()
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        unregisterReceiver(broadCast)
    }

    @SuppressLint("SetTextI18n")
    override fun initViews() {
        val tvUserName: TextView = findViewById(R.id.tv_user_name)
        tvUserName.text = "\t" + GlobalVar.realname

        list = ArrayList()
        adapter = CarFrameInLocationAdapter(list!!, context)
        val recyclerview = findViewById<RecyclerView>(R.id.recyclerview)
        val manager = LinearLayoutManager(context)
        etCarNumber = findViewById(R.id.tv_cjh)

        manager.orientation = LinearLayoutManager.VERTICAL
        recyclerview.layoutManager = manager
        recyclerview.adapter = adapter
        adapter!!.onItemCLick = this

        findViewById<TextView>(R.id.tv_scanf).setOnClickListener {
            val intent = Intent(context, CaptureActivity::class.java)
            startActivityForResult(intent, 1073)
        }

        findViewById<Button>(R.id.btn_query).setOnClickListener {
            query()
        }

        filter.priority = Int.MAX_VALUE
        registerReceiver(broadCast,filter)
    }


    fun query() {
        if (etCarNumber!!.text.toString().isBlank()) return
        showLoadingDialog()
        list!!.clear()
        adapter!!.notifyDataSetChanged()
        val map = ArrayMap<String, String>()
        map["outDh"] = etCarNumber!!.text.toString()
        val param = gson.toJson(map)
        Log.e("参数", param)
        val client = OkHttpClient()
        val requestBody = RequestBody.create(JSON, param)
        val request = Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/hmes/wlb/api/findCktzOut")
                .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread {
                    Log.d(TAG, "onFailure: 失败")
                    cancelLoadingDialog()
                    ToastUtils.show("请求数据失败")
                }
            }

            override fun onResponse(call: Call, response: Response) {
                val result = response.body()!!.string()
                runOnUiThread {
                    try {
                        cancelLoadingDialog()
                        Log.e("--->", result)
                        val jsonObject = JSONObject(result)
                        if (TextUtils.equals(jsonObject.optString("retCode"), "0") && jsonObject.optString("data") != null && jsonObject.optString("data").isNotBlank()) {
                            val listType = object : TypeToken<ArrayList<CarFrameInLocationListEn>>() {}.type
                            val temp: ArrayList<CarFrameInLocationListEn> = Gson().fromJson(jsonObject.optString("data"), listType)
                            list!!.addAll(temp)
                            adapter!!.notifyDataSetChanged()
                            if (list!!.isEmpty()){
                                showEmptyMessage()
                            }
                        } else {
                            showEmptyMessage()
                            adapter!!.notifyDataSetChanged()
                        }

                    } catch (jsonException: JSONException) {
                        jsonException.printStackTrace()
                    }
                }
            }
        })
    }

    override fun getResId(): Int {
        return R.layout.activity_car_frame_location
    }

    override fun onResume() {
        super.onResume()
        query()
    }


    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (data != null) {
            val str = data.getStringExtra("encoderesult").toString()
            etCarNumber!!.setText(str)
            etCarNumber!!.setSelection(str.length)
        }
        super.onActivityResult(requestCode, resultCode, data)
    }

    override fun onItemCLicked(position: Int) {
        //点击保存
        if (TextUtils.isEmpty( list!![position].jssl)){
            ToastUtils.show("请输入")
            return
        }
        showLoadingDialog()
        val map = ArrayMap<String, Any>()
        map["outDh"] = list!![position].outDh
        map["fldWlBh"] = list!![position].fldWlBh
        map["jssl"] = list!![position].jssl.toInt()
        map["userName"] = GlobalVar.realname

        val param = gson.toJson(map)
        Log.e("参数", param)

        val client = OkHttpClient()
        val requestBody = RequestBody.create(JSON, param)
        val request = Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/hmes/wlb/api/saveCjrk")
                .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread {
                    Log.d(TAG, "onFailure: 失败")
                    cancelLoadingDialog()
                    ToastUtils.show("提交数据失败")
                }
            }

            override fun onResponse(call: Call, response: Response) {
                val result = response.body()!!.string()
                runOnUiThread {
                    try {
                        cancelLoadingDialog()
                        Log.e("--->", result)
                        val jsonObject = JSONObject(result)
                        if (TextUtils.equals(jsonObject.optString("retCode"), "0")) {
                            ToastUtils.show("成功")
                            query()
                        } else {
                            ToastUtils.show(jsonObject.optString("retMessage"))
                        }

                    } catch (jsonException: JSONException) {
                        jsonException.printStackTrace()
                    }
                }
            }
        })
    }

}