package com.zhuisu.fastdev.ui.rain

import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.text.TextUtils
import android.util.ArrayMap
import android.util.Log

import com.google.gson.reflect.TypeToken
import com.zhuisu.fastdev.BaseActivity
import com.zhuisu.fastdev.ui.rain.raindetal.RainFailureBean
import com.zhuisu.fastdev.ui.rain.raindetal.RainFailureDetailAdapter
import com.zhuisu.qualityManagement.R
import com.zhuisu.suppliermanagement.util.GlobalVar
import okhttp3.*
import org.json.JSONException
import org.json.JSONObject
import java.io.IOException

/**
 * @author cxh
 * @description
 * @date 2020/12/22.
 */
class RainFailureDetailActivity : BaseActivity() {

    var list: ArrayList<RainFailureBean>? = null
    var adapter: RainFailureDetailAdapter? = null

    override fun initViews() {

        val rvList: RecyclerView = findViewById(R.id.rv)
        val manager = LinearLayoutManager(context)
        manager.orientation = LinearLayoutManager.VERTICAL
        rvList.layoutManager = manager

        list = ArrayList()
        adapter = RainFailureDetailAdapter(context, list!!)
        rvList.adapter = adapter

        if (intent != null && intent.getStringExtra(ACTION_ID) != null){
            query(intent.getStringExtra(ACTION_ID))
        }

    }

    fun query(id : String) {
        val map = ArrayMap<String, String>()
        map["recordId"] = id
        val param = gson.toJson(map)
        Log.e("不合格详情", param)
        val client = OkHttpClient()
        val requestBody = RequestBody.create(JSON, param)
        val request = Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/offlinedebuggingstatus/qmsOfflineStatus/api/rainFailedDetials")
                .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread {
                    Log.d(TAG, "onFailure: 失败")
                }
            }

            override fun onResponse(call: Call, response: Response) {
                val result = response.body()!!.string()
                runOnUiThread {
                    try {
                        Log.e("--->数据", result)
                        val jsonObject = JSONObject(result)
                        if (TextUtils.equals(jsonObject.optString("status"), "0")) {
                            list!!.addAll(gson.fromJson(jsonObject.optString("data"), object : TypeToken<List<RainFailureBean?>?>() {}.type))
                            adapter!!.notifyDataSetChanged()
                        } else
                            showEmptyMessage()

                    } catch (jsonException: JSONException) {
                        jsonException.printStackTrace()
                    }
                }
            }
        })

    }

    override fun getResId(): Int {
        return R.layout.activity_rain_failure_detail
    }

    companion object{
        const val  ACTION_ID = "action_id"
    }

}