package com.zhuisu.fastdev.ui.lackhistory

import android.app.Activity
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.support.v4.content.FileProvider
import android.text.TextUtils
import android.util.ArrayMap
import android.util.Log
import android.widget.*
import com.bumptech.glide.Glide
import com.zhuisu.fastdev.BaseActivity
import com.zhuisu.qualityManagement.R
import com.zhuisu.suppliermanagement.util.FileUtil
import com.zhuisu.suppliermanagement.util.GlobalVar
import com.zhuisu.suppliermanagement.util.ToastUtils
import com.zhuisu.suppliermanagement.util.Util
import okhttp3.*
import org.json.JSONException
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.*

/**
 * @author cxh
 * @description
 * @date 2020/11/5.
 */
class CarFrameCloseLackDetailActivity : BaseActivity() {

    private var showImage: ImageView? = null
    override fun initViews() {
        val id = intent.getStringExtra("id")
        val btn = findViewById<Button>(R.id.btn_submit)
        val selectImage = findViewById<ImageView>(R.id.iv_select_image)

        val userName: TextView = findViewById(R.id.tv_user_name)
        userName.text = String.format(resources.getString(R.string.format_tabs_string), GlobalVar.realname)

        showImage = findViewById(R.id.showimage)
        selectImage.setOnClickListener { selectImage() }
        btn.setOnClickListener { submit(id) }
    }


    override fun getResId(): Int {
        return R.layout.activity_car_frame_lack_close_detail
    }


    fun submit(id: String) {
        val etInfo = findViewById<EditText>(R.id.et_info)
        val map = ArrayMap<String, String>()
        map["id"] = id
        map["instruction"] = etInfo.text.toString()
        if (TextUtils.isEmpty(uploadFilePath)) {
            map["imgStr"] = ""
        } else {
            map["imgStr"] = bitmapToBase64(getLoacalBitmap(uploadFilePath))
        }
        map["recordUser"] = GlobalVar.username


        val param = gson.toJson(map)
        showCommitDialog()


        Log.e("参数", param)
        val client = OkHttpClient()
        val requestBody = RequestBody.create(JSON, param)
        val request = Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/missingpartsmgr/qmsManufactureMissingparts/api/closeMissingPart")
                .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.d(TAG, "onFailure: 失败")
                runOnUiThread {
                    showNetErrorMessage()
                    cancelDialog()
                }
            }

            override fun onResponse(call: Call, response: Response) {
                val result = response.body()!!.string()
                runOnUiThread {
                    try {
                        cancelDialog()
                        Log.e("--->", result)
                        val jsonObject = JSONObject(result)
                        if (TextUtils.equals(jsonObject.optString("retCode"), "0")) {
                            ToastUtils.show("成功")
                            finish()
                        }
                    } catch (jsonException: JSONException) {
                        jsonException.printStackTrace()
                    }
                }
            }
        })
    }


    /**
     * 选择照片
     */


    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == RESULT_OK && requestCode == 200) {
            // 选择文件
            if (data == null) return
            val path: String? = FileUtil.getImageAbsolutePath(context as Activity, data) ?: return
            uploadFilePath = path
            Glide.with(context).load(path).into(showImage!!)
        } else if (requestCode == 1 && resultCode == RESULT_OK) {
            Glide.with(context).load(uploadFilePath).into(showImage!!)
        }
    }

    var uploadFilePath: String? = ""
    private fun selectImage() {
        var alertdialog: AlertDialog? = null
        var imageUri : Uri?
        val fileDir = Environment.getExternalStorageDirectory().absolutePath + "/qualitymanagement/files/media/"

        val IMAGE_CODE = 200 // 这里的IMAGE_CODE是自己任意定义的
        alertdialog = Util.getDialog(context, "选择图像", 0, { arg0, view, position, arg3 ->
            if (alertdialog!!.isShowing) {
                alertdialog!!.dismiss()
            }
            val f: File?
            val uri: Uri?
            when (position) {
                0 -> {
                    val capimgIntent = Intent()
                    val fileName: String = SimpleDateFormat("yyyyMMddHHmmss", Locale.CHINA).format(Date()) + ".jpg"
                    FileUtil.checkDir(fileDir + "_/")
                    f = File(fileDir + "_", fileName)
                    uploadFilePath = fileDir + "_/" + fileName
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                        // 7.0+以上版本
                        //与manifest中定义的provider中的authorities="cn.wlantv.kznk.fileprovider"保持一致
                        imageUri = FileProvider.getUriForFile(this, "com.jnqms.fileprovider", f)
                        capimgIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    } else {
                        imageUri = Uri.fromFile(f)
                    }
                    capimgIntent.putExtra(MediaStore.EXTRA_OUTPUT, imageUri)
                    capimgIntent.action = MediaStore.ACTION_IMAGE_CAPTURE
                    capimgIntent.addCategory(Intent.CATEGORY_DEFAULT)

                    startActivityForResult(capimgIntent, 1)
                }
                1 -> {
                    val intent = Intent(Intent.ACTION_GET_CONTENT)
                    intent.type = "image/*"
                    intent.addCategory(Intent.CATEGORY_OPENABLE)
                    try {
                        startActivityForResult(Intent.createChooser(intent, "Select a File to Upload"),
                                IMAGE_CODE)
                    } catch (ex: ActivityNotFoundException) {
                        Toast.makeText(context, "Please install a File Manager.", Toast.LENGTH_SHORT)
                                .show()
                    }
                }
                else -> {
                }
            }
        }, arrayOf("拍照", "文件"), arrayOf(R.drawable.i_camera, R.drawable.i_image))
        alertdialog.show()
    }

}