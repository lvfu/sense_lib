package com.zhuisu.fastdev.ui.util;

import android.util.Log;

/**
 * @author cxh
 * @description
 * @date 2020/11/5.
 */
public class LogUtils {
    public static final  boolean DEBUG = true;

    public static void printError(String tag,String message){
        if (DEBUG){
            Log.e(tag,message);
        }
    }


    public static void printError(String message){
        if (DEBUG){
            Log.e(message.getClass().getName(),message);
        }
    }


    public static void printDebug(String message){
        if (DEBUG){
            Log.d(message.getClass().getName(),message);
        }
    }

}
