package com.zhuisu.fastdev.ui.onlinecar

import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.text.TextUtils
import android.util.ArrayMap
import android.util.Log
import android.widget.TextView
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.zhuisu.fastdev.BaseActivity
import com.zhuisu.fastdev.adapter.lackhistoryge.DebugCarRainMessageAdapter
import com.zhuisu.fastdev.adapter.lackhistoryge.DebugCarRainMessageBean
import com.zhuisu.fastdev.adapter.lackhistoryge.ProblemCloseAdapter
import com.zhuisu.fastdev.adapter.online.OnLineDeAdapter
import com.zhuisu.fastdev.adapter.online.OnLineMissAdapter
import com.zhuisu.fastdev.beans.ProblemCloseBean
import com.zhuisu.fastdev.beans.online.OnLineCarListBean
import com.zhuisu.fastdev.beans.online.OnLineDeHistoryBean
import com.zhuisu.fastdev.beans.online.OnLineMissListBean
import com.zhuisu.fastdev.beans.registercar.RegisterCarDetails
import com.zhuisu.qualityManagement.R
import com.zhuisu.suppliermanagement.util.GlobalVar
import com.zhuisu.suppliermanagement.util.ToastUtils
import okhttp3.*
import org.json.JSONException
import org.json.JSONObject
import java.io.IOException

/**
 * @author cxh
 * @description
 * @date 2020/11/10.
 */
class OnLineCarDetailActivity : BaseActivity() {

    var detailBean: OnLineCarListBean? = null
    var rvDebug: RecyclerView? = null
    var adapter: OnLineDeAdapter? = null
    var rainAdapter : DebugCarRainMessageAdapter? = null
    var deHistoryList: ArrayList<OnLineDeHistoryBean>? = null
    var rvUnClose: RecyclerView? = null
    var unCloseAdapter: ProblemCloseAdapter? = null
    var unCloseList: ArrayList<ProblemCloseBean>? = null
    var missAdapter: OnLineMissAdapter? = null
    var missList: ArrayList<OnLineMissListBean>? = null
    var rvRain : RecyclerView? = null
    private var rainList: ArrayList<DebugCarRainMessageBean>? = null

    companion object {
        const val ACTION_DATA = "action_data"
    }


    override fun initViews() {
        val tv_user_name: TextView = findViewById(R.id.tv_user_name)
        tv_user_name.text = "\t" + GlobalVar.realname
        rvUnClose = findViewById(R.id.rv_un_close_ask)
        unCloseList = ArrayList()
        unCloseAdapter = ProblemCloseAdapter(unCloseList, context)
        unCloseAdapter!!.setShowBottom(false)

        rainList = ArrayList()
        rainAdapter = DebugCarRainMessageAdapter(context,rainList)
        rvRain = findViewById(R.id.rv_rain_message)
        val rainManager = LinearLayoutManager(this)
        rainManager.orientation = LinearLayoutManager.VERTICAL
        rvRain!!.layoutManager = rainManager
        rvRain!!.adapter = rainAdapter

        deHistoryList = ArrayList()
        adapter = OnLineDeAdapter(deHistoryList!!, context)

        detailBean = intent.getParcelableExtra(ACTION_DATA)
        rvDebug = findViewById(R.id.rv_debug_message)
        val layoutManger = LinearLayoutManager(this)
        layoutManger.orientation = LinearLayoutManager.VERTICAL
        rvDebug!!.layoutManager = layoutManger

        val layoutManger2 = LinearLayoutManager(this)
        layoutManger2.orientation = LinearLayoutManager.VERTICAL
        rvUnClose!!.layoutManager = layoutManger2
        rvUnClose!!.adapter = unCloseAdapter
        rvDebug!!.adapter = adapter

        missList = ArrayList()
        val rvMissing: RecyclerView = findViewById(R.id.rv_miss_list)
        val linearManager3 = LinearLayoutManager(this)
        linearManager3.orientation = LinearLayoutManager.VERTICAL
        rvMissing.layoutManager = linearManager3
        missAdapter = OnLineMissAdapter(missList!!, context)
        rvMissing.adapter = missAdapter

        queryDetail() //查询详情
        queryDeMessage() //查询调试历史
        queryUnCloseAsk() //查询未关闭问题
        queryMiss()
    }


    /**
     * 查询缺件
     * */
    fun queryMiss() {
        val map = ArrayMap<String, String>()
        map["carFarmeNo"] = detailBean!!.carFrameNo
        val param = gson.toJson(map)
        val client = OkHttpClient()
        val requestBody = RequestBody.create(JSON, param)
        val request = Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/offlinedebuggingstatus/qmsOfflineStatus/api/missingPartsInfo")
                .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread {
                    Log.d(TAG, "onFailure: 失败")
                }
            }

            override fun onResponse(call: Call, response: Response) {
                val result = response.body()!!.string()
                runOnUiThread {
                    try {
                        Log.e("--->查询缺件", result)
                        val jsonObject = JSONObject(result)
                        if (TextUtils.equals(jsonObject.optString("status"), "0")) {
                            val listType = object : TypeToken<java.util.ArrayList<OnLineMissListBean>>() {}.type
                            missList!!.addAll(Gson().fromJson(jsonObject.optString("data"), listType))
                            missAdapter!!.notifyDataSetChanged()
                        } else
                            showEmptyMessage()

                    } catch (jsonException: JSONException) {
                        jsonException.printStackTrace()
                    }
                }
            }
        })
    }

    /**
     * 查询详情
     * */
    fun queryDetail() {
        val map = ArrayMap<String, String>()
        map["carFarmeNo"] = detailBean!!.carFrameNo
        val param = gson.toJson(map)
        Log.e("获取详情", param)
        val client = OkHttpClient()
        val requestBody = RequestBody.create(JSON, param)
        val request = Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/offlinedebuggingstatus/qmsOfflineStatus/api/carFrameInfo")
                .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread {
                    Log.d(TAG, "onFailure: 失败")
                }
            }

            override fun onResponse(call: Call, response: Response) {
                val result = response.body()!!.string()
                runOnUiThread {
                    try {
                        Log.e("--->获取详情", result)
                        val jsonObject = JSONObject(result)
                        if (jsonObject.optString("status") == "-1") {
                            ToastUtils.show(jsonObject.optString("msg"))
                        } else {
                            val current: RegisterCarDetails = gson.fromJson(jsonObject.optString("data"), RegisterCarDetails::class.java)
                            val tvNumber1: TextView = findViewById(R.id.tv_order_number) //订单号
                            tvNumber1.text = detailBean!!.orderNo
                            val tvNumber5: TextView = findViewById(R.id.tv_date)
                            tvNumber5.text = detailBean!!.startTime

                            val tvNumber2: TextView = findViewById(R.id.tv_random_number)//随车单号
                            tvNumber2.text = current.flowCarNo
                            val tvNumber3: TextView = findViewById(R.id.tv_car_type)//车型
                            val tvNumber4: TextView = findViewById(R.id.tv_low_number)
                            val tvNumber6: TextView = findViewById(R.id.tv_console)

                            tvNumber4.text = current.carFarmeNo
                            tvNumber5.text = current.createDate

                            if (current.qmsManufactureProductionplan != null) {
                                tvNumber3.text = current.qmsManufactureProductionplan.carModelNo
                                tvNumber6.text = current.qmsManufactureProductionplan.configDesc
                            } else {
                                tvNumber3.text = ""
                                tvNumber6.text = ""
                            }
                        }

                    } catch (jsonException: JSONException) {
                        jsonException.printStackTrace()
                    }
                }
            }
        })
    }


    /**
     * 查询未关闭问题
     * */
    fun queryUnCloseAsk() {
        val map = ArrayMap<String, Any>()
        map["problemSource"] = "" //offLineCheck
        map["problemLevel"] = ""
        map["beginOccurTime"] = ""
        map["endOccurTime"] = ""
        map["peoblemTitle"] = ""
        map["feedbackUser"] = ""
        map["carFrameNo"] = detailBean!!.carFrameNo
        map["pageNo"] = 1
        map["pageSize"] = 100


        val param = gson.toJson(map)

        Log.e("未关闭问题参数", param)
        val client = OkHttpClient()
        val requestBody = RequestBody.create(JSON, param)
        val request = Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/checkfaildflow/qmsManufactureProblemflow/api/notCloseProblemPage")
                .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.d(TAG, "onFailure: 失败")
            }

            @Throws(IOException::class)
            override fun onResponse(call: Call, response: Response) {
                val result = response.body()!!.string()
                runOnUiThread {
                    try {
                        Log.e("未关闭问题数据", result)
                        val jsonObject = JSONObject(result)
                        if (jsonObject.optString("retCode") == "0") {
                            if (jsonObject.optJSONObject("data").optString("list") != null && !TextUtils.isEmpty(jsonObject.optJSONObject("data").optString("list"))) {
                                unCloseList!!.addAll(gson.fromJson(jsonObject.optJSONObject("data").optString("list"), object : TypeToken<List<ProblemCloseBean?>?>() {}.type))
                                unCloseAdapter!!.notifyDataSetChanged()
                            } else {
                                if (unCloseAdapter != null) unCloseAdapter!!.notifyDataSetChanged()
//                                ToastUtils.show("未关闭问题数据")
                            }
                        } else {
                            ToastUtils.show(jsonObject.optString("retMessage"))
                        }
                    } catch (jsonException: JSONException) {
                        jsonException.printStackTrace()
                    }
                }
            }
        })
    }

    /**
     * 查询调试信息
     * */
    fun queryDeMessage() {
        val map = ArrayMap<String, String>()
        map["carFarmeNo"] = detailBean!!.carFrameNo
//        map["carFarmeNo"] = "MJ197419"
        val param = gson.toJson(map)
        Log.e("调试历史参数", param)
        val client = OkHttpClient()
        val requestBody = RequestBody.create(JSON, param)
        val request = Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/offlinedebuggingstatus/qmsOfflineStatus/api/statusHistory")
                .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread {
                    Log.d(TAG, "onFailure: 失败")
                }
            }

            override fun onResponse(call: Call, response: Response) {
                val result = response.body()!!.string()
                runOnUiThread {
                    try {
                        Log.e("调试历史--->", result)
                        val jsonObject = JSONObject(result)
                        if (TextUtils.equals(jsonObject.optString("status"), "0") && jsonObject.optJSONArray("data") != null) {
                            if (jsonObject.optJSONArray("data").opt(0) != null){
                                val listType = object : TypeToken<java.util.ArrayList<OnLineDeHistoryBean>>() {}.type
                                deHistoryList!!.addAll(Gson().fromJson(jsonObject.optJSONArray("data").opt(0).toString(), listType))
                                adapter!!.notifyDataSetChanged()
                            }

                            if (jsonObject.optJSONArray("data").opt(1) != null){
                                val listType = object : TypeToken<java.util.ArrayList<DebugCarRainMessageBean>>() {}.type
                                rainList!!.clear()
                                rainList!!.addAll(Gson().fromJson(jsonObject.optJSONArray("data").opt(1).toString(), listType))
                                rainAdapter?.notifyDataSetChanged()
                            }

                        }

                    } catch (jsonException: JSONException) {
                        jsonException.printStackTrace()
                    }
                }
            }
        })
    }

    override fun getResId(): Int {
        return R.layout.activity_online_car_detail
    }



}