package com.zhuisu.fastdev.ui.rain

import android.content.Intent
import android.os.Handler
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.text.TextUtils
import android.util.ArrayMap
import android.util.Log
import android.view.View
import android.widget.*
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.zhuisu.fastdev.BaseActivity
import com.zhuisu.fastdev.adapter.rain.RainDetailHostoryAdapter
import com.zhuisu.fastdev.beans.rain.RainHistoryListBean
import com.zhuisu.fastdev.beans.rain.RainListBean
import com.zhuisu.fastdev.view.NewSpinner
import com.zhuisu.fastdev.view.SmartTextView
import com.zhuisu.qualityManagement.R
import com.zhuisu.suppliermanagement.util.GlobalVar
import com.zhuisu.suppliermanagement.util.ToastUtils
import okhttp3.*
import org.json.JSONException
import org.json.JSONObject
import java.io.IOException
import java.util.*

/**
 * @author cxh
 * @description
 * @date 2020/10/23.
 */
class RainDetailActivity : BaseActivity(), RainDetailHostoryAdapter.OnDetailsClickListener {
    private var listBean: RainListBean? = null
    private var recyclerview: RecyclerView? = null
    private var adapter: RainDetailHostoryAdapter? = null
    private var list: MutableList<RainHistoryListBean>? = null
    private var btn_rain_successful //淋雨确认
            : Button? = null
    private var spType: NewSpinner? = null
    private var isSelectType = false

    override fun initViews() {

        spType = findViewById(R.id.sp_type)
        recyclerview = findViewById(R.id.recyclerview)
        btn_rain_successful = findViewById(R.id.btn_rain_successful)
        btn_rain_successful!!.setOnClickListener {

            if (!isSelectData) {
                ToastUtils.show("请先选择驾驶室类型")
                return@setOnClickListener
            }

            commitData()
        }



        list = ArrayList()
        adapter = RainDetailHostoryAdapter(list, context)
        val linearLayoutManager = LinearLayoutManager(context)
        linearLayoutManager.orientation = LinearLayoutManager.VERTICAL
        recyclerview!!.isNestedScrollingEnabled = false
        recyclerview!!.layoutManager = linearLayoutManager
        recyclerview!!.adapter = adapter
        adapter!!.setOnDetailsClickListener(this)
        if (intent != null && intent.hasExtra(ACTION_VALUE_DATA)) {
            listBean = intent.getParcelableExtra(ACTION_VALUE_DATA)
            val tvOrderNumber: SmartTextView = findViewById(R.id.tv_dingdanhao) //订单号
            val tvRandomNumber: SmartTextView = findViewById(R.id.tv_suichedanhao) //随车单号
            val tvCarNumber: SmartTextView = findViewById(R.id.tv_car_number) //车架号
            val tvCarType: SmartTextView = findViewById(R.id.tv_car_type) //车型号
            val tvInfo: SmartTextView = findViewById(R.id.tv_info) //配置
            val tvTime: SmartTextView = findViewById(R.id.tv_up_time) //上线时间
            if (listBean?.qmsManufactureProductionplan != null) {
                tvOrderNumber.setText(listBean!!.qmsManufactureProductionplan.orderNo)
            }
            tvRandomNumber.setText(listBean?.flowCarNo)
            tvCarNumber.setText(listBean!!.carFarmeNo)
            if (listBean?.qmsManufactureProductionplan != null) {
                tvCarType.setText(listBean!!.qmsManufactureProductionplan.carModelNo)
            }
            if (listBean?.qmsManufactureProductionplan != null) {
                tvInfo.setText(listBean!!.qmsManufactureProductionplan.configDesc)
            }
            tvTime.setText(listBean!!.createDate)

            if (listBean!!.rainCount == null) {
                findViewById<LinearLayout>(R.id.ll_type).visibility = View.VISIBLE
                isSelectType = true

            } else {
                isSelectData = true
            }

            if (listBean!!.rainCount != null && TextUtils.equals("0", listBean!!.rainCount)) {
                findViewById<LinearLayout>(R.id.ll_type).visibility = View.VISIBLE
                isSelectType = true

            } else {
                isSelectData = true
            }
        }




        spType!!.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {
                Log.d("", "");
            }

            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {

                if (isSpinnerFirst) {
                    // 初始化时不显示
                    view?.visibility = View.INVISIBLE
                } else {
                    // 手动选择后显示布局
                    view?.visibility = View.VISIBLE
                    isSelectData = true
                }

                isSpinnerFirst = false
            }
        }

        queryType()


    }

    var isSelectData = false
    var isSpinnerFirst = true

    data class RainType(var id: String, var label: String, var value: String) {
        override fun toString(): String {
            return label
        }
    }


    /**
     * 查询字典
     * */
    var dictList: ArrayList<RainType>? = null
    fun queryType() {
        val map = ArrayMap<String, String>()
        map["type"] = "RAIN_BRIDGE_TYPE"
        val param = gson.toJson(map)
        Log.e("字典参数", param)
        val client = OkHttpClient()
        val requestBody = RequestBody.create(JSON, param)
        val request = Request.Builder()
            .post(requestBody)
            .url(GlobalVar.url + "a/common/util/api/getDict")
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread {
                    Log.d(TAG, "onFailure: 失败")
                }
            }

            override fun onResponse(call: Call, response: Response) {
                val result = response.body()!!.string()
                runOnUiThread {
                    try {
                        Log.e("--->驾驶室类型", result)
                        val jsonObject = JSONObject(result)
                        if (TextUtils.equals(jsonObject.optString("retCode"), "0")) {
                            val listType = object : TypeToken<ArrayList<RainType>>() {}.type
                            dictList = Gson().fromJson(jsonObject.optString("data"), listType)
                            val arr = ArrayAdapter(context, R.layout.simple_textview1, dictList)
                            spType!!.adapter = arr
                        } else
                            showEmptyMessage()

                    } catch (jsonException: JSONException) {
                        jsonException.printStackTrace()
                    }
                }
            }
        })
    }

    override fun onResume() {
        super.onResume()
        query()
    }

    private fun commitData() {
//        if (list != null && !list.isEmpty()) {
        val map = ArrayMap<String, String>()
        map["carFarmeNo"] = listBean!!.carFarmeNo
        map["userName"] = GlobalVar.username

        if (isSelectType) {
            map["rainBridgeType"] = dictList!![spType!!.selectedItemPosition].value
        }
        val param = gson.toJson(map)
        showCommitDialog()
        val client = OkHttpClient()
        val requestBody = RequestBody.create(JSON, param)
        val request = Request.Builder()
            .post(requestBody)
            .url(GlobalVar.url + "a/offlinedebuggingstatus/qmsOfflineStatus/api/rainOperator")
            .build()
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.d(TAG, "onFailure: 失败")
                runOnUiThread {
                    showNetErrorMessage()
                    cancelDialog()
                }
            }

            @Throws(IOException::class)
            override fun onResponse(call: Call, response: Response) {
                val result = response.body()!!.string()
                runOnUiThread {
                    try {
                        cancelDialog()
                        Log.e("淋雨result", result)
                        val jsonObject = JSONObject(result)
                        if (jsonObject.optString("status") == "0") {
                            runOnUiThread {
                                ToastUtils.show("成功")
                                Handler().postDelayed({ finish() }, 1500)
                            }
                        } else {
                            ToastUtils.show(jsonObject.optString("msg"))
                        }
                    } catch (e: JSONException) {
                        e.printStackTrace()
                    }
                }
            }
        })
        //        }
    }

    override fun getResId(): Int {
        return R.layout.activity_rain_detail
    }

    fun query() {
        list!!.clear()
        val map = ArrayMap<String, String>()
        map["carFarmeNo"] = listBean!!.carFarmeNo
        map["pageNo"] = "1"
        map["pageSize"] = "11111"
        val param = gson.toJson(map)
        val client = OkHttpClient()
        val requestBody = RequestBody.create(JSON, param)
        val request = Request.Builder()
            .post(requestBody)
            .url(GlobalVar.url + "a/offlinedebuggingstatus/qmsOfflineStatus/api/showAllRainRecord")
            .build()
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.d(TAG, "onFailure: 失败")
            }

            @Throws(IOException::class)
            override fun onResponse(call: Call, response: Response) {
                val result = response.body()!!.string()
                runOnUiThread { showlistBean(result) }
            }
        })
    }

    private fun showlistBean(result: String) {
        Log.d(TAG, "onResponse: 淋雨记录列表$result")
        try {
            val jsonObject = JSONObject(result)
            if (jsonObject.optString("status") == "0") {
                list!!.addAll(
                    gson.fromJson(
                        jsonObject.optJSONObject("data").optString("list"),
                        object : TypeToken<List<RainHistoryListBean?>?>() {}.type
                    )
                )
                adapter!!.notifyDataSetChanged()
            }
        } catch (e: JSONException) {
            e.printStackTrace()
        }
    }

    companion object {
        const val ACTION_VALUE_DATA = "action_value_listBean"
    }

    override fun onDetailsClickListener(position: Int) {
        val intent = Intent(context, RainFailureDetailActivity::class.java)
        intent.putExtra(RainFailureDetailActivity.ACTION_ID, list!![position].id)
        startActivity(intent)
    }

}