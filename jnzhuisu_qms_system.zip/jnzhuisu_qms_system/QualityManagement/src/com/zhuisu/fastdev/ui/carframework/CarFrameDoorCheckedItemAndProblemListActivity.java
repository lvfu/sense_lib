package com.zhuisu.fastdev.ui.carframework;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.ArrayMap;
import android.util.Log;
import android.view.View;
import android.widget.ListView;
import android.widget.TextView;

import com.google.gson.reflect.TypeToken;
import com.zhuisu.fastdev.BaseActivity;
import com.zhuisu.fastdev.adapter.carframe.CarFrameCheckedAndProblemAdapter;
import com.zhuisu.fastdev.adapter.carframe.CarFrameCheckedProblemAdapter;
import com.zhuisu.fastdev.adapter.lackhistoryge.QualityCheckedProblemAdapter;
import com.zhuisu.fastdev.adapter.zhiliangmen.QualityCheckedAndProblemAdapter;
import com.zhuisu.fastdev.beans.ProblemCloseBean;
import com.zhuisu.fastdev.beans.consolework.ConsoleProjectList;
import com.zhuisu.fastdev.beans.zhiliangmen.ZhiLiangMenWeiJianFirstBean;
import com.zhuisu.fastdev.ui.problemquery.ProblemQueryForDoorLJHTQualityActivity;
import com.zhuisu.fastdev.ui.problemquery.ProblemQueryQualityActivity;
import com.zhuisu.fastdev.ui.zhiliangmen.ZhiLiangMenWeiJianMingXingActivity;
import com.zhuisu.fastdev.view.FastTitleLayout;
import com.zhuisu.qualityManagement.R;
import com.zhuisu.suppliermanagement.util.GlobalVar;
import com.zhuisu.suppliermanagement.util.ToastUtils;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 * 质量门已检
 */
public class CarFrameDoorCheckedItemAndProblemListActivity extends BaseActivity {

    private List<ZhiLiangMenWeiJianFirstBean> list;
    private ListView listview;
    private CarFrameCheckedAndProblemAdapter adapter;
    public static final String ACTION_DATA = "action";
    private ConsoleProjectList data;
    private ArrayList<ProblemCloseBean> unCloseList;
    private CarFrameCheckedProblemAdapter unCloseAdapter = null;
    private TextView tvConfig;

    @SuppressLint("SetTextI18n")
    @Override
    protected void initViews() {
        list = new ArrayList<>();
        adapter = new CarFrameCheckedAndProblemAdapter(list, context);
        listview = findViewById(R.id.listview);
        listview.setAdapter(adapter);

        RecyclerView rvUnClose = findViewById(R.id.rv_un_close_ask);
        unCloseList = new ArrayList<>();
        unCloseAdapter = new CarFrameCheckedProblemAdapter(unCloseList, context);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(context);
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        rvUnClose.setLayoutManager(linearLayoutManager);
        rvUnClose.setAdapter(unCloseAdapter);

        tvConfig = findViewById(R.id.tv_config);
        TextView tv_user_name = findViewById(R.id.tv_user_name);
        tv_user_name.setText("\t" + GlobalVar.realname);

        if (getIntent() != null && getIntent().hasExtra("url")) {
            FastTitleLayout fa = findViewById(R.id.fast);
            fa.setTitle(getIntent().getStringExtra("url"));
        }

        if (getIntent() != null && getIntent().getParcelableExtra(ACTION_DATA) != null) {
            data = getIntent().getParcelableExtra(ACTION_DATA);
            TextView tvCarFrame = findViewById(R.id.tv_carnumber);
            tvCarFrame.setText(data.getCarframeNo());

            findViewById(R.id.btn_ask).setOnClickListener(v -> {
                //问题列表
                Intent notCloseIntent = new Intent(context, ProblemQueryForDoorLJHTQualityActivity.class);
                notCloseIntent.putExtra("data", data.getCarframeNo());
                startActivity(notCloseIntent);
            });
        }
        findViewById(R.id.btn_all_success).setVisibility(View.GONE);
    }

    /**
     * 查询详情
     */
    private void queryUnCloseAsk() {
        unCloseList.clear();
        unCloseAdapter.notifyDataSetChanged();

//        ArrayMap<String, String> map = new ArrayMap<>();
//        map.put("id", data.getId());
//        map.put("loginName",GlobalVar.username);
//        String param = gson.toJson(map);
//        Log.e("明细参数",param);
//        OkHttpClient client = new OkHttpClient();
//        RequestBody requestBody = RequestBody.create(JSON, param);
//        Request request = new Request.Builder()
//                .post(requestBody)
//                .url(GlobalVar.url + "a/prduictionrelation/qmsManufactureProductionplanrelation/api/getCheckItemDetail")
//                .build();
//
//        client.newCall(request).enqueue(new Callback() {
//            @Override
//            public void onFailure(Call call, IOException e) {
//                Log.d(TAG, "onFailure: 失败");
//            }
//
//            @Override
//            public void onResponse(Call call, Response response) throws IOException {
//                final String result = response.body().string();
//                Log.d(TAG, "onResponse: 明细" + result);
//                runOnUiThread(() -> {
//
//                });
//            }
//        });

        ArrayMap<String, Object> map = new ArrayMap<>();
        map.put("carframeNo", data.getCarframeNo());  //offLineCheck
        map.put("loginName", GlobalVar.username);
        String param = gson.toJson(map);

        Log.e("查询问题", param);
        OkHttpClient client = new OkHttpClient();
        RequestBody requestBody = RequestBody.create(JSON, param);
        Request request = new Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/checkfaildflow/qmsManufactureProblemflow/api/getProblemByCarFrameNo")
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                Log.d(TAG, "onFailure: 失败");
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                String result = response.body().string();
                runOnUiThread(() -> {
                    try {
                        Log.e("未关闭问题数据", result);

                        JSONObject jsonObject = new JSONObject(result);
                        if (jsonObject.optString("retCode").equals("0")) {
                            if (jsonObject.optString("data") != null && !jsonObject.optString("data").isEmpty()) {

                                JSONArray jsonArray = jsonObject.optJSONArray("data");
                                for (int i = 0; i < jsonArray.length(); i++) {

                                    JSONObject problemData = jsonArray.optJSONObject(i);
                                    if (problemData.optString("createBy").equals(GlobalVar.realname)){
                                        ProblemCloseBean bean = new ProblemCloseBean();
                                        bean.setPeoblemTitle(problemData.optString("problemTitle"));
                                        bean.setProblemDesc(problemData.optString("problemDesc"));
                                        bean.setId(problemData.optString("problemId"));
                                        bean.setCreateBy(problemData.optString("createBy"));
                                        bean.setProblemSource("assemble_quality_door");
                                        unCloseList.add(bean);
                                    }

                                }
                            }
                            unCloseAdapter.notifyDataSetChanged();
                        } else {
                            ToastUtils.show(jsonObject.optString("retMessage"));
                        }
                    } catch (Exception jsonException) {
                        jsonException.printStackTrace();
                    }
                });
            }
        });
    }

    /**
     * 查询详情
     * */
    private void queryDetail() {

        ArrayMap<String, Object> map = new ArrayMap<>();
        map.put("carFrameNo", data.getCarframeNo());  //offLineCheck
        String param = gson.toJson(map);

        Log.e("查询详情", param);
        OkHttpClient client = new OkHttpClient();
        RequestBody requestBody = RequestBody.create(JSON, param);
        Request request = new Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/assemblyprocess/qmsManufactureProductionplan/api/getFlowCarNoByCarFramno")
                .build();


        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                Log.d(TAG, "onFailure: 失败");
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                String result = response.body().string();
                runOnUiThread(() -> {
                    try {
                        Log.e("未关闭问题数据", result);

                        JSONObject jsonObject = new JSONObject(result);
                        if (jsonObject.optString("retCode").equals("0")) {
                            if (jsonObject.optString("data") != null && !jsonObject.optString("data").isEmpty()) {
                                tvConfig.setText(jsonObject.optJSONObject("data").optString("configDesc"));

                                TextView tvOrder = findViewById(R.id.tv_dingdan);
                                tvOrder.setText(jsonObject.optJSONObject("data").optString("orderNo"));
                                TextView tvType = findViewById(R.id.tv_car_type);
                                tvType.setText(jsonObject.optJSONObject("data").optString("carModelNo"));
                            }
                        } else {
                            ToastUtils.show(jsonObject.optString("retMessage"));
                        }
                    } catch (Exception jsonException) {
                        jsonException.printStackTrace();
                    }
                });
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        queryData();
        queryDetail();
        queryUnCloseAsk();
    }

    @Override
    protected int getResId() {
        return R.layout.activity_car_frame_checked;
    }

    private void queryData() {
        if (list != null) {
            list.clear();
            adapter.notifyDataSetChanged();
        }
        ArrayMap<String, String> map = new ArrayMap<>();
        map.put("carframeNo", data.getCarframeNo());
        map.put("loginName", GlobalVar.username);
        map.put("checkedType", "checked");//未检 checked 检验
        String param = gson.toJson(map);
        Log.e("-->", param);
        OkHttpClient client = new OkHttpClient();
        RequestBody requestBody = RequestBody.create(JSON, param);
        Request request = new Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/prduictionrelation/qmsManufactureProductionplanrelation/api/qryCheckItems")
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                Log.d(TAG, "onFailure: 失败");
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                final String result = response.body().string();
                Log.d(TAG, "onResponse: " + result);
                runOnUiThread(() -> showData(result));
            }
        });

    }


    private void showData(String result) {
        try {
            Log.e("--->", result);
            JSONObject jsonObject = new JSONObject(result);
            if (jsonObject.optString("data") != null) {
                list.addAll(gson.fromJson(jsonObject.optString("data"), new TypeToken<List<ZhiLiangMenWeiJianFirstBean>>() {
                }.getType()));
                adapter.notifyDataSetChanged();
                if (list == null || list.isEmpty()) {
                    ToastUtils.show("暂无数据");
                }

                adapter.setOnItemClick(position -> {
                    Intent intent = new Intent(context, CarFrameNotCheckDetailActivity.class);
                    intent.putExtra(CarFrameNotCheckDetailActivity.ACTION_DETAIL_DATA, list.get(position));
                    intent.putExtra(CarFrameNotCheckDetailActivity.ACTION_CHECKSUCCESS, true);
                    startActivity(intent);
                });
            } else {
                ToastUtils.show("暂无数据");
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

}