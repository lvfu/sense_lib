package com.zhuisu.fastdev.ui.TempTaskUpload

/**
 * @author cxh
 * @description
 * @date 2021/2/4.
 */
data class SendDeptBean(var supcode : String? ,var supnm : String , var supsnm : String ,var id : String?,var bizLicense : String?){
    override fun toString(): String {
        return supcode +"\n\n"+supsnm
    }
}
