package com.zhuisu.fastdev.ui.payask

import android.util.ArrayMap
import android.util.Log
import android.widget.TextView
import com.google.gson.reflect.TypeToken
import com.zhuisu.fastdev.BaseActivity
import com.zhuisu.fastdev.beans.PayAskQueryListBean
import com.zhuisu.qualityManagement.R
import com.zhuisu.suppliermanagement.util.GlobalVar
import com.zhuisu.suppliermanagement.util.ToastUtils
import okhttp3.*
import org.json.JSONObject
import java.io.IOException

/**
 * @author cxh
 * @description
 * @date 2021/4/14.
 */
class PayTaskDetailActivity : BaseActivity() {
    private var id = ""
    companion object{
        val ID : String? = ""
    }
    override fun initViews() {
        id = intent?.getStringExtra(ID).toString()
        query()
    }


    private fun query(){
        val map = ArrayMap<String, Any>()
        map["userName"] = GlobalVar.username
        map["id"] = id
        val param = gson.toJson(map)
        showLoadingDialog()
        Log.e("查询", param)
        val client = OkHttpClient()
        val requestBody = RequestBody.create(JSON, param)
        val request = Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/nonconforming/qmsPurchasecheckUnqualifiedRecord/api/getUnqualifyRecord")
                .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread {
                    ToastUtils.show("请求失败")
                    cancelLoadingDialog()
                }
            }

            override fun onResponse(call: Call, response: Response) {
                val result = response.body()!!.string()
                runOnUiThread {
                    Log.e("result", result)
                    cancelLoadingDialog()
                    val json = JSONObject(result)
                    if (json.optString("retCode").equals("0") && json.optJSONObject("data") != null) {
                        val jsonData = json.optJSONObject("data")
                        val tvNotingNumber : TextView = findViewById(R.id.tv_buhegedanhao)
                        tvNotingNumber.setText(jsonData.optString("billCode"))

                        val tv_daohuodanhao : TextView = findViewById(R.id.tv_daohuodanhao)
                        tv_daohuodanhao.setText(jsonData.optString("receiveBillcode"))

                        val tv_wuliaobianhao : TextView = findViewById(R.id.tv_wuliaobianhao)
                        tv_wuliaobianhao.setText(jsonData.optString("materialCode"))

                        val tv_wuliao_mingcheng : TextView = findViewById(R.id.tv_wuliao_mingcheng)
                        tv_wuliao_mingcheng.setText(jsonData.optString("itemName"))

                        val tv_gongyingshangbianhao : TextView = findViewById(R.id.tv_gongyingshangbianhao)
                        tv_gongyingshangbianhao.setText(jsonData.optString("supplierNo"))


                        val tv_gongyingshangmingcheng : TextView = findViewById(R.id.tv_gongyingshangmingcheng)
                        tv_gongyingshangmingcheng.setText(jsonData.optString("supplierName"))

                        val tv_laiyuan : TextView = findViewById(R.id.tv_laiyuan)
                        tv_laiyuan.setText(if (jsonData.optString("datasource").equals("wzk")) "物资库" else "其他")

                        val tv_daohuoriiqi : TextView = findViewById(R.id.tv_daohuoriiqi)
                        tv_daohuoriiqi.setText(jsonData.optString("createDate"))

                        val tv_buhegemiaoshu : TextView = findViewById(R.id.tv_buhegemiaoshu)
                        tv_buhegemiaoshu.setText(jsonData.optString("unqualifiedDescription"))

                        val tv_jianyanren : TextView = findViewById(R.id.tv_jianyanren)
                        tv_jianyanren.setText(jsonData.optString("checkUser"))

                        val tv_jianyanshijian : TextView = findViewById(R.id.tv_jianyanshijian)
                        tv_jianyanshijian.setText(jsonData.optString("checkTime"))

                        val tv_songjianshuliang : TextView = findViewById(R.id.tv_songjianshuliang)
                        tv_songjianshuliang.setText(jsonData.optString("submitCheckNum"))

                        val tv_choujianshuliang : TextView = findViewById(R.id.tv_choujianshuliang)
                        tv_choujianshuliang.setText(jsonData.optString("samplingNum"))

                        val tv_zjkw : TextView = findViewById(R.id.tv_zjkw)
                        tv_zjkw.setText(jsonData.optString("checkposition"))


                    }
                }
            }

        })
    }
    override fun getResId(): Int {
        return R.layout.activity_pay_query_detail
    }
}