package com.zhuisu.fastdev.ui.worktime

import com.zhuisu.fastdev.BaseActivity
import com.zhuisu.qualityManagement.R

/**
 * @author cxh
 * @description
 * @date 2021/3/12.
 */
class WorkTimeCanUpdateDetailActivity : BaseActivity() {
    override fun initViews() {

    }

    override fun getResId(): Int {
        return R.layout.activity_work_time_can_update_details
    }
}