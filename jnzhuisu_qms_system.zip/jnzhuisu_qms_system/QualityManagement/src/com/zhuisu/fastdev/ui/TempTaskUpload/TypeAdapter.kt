package com.zhuisu.fastdev.ui.TempTaskUpload

import android.content.Context
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.RadioButton
import com.zhuisu.qualityManagement.R

/**
 * @author cxh
 * @description
 * @date 2021/2/4.
 */
class TypeAdapter(typeList : ArrayList<TypeListBean>,context : Context) : BaseAdapter() {

    private var typeList : ArrayList<TypeListBean>? = null
    private var context : Context? = null
    var onCheckChangeListener : OnCheckChangeListener? = null

    init {
        this.typeList = typeList
        this.context = context
    }
    override fun getCount(): Int {
        return if (typeList == null) 0 else typeList!!.size
    }

    override fun getItem(position: Int): Any {
        return position
    }

    override fun getItemId(position: Int): Long {
        return position.toLong()
    }

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        var vh : VH
        var view = convertView
        if (view == null){
            vh = VH()
            view = View.inflate(context, R.layout.item_temp_task_upload,null)
            vh.radioButton = view!!.findViewById(R.id.rb_btn)
            view.tag = vh
        }
        vh = view.tag as VH
        vh.radioButton!!.text = typeList!![position].label
        vh.radioButton!!.setOnCheckedChangeListener { _, isChecked ->
            if (onCheckChangeListener != null){
                if (isChecked){
                    for (index in typeList!!.indices){
                        typeList!![index].isChecked = false
                    }
                }
                typeList!![position].isChecked = isChecked
                onCheckChangeListener!!.onCheckChangeListener(position)
            }

        }

        vh.radioButton!!.isChecked = typeList!![position].isChecked
        return view
    }

    inner class VH{
        var radioButton : RadioButton? = null
    }

    public interface OnCheckChangeListener{
        fun onCheckChangeListener(position: Int)
    }
}