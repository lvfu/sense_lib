package com.zhuisu.fastdev.ui.problem

import android.annotation.SuppressLint
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Bundle
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.text.TextUtils
import android.util.ArrayMap
import android.util.Log
import android.view.View
import android.widget.EditText
import android.widget.TextView
import com.google.gson.reflect.TypeToken
import com.zhuisu.fastdev.BaseActivity
import com.zhuisu.fastdev.adapter.lackhistoryge.ProblemCloseAdapter
import com.zhuisu.fastdev.beans.ProblemCloseBean
import com.zhuisu.fastdev.dialog.BasePopupWindowDialog
import com.zhuisu.fastdev.ui.lackhistory.CloseLackDetailActivity
import com.zhuisu.fastdev.ui.util.BroadCastConfig
import com.zhuisu.qualityManagement.R
import com.zhuisu.suppliermanagement.base.CaptureActivity
import com.zhuisu.suppliermanagement.util.GlobalVar
import com.zhuisu.suppliermanagement.util.ToastUtils
import okhttp3.*
import org.json.JSONException
import org.json.JSONObject
import java.io.IOException
import java.util.*

/**
 * @author cxh
 * @description 下线模块问题列表
 * @date 2020/11/2.
 */
class OffLineProblemListActivity : BaseActivity() {
    private var recyclerView: RecyclerView? = null
    private var tv_cjh: EditText? = null
    private var adapter: ProblemCloseAdapter? = null
    private var listBeans: MutableList<ProblemCloseBean>? = null
    private var etProblemmTitle : EditText? = null
    private var id = ""
    private val broadCast : BroadCastChange = BroadCastChange()
    val filter : IntentFilter = IntentFilter(BroadCastConfig.BROADCAST_ACTION)

    inner class BroadCastChange : BroadcastReceiver(){
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent != null && intent.action != null && intent.action == BroadCastConfig.BROADCAST_ACTION){
                tv_cjh!!.setText(intent.extras!!.getString(BroadCastConfig.BROADCAST_ACTION_TAG))
                tv_cjh!!.setSelection(tv_cjh!!.text.toString().length)
            }
        }
    }

    @SuppressLint("SetTextI18n")
    override fun initViews() {
        listBeans = ArrayList()

        val tvName = findViewById<TextView>(R.id.tv_user_name)
        tvName.text = "\t" + GlobalVar.realname
        etProblemmTitle = findViewById(R.id.et_problem);
        recyclerView = findViewById(R.id.recyclerview_lack)
        val linearLayoutManager = LinearLayoutManager(context)
        linearLayoutManager.orientation = LinearLayoutManager.VERTICAL
        recyclerView!!.layoutManager = linearLayoutManager
        adapter = ProblemCloseAdapter(listBeans, context)
        recyclerView!!.adapter = adapter
        adapter!!.setOnCloseMenuClickListener { position: Int ->
            if (TextUtils.equals(listBeans!![position].problemSource, "missing_parts")) {
                val intent = Intent(context, CloseLackDetailActivity::class.java)
                intent.putExtra("id", listBeans!!.get(position).id)
                startActivity(intent)
                return@setOnCloseMenuClickListener
            }
            val intent = Intent(context, ProblemDetailActivity::class.java)
            intent.putExtra(ProblemDetailActivity.REQUEST_DATA, listBeans!![position])
            intent.putExtra(ProblemDetailActivity.ACTION_FINISH_CHECK_JUMP,false)
            startActivity(intent)
        }
        tv_cjh = findViewById(R.id.tv_cjh)

        if (intent != null && intent.getStringExtra(ACTION_PARAMS) != null) {
            tv_cjh!!.setText(intent.getStringExtra(ACTION_PARAMS))
            id = intent.getStringExtra(ACTION_ID)
        }

        filter.priority = Int.MAX_VALUE
        registerReceiver(broadCast,filter)
    }

    override fun onDestroy() {
        super.onDestroy()
        unregisterReceiver(broadCast)
    }



    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1073 && resultCode == RESULT_OK) {
            tv_cjh!!.setText(data!!.getStringExtra("encoderesult"))
            query()
        }
    }

    override fun onResume() {
        super.onResume()
        query()
    }

    override fun getResId(): Int {
        return R.layout.activity_offine_problem_close
    }

    private fun query() {
        val map = ArrayMap<String, Any>()

        map["carFrameNo"] = tv_cjh!!.text.toString()
        map["checkItemNo"] = id

        val param = gson.toJson(map)
        Log.e("参数", param)
        val client = OkHttpClient()
        val requestBody = RequestBody.create(JSON, param)
        val request = Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/checkfaildflow/qmsManufactureProblemflow/api/getProblemByCarFrameNoAndCheckItem")
                .build()
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.d(TAG, "onFailure: 失败")
            }

            @Throws(IOException::class)
            override fun onResponse(call: Call, response: Response) {
                val result = response.body()!!.string()
                runOnUiThread { showData(result) }
            }
        })
    }

    private fun showData(result: String) {
        Log.e("--->问题关闭列表", result)
        listBeans!!.clear()
        try {
            val jsonObject = JSONObject(result)
            if (jsonObject.optString("retCode") == "0") {
                if (jsonObject.optString("data") != null && !TextUtils.isEmpty(jsonObject.optString("data"))) {
                    listBeans!!.addAll(gson.fromJson(jsonObject.optString("data"), object : TypeToken<List<ProblemCloseBean?>?>() {}.type))
                    adapter!!.notifyDataSetChanged()
                } else {
                    if (adapter != null) adapter!!.notifyDataSetChanged()
                    ToastUtils.show("暂无数据")
                }
            } else {
                ToastUtils.show(jsonObject.optString("retMessage"))
                adapter!!.notifyDataSetChanged()
            }
        } catch (jsonException: JSONException) {
            jsonException.printStackTrace()
        }
    }

    companion object {
        const val ACTION_PARAMS = "action_params"
        const val ACTION_ID = "action_id"
    }
}