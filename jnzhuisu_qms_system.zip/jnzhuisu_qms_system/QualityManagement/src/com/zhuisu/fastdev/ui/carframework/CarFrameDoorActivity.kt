package com.zhuisu.fastdev.ui.carframework

import android.annotation.SuppressLint
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.text.TextUtils
import android.util.ArrayMap
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.zhuisu.fastdev.BaseActivity
import com.zhuisu.fastdev.adapter.carframe.CarFrameDoorCheckItemAndProblemListActivity
import com.zhuisu.fastdev.adapter.carframe.CarFrameNotCheckAdapter
import com.zhuisu.fastdev.beans.consolework.ConsoleProjectList
import com.zhuisu.fastdev.ui.util.BroadCastConfig
import com.zhuisu.fastdev.view.FastTitleLayout
import com.zhuisu.qualityManagement.R
import com.zhuisu.suppliermanagement.base.CaptureActivity
import com.zhuisu.suppliermanagement.util.GlobalVar
import okhttp3.*
import org.json.JSONException
import org.json.JSONObject
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit
import kotlin.collections.ArrayList

/**
 * @author cxh
 * @description 车架质量门
 * @date 2020/12/22.
 */
class CarFrameDoorActivity : BaseActivity(), CarFrameNotCheckAdapter.OnItemClickListener {

    private var etCarNumber: EditText? = null
    private var list: ArrayList<ConsoleProjectList>? = null
    private var adapter: CarFrameNotCheckAdapter? = null
    var isCarFrameNumer = false

    private val broadCast: BroadCastChange = BroadCastChange()
    val filter: IntentFilter = IntentFilter(BroadCastConfig.BROADCAST_ACTION)

    inner class BroadCastChange : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent != null && intent.action != null && intent.action == BroadCastConfig.BROADCAST_ACTION) {
                etCarNumber!!.setText(intent.extras!!.getString(BroadCastConfig.BROADCAST_ACTION_TAG))
                etCarNumber!!.setSelection(etCarNumber!!.text.toString().length)
                query()
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        unregisterReceiver(broadCast)
    }

    @SuppressLint("SetTextI18n")
    override fun initViews() {
        val tvUserName = findViewById<TextView>(R.id.tv_user_name)
        tvUserName.text = "\t" + GlobalVar.realname

        isCarFrameNumer = intent.getBooleanExtra("isFinish", false)
        val fast: FastTitleLayout = findViewById(R.id.ftl)
        fast.setTitle(if (isCarFrameNumer) "车架质量门作业" else "车身质量门作业")

        etCarNumber = findViewById(R.id.et_barcode)
        list = ArrayList()
        adapter = CarFrameNotCheckAdapter(list!!, context)
        val manager = LinearLayoutManager(context)
        manager.orientation = LinearLayoutManager.VERTICAL
        val rvList: RecyclerView = findViewById(R.id.rv_list)
        rvList.layoutManager = manager
        rvList.adapter = adapter
        adapter!!.onItenClick = this

        findViewById<TextView>(R.id.tv_scanf).setOnClickListener {
            val intent = Intent()
            intent.setClass(context, CaptureActivity::class.java)
            startActivityForResult(intent, 1073)
        }

        findViewById<Button>(R.id.btn_ok).setOnClickListener {
            query()
        }

        filter.priority = Int.MAX_VALUE
        registerReceiver(broadCast, filter)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1073 && resultCode == RESULT_OK) {
            etCarNumber?.setText(data?.getStringExtra("encoderesult"))
        }
    }

    override fun onResume() {
        super.onResume()
        query()
    }

    @SuppressLint("SimpleDateFormat")
    fun query() {
        list!!.clear()
        adapter?.notifyDataSetChanged()

        showLoadingDialog()
        val map = ArrayMap<String, String>()

        map["carframeNo"] = etCarNumber?.text.toString()
        map["loginName"] = GlobalVar.username
        map["checkedType"] = ""
        map["actualOnlineDateStr"] = if (TextUtils.isEmpty(etCarNumber!!.text.toString())) SimpleDateFormat("yyyy-MM-dd").format(Date(System.currentTimeMillis())) else ""
//        map["actualOnlineDateStr"] = "2018-10-09"
        map["productModel"] = if (isCarFrameNumer) "cj" else "cs"
        val param = gson.toJson(map)
        Log.e("参数", param)

        val client = OkHttpClient()
        client.newBuilder().connectTimeout(10000, TimeUnit.SECONDS).readTimeout(10000, TimeUnit.SECONDS)
        val requestBody = RequestBody.create(JSON, param)
        val request = Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/prduictionrelation/qmsManufactureProductionplanrelation/api/qryZLMCheckItems")
                .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread {
                    Log.d(TAG, "onFailure: 失败")
                    cancelLoadingDialog()
                }
            }

            override fun onResponse(call: Call, response: Response) {
                val result = response.body()!!.string()
                runOnUiThread {
                    try {
                        cancelLoadingDialog()
                        Log.e("--->", result)
                        val jsonObject = JSONObject(result)
                        if (TextUtils.equals(jsonObject.optString("retCode"), "0") && jsonObject.optString("data") != null && jsonObject.optString("data").isNotBlank()) {
                            val listType = object : TypeToken<ArrayList<ConsoleProjectList>>() {}.type
                            val temp: ArrayList<ConsoleProjectList> = Gson().fromJson(jsonObject.optString("data"), listType)
                            list!!.addAll(temp)
                            adapter!!.notifyDataSetChanged()
                        } else
                            showEmptyMessage()

                    } catch (jsonException: JSONException) {
                        jsonException.printStackTrace()
                    }
                }
            }
        })
    }

    override fun getResId(): Int {
        return R.layout.activity_car_frame_door_list
    }

    override fun onItemClickListener(position: Int) {

//
//            val jumpIntent = Intent(context!!, CarFrameDoorCheckedItemAndProblemListActivity::class.java)
//            jumpIntent.putExtra(CarFrameDoorCheckedItemAndProblemListActivity.ACTION_DATA, list!![position])
//            jumpIntent.putExtra("url", if (isFinishCheck) "质量门已检" else "质量门作业")
//            startActivity(jumpIntent)

        val jumpIntent = Intent(context!!, CarFrameDoorCheckItemAndProblemListActivity::class.java)
        jumpIntent.putExtra(CarFrameDoorCheckItemAndProblemListActivity.ACTION_DATA, list!![position])
        jumpIntent.putExtra("url", intent?.getStringExtra("title"))
        startActivity(jumpIntent)

    }


}