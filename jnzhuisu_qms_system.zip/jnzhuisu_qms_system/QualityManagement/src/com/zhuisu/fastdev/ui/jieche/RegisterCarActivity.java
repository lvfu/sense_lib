package com.zhuisu.fastdev.ui.jieche;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.os.Handler;
import android.os.Parcelable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.ArrayMap;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import com.google.gson.reflect.TypeToken;
import com.zhuisu.fastdev.BaseActivity;
import com.zhuisu.fastdev.adapter.registercar.RegisterCarListAdapter;
import com.zhuisu.fastdev.beans.registercar.RegisterCarListBean;
import com.zhuisu.fastdev.beans.registercar.RegisterCarLocationListBean;
import com.zhuisu.fastdev.dialog.BasePopupWindowDialog;
import com.zhuisu.fastdev.ui.util.BroadCastConfig;
import com.zhuisu.fastdev.ui.util.LogUtils;
import com.zhuisu.fastdev.ui.xiaxian.XiaXianWeiJianActivity;
import com.zhuisu.fastdev.view.FastTitleLayout;
import com.zhuisu.qualityManagement.R;
import com.zhuisu.suppliermanagement.base.CaptureActivity;
import com.zhuisu.suppliermanagement.util.GlobalVar;
import com.zhuisu.suppliermanagement.util.ToastUtils;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 * @author cxh
 * @description
 * @date 2020/10/16.
 */
public class RegisterCarActivity extends BaseActivity {
    private FastTitleLayout fastTitleLayout;
    private EditText et_scanf_car_number;//车架号
    private Button btn_query;//查询
    private RecyclerView rv_list;
    private List<RegisterCarListBean> list;
    private RegisterCarListAdapter adapter;

    private List<RegisterCarLocationListBean> locationListBeanList;

    BroadCastChange broadCast  = new BroadCastChange();
    IntentFilter filter  = new IntentFilter(BroadCastConfig.BROADCAST_ACTION);

    class BroadCastChange extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent != null && intent.getAction() != null && intent.getAction().equals(BroadCastConfig.BROADCAST_ACTION)){
                et_scanf_car_number.setText(intent.getExtras().getString(BroadCastConfig.BROADCAST_ACTION_TAG));
                et_scanf_car_number.setSelection(et_scanf_car_number.getText().toString().length());
                query();
            }
        }
    }

    @SuppressLint("SetTextI18n")
    @Override
    protected void initViews() {
        list = new ArrayList<>();
        locationListBeanList = new ArrayList<>();



        fastTitleLayout = findViewById(R.id.fast_layout);
        et_scanf_car_number = findViewById(R.id.et_scanf_car_number);
        btn_query = findViewById(R.id.btn_query);
        btn_query.setOnClickListener(view -> query());
        rv_list = findViewById(R.id.rv_list);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(context);
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        rv_list.setLayoutManager(linearLayoutManager);
        adapter = new RegisterCarListAdapter(list, context);
        rv_list.setAdapter(adapter);
        adapter.setRegisterCarClicked(position -> {

            if (list.get(position) != null) {
                commitData(list.get(position));
            } else {
                ToastUtils.show("暂无数据");
            }

//            Intent intent = new Intent(context, RegisterDetailActivity.class);
//            intent.putExtra(RegisterDetailActivity.ACTION, list.get(position));
//            startActivity(intent);

        });


        TextView tv_user_name = findViewById(R.id.tv_user_name);
        tv_user_name.setText("\t" + GlobalVar.realname);


        findViewById(R.id.tv_scanf).setOnClickListener(arg0 -> {
            Intent intent = new Intent();
            intent.setClass(context, CaptureActivity.class);
            startActivityForResult(intent, 1073);
        });

        queryLocation();

        filter.setPriority(Integer.MAX_VALUE);
        registerReceiver(broadCast,filter);

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        unregisterReceiver(broadCast);
    }

    /**
     * 提交
     */
    private void commitData(RegisterCarListBean data) {
        ArrayMap<String, String> map = new ArrayMap<>();
        map.put("location", data.getValue());
        map.put("carFarmeNo", data.getCarFarmeNo());
        map.put("status", "debug");
        map.put("userName", GlobalVar.username);

        String param = gson.toJson(map);
        LogUtils.printDebug(param);
        showCommitDialog();


        OkHttpClient client = new OkHttpClient();
        RequestBody requestBody = RequestBody.create(JSON, param);
        Request request = new Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/offlinedebuggingstatus/qmsOfflineStatus/api/saveOffLineStatus")
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                Log.d(TAG, "onFailure: 失败");
                runOnUiThread(()->{
                    showNetErrorMessage();
                    cancelDialog();
                });
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                final String result = response.body().string();
                Log.d(TAG, "onResponse: 接车" + result);
                runOnUiThread(() -> {
                    try {
                        cancelDialog();
                        JSONObject jsonObject = new JSONObject(result);
                        if (jsonObject.optString("status").equals("0")) {
                            ToastUtils.show(jsonObject.optString("msg"));
                            new Handler().postDelayed(() -> finish(), 1500);
//                            query();
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                });
            }
        });
    }



    /**
     * 获取接车的库位
     */
    private void queryLocation() {
        ArrayMap<String, String> map = new ArrayMap<>();
        map.put("type", "CAR_LOCATION");

        String param = gson.toJson(map);
        OkHttpClient client = new OkHttpClient();
        RequestBody requestBody = RequestBody.create(JSON, param);
        Request request = new Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/common/util/api/getDict")
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                Log.d(TAG, "onFailure: 失败");
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                final String result = response.body().string();
                Log.d(TAG, "onResponse: 接车库位" + result);
                runOnUiThread(() -> {
                    try {
                        query();
                        JSONObject jsonObject = new JSONObject(result);
                        locationListBeanList = new ArrayList<>();
                        locationListBeanList.addAll(gson.fromJson(jsonObject.optString("data"), new TypeToken<List<RegisterCarLocationListBean>>() {}.getType()));

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                });
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1073 && resultCode == Activity.RESULT_OK) {
            et_scanf_car_number.setText(data.getStringExtra("encoderesult"));
            query();
        }
    }


    @Override
    protected void onResume() {
        super.onResume();
    }

    private void query() {
        Log.e("url", GlobalVar.url + "a/offlinedebuggingstatus/qmsOfflineStatus/api/list");
        ArrayMap<String, String> map = new ArrayMap<>();
        map.put("flowCarNo", "");
        map.put("carFarmeNo", et_scanf_car_number.getText().toString());
        map.put("pageNo", "1");
        map.put("pageSize", "111111");
        String param = gson.toJson(map);
        OkHttpClient client = new OkHttpClient();
        RequestBody requestBody = RequestBody.create(JSON, param);
        Request request = new Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/offlinedebuggingstatus/qmsOfflineStatus/api/list")
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                Log.d(TAG, "onFailure: 失败");
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                final String result = response.body().string();
                Log.d(TAG, "onResponse: 接车列表" + result);
                runOnUiThread(() -> showData(result));
            }
        });
    }

    private void showData(String result) {
        list.clear();
//        adapter.notifyDataSetChanged();
        try {
            JSONObject jsonObject = new JSONObject(result);
            JSONObject jsonData = jsonObject.optJSONObject("data");
            if (jsonData != null && jsonData.optInt("count") > 0) {
                String jsonArr = jsonData.optString("list");
                list.addAll(gson.fromJson(jsonArr, new TypeToken<List<RegisterCarListBean>>() {
                }.getType()));
            } else {
                showEmptyMessage();
            }


            adapter.setLocationListBeanList(locationListBeanList);
            adapter.notifyDataSetChanged();
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    @Override
    protected int getResId() {
        return R.layout.activity_register_car;
    }
}
