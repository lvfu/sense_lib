package com.zhuisu.fastdev.ui.shengchanqingkuanggenzong

data class ShengchanList(
    val isNewRecord: Boolean?,
    val createDate: String?,
    val carFarmeNo: String?,
    val orderNo: String?,
    val isExistCloseTrouble: Int?,
    val pageNo: Int?,
    val pageSize: Int?,
    val operator: String?,
    val alreadyOffLineDays: Int?,
    val troubleShootingDate: String?,
    val troubleShootingUser: String?,
    val submitCheckDate: String?,
    val submitCheckUser: String?,
    val submitCheckPassedDate: String?,
    val submitCheckPassedUser: String?,
    val recheckDate: String?,
    val recheckUser: String?,
    val HEMSonLineDate: String?,
    val HEMSDowmLineDate: String?,
    val HEMSInWareHousingDate: String?,
    val debugDate: String?,
    val debugUser: String?,
    val hemsdowmLineDate: Long?,
    val hemsinWareHousingDate: Long?,
    val hemsonLineDate: Long?,
    val configChange: Boolean?,
    val configDesc: String
)




