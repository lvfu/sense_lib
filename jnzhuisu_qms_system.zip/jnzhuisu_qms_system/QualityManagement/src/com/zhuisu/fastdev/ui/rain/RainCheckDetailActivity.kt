package com.zhuisu.fastdev.ui.rain

import android.content.Intent
import android.os.Handler
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.text.TextUtils
import android.util.ArrayMap
import android.util.Log
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Spinner
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.zhuisu.fastdev.BaseActivity
import com.zhuisu.fastdev.adapter.rain.RainCheckDetailHostoryAdapter
import com.zhuisu.fastdev.beans.rain.RainHistoryListBean
import com.zhuisu.fastdev.beans.rain.RainListBean
import com.zhuisu.fastdev.view.SmartTextView
import com.zhuisu.qualityManagement.R
import com.zhuisu.suppliermanagement.util.GlobalVar
import com.zhuisu.suppliermanagement.util.ToastUtils
import okhttp3.*
import org.json.JSONException
import org.json.JSONObject
import java.io.IOException
import java.util.*

/**
 * @author cxh
 * @description
 * @date 2020/10/23.
 */
class RainCheckDetailActivity : BaseActivity(),
    RainCheckDetailHostoryAdapter.RainFailureDetailClick {
    private var listBean: RainListBean? = null
    private var recyclerview: RecyclerView? = null
    private var adapter: RainCheckDetailHostoryAdapter? = null
    private var list: MutableList<RainHistoryListBean>? = null
    private var btn_rain_successful: Button? = null //淋雨确认
    private var spType: Spinner? = null
    private var isSelectType = false
    override fun initViews() {

        spType = findViewById(R.id.sp_type)
        recyclerview = findViewById(R.id.recyclerview)
        btn_rain_successful = findViewById(R.id.btn_rain_successful)
        btn_rain_successful!!.setOnClickListener { commitData() }
        list = ArrayList()
        adapter = RainCheckDetailHostoryAdapter(list, context)
        adapter!!.setRainFailureDetailClick(this)
        val linearLayoutManager = LinearLayoutManager(context)
        linearLayoutManager.orientation = LinearLayoutManager.VERTICAL
        recyclerview!!.isNestedScrollingEnabled = false
        recyclerview!!.layoutManager = linearLayoutManager
        recyclerview!!.adapter = adapter
        if (intent != null && intent.hasExtra(ACTION_VALUE_DATA)) {
            listBean = intent.getParcelableExtra(ACTION_VALUE_DATA)
            val tv_dingdanhao: SmartTextView = findViewById(R.id.tv_dingdanhao) //订单号
            val tv_suichedanhao: SmartTextView = findViewById(R.id.tv_suichedanhao) //随车单号
            val tv_car_number: SmartTextView = findViewById(R.id.tv_car_number) //车架号
            val tv_car_type: SmartTextView = findViewById(R.id.tv_car_type) //车型号
            val tv_info: SmartTextView = findViewById(R.id.tv_info) //配置
            val tv_up_time: SmartTextView = findViewById(R.id.tv_up_time) //上线时间
            if (listBean!!.qmsManufactureProductionplan != null) {
                tv_dingdanhao.setText(listBean!!.qmsManufactureProductionplan.orderNo)
            }
            tv_suichedanhao.setText(listBean!!.flowCarNo)
            tv_car_number.setText(listBean!!.carFarmeNo)
            if (listBean!!.qmsManufactureProductionplan != null) {
                tv_car_type.setText(listBean!!.qmsManufactureProductionplan.carModelNo)
            }
            if (listBean!!.qmsManufactureProductionplan != null) {
                tv_info.setText(listBean!!.qmsManufactureProductionplan.configDesc)
            }
            tv_up_time.setText(listBean!!.createDate)

            if (listBean!!.rainCount == null) {
                findViewById<LinearLayout>(R.id.ll_type).visibility = View.VISIBLE
                isSelectType = true
            }
            if (listBean!!.rainCount != null && TextUtils.equals("0", listBean!!.rainCount)) {
                findViewById<LinearLayout>(R.id.ll_type).visibility = View.VISIBLE
                isSelectType = true
            }
        }
        queryType()

    }


    data class RainType(var id: String, var label: String, var value: String) {
        override fun toString(): String {
            return label
        }
    }

    /**
     * 查询字典
     * */
    var dictList: ArrayList<RainType>? = null
    fun queryType() {
        val map = ArrayMap<String, String>()
        map["type"] = "RAIN_BRIDGE_TYPE"
        val param = gson.toJson(map)
        Log.e("字典参数", param)
        val client = OkHttpClient()
        val requestBody = RequestBody.create(JSON, param)
        val request = Request.Builder()
            .post(requestBody)
            .url(GlobalVar.url + "a/common/util/api/getDict")
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread {
                    Log.d(TAG, "onFailure: 失败")
                }
            }

            override fun onResponse(call: Call, response: Response) {
                val result = response.body()!!.string()
                runOnUiThread {
                    try {
                        Log.e("--->驾驶室类型", result)
                        val jsonObject = JSONObject(result)
                        if (TextUtils.equals(jsonObject.optString("retCode"), "0")) {
                            val listType = object : TypeToken<ArrayList<RainType>>() {}.type
                            dictList = Gson().fromJson(jsonObject.optString("data"), listType)
                            val arr = ArrayAdapter(context, R.layout.simple_textview1, dictList)
                            spType!!.adapter = arr
                        } else
                            showEmptyMessage()

                    } catch (jsonException: JSONException) {
                        jsonException.printStackTrace()
                    }
                }
            }
        })
    }

    override fun onResume() {
        super.onResume()
        query()
    }

    private fun commitData() {
//        if (list != null && !list.isEmpty()) {
        val map = ArrayMap<String, String>()
        map["carFarmeNo"] = listBean!!.carFarmeNo
        map["userName"] = GlobalVar.username

        if (isSelectType) {
            map["rainBridgeType"] = dictList!![spType!!.selectedItemPosition].value
        }
        val param = gson.toJson(map)
        showCommitDialog()
        val client = OkHttpClient()
        val requestBody = RequestBody.create(JSON, param)
        val request = Request.Builder()
            .post(requestBody)
            .url(GlobalVar.url + "a/offlinedebuggingstatus/qmsOfflineStatus/api/rainOperator")
            .build()
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.d(TAG, "onFailure: 失败")
                runOnUiThread {
                    showNetErrorMessage()
                    cancelDialog()
                }
            }

            @Throws(IOException::class)
            override fun onResponse(call: Call, response: Response) {
                val result = response.body()!!.string()
                runOnUiThread {
                    try {
                        cancelDialog()
                        Log.e("淋雨result", result)
                        val jsonObject = JSONObject(result)
                        if (jsonObject.optString("status") == "0") {
                            runOnUiThread {
                                ToastUtils.show("成功")
                                Handler().postDelayed({ finish() }, 1500)
                            }
                        } else {
                            ToastUtils.show(jsonObject.optString("msg"))
                        }
                    } catch (e: JSONException) {
                        e.printStackTrace()
                    }
                }
            }
        })
        //        }
    }

    override fun getResId(): Int {
        return R.layout.activity_rain_check_detail
    }

    fun query() {
        list!!.clear()
        val map = ArrayMap<String, String>()
        map["carFarmeNo"] = listBean!!.carFarmeNo
        map["pageNo"] = "1"
        map["pageSize"] = "11111"
        val param = gson.toJson(map)
        val client = OkHttpClient()
        val requestBody = RequestBody.create(JSON, param)
        val request = Request.Builder()
            .post(requestBody)
            .url(GlobalVar.url + "a/offlinedebuggingstatus/qmsOfflineStatus/api/showAllRainRecord")
            .build()
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.d(TAG, "onFailure: 失败")
            }

            @Throws(IOException::class)
            override fun onResponse(call: Call, response: Response) {
                val result = response.body()!!.string()
                runOnUiThread { showlistBean(result) }
            }
        })
    }

    private fun showlistBean(result: String) {
        Log.d(TAG, "onResponse: 淋雨记录列表$result")
        try {
            val jsonObject = JSONObject(result)
            if (jsonObject.optString("status") == "0") {
                list!!.addAll(
                    gson.fromJson(
                        jsonObject.optJSONObject("data").optString("list"),
                        object : TypeToken<List<RainHistoryListBean?>?>() {}.type
                    )
                )
                adapter!!.notifyDataSetChanged()
                for (i in list!!.indices) {
                    if (list!![i].rainResult == null) {
                        btn_rain_successful!!.visibility = View.GONE
                        return
                    }
                }
            }
        } catch (e: JSONException) {
            e.printStackTrace()
        }
    }

    companion object {
        const val ACTION_VALUE_DATA = "action_value_listBean"
    }

    override fun onFailureDetailClickListener(position: Int) {
        val intent = Intent(context, RainFailureDetailActivity::class.java)
        intent.putExtra(RainFailureDetailActivity.ACTION_ID, list!![position].id)
        startActivity(intent)
    }
}