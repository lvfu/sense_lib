package com.zhuisu.fastdev.ui.outtask

import android.os.Handler
import android.text.TextUtils
import android.util.ArrayMap
import android.util.Log
import android.widget.*
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.zhuisu.fastdev.BaseActivity
import com.zhuisu.fastdev.beans.AdmissionDictListBean
import com.zhuisu.qualityManagement.R
import com.zhuisu.suppliermanagement.ui.UnCheckLineBean
import com.zhuisu.suppliermanagement.ui.UnCheckListData
import com.zhuisu.suppliermanagement.util.GlobalVar
import com.zhuisu.suppliermanagement.util.ToastUtils
import okhttp3.*
import org.json.JSONException
import org.json.JSONObject
import java.io.IOException
import java.lang.Exception
import java.text.SimpleDateFormat
import java.util.*

/**
 * @author cxh
 * @description
 * @date 2020/11/6.
 */
class AdmissionAndUpdateActivity : BaseActivity() {

    private var showimage: ImageView? = null
    private var et_car_frame_number: EditText? = null
    private var unCheckBean: UnCheckLineBean? = null
    private var listBeans: ArrayList<AdmissionDictListBean>? = null
    private var et_product_number: EditText? = null //编号

    private var sp_type: Spinner? = null //类型
    private var switch_number: Switch? = null //是否数值
    private var et_starand: EditText? = null //标准
    private var et_info: EditText? = null//备注
    private var addData: UnCheckListData? = null


    companion object {
        const val ACTION_DATA = "action_data"
        const val ACTION_ADD_DATA = "action_add_data"
    }


    override fun initViews() {
        findViewById<Button>(R.id.btn_submit).setOnClickListener { submit() }
        et_product_number = findViewById(R.id.et_product_number)
        et_car_frame_number = findViewById(R.id.et_car_frame_number)
        showimage = findViewById(R.id.showimage)
        sp_type = findViewById(R.id.et_number)
        switch_number = findViewById(R.id.switch_number)
        et_starand = findViewById(R.id.et_starand)
        et_info = findViewById(R.id.et_info)


        if (intent.getSerializableExtra(ACTION_DATA) != null) {
            unCheckBean = intent.getSerializableExtra(ACTION_DATA) as UnCheckLineBean?
            et_product_number!!.setText(unCheckBean?.checkitemcode)
            et_starand!!.setText(unCheckBean?.standard)
            et_product_number!!.isClickable = false;
            et_product_number!!.isEnabled = false;
            sp_type!!.isEnabled = false;
            sp_type!!.isClickable = false;
            switch_number!!.isEnabled = false
            switch_number!!.isClickable = false
            et_info!!.isEnabled = false
            et_info!!.isClickable = false

        }

        if (intent.getSerializableExtra(ACTION_ADD_DATA) != null) {
            addData = intent.getSerializableExtra(ACTION_ADD_DATA) as UnCheckListData?
        }

        query()
    }


    private fun query() {
        val map = ArrayMap<String, String>()
        map["type"] = "qms_purchasecheck_checkitemtype"
        val param = gson.toJson(map)
        val client = OkHttpClient()
        val requestBody = RequestBody.create(JSON, param)
        val request = Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/common/util/api/getDict")
                .build()
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.d(TAG, "onFailure: 失败")
            }

            @Throws(IOException::class)
            override fun onResponse(call: Call, response: Response) {
                val result = response.body()!!.string()
                runOnUiThread { showData(result) }
            }
        })
    }

    private fun showData(result: String?) {
        Log.d(TAG, "onResponse: 获取字典$result")
        try {
            val jsonObject = JSONObject(result)
            if (jsonObject.optString("retCode") == "0") {
                if (jsonObject.optString("data") != null) {
                    val listType = object : TypeToken<ArrayList<AdmissionDictListBean>>() {}.type
                    listBeans = Gson().fromJson(jsonObject.optString("data"), listType)
                    if (listBeans == null || listBeans!!.isEmpty()) {
                        showEmptyMessage()
                        return
                    }

                    val arr = ArrayAdapter(context, R.layout.simple_textview1, listBeans)
                    sp_type!!.adapter = arr

                    if (unCheckBean != null) {
                        var index = 0;
                        for (value in listBeans!!) {
                            try {
                                index++
                                if (TextUtils.equals(unCheckBean!!.checkitemtype, value.value)) {
                                    sp_type!!.setSelection(index-1)
                                }
                            } catch (exe: Exception) {
                                exe.printStackTrace()
                            }
                        }
                    }

                } else {
                    showEmptyMessage()
                }
            }
        } catch (e: JSONException) {
            e.printStackTrace()
        }
    }

    override fun getResId(): Int {
        return R.layout.activity_admission_update
    }

    /**
     * 提交数据
     */
    private fun submit() {

        val map = ArrayMap<String, String>()
        if (unCheckBean != null) {
            map["checktaskid"] = addData?.id
            map["id"] = unCheckBean!!.id
        } else {
            map["checktaskid"] = addData?.id
            map["id"] = ""
        }

        map["checkitemcode "] = et_product_number?.text.toString() //项目编号

        if (listBeans != null) {
            map["checkitem"] = sp_type?.selectedItemPosition?.let { listBeans!!.get(it).label } //类型
        } else {
            map["checkitem"] = ""
        }


        map["occurTime"] = SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(Date(System.currentTimeMillis()))
        if (listBeans != null) {
            map["checkitemtype"] = sp_type?.selectedItemPosition?.let { listBeans!!.get(it).label } //类型
        } else {
            map["checkitemtype"] = ""
        }

        if (switch_number?.isChecked!!) {
            map["isnumber"] = "1"
        } else {
            map["isnumber"] = "0"
        }

        map["standard"] = et_starand?.text.toString() //标准
        map["remark"] = et_info?.text.toString() //备注
        val param = gson.toJson(map)
        Log.e("参数", param)
        showCommitDialog()
        val client = OkHttpClient()
        val requestBody = RequestBody.create(JSON, param)
        val request = Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/checktaskitem/qmsPurchasecheckChecktaskitem/api/saveChecktaskItem")
                .build()
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.d(TAG, "onFailure: 失败")
                runOnUiThread {
                    showNetErrorMessage()
                    cancelDialog()
                }
            }

            @Throws(IOException::class)
            override fun onResponse(call: Call, response: Response) {
                val result = response.body()!!.string()
                runOnUiThread {
                    Log.d(TAG, "onResponse: 功能模块$result")
                    try {
                        cancelDialog()
                        val jsonObject = JSONObject(result)
                        if (jsonObject.optString("retCode") == "0") {
                            ToastUtils.show("提交成功")
                            Handler().postDelayed({ finish() }, 1500)
                        } else {
                            ToastUtils.show(jsonObject.optString("retMessage"))
                        }
                    } catch (e: JSONException) {
                        e.printStackTrace()
                        ToastUtils.show("数据解析异常")
                    }
                }
            }
        })
    }


}