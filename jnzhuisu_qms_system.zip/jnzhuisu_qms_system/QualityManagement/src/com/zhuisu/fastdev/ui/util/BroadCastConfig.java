package com.zhuisu.fastdev.ui.util;

/**
 * @author cxh
 * @description
 * @date 2020/12/28.
 */
public class BroadCastConfig {
    public static final String BROADCAST_ACTION = "com.sense.qms.action";
    public static final String BROADCAST_ACTION_TAG = "com.sense.qms.action_tag";
}
