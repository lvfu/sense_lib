package com.zhuisu.fastdev.ui.worktime

import android.app.Activity
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.DialogInterface
import android.content.Intent
import android.media.Image
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.support.v4.content.FileProvider
import android.text.TextUtils
import android.util.ArrayMap
import android.util.Log
import android.view.View
import android.widget.*
import android.widget.AdapterView.OnItemSelectedListener
import com.bumptech.glide.Glide
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.zhuisu.fastdev.BaseActivity
import com.zhuisu.fastdev.beans.registercar.RegisterCarDetails
import com.zhuisu.fastdev.beans.xunjian.XunJianWeiJianXiangQingBuMenList
import com.zhuisu.fastdev.beans.zhuangpei.ZhuangPeiWeiJianXiangQingWuLiaoList
import com.zhuisu.fastdev.dialog.BasePopupWindowDialog
import com.zhuisu.fastdev.ui.TempTaskUpload.TypeListBean
import com.zhuisu.fastdev.ui.util.LogUtils
import com.zhuisu.fastdev.ui.zhiliangmen.DeptUserBean
import com.zhuisu.fastdev.view.SmartTextView
import com.zhuisu.qualityManagement.R
import com.zhuisu.suppliermanagement.base.CaptureActivity
import com.zhuisu.suppliermanagement.ui.ShowImageDisplayActivity
import com.zhuisu.suppliermanagement.util.FileUtil
import com.zhuisu.suppliermanagement.util.GlobalVar
import com.zhuisu.suppliermanagement.util.ToastUtils
import com.zhuisu.suppliermanagement.util.Util
import okhttp3.*
import org.json.JSONException
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.*
import kotlin.collections.ArrayList

/**
 * @author cxh
 * @description
 * @date 2021/3/10.
 */
class WorkTimeDetailActivity : BaseActivity() {

    private var tvCarNumber: EditText? = null
    private var etDrawCode: EditText? = null
    private var etLineNumberNew: EditText? = null //新条码号
    private var etDrawCodeNew: EditText? = null //新图号
    private var etSupNew: EditText? = null//新供应商

    private var tvOrderNumber: SmartTextView? = null
    private var tvFlowNumber: SmartTextView? = null
    private var etLineNumber: EditText? = null //条码
    private var etSup: EditText? = null
    private var etNumber: EditText? = null
    private var spDept: Spinner? = null
    private var tvUsers: SmartTextView? = null
    private var spType: Spinner? = null
    private var spShop: Spinner? = null
    private var etLocation: EditText? = null
    private var etFullMeta: EditText? = null
    private var etFullNo: EditText? = null
    private var etReano: EditText? = null
    private var etRemark: EditText? = null
    private var showimage: ImageView? = null
    private var current: WorkTimeDetailBean? = null

    override fun initViews() {
        etDrawCodeNew = findViewById(R.id.et_draw_number_new)
        etSupNew = findViewById(R.id.et_suppude_new)
        etDrawCode = findViewById(R.id.et_draw_number)
        etLineNumberNew = findViewById(R.id.et_wltm_new)
        tvCarNumber = findViewById(R.id.tv_cjh)
        tvOrderNumber = findViewById(R.id.tv_order_number)
        tvFlowNumber = findViewById(R.id.tv_flow_numer)
        etLineNumber = findViewById(R.id.et_wltm)
        etSup = findViewById(R.id.et_suppude)
        etNumber = findViewById(R.id.et_number)
        spDept = findViewById(R.id.sp_dept)
        tvUsers = findViewById(R.id.tv_users)
        spType = findViewById(R.id.sp_type)
        spShop = findViewById(R.id.sp_shop)
        etLocation = findViewById(R.id.et_location)
        etFullMeta = findViewById(R.id.et_fuliao)
        etFullNo = findViewById(R.id.et_full_no)
        etReano = findViewById(R.id.et_reano)
        etRemark = findViewById(R.id.et_remark)
        showimage = findViewById(R.id.showimage)

        findViewById<View>(R.id.btn_replace_log).setOnClickListener {
            //删除
            val dialog = BasePopupWindowDialog()
            val arguments = Bundle()
            arguments.putString(BasePopupWindowDialog.ACTION_VALUE_TITLE, "提示")
            arguments.putString(BasePopupWindowDialog.ACTION_VALUE_MESSAGE, "确认删除吗?")
            dialog.arguments = arguments

            dialog.setOnConfirmClickListener {
                dialog.dismiss()
                deleteItem()
            }
            dialog.show(supportFragmentManager, "")

        }

        findViewById<View>(R.id.btn_submit_result).setOnClickListener {
            finish()
        }

        findViewById<View>(R.id.btn_save_commit).setOnClickListener {
            submit("1")
        }

        findViewById<View>(R.id.tv_scanf).setOnClickListener {
            val intent = Intent()
            intent.setClass(context, CaptureActivity::class.java)
            startActivityForResult(intent, 1073)
        }

        findViewById<View>(R.id.tv_scanf_wl).setOnClickListener {
            val intent = Intent()
            intent.setClass(context, CaptureActivity::class.java)
            startActivityForResult(intent, 1074)
        }

        findViewById<View>(R.id.tv_scanf_wl_new).setOnClickListener {
            val intent = Intent()
            intent.setClass(context, CaptureActivity::class.java)
            startActivityForResult(intent, 1094)
        }

        findViewById<View>(R.id.iv_select_image).setOnClickListener { view: View? -> selectImage() }

//        tvUsers!!.setOnClickListener {
//            showMutilDialog()
//        }

        queryDetail()
        queryDept()
        queryState()
        queryShop()
    }


    private fun deleteItem() {
        val map = ArrayMap<String, Any>()
        map["id"] = current!!.id
        val params = gson.toJson(map)
        val client = OkHttpClient()
        val requestBody = RequestBody.create(JSON, params)
        val request = Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/materielreplacerecord/qmsManufactureMaterielReplaceRecord/api/delData")
                .build()
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.d(TAG, "onFailure: 失败")
            }

            @Throws(IOException::class)
            override fun onResponse(call: Call, response: Response) {
                val result = response.body()!!.string()
                runOnUiThread {
                    Log.d(TAG, "onResponse: 删除$result")
                    try {
                        val jsonObject = JSONObject(result)
                        if (jsonObject.optString("retCode").equals("0")) {
                            ToastUtils.show("删除成功")
                            finish()
                        }
                    } catch (e: JSONException) {
                        e.printStackTrace()
                    }
                }
            }
        })
    }

    /**
     * 选择照片
     */
    var alertdialog: AlertDialog? = null
    var fileDir = Environment.getExternalStorageDirectory().absolutePath + "/qualitymanagement/files/media/"
    var uploadFilePath: String? = null
    private val IMAGE_CODE = 200 // 这里的IMAGE_CODE是自己任意定义的
    var imageUri: Uri? = null
    private fun selectImage() {
        alertdialog = Util.getDialog(context, "选择图像", 0, { arg0, view, position, arg3 ->
            if (alertdialog!!.isShowing) {
                alertdialog!!.dismiss()
            }
            val f: File
            when (position) {
                0 -> {
                    var fileName = ""
                    val capimgIntent = Intent()
                    fileName = SimpleDateFormat("yyyyMMddHHmmss").format(Date()) + ".jpg"
                    FileUtil.checkDir(fileDir + "_/")
                    f = File(fileDir + "_", fileName)
                    uploadFilePath = fileDir + "_/" + fileName
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                        // 7.0+以上版本
                        //与manifest中定义的provider中的authorities="cn.wlantv.kznk.fileprovider"保持一致
                        imageUri = FileProvider.getUriForFile(context, "com.jnqms.fileprovider", f)
                        capimgIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    } else {
                        imageUri = Uri.fromFile(f)
                    }
                    capimgIntent.putExtra(MediaStore.EXTRA_OUTPUT, imageUri)
                    capimgIntent.action = MediaStore.ACTION_IMAGE_CAPTURE
                    capimgIntent.addCategory(Intent.CATEGORY_DEFAULT)
                    startActivityForResult(capimgIntent, 1)
                }
                1 -> {
                    val intent = Intent(Intent.ACTION_GET_CONTENT)
                    intent.type = "image/*"
                    intent.addCategory(Intent.CATEGORY_OPENABLE)
                    try {
                        startActivityForResult(Intent.createChooser(intent, "Select a File to Upload"),
                                IMAGE_CODE)
                    } catch (ex: ActivityNotFoundException) {
                        Toast.makeText(context, "Please install a File Manager.", Toast.LENGTH_SHORT)
                                .show()
                    }
                }
                else -> {
                }
            }
        }, arrayOf("拍照", "文件"), arrayOf(R.drawable.i_camera, R.drawable.i_image))
        alertdialog?.show()
    }

    val shopList: ArrayList<CarShop> = ArrayList()
    private fun queryShop() {
        val client = OkHttpClient()
        val requestBody = RequestBody.create(JSON, "")
        val request = Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/materielreplacerecord/qmsManufactureMaterielReplaceRecord/api/getWorkShop")
                .build()
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.d(TAG, "onFailure: 失败")
            }

            @Throws(IOException::class)
            override fun onResponse(call: Call, response: Response) {
                val result = response.body()!!.string()
                runOnUiThread {
                    LogUtils.printDebug("查询车间: $result")
                    val jsonData = JSONObject(result)
                    if (jsonData.optString("retCode") == "0") {
                        val listType = object : TypeToken<java.util.ArrayList<CarShop>>() {}.type
                        val temp: ArrayList<CarShop> = Gson().fromJson(jsonData.optString("data"), listType)

                        shopList.addAll(temp)
                        val arrayAdapter = ArrayAdapter(context, R.layout.simple_textview1, shopList)
                        spShop!!.adapter = arrayAdapter

                    }
                }
            }
        })
    }

    private var typeList: ArrayList<TypeListBean> = ArrayList()
    private fun queryState() {
        val map = ArrayMap<String, String>()
        map["type"] = "MATERIEL_WORK_HOUR_TYPE"
        val param = gson.toJson(map)
        val client = OkHttpClient()
        val requestBody = RequestBody.create(JSON, param)
        val request = Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/common/util/api/getDict")
                .build()
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.d(TAG, "onFailure: 失败")
            }

            @Throws(IOException::class)
            override fun onResponse(call: Call, response: Response) {
                val result = response.body()!!.string()
                runOnUiThread {
                    LogUtils.printDebug("查询状态: $result")
                    val jsonData = JSONObject(result)
                    if (jsonData.optString("retCode") == "0") {
                        val listType = object : TypeToken<java.util.ArrayList<TypeListBean>>() {}.type
                        val temp: ArrayList<TypeListBean> = Gson().fromJson(jsonData.optString("data"), listType)

                        typeList.addAll(temp)
                        val arrayAdapter = ArrayAdapter(context, R.layout.simple_textview1, typeList)
                        spType!!.adapter = arrayAdapter

                    }
                }
            }
        })
    }

    /**
     * 查询部门
     */
    private fun queryDept() {
        val client = OkHttpClient()
        val requestBody = RequestBody.create(JSON, "")
        val request = Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/sys/office/api/getOfficeList")
                .build()
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.d(TAG, "onFailure: 失败")
            }

            @Throws(IOException::class)
            override fun onResponse(call: Call, response: Response) {
                val result = response.body()!!.string()
                runOnUiThread {
                    Log.d(TAG, "onResponse: 部门$result")
                    try {
                        val jsonObject = JSONObject(result)
                        buMenLists = gson.fromJson(jsonObject.optString("data"), object : TypeToken<List<XunJianWeiJianXiangQingBuMenList?>?>() {}.type)
                        if (buMenLists == null || buMenLists!!.isEmpty()) return@runOnUiThread
                        val arrayAdapter = ArrayAdapter(context, R.layout.simple_textview1, buMenLists)
                        spDept!!.adapter = arrayAdapter
                        spDept!!.onItemSelectedListener = object : OnItemSelectedListener {
                            override fun onItemSelected(parent: AdapterView<*>?, view: View, position: Int, id: Long) {
                                queryUser()
                            }

                            override fun onNothingSelected(parent: AdapterView<*>?) {}
                        }
                    } catch (e: JSONException) {
                        e.printStackTrace()
                    }
                }
            }
        })
    }

    /**
     * 查询责任人
     */
    private fun queryUser() {
        val map = ArrayMap<String, String>()
        tvUsers!!.setText("")
        map["officeid"] = buMenLists!![spDept!!.selectedItemPosition].code
        val requestJson = gson.toJson(map)
        Log.e("--->", requestJson)
        val client = OkHttpClient()
        val requestBody = RequestBody.create(JSON, requestJson)
        val request = Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/materielreplacerecord/qmsManufactureMaterielReplaceRecord/api/getJoinUser")
                .build()
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.d(TAG, "onFailure: 失败")
            }

            @Throws(IOException::class)
            override fun onResponse(call: Call, response: Response) {
                val result = response.body()!!.string()
                runOnUiThread {
                    Log.d(TAG, "onResponse: 人员$result")
                    try {
                        val jsonObject = JSONObject(result)
                        if (jsonObject.optString("retCode") == "0" && jsonObject.optString("data") != null) {
                            userList = gson.fromJson(jsonObject.optString("data"), object : TypeToken<List<DeptUserBean?>?>() {}.type)
                        }
                    } catch (e: JSONException) {
                        e.printStackTrace()
                    }
                }
            }
        })
    }

    //弹出一个多选对话框
    private fun showMutilDialog() {
        if (userList.isEmpty()) return
        val builder = AlertDialog.Builder(this, R.style.MyAlertDialogStyle)
        builder.setTitle("请选择人员")
        val items = arrayOfNulls<String>(userList.size)
        val checkedItems = BooleanArray(userList.size)
        for (i in userList.indices) {
            items[i] = userList[i].name
            checkedItems[i] = false
        }
        builder.setMultiChoiceItems(items, checkedItems) { _: DialogInterface?, _: Int, _: Boolean -> }
        builder.setPositiveButton("确定") { dialog: DialogInterface, _: Int ->
            val value = StringBuilder()
            val appEndIds = StringBuilder()
            for (i in checkedItems.indices) {
                if (checkedItems[i]) {
                    for (j in userList.indices) {
                        if (userList[j].name == items[i]) {
                            val fruit = items[i]
                            appEndIds.append(userList[j].id).append(",")
                            value.append(fruit).append(",")
                        }
                    }
                }
            }
            if (value.toString().isNotEmpty() && value.toString().length > 1) {
                userIds = appEndIds.toString().substring(0, appEndIds.toString().length - 1)
                tvUsers!!.setText(value.toString().substring(0, value.toString().length - 1))
            }
            dialog.dismiss()
        }
        builder.show()
    }

    private var userList: List<DeptUserBean> = ArrayList()
    private var userIds = ""
    private var buMenLists: List<XunJianWeiJianXiangQingBuMenList>? = ArrayList()

    var zhuangPeiWeiJianXiangQingWuLiaoList1074: ZhuangPeiWeiJianXiangQingWuLiaoList? = null
    var zhuangPeiWeiJianXiangQingWuLiaoList1094: ZhuangPeiWeiJianXiangQingWuLiaoList? = null

    //根据物料名查询
    private fun queryMetaByTmh(code: Int) {
        val map = ArrayMap<String, String>()
        map["tmh"] = if (code == 1074) etLineNumber!!.text.toString() else etLineNumberNew!!.text.toString()
        val param = gson.toJson(map)
        LogUtils.printDebug("获取物料参数:${param}")
        val client = OkHttpClient()
        val requestBody = RequestBody.create(JSON, param)
        val request = Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/materiel/qmsManufactureMateriel/api/getMaterielByTmh")
                .build()
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.d(TAG, "onFailure: 失败")
            }

            @Throws(IOException::class)
            override fun onResponse(call: Call, response: Response) {
                val result = response.body()!!.string()
                runOnUiThread {
                    LogUtils.printDebug("获取物料:$result")
                    val jsonData = JSONObject(result)
                    if (jsonData.optString("retCode") == "0" && jsonData.optString("data") != null && !TextUtils.isEmpty(jsonData.optString("data"))) {
                        if (code == 1074) {
                            zhuangPeiWeiJianXiangQingWuLiaoList1074 = gson.fromJson(jsonData.optString("data"), ZhuangPeiWeiJianXiangQingWuLiaoList::class.java)
                            if (zhuangPeiWeiJianXiangQingWuLiaoList1074 != null) {
                                etSup!!.setText(zhuangPeiWeiJianXiangQingWuLiaoList1074?.supplierName)
                                etLineNumber!!.setText(zhuangPeiWeiJianXiangQingWuLiaoList1074?.materielName)
                            }
                        } else {
                            zhuangPeiWeiJianXiangQingWuLiaoList1094 = gson.fromJson(jsonData.optString("data"), ZhuangPeiWeiJianXiangQingWuLiaoList::class.java)
                            if (zhuangPeiWeiJianXiangQingWuLiaoList1094 != null) {
                                etSupNew!!.setText(zhuangPeiWeiJianXiangQingWuLiaoList1094?.supplierName)
                                etLineNumberNew!!.setText(zhuangPeiWeiJianXiangQingWuLiaoList1094?.materielName)
                            }
                        }

                    } else {
                        ToastUtils.show("获取物料失败,请联系管理员")
                    }
                }
            }
        })
    }


    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1073 && resultCode == RESULT_OK) {
            tvCarNumber?.setText(data!!.getStringExtra("encoderesult"))
            queryDetail()
        }
        if (requestCode == 1074 && resultCode == RESULT_OK) {
            etLineNumber?.setText(data!!.getStringExtra("encoderesult"))
            queryMetaByTmh(1074)
        }

        if (requestCode == 1094 && resultCode == RESULT_OK) {
            etLineNumber?.setText(data!!.getStringExtra("encoderesult"))
            queryMetaByTmh(1094)
        }

        if (resultCode == RESULT_OK && requestCode == IMAGE_CODE) {
            // 选择文件
            var path: String? = null
            if (data == null) return
            path = FileUtil.getImageAbsolutePath(context as Activity, data)
            if (path == null) {
                return
            }
            uploadFilePath = path
            showimage!!.setVisibility(View.VISIBLE)
            Glide.with(context).load(path).into(showimage!!)
        } else if (requestCode == 1 && resultCode == RESULT_OK) {
            showimage!!.setVisibility(View.VISIBLE)
            Glide.with(context).load(uploadFilePath).into(showimage!!)
        }
    }

    /**
     * 查询详情
     * */
    fun queryDetail() {
        val map = ArrayMap<String, String>()
        map["id"] = intent?.getStringExtra("id")
        val param = gson.toJson(map)
        Log.e("获取详情", param)
        val client = OkHttpClient()
        val requestBody = RequestBody.create(JSON, param)
        val request = Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/materielreplacerecord/qmsManufactureMaterielReplaceRecord/api/getSingleData")
                .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread {
                    Log.d(TAG, "onFailure: 失败")
                }
            }

            override fun onResponse(call: Call, response: Response) {
                val result = response.body()!!.string()
                runOnUiThread {
                    try {
                        Log.e("--->获取详情", result)
                        val jsonObject = JSONObject(result)
                        if (jsonObject.optString("retCode") == "-1") {
                            ToastUtils.show(jsonObject.optString("msg"))
                        } else {
                            current = gson.fromJson(jsonObject.optString("data"), WorkTimeDetailBean::class.java)
                            if (current != null && current!!.procStatus != null && !TextUtils.isEmpty(current!!.procStatus)) {
                                //启动流程
                                tvCarNumber!!.setText(current!!.carFrameNo)
                                tvOrderNumber!!.setText(current!!.orderNo)
                                tvFlowNumber!!.setText(current?.flowCarNo)
                                etLineNumber!!.setText(current!!.faultBarcode)

                                if (current!!.responseDepartment.contains("|")) {
                                    etSup!!.setText(current!!.responseDepartment.substring(current!!.responseDepartment.indexOf("|")))
                                } else {
                                    etSup!!.setText(current!!.responseDepartment)
                                }

                                etNumber!!.setText(current!!.num)
                                //
                                spDept!!.visibility = View.GONE
                                val tvDept: SmartTextView = findViewById(R.id.tv_depty)
                                tvDept.visibility = View.VISIBLE
                                tvDept!!.setText(current!!.teamNames)

                                tvUsers!!.setText(current!!.joinUserNames)

                                //
                                spType!!.visibility = View.GONE
                                val tvType: SmartTextView = findViewById(R.id.tv_type)
                                tvType.visibility = View.VISIBLE
                                tvType!!.setText(current!!.replaceTypeName)
                                //
                                spShop!!.visibility = View.GONE
                                val tvShop: SmartTextView = findViewById(R.id.tv_shop)
                                tvShop.visibility = View.VISIBLE
                                tvShop!!.setText(current!!.workShopName)

                                etLocation!!.setText(current!!.location)
                                etFullMeta!!.setText(current!!.accessoriesConsume)
                                etFullNo!!.setText(current!!.accessoriesConsumeFee)
                                etReano!!.setText(current!!.reason)
                                etRemark!!.setText(current!!.remark)


                                etDrawCode!!.setText(current!!.produceName)
                                etDrawCodeNew!!.setText(current!!.newProductName)
                                etLineNumberNew!!.setText(current!!.newBarcode)

                                if (current!!.newResponseDepartment.contains("|")) {
                                    etSupNew!!.setText(current!!.newResponseDepartment.substring(current!!.newResponseDepartment.indexOf("|")))
                                } else {
                                    etSupNew!!.setText(current!!.newResponseDepartment)
                                }


                                //禁用
                                etSupNew!!.isEnabled = false
                                etDrawCodeNew!!.isEnabled = false
                                etDrawCode!!.isEnabled = false
                                etLineNumberNew!!.isEnabled = false
                                tvCarNumber!!.isEnabled = false
                                tvOrderNumber!!.isEnabled = false
                                tvFlowNumber!!.isEnabled = false
                                etLineNumber!!.isEnabled = false
                                etSup!!.isEnabled = false
                                etNumber!!.isEnabled = false
                                tvDept!!.isEnabled = false
                                tvUsers!!.isEnabled = false
                                spType!!.isEnabled = false
                                tvType!!.isEnabled = false
                                tvShop!!.isEnabled = false
                                etLocation!!.isEnabled = false
                                etFullMeta!!.isEnabled = false
                                etFullNo!!.isEnabled = false
                                etReano!!.isEnabled = false
                                etRemark!!.isEnabled = false
                                if (current!!.imgStr != null && !TextUtils.isEmpty(current!!.imgStr)) {
                                    showimage!!.setImageBitmap(base64ToBitmap(current!!.imgStr))
                                    showimage!!.setOnClickListener {
                                        val intent = Intent(context, ShowImageDisplayActivity::class.java)
                                        GlobalVar.IMGBASE64 = current!!.imgStr
                                        context?.startActivity(intent)
                                    }
                                }

                                findViewById<View>(R.id.tv_scanf_wl).visibility = View.GONE
                                findViewById<View>(R.id.tv_scanf_wl_new).visibility = View.GONE

                                findViewById<View>(R.id.tv_scanf).visibility = View.GONE
                                findViewById<View>(R.id.iv_select_image).visibility = View.GONE
                                findViewById<View>(R.id.btn_replace_log).visibility = View.GONE
                                findViewById<View>(R.id.btn_save_commit).visibility = View.GONE
                            } else {
                                // 未启动流程
                                findViewById<View>(R.id.btn_replace_log).visibility = View.VISIBLE
                                findViewById<View>(R.id.btn_save_commit).visibility = View.VISIBLE

                                etLineNumber!!.setText(current!!.faultBarcode)
                                tvCarNumber!!.setText(current!!.carFrameNo)
                                tvOrderNumber!!.setText(current!!.orderNo)
                                tvFlowNumber!!.setText(current!!.flowCarNo)

                                if (current!!.responseDepartment.contains("|")) {
                                    etSup!!.setText(current!!.responseDepartment.substring(current!!.responseDepartment.indexOf("|")))
                                } else {
                                    etSup!!.setText(current!!.responseDepartment)
                                }

                                etNumber!!.setText(current!!.num)
                                //
                                spDept!!.visibility = View.GONE
                                val tvDept: SmartTextView = findViewById(R.id.tv_depty)
                                tvDept.visibility = View.VISIBLE
                                tvDept!!.setText(current!!.teamNames)

                                tvUsers!!.setText(current!!.joinUserNames)

                                //
                                spType!!.visibility = View.GONE
                                val tvType: SmartTextView = findViewById(R.id.tv_type)
                                tvType.visibility = View.VISIBLE
                                tvType!!.setText(current!!.replaceTypeName)
                                //
                                spShop!!.visibility = View.GONE
                                val tvShop: SmartTextView = findViewById(R.id.tv_shop)
                                tvShop.visibility = View.VISIBLE
                                tvShop!!.setText(current!!.workShopName)


                                etDrawCode!!.setText(current!!.produceName)
                                etDrawCodeNew!!.setText(current!!.newProductName)
                                etLineNumberNew!!.setText(current!!.newBarcode)

                                if (current!!.newResponseDepartment.contains("|")) {
                                    etSupNew!!.setText(current!!.newResponseDepartment.substring(current!!.newResponseDepartment.indexOf("|")))
                                } else {
                                    etSupNew!!.setText(current!!.newResponseDepartment)
                                }

                                //新供应商
                                etSupNew!!.isEnabled = false
                                etDrawCodeNew!!.isEnabled = false
                                etLineNumberNew!!.isEnabled = false


                                etLocation!!.setText(current!!.location)
                                etFullMeta!!.setText(current!!.accessoriesConsume)
                                etFullNo!!.setText(current!!.accessoriesConsumeFee)
                                etReano!!.setText(current!!.reason)
                                etRemark!!.setText(current!!.remark)

                                if (current!!.imgStr != null && !TextUtils.isEmpty(current!!.imgStr)) {
                                    showimage!!.setImageBitmap(base64ToBitmap(current!!.imgStr))
                                    showimage!!.setOnClickListener {
                                        val intent = Intent(context, ShowImageDisplayActivity::class.java)
                                        GlobalVar.IMGBASE64 = current!!.imgStr
                                        context?.startActivity(intent)
                                    }
                                }
                            }
                        }

                    } catch (jsonException: JSONException) {
                        jsonException.printStackTrace()
                    }
                }
            }
        })
    }


    private fun submit(flag: String) {
        if (TextUtils.isEmpty(tvCarNumber!!.text.toString())) {
            ToastUtils.show("请输入车架号")
            return
        }
        if (zhuangPeiWeiJianXiangQingWuLiaoList1074 == null && current == null) {
            ToastUtils.show("请输入或扫描故障件条码")
            return
        }

        if (zhuangPeiWeiJianXiangQingWuLiaoList1094 == null && current == null) {
            ToastUtils.show("请输入或扫描新件条码")
            return
        }

        if (etNumber!!.text.toString().isBlank()) {
            ToastUtils.show("请输入数量")
            return
        }
        if (etLocation!!.text.toString().isBlank()) {
            ToastUtils.show("请输入地点")
            return
        }
//        if (etFullMeta!!.text.toString().isBlank()) {
//            ToastUtils.show("请输入辅料")
//            return
//        }
//        if (etFullNo!!.text.toString().isBlank()) {
//            ToastUtils.show("请输入辅料费用")
//            return
//        }

        if (etReano!!.text.toString().isBlank()) {
            ToastUtils.show("请输入原因")
            return
        }

        val map = ArrayMap<String, Any>()
        map["carFrameNo"] = tvCarNumber!!.text.toString()
        if (zhuangPeiWeiJianXiangQingWuLiaoList1074 == null && current != null) {
            map["productNo"] = current!!.productNo
            map["produceName"] = current!!.produceName
            map["responseDepartment"] = current!!.responseDepartment
        } else if (zhuangPeiWeiJianXiangQingWuLiaoList1074 != null) {
            map["productNo"] = if (zhuangPeiWeiJianXiangQingWuLiaoList1074 == null) etLineNumber!!.text.toString() else zhuangPeiWeiJianXiangQingWuLiaoList1074!!.materielId
            map["produceName"] = if (zhuangPeiWeiJianXiangQingWuLiaoList1074 == null) etLineNumber!!.text.toString() else zhuangPeiWeiJianXiangQingWuLiaoList1074!!.materielName
            map["responseDepartment"] = zhuangPeiWeiJianXiangQingWuLiaoList1074?.supplierNo + "|" + zhuangPeiWeiJianXiangQingWuLiaoList1074?.supplierName
        } else {
            map["productNo"] = etLineNumber!!.text.toString()
            map["produceName"] = etLineNumber!!.text.toString()
            map["responseDepartment"] = ""
        }

        map["orderNo"] = tvOrderNumber!!.text.toString()
        map["replaceDate"] = SimpleDateFormat("yyyy-MM-dd", Locale.CHINA).format(Date(System.currentTimeMillis()))
        map["workShop"] = shopList!![spShop!!.selectedItemPosition].node
        map["joinUser"] = current!!.joinUser

        map["replaceType"] = typeList[spType!!.selectedItemPosition].value
        map["num"] = etNumber!!.text.toString()
        map["location"] = etLocation!!.text.toString()
        map["accessoriesConsume"] = etFullMeta!!.text.toString()
        map["team"] = current!!.team
        map["accessoriesConsumeFee"] = etFullNo!!.text.toString()
        map["imgStr"] = if (TextUtils.isEmpty(uploadFilePath)) "" else bitmapToBase64(getLoacalBitmap(uploadFilePath))
        map["reason"] = etReano!!.text.toString()
        map["remark"] = etRemark!!.text.toString()
        map["isStartProcess"] = flag
        map["mobileStartProcessLoginName"] = if (flag.isBlank()) "" else GlobalVar.username
        map["createUserStr"] = GlobalVar.username
        map["id"] = current!!.id
//        map["faultBarcode"] = if (zhuangPeiWeiJianXiangQingWuLiaoList1074 == null) etLineNumber!!.text.toString() else zhuangPeiWeiJianXiangQingWuLiaoList1074!!.barCode
//        map["newBarcode"] = if (zhuangPeiWeiJianXiangQingWuLiaoList1094 == null) etLineNumberNew!!.text.toString() else zhuangPeiWeiJianXiangQingWuLiaoList1094!!.barCode
//        map["newProductNo"] = if (zhuangPeiWeiJianXiangQingWuLiaoList1094 == null) etLineNumberNew!!.text.toString() else zhuangPeiWeiJianXiangQingWuLiaoList1094!!.materielId
//        map["newProductName"] = if (zhuangPeiWeiJianXiangQingWuLiaoList1094 == null) etDrawCodeNew!!.text.toString() else zhuangPeiWeiJianXiangQingWuLiaoList1094!!.materielName

        map["faultBarcode"] = if (zhuangPeiWeiJianXiangQingWuLiaoList1074 == null) "" else zhuangPeiWeiJianXiangQingWuLiaoList1074!!.barCode
        map["newBarcode"] = if (zhuangPeiWeiJianXiangQingWuLiaoList1094 == null) "" else zhuangPeiWeiJianXiangQingWuLiaoList1094!!.barCode
        map["newProductNo"] = if (zhuangPeiWeiJianXiangQingWuLiaoList1094 == null) "" else zhuangPeiWeiJianXiangQingWuLiaoList1094!!.materielId
        map["newProductName"] = if (zhuangPeiWeiJianXiangQingWuLiaoList1094 == null) "" else zhuangPeiWeiJianXiangQingWuLiaoList1094!!.materielName

        if (zhuangPeiWeiJianXiangQingWuLiaoList1094 == null) {
            map["newResponseDepartment"] = current!!.newResponseDepartment
        } else {
            map["newResponseDepartment"] = zhuangPeiWeiJianXiangQingWuLiaoList1094?.supplierNo?.replace(" ", "")?.replace("  ", "")?.replace("         ", "") + "|" + zhuangPeiWeiJianXiangQingWuLiaoList1094?.supplierName
        }

        val params = gson.toJson(map)
        Log.e("提交数据-->", params)
        val client = OkHttpClient()
        val requestBody = RequestBody.create(JSON, params)
        val request = Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/materielreplacerecord/qmsManufactureMaterielReplaceRecord/api/save")
                .build()
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.d(TAG, "onFailure: 失败")
            }

            @Throws(IOException::class)
            override fun onResponse(call: Call, response: Response) {
                val result = response.body()!!.string()
                runOnUiThread {
                    LogUtils.printDebug("提交: $result")
                    val jsonData = JSONObject(result)
                    if (jsonData.optString("retCode") == "0") {
                        ToastUtils.show("成功")
                        finish()
                    }
                }
            }
        })
    }

    override fun getResId(): Int {
        return R.layout.activity_work_time_details
    }
}