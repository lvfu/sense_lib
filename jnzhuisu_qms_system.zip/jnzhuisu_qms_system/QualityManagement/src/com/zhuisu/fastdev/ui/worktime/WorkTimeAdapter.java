package com.zhuisu.fastdev.ui.worktime;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.zhuisu.qualityManagement.R;

import java.util.ArrayList;

/**
 * @author cxh
 * @description
 * @date 2021/3/12.
 */
public class WorkTimeAdapter extends RecyclerView.Adapter<WorkTimeAdapter.VH> {

    private ArrayList<WorkTimeListBean> list;
    private Context context;
    public OnItemCLickListener onItemCLickListener;

    public OnItemCLickListener getOnItemCLickListener() {
        return onItemCLickListener;
    }

    public WorkTimeAdapter(ArrayList<WorkTimeListBean> list, Context context) {
        this.list = list;
        this.context = context;
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        return new VH(((LayoutInflater)(context.getSystemService(Context.LAYOUT_INFLATER_SERVICE)))
                .inflate(R.layout.item_work_time,viewGroup,false));
    }

    @Override
    public void onBindViewHolder(@NonNull VH vh, int i) {
        WorkTimeListBean data = list.get(i);
        Log.e("datasp",data.getResponseDepartment());
        vh.tv.setText((data.getCarFrameNo() + " | " )+ (data.getProduceName())+"|"+
                (data.getResponseDepartment().contains("|") ? (data.getResponseDepartment().substring(data.getResponseDepartment().indexOf("|"),data.getResponseDepartment().length()).substring(0,
                        data.getResponseDepartment().substring(data.getResponseDepartment().indexOf("|")).length()-2)) : data.getResponseDepartment())+"| "+data.getReplaceType()+"\t\t\t\t\t\t\t\t>>");
        vh.tv.setOnClickListener(v -> {
            if (onItemCLickListener != null){
                onItemCLickListener.onItemClickListener(i);
            }
        });
    }

    @Override
    public int getItemCount() {
        return list == null ? 0 : list.size();
    }

    static class VH extends RecyclerView.ViewHolder{

        private TextView tv;
        public VH(@NonNull View itemView) {
            super(itemView);
            tv = itemView.findViewById(R.id.tv);
        }
    }

    public interface OnItemCLickListener{
        void onItemClickListener(int position);
    }
}
