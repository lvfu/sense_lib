package com.zhuisu.fastdev.ui.problemquery

import android.app.Dialog
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.text.TextUtils
import android.util.ArrayMap
import android.util.Log
import android.view.View
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import com.google.gson.reflect.TypeToken
import com.zhuisu.fastdev.BaseActivity
import com.zhuisu.fastdev.adapter.problemquery.ProblemCarFrameQueryAdapter
import com.zhuisu.fastdev.beans.xiaxian.XiaXianWeiJianXiangQingBuMenList
import com.zhuisu.fastdev.beans.zhuangpei.CarFrameProList
import com.zhuisu.fastdev.ui.problem.CarFrameProblemDetailActivity
import com.zhuisu.fastdev.ui.util.BroadCastConfig
import com.zhuisu.fastdev.view.FastTitleLayout
import com.zhuisu.qualityManagement.R
import com.zhuisu.suppliermanagement.base.CaptureActivity
import com.zhuisu.suppliermanagement.util.GlobalVar
import com.zhuisu.suppliermanagement.util.ToastUtils
import com.zhuisu.suppliermanagement.util.Util
import kotlinx.android.synthetic.main.activity_problem_query.*
import kotlinx.android.synthetic.main.loading_dialog.*
import okhttp3.*
import org.json.JSONException
import org.json.JSONObject
import java.io.IOException
import java.util.*

/**
 * @author cxh
 * @description  车架 车身问题查询
 * @date 2020/11/2.
 */
class CarFrameProblemQueryActivity : BaseActivity() {
    private var recyclerView: RecyclerView? = null
    private var tv_cjh: EditText? = null
    private var adapter: ProblemCarFrameQueryAdapter? = null
    private var listBeans: MutableList<CarFrameProList>? = null
    private var isFirst = true
    private var isFinishJump = false
    private var tvStartTime : TextView? = null
    private var tvEndTime : TextView? = null
    private var etPerson : EditText? = null
    private var spClass : Spinner? = null
    private var spType : Spinner? = null
    private var etTitle : EditText? = null
    var dialog: Dialog? = null
    var isCarFrame = true //是否是车架

    private val broadCast : BroadCastChange = BroadCastChange()
    val filter : IntentFilter = IntentFilter(BroadCastConfig.BROADCAST_ACTION)

    inner class BroadCastChange : BroadcastReceiver(){
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent != null && intent.action != null && intent.action == BroadCastConfig.BROADCAST_ACTION){
                tv_cjh!!.setText(intent.extras!!.getString(BroadCastConfig.BROADCAST_ACTION_TAG))
                tv_cjh!!.setSelection(tv_cjh!!.text.toString().length)
                query()
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        unregisterReceiver(broadCast)
    }


    override fun initViews() {
        val fastTitleLayout : FastTitleLayout = findViewById(R.id.ftl_title)
        val commitUrl = intent!!.getStringExtra("title")
        fastTitleLayout.setTitle(commitUrl)
        dialog = Util.createLoadingDialog(this, "正在查询...")
        isCarFrame = commitUrl == "车架问题查询"
        listBeans = ArrayList()
        recyclerView = findViewById(R.id.recyclerview_lack)
        val linearLayoutManager = LinearLayoutManager(context)
        linearLayoutManager.orientation = LinearLayoutManager.VERTICAL
        recyclerView!!.layoutManager = linearLayoutManager
        adapter = ProblemCarFrameQueryAdapter(listBeans, context)
        recyclerView!!.adapter = adapter

        adapter!!.setOnCloseMenuClickListener { position: Int ->
            isFirst = false

            //关闭缺件
//            if (TextUtils.equals(listBeans!!.get(position).problemSource, "missing_parts")) {
//                val intent = Intent(context, CloseLackDetailActivity::class.java)
//                intent.putExtra("id", listBeans!![position].id)
//                startActivity(intent)
//                return@setOnCloseMenuClickListener
//            }

            val intent = Intent(context, CarFrameProblemDetailActivity::class.java)
            intent.putExtra(CarFrameProblemDetailActivity.REQUEST_DATA, listBeans!![position])
            intent.putExtra(CarFrameProblemDetailActivity.ACTION_FINISH_CHECK_JUMP, true)
            intent.putExtra(CarFrameProblemDetailActivity.DORM_QUERY, true)
            startActivity(intent)
        }



        tv_cjh = findViewById(R.id.tv_cjh)
        tvStartTime = findViewById(R.id.tv_start_time)
        tvEndTime = findViewById(R.id.tv_end_time)
        etPerson = findViewById(R.id.et_log_person)
        spClass = findViewById(R.id.sp_banzu)
        spType = findViewById(R.id.sp_product_source)
        etTitle = findViewById(R.id.et_title)


        tvStartTime?.setOnClickListener(DateClickListener(tvStartTime))//选择时间
        tvEndTime?.setOnClickListener(DateClickListener(tvEndTime))

        findViewById<View>(R.id.btn_query).setOnClickListener {
            isFirst = false
            query()
        }

        val tv_user_name = findViewById<TextView>(R.id.tv_user_name)
        tv_user_name.text = "\t" + GlobalVar.realname
        findViewById<View>(R.id.tv_scanf).setOnClickListener { arg0: View? ->
            val intent = Intent()
            intent.setClass(context, CaptureActivity::class.java)
            startActivityForResult(intent, 1073)
        }

        if (intent != null && intent.getStringExtra(ACTION_PARAMS) != null) {
            tv_cjh!!.setText(intent.getStringExtra(ACTION_PARAMS))
            isFinishJump = true
            adapter?.setShowClose(true)
        }

        filter.priority = Int.MAX_VALUE
        registerReceiver(broadCast, filter)

        queryDept()
//        queryType()
    }





    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1073 && resultCode == RESULT_OK) {
            tv_cjh!!.setText(data!!.getStringExtra("encoderesult"))
//            tv_cjh!!.setSelection(tv_cjh!!.text.toString().length)
        }
    }


    /**
     * 查询部门
     */
    private var buMenLists: List<XiaXianWeiJianXiangQingBuMenList>? = null
    private fun queryDept() {
        val map = ArrayMap<String, String>()
        val client = OkHttpClient()
        val requestBody = RequestBody.create(JSON, "")
        val dept = if (isCarFrame) "NC.11.51100" else "NC.15.51500"
        val request = Request.Builder()
                .get()
                .url(GlobalVar.url + "a/sys/office/api/getOfficeList?dept=" + dept)
                .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.d(TAG, "onFailure: 失败")
            }

            @Throws(IOException::class)
            override fun onResponse(call: Call, response: Response) {
                val result = response.body()!!.string()
                runOnUiThread {
                    Log.d(TAG, "onResponse: 部门$result")
                    try {
                        val jsonObject = JSONObject(result)
                        buMenLists = gson.fromJson(jsonObject.optString("data"), object : TypeToken<List<XiaXianWeiJianXiangQingBuMenList?>?>() {}.type)
                        if (buMenLists == null) return@runOnUiThread
                        val arrayAdapter = ArrayAdapter(context, R.layout.simple_textview1, buMenLists)
                        spClass!!.adapter = arrayAdapter
                        query()
                    } catch (e: JSONException) {
                        e.printStackTrace()
                    }
                }
            }
        })
    }

    override fun getResId(): Int {
        return R.layout.activity_problem_car_frame_query
    }

//    var dictList: ArrayList<RainCheckDetailActivity.RainType>? = null
//    fun queryType() {
//        showLoadingDialog()
//        val map = ArrayMap<String, String>()
//        map["type"] = "manufacture_problem_source"
//        val param = gson.toJson(map)
//        Log.e("字典参数", param)
//        val client = OkHttpClient()
//        val requestBody = RequestBody.create(JSON, param)
//        val request = Request.Builder()
//                .post(requestBody)
//                .url(GlobalVar.url + "a/common/util/api/getDict")
//                .build()
//
//        client.newCall(request).enqueue(object : Callback {
//            override fun onFailure(call: Call, e: IOException) {
//                runOnUiThread {
//                    Log.d(TAG, "onFailure: 失败")
//                    cancelLoadingDialog()
//                }
//            }
//
//            override fun onResponse(call: Call, response: Response) {
//                val result = response.body()!!.string()
//                runOnUiThread {
//                    try {
//                        Log.e("--->字典", result)
//                        cancelLoadingDialog()
//                        val jsonObject = JSONObject(result)
//                        if (TextUtils.equals(jsonObject.optString("retCode"), "0")) {
//                            val listType = object : TypeToken<ArrayList<RainCheckDetailActivity.RainType>>() {}.type
//                            dictList = Gson().fromJson(jsonObject.optString("data"), listType)
//                            val arr = ArrayAdapter(context, R.layout.simple_textview1, dictList)
//                            spType!!.adapter = arr
//                        } else
//                            showEmptyMessage()
//
//                    } catch (jsonException: JSONException) {
//                        jsonException.printStackTrace()
//                    }
//                }
//            }
//        })
//    }

    private fun query() {
        dialog?.show()
        val map = ArrayMap<String, Any>()
        map["problemLevel"] = ""
        map["beginCreateTime"] = tvStartTime?.text.toString()
        map["endCreateTime"] = tvEndTime?.text.toString()
        map["peoblemTitle"] = etTitle?.text.toString()
        map["createByName"] = etPerson?.text.toString()
        map["carframeNo"] = tv_cjh!!.text.toString()
//        map["pageNo"] = 1
//        map["pageSize"] = 100
        if (buMenLists != null && buMenLists!!.isNotEmpty()){
            map["createByDepartment"] = buMenLists!![spClass!!.selectedItemPosition].code //
        }else{
            map["createByDepartment"] = ""
        }
        map["isClose"] = ""
        map["productModel"] = if (isCarFrame)  "cj" else "cs"

//        if (dictList != null && dictList!!.isNotEmpty()) {
//            map["problemSourceValue"] = dictList!![spType!!.selectedItemPosition].value
//        }

        val param = gson.toJson(map)
        Log.e("参数", param)
        val client = OkHttpClient()
        val requestBody = RequestBody.create(JSON, param)
        val request = Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/checkfaildflow/qmsManufactureCjProblemflow/api/getProblemByCarFrameNo")
                .build()
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.d(TAG, "onFailure: 失败")
                dialog?.dismiss()
            }

            @Throws(IOException::class)
            override fun onResponse(call: Call, response: Response) {
                dialog?.dismiss()
                val result = response.body()!!.string()
                runOnUiThread { showData(result) }
            }
        })
    }

    private fun showData(result: String) {
        Log.e("--->问题关闭列表", result)
        listBeans!!.clear()
        try {
            val jsonObject = JSONObject(result)
            if (jsonObject.optString("retCode") == "0") {
                if (jsonObject.optString("data") != null && !TextUtils.isEmpty(jsonObject.optString("data"))) {
                    listBeans!!.addAll(gson.fromJson(jsonObject.optString("data"), object : TypeToken<List<CarFrameProList?>?>() {}.type))
                    adapter!!.notifyDataSetChanged()
                } else {
                    if (adapter != null) adapter!!.notifyDataSetChanged()
                    ToastUtils.show("暂无数据")
                }
            } else {
                ToastUtils.show(jsonObject.optString("retMessage"))
                adapter!!.notifyDataSetChanged()
            }
        } catch (jsonException: JSONException) {
            jsonException.printStackTrace()
        }
    }

    companion object {
        const val ACTION_PARAMS = "action_params"
    }
}