package com.zhuisu.fastdev.ui.gracelog;

import java.util.List;

/**
 * @author cxh
 * @description
 * @date 2021/2/25.
 */

public class GradeProblemProjectListBean {

    /**
     * retCode : 0
     * data : [{"id":"7e177d2cf4e9454899a8e8398021b474","isNewRecord":false,"createDate":"2021-02-25 14:09:50","updateDate":"2021-02-25 14:09:50","reviewProjectNo":"20210225001","reviewProjectName":"2021年2月25日评审一项目","reviewType":"problem_source_11_04","auditTime":"2021-02-25 00:00:00","auditPurposes":"移动端测试","auditUsers":"sense,061258,","auditUserNames":"系统管理员,赵和军,","samplingLocation":"调试区","samplingMethod":"1","samplingNum":"2","prototypeCarDes":"测试数据","prototypeCarFrames":"LJ177350,LJ177390,","fileName":"","filePath":"","auditConclusion":"","remark":"","prototypeCarModels":"ZZ4255V3846F1L/U9VDM38-标运,ZZ1185K5113E1/J7V7M51-20冷藏,","auditUserDepartments":"[NC.00.50000]济宁商用车公司,[NC.01.50100]厂领导,","onLineTimes":"2020-08-30 15:02:55,2020-08-30 19:39:47,","engineNos":"200817620427,200807840147,","engineModelNos":"MT13.44-60,MC07.24-50,","engineFactorys":"DL.00.90000|动力公司,33.01.00001|杭发,"}]
     */


    /**
     * id : 7e177d2cf4e9454899a8e8398021b474
     * isNewRecord : false
     * createDate : 2021-02-25 14:09:50
     * updateDate : 2021-02-25 14:09:50
     * reviewProjectNo : 20210225001
     * reviewProjectName : 2021年2月25日评审一项目
     * reviewType : problem_source_11_04
     * auditTime : 2021-02-25 00:00:00
     * auditPurposes : 移动端测试
     * auditUsers : sense,061258,
     * auditUserNames : 系统管理员,赵和军,
     * samplingLocation : 调试区
     * samplingMethod : 1
     * samplingNum : 2
     * prototypeCarDes : 测试数据
     * prototypeCarFrames : LJ177350,LJ177390,
     * fileName :
     * filePath :
     * auditConclusion :
     * remark :
     * prototypeCarModels : ZZ4255V3846F1L/U9VDM38-标运,ZZ1185K5113E1/J7V7M51-20冷藏,
     * auditUserDepartments : [NC.00.50000]济宁商用车公司,[NC.01.50100]厂领导,
     * onLineTimes : 2020-08-30 15:02:55,2020-08-30 19:39:47,
     * engineNos : 200817620427,200807840147,
     * engineModelNos : MT13.44-60,MC07.24-50,
     * engineFactorys : DL.00.90000|动力公司,33.01.00001|杭发,
     */

    private String id;
    private Boolean isNewRecord;
    private String createDate;
    private String updateDate;
    private String reviewProjectNo;
    private String reviewProjectName;
    private String reviewType;
    private String auditTime;
    private String auditPurposes;
    private String auditUsers;
    private String auditUserNames;
    private String samplingLocation;
    private String samplingMethod;
    private String samplingNum;
    private String prototypeCarDes;
    private String prototypeCarFrames;
    private String fileName;
    private String filePath;
    private String auditConclusion;
    private String remark;
    private String prototypeCarModels;
    private String auditUserDepartments;
    private String onLineTimes;
    private String engineNos;
    private String engineModelNos;
    private String engineFactorys;

    public void setId(String id) {
        this.id = id;
    }

    public void setNewRecord(Boolean newRecord) {
        isNewRecord = newRecord;
    }

    public void setCreateDate(String createDate) {
        this.createDate = createDate;
    }

    public void setUpdateDate(String updateDate) {
        this.updateDate = updateDate;
    }

    public void setReviewProjectNo(String reviewProjectNo) {
        this.reviewProjectNo = reviewProjectNo;
    }

    public void setReviewProjectName(String reviewProjectName) {
        this.reviewProjectName = reviewProjectName;
    }

    public void setReviewType(String reviewType) {
        this.reviewType = reviewType;
    }

    public void setAuditTime(String auditTime) {
        this.auditTime = auditTime;
    }

    public void setAuditPurposes(String auditPurposes) {
        this.auditPurposes = auditPurposes;
    }

    public void setAuditUsers(String auditUsers) {
        this.auditUsers = auditUsers;
    }

    public void setAuditUserNames(String auditUserNames) {
        this.auditUserNames = auditUserNames;
    }

    public void setSamplingLocation(String samplingLocation) {
        this.samplingLocation = samplingLocation;
    }

    public void setSamplingMethod(String samplingMethod) {
        this.samplingMethod = samplingMethod;
    }

    public void setSamplingNum(String samplingNum) {
        this.samplingNum = samplingNum;
    }

    public void setPrototypeCarDes(String prototypeCarDes) {
        this.prototypeCarDes = prototypeCarDes;
    }

    public void setPrototypeCarFrames(String prototypeCarFrames) {
        this.prototypeCarFrames = prototypeCarFrames;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }

    public void setAuditConclusion(String auditConclusion) {
        this.auditConclusion = auditConclusion;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public void setPrototypeCarModels(String prototypeCarModels) {
        this.prototypeCarModels = prototypeCarModels;
    }

    public void setAuditUserDepartments(String auditUserDepartments) {
        this.auditUserDepartments = auditUserDepartments;
    }

    public void setOnLineTimes(String onLineTimes) {
        this.onLineTimes = onLineTimes;
    }

    public void setEngineNos(String engineNos) {
        this.engineNos = engineNos;
    }

    public void setEngineModelNos(String engineModelNos) {
        this.engineModelNos = engineModelNos;
    }

    public void setEngineFactorys(String engineFactorys) {
        this.engineFactorys = engineFactorys;
    }

    public String getId() {
        return id;
    }

    public Boolean getNewRecord() {
        return isNewRecord;
    }

    public String getCreateDate() {
        return createDate;
    }

    public String getUpdateDate() {
        return updateDate;
    }

    public String getReviewProjectNo() {
        return reviewProjectNo;
    }

    public String getReviewProjectName() {
        return reviewProjectName;
    }

    public String getReviewType() {
        return reviewType;
    }

    public String getAuditTime() {
        return auditTime;
    }

    public String getAuditPurposes() {
        return auditPurposes;
    }

    public String getAuditUsers() {
        return auditUsers;
    }

    public String getAuditUserNames() {
        return auditUserNames;
    }

    public String getSamplingLocation() {
        return samplingLocation;
    }

    public String getSamplingMethod() {
        return samplingMethod;
    }

    public String getSamplingNum() {
        return samplingNum;
    }

    public String getPrototypeCarDes() {
        return prototypeCarDes;
    }

    public String getPrototypeCarFrames() {
        return prototypeCarFrames;
    }

    public String getFileName() {
        return fileName;
    }

    public String getFilePath() {
        return filePath;
    }

    public String getAuditConclusion() {
        return auditConclusion;
    }

    public String getRemark() {
        return remark;
    }

    public String getPrototypeCarModels() {
        return prototypeCarModels;
    }

    public String getAuditUserDepartments() {
        return auditUserDepartments;
    }

    public String getOnLineTimes() {
        return onLineTimes;
    }

    public String getEngineNos() {
        return engineNos;
    }

    public String getEngineModelNos() {
        return engineModelNos;
    }

    public String getEngineFactorys() {
        return engineFactorys;
    }

    @Override
    public String toString() {
        return reviewProjectName;
    }
}
