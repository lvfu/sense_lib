package com.zhuisu.fastdev.ui.TempTaskUpload

import android.content.Intent
import android.os.Parcelable
import android.text.TextUtils
import android.util.ArrayMap
import android.util.Log
import android.view.View
import android.widget.*
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.zhuisu.fastdev.BaseActivity
import com.zhuisu.fastdev.beans.zhuangpei.ZhuangPeiWeiJianXiangQingWuLiaoList
import com.zhuisu.fastdev.ui.util.LogUtils
import com.zhuisu.fastdev.ui.zhuangpei.SelectWuLiaoActivity
import com.zhuisu.qualityManagement.R
import com.zhuisu.suppliermanagement.base.CaptureActivity
import com.zhuisu.suppliermanagement.util.GlobalVar
import com.zhuisu.suppliermanagement.util.ToastUtils
import okhttp3.*
import org.json.JSONObject
import java.io.IOException

/**
 * @author cxh
 * @description
 * @date 2021/2/4.
 */

class TempTaskUploadActivity : BaseActivity(), TypeAdapter.OnCheckChangeListener {
    private var typeAdapter: TypeAdapter? = null
    private var typeList: ArrayList<TypeListBean> = ArrayList()
    private var spForm: Spinner? = null
    private var spSendDept: Spinner? = null
    private var spRegisterDept: Spinner? = null
    private var spRegisterLocation: Spinner? = null
    private var spWuLiao: TextView? = null
    private var tvDate: TextView? = null
    private var etWlCode: EditText? = null //物料条码
    private var etSendNumber: EditText? = null //发料数量
    private var etOrderNumber: EditText? = null //发货单号
    private var etRemark : EditText? = null
    private var sp_wuliaobianhao : TextView? = null

    override fun initViews() {
        val gvType: GridView = findViewById(R.id.gv_type)
        typeAdapter = TypeAdapter(typeList, context)
        gvType.adapter = typeAdapter
        typeAdapter!!.onCheckChangeListener = this
        spForm = findViewById(R.id.sp_regist_form)
        spSendDept = findViewById(R.id.sp_send_dept)
        spRegisterDept = findViewById(R.id.sp_register_dept)
        spRegisterLocation = findViewById(R.id.sp_register_location)
        spWuLiao = findViewById(R.id.sp_wuliao)
        etRemark = findViewById(R.id.et_remark)

        tvDate = findViewById(R.id.tv_date);
        tvDate!!.setOnClickListener(DateClickListener(tvDate!!))
        etWlCode = findViewById(R.id.et_wl_code)
        etSendNumber = findViewById(R.id.et_send_number)
        etOrderNumber = findViewById(R.id.et_order_number)
        sp_wuliaobianhao = findViewById(R.id.sp_wuliaobianhao)

        queryType()
        queryForm()
        queryFormDept()
        queryRegisterDept()

//        queryMetaMssage()

        spWuLiao!!.setOnClickListener {
            val intent = Intent(context, SelectWuLiaoActivity::class.java)
            startActivityForResult(intent, 0x13)
        }


        findViewById<Button>(R.id.btn_scanf).setOnClickListener {
            val intent = Intent(context, CaptureActivity::class.java)
            startActivityForResult(intent, 1073)
        }

        findViewById<Button>(R.id.btn_save).setOnClickListener {

            if (TextUtils.isEmpty(etSendNumber!!.text.toString())) {
                ToastUtils.show("请输入数量")
                return@setOnClickListener
            }

            if (TextUtils.isEmpty(etOrderNumber!!.text.toString())) {
                ToastUtils.show("请输入单号")
                return@setOnClickListener
            }
            commitData()
        }

        findViewById<Button>(R.id.btn_clear).setOnClickListener {
            etWlCode!!.setText("")
            etSendNumber!!.setText("")
            etOrderNumber!!.setText("")
        }
    }


    /**
     * 提交数据
     * */
    private fun commitData() {
        val map = ArrayMap<String, String>()
        if (typeList.isEmpty()) {
            ToastUtils.show("请选择计划类型")
            return
        }

        var canCommit = false
        for (index in typeList.indices) {
            if (typeList[index].isChecked) {
                canCommit = true
            }
        }

        if (!canCommit) {
            ToastUtils.show("请选择计划类型")
            return
        }
        var type = ""
        for (index in typeList.indices) {
            if (typeList[index].isChecked) {
                type = typeList[index].label
            }
        }
        map["plantype"] = type
        if (registerFormList.isEmpty()) {
            ToastUtils.show("请选择领料原因")
            return
        }

        map["reason"] = registerFormList[spForm!!.selectedItemPosition].reason //领料原因

        if (sendDeptList.isEmpty()) {
            ToastUtils.show("请选择发料单位")
            return
        }

        map["senddepartmentcode"] = sendDeptList[spSendDept!!.selectedItemPosition].supcode  //发料单位编码
        map["senddepartmentname"] = sendDeptList[spSendDept!!.selectedItemPosition].supnm //发料单位名称

        if (registerDeptList.isEmpty()) {
            ToastUtils.show("请选择接收单位")
            return
        }


        map["receivedepartmentcode"] = registerDeptList[spRegisterDept!!.selectedItemPosition].supcode //接收单位编码
        map["receivedepartmentname"] = registerDeptList[spRegisterDept!!.selectedItemPosition].supnm //接收单位名称

        if (TextUtils.isEmpty(tvDate!!.text.toString())) {
            ToastUtils.show("请选择要求到货日期")
            return
        }

        map["requiredate"] = tvDate!!.text.toString() + " 00:00:00" //要求到货日期

        if (registerLocationList.isEmpty()) {
            ToastUtils.show("请选择接收单位")
            return
        }

        map["receivestockcode"] = registerLocationList[spRegisterLocation!!.selectedItemPosition].warehousecode //接收仓库编号
        map["receivestockname"] = registerLocationList[spRegisterLocation!!.selectedItemPosition].warehousename //接收仓库名称

        if (zhuangPeiWeiJianXiangQingWuLiaoList != null) {

            map["materialcode"] = zhuangPeiWeiJianXiangQingWuLiaoList!!.materielId //物料号
            map["materialname"] = zhuangPeiWeiJianXiangQingWuLiaoList!!.materielName //物料名称

            map["unit"] = zhuangPeiWeiJianXiangQingWuLiaoList!!.unit
            map["suppliercode"] = zhuangPeiWeiJianXiangQingWuLiaoList!!.supplierNo //供应商号
            map["suppliername"] = zhuangPeiWeiJianXiangQingWuLiaoList!!.supplierName //供应商名称
        } else {
            ToastUtils.show("请选择或扫描物料")
        }

//        map["materialcode"] = etWlCode!!.text.toString() //物料号


        if (TextUtils.isEmpty(etSendNumber!!.text.toString())) {
            ToastUtils.show("请输入发料数量")
            return
        }
        map["requireqty"] = etSendNumber!!.text.toString() //发料数量

        if (TextUtils.isEmpty(etOrderNumber!!.text.toString())) {
            ToastUtils.show("请输入订单号")
            return
        }

        map["orderno"] = etOrderNumber!!.text.toString() //订单号

        map["remark"] = etRemark?.text.toString() //备注
        map["createbyName"] = GlobalVar.username //登陆用户
        map["officeCode"] = GlobalVar.officeCode


        val param = gson.toJson(map)
        LogUtils.printDebug("提交数据:${param}")
        val client = OkHttpClient()
        val requestBody = RequestBody.create(JSON, param)
        val request = Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/tempplan/qmsMaterialTempplan/api/saveTempplan")
                .build()
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.d(TAG, "onFailure: 失败")
            }

            @Throws(IOException::class)
            override fun onResponse(call: Call, response: Response) {
                val result = response.body()!!.string()
                runOnUiThread {
                    LogUtils.printDebug("提交:$result")
                    try {
                        val jsonData = JSONObject(result)
                        if (jsonData.optString("retCode") == "0") {
                            //{"retCode":"0","retMessage":"保存成功！"}
                            ToastUtils.show("成功")
                            finish()
                        } else {
                            ToastUtils.show(jsonData.optString("retMessage"))
                        }
                    } catch (e: Exception) {
                        e.printStackTrace()
                        ToastUtils.show("提交失败")
                    }
                }
            }
        })
    }

    override fun getResId(): Int {
        return R.layout.activity_temp_task_upload
    }

    override fun onCheckChangeListener(position: Int) {
        typeAdapter!!.notifyDataSetChanged()
    }


    /**
     * 获取物料信息
     * */
//    var wuliaoList : ArrayList<Wuliao> = ArrayList()
//    var wuliaoAdapter : ArrayAdapter<Wuliao>? = null
//    private fun queryMetaMssage() {
//        val map = ArrayMap<String, String>()
//        map["qryValue"] = ""
//        val param = gson.toJson(map)
//        LogUtils.printDebug("获取物料参数:${param}")
//        val client = OkHttpClient()
//        val requestBody = RequestBody.create(JSON, param)
//        val request = Request.Builder()
//                .post(requestBody)
//                .url(GlobalVar.url + "a/materiel/qmsManufactureMateriel/api/getMateriel")
//                .build()
//        client.newCall(request).enqueue(object : Callback {
//            override fun onFailure(call: Call, e: IOException) {
//                Log.d(TAG, "onFailure: 失败")
//            }
//
//            @Throws(IOException::class)
//            override fun onResponse(call: Call, response: Response) {
//                val result = response.body()!!.string()
//                runOnUiThread {
//                    LogUtils.printDebug("获取物料:$result")
//
//                    val jsonData = JSONObject(result)
//                    if (jsonData.optString("retCode") == "0" && jsonData.optString("data").isNotEmpty()) {
//
//                        val listType = object : TypeToken<java.util.ArrayList<Wuliao>>() {}.type
//                        val temp: ArrayList<Wuliao> = Gson().fromJson(jsonData.optString("data"), listType)
//                        wuliaoList.clear()
//                        wuliaoList.addAll(temp)
//                        wuliaoAdapter = ArrayAdapter(context!!, R.layout.simple_textview1, wuliaoList)
//                        spWuLiao!!.adapter = wuliaoAdapter
//
//                    } else {
//                        ToastUtils.show("获取物料失败,请联系管理员")
//                    }
//                }
//            }
//        })
//    }


    /**
     * 获取接收仓库
     * */
    var registerLocationList: ArrayList<RegisterLocaionBean> = ArrayList()
    var registerLocationAdapter: ArrayAdapter<RegisterLocaionBean>? = null
    private fun queryRegisterLocation() {
        registerLocationList.clear()
        if (registerLocationAdapter != null){
            registerLocationAdapter!!.notifyDataSetChanged()
        }
        val map = ArrayMap<String, String>()
        map["userName"] = GlobalVar.username
        map["ssdw"] = registerDeptList!![spRegisterDept!!.selectedItemPosition].supcode

        val param = gson.toJson(map)
        LogUtils.printDebug("获取接收仓库参数:${param}")
        val client = OkHttpClient()
        val requestBody = RequestBody.create(JSON, param)
        //a/tempplan/qmsMaterialTempplan/api/getReceiveWarehouse
        val request = Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/tempplan/qmsMaterialTempplan/api/getWarehouse")
                .build()
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.d(TAG, "onFailure: 失败")
            }

            @Throws(IOException::class)
            override fun onResponse(call: Call, response: Response) {
                val result = response.body()!!.string()
                runOnUiThread {
                    LogUtils.printDebug("获取接收仓库:$result")
                    val jsonData = JSONObject(result)
                    if (jsonData.optString("retCode") == "0" && jsonData.optString("data").isNotEmpty()) {

                        val listType = object : TypeToken<java.util.ArrayList<RegisterLocaionBean>>() {}.type
                        val temp: ArrayList<RegisterLocaionBean> = Gson().fromJson(jsonData.optString("data"), listType)
                        registerLocationList.clear()
                        registerLocationList.addAll(temp)
                        registerLocationAdapter = ArrayAdapter(context!!, R.layout.simple_textview1, registerLocationList)
                        spRegisterLocation!!.adapter = registerLocationAdapter

                    } else {
                        ToastUtils.show("获取接收仓库失败,请联系管理员")
                    }
                }
            }
        })
    }


    /**
     * 获取接收单位
     * */
    var registerDeptList: ArrayList<RegisterBean> = ArrayList()
    var registerDeptAdapter: ArrayAdapter<RegisterBean>? = null
    private fun queryRegisterDept() {
        val map = ArrayMap<String, String>()
        map["userName"] = GlobalVar.username
        val param = gson.toJson(map)
        LogUtils.printDebug("获取接收单位参数:${param}")
        val client = OkHttpClient()
        val requestBody = RequestBody.create(JSON, param)
        val request = Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/tempplan/qmsMaterialTempplan/api/getReceiveDepartment")
                .build()
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.d(TAG, "onFailure: 失败")
            }

            @Throws(IOException::class)
            override fun onResponse(call: Call, response: Response) {
                val result = response.body()!!.string()
                runOnUiThread {
                    LogUtils.printDebug("获取接收单位:$result")
                    val jsonData = JSONObject(result)
                    if (jsonData.optString("retCode") == "0" && jsonData.optString("data").isNotEmpty()) {

                        val listType = object : TypeToken<java.util.ArrayList<RegisterBean>>() {}.type
                        val temp: ArrayList<RegisterBean> = Gson().fromJson(jsonData.optString("data"), listType)
                        registerDeptList.clear()
                        registerDeptList.addAll(temp)
                        registerDeptAdapter = ArrayAdapter(context!!, R.layout.simple_textview1, registerDeptList)
                        spRegisterDept!!.adapter = registerDeptAdapter
                        for (index in registerDeptList.indices) {
                            if (registerDeptList != null && registerDeptList[index].supnm != null && registerDeptList[index].supnm.contains("济宁商用车有限公司总装厂")) {
                                spRegisterDept!!.setSelection(index, true)
                                queryRegisterLocation()
                            }
                        }

                        spRegisterDept!!.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                                queryRegisterLocation()
                            }

                            override fun onNothingSelected(parent: AdapterView<*>?) {

                            }

                        }
                    } else {
                        ToastUtils.show("获取接收单位失败,请联系管理员")
                    }
                }
            }
        })
    }


    /**
     * 获取发料单位
     * */
    var sendDeptList: ArrayList<SendDeptBean> = ArrayList()
    var sendDeptAdapter: ArrayAdapter<SendDeptBean>? = null
    private fun queryFormDept() {
        val map = ArrayMap<String, String>()
        map["userName"] = GlobalVar.username
        val param = gson.toJson(map)
        LogUtils.printDebug("获取发料单位参数:${param}")
        val client = OkHttpClient()
        val requestBody = RequestBody.create(JSON, param)
        val request = Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/tempplan/qmsMaterialTempplan/api/getSendDepartment")
                .build()
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.d(TAG, "onFailure: 失败")
            }

            @Throws(IOException::class)
            override fun onResponse(call: Call, response: Response) {
                val result = response.body()!!.string()
                runOnUiThread {
                    LogUtils.printDebug("获取发料单位参数:$result")
                    val jsonData = JSONObject(result)
                    if (jsonData.optString("retCode") == "0" && jsonData.optString("data").isNotEmpty()) {
                        val listType = object : TypeToken<java.util.ArrayList<SendDeptBean>>() {}.type
                        val temp: ArrayList<SendDeptBean> = Gson().fromJson(jsonData.optString("data"), listType)
                        sendDeptList.clear()
                        sendDeptList.addAll(temp)
                        sendDeptAdapter = ArrayAdapter(context!!, R.layout.simple_textview1, sendDeptList)
                        spSendDept!!.adapter = sendDeptAdapter
                        for (index in sendDeptList.indices) {
                            if (sendDeptList[index].supnm.contains("济宁商用车有限公司物流部")) {
                                spSendDept!!.setSelection(index, true)
                            }
                        }

                    } else {
                        ToastUtils.show("获取发料单位失败,请联系管理员")
                    }
                }
            }
        })
    }


    /**
     * 获取原因
     * */
    var registerFormList: ArrayList<RegisterForm> = ArrayList()
    var registerFormAdapter: ArrayAdapter<RegisterForm>? = null
    private fun queryForm() {
        val map = ArrayMap<String, String>()
        map["userName"] = GlobalVar.username
        val param = gson.toJson(map)
        LogUtils.printDebug("获取原因参数:${param}")
        val client = OkHttpClient()
        val requestBody = RequestBody.create(JSON, param)
        val request = Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/planreason/qmsMaterialPlanreason/api/getPlanReason")
                .build()
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.d(TAG, "onFailure: 失败")
            }

            @Throws(IOException::class)
            override fun onResponse(call: Call, response: Response) {
                val result = response.body()!!.string()
                runOnUiThread {
                    LogUtils.printDebug("获取领料原因:$result")
                    val jsonData = JSONObject(result)
                    if (jsonData.optString("retCode") == "0" && jsonData.optString("data").isNotEmpty()) {

                        val listType = object : TypeToken<java.util.ArrayList<RegisterForm>>() {}.type
                        val temp: ArrayList<RegisterForm> = Gson().fromJson(jsonData.optString("data"), listType)
                        registerFormList.clear()
                        registerFormList.addAll(temp)

                        registerFormAdapter = ArrayAdapter(context!!, R.layout.simple_textview1, registerFormList)
                        spForm!!.adapter = registerFormAdapter

                    } else {
//                        ToastUtils.show("获取临时领料原因失败,请联系管理员")
                    }
                }
            }
        })
    }


    /**
     * 获取计划类型
     * */
    private fun queryType() {
        val map = ArrayMap<String, String>()
        map["type"] = "qms_tempplan_type"
        val param = gson.toJson(map)
        val client = OkHttpClient()
        val requestBody = RequestBody.create(JSON, param)
        val request = Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/common/util/api/getDict")
                .build()
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.d(TAG, "onFailure: 失败")
            }

            @Throws(IOException::class)
            override fun onResponse(call: Call, response: Response) {
                val result = response.body()!!.string()
                runOnUiThread {
                    LogUtils.printDebug("计划类型: $result")
                    val jsonData = JSONObject(result)
                    if (jsonData.optString("retCode") == "0") {
                        val listType = object : TypeToken<java.util.ArrayList<TypeListBean>>() {}.type
                        val temp: ArrayList<TypeListBean> = Gson().fromJson(jsonData.optString("data"), listType)
                        typeList.clear()
                        typeList.addAll(temp)
                        typeAdapter!!.notifyDataSetChanged()
                    }
                }
            }
        })
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {

        if (resultCode == 0x19) {
            if (data!!.getParcelableExtra<Parcelable?>("data") != null) {
                zhuangPeiWeiJianXiangQingWuLiaoList = data.getParcelableExtra("data")
                spWuLiao!!.text = zhuangPeiWeiJianXiangQingWuLiaoList!!.materielName
                sp_wuliaobianhao!!.text = zhuangPeiWeiJianXiangQingWuLiaoList!!.materielId
            }
        } else {
            if (data != null) {
                val str = data.getStringExtra("encoderesult").toString()
                etWlCode!!.setText(str)
                etWlCode!!.setSelection(str.length)
                queryMetaByTmh()
            }
        }
        super.onActivityResult(requestCode, resultCode, data)
    }

    var zhuangPeiWeiJianXiangQingWuLiaoList: ZhuangPeiWeiJianXiangQingWuLiaoList? = null

    //根据物料名查询
    private fun queryMetaByTmh() {
        val map = ArrayMap<String, String>()
        map["tmh"] = etWlCode!!.text.toString()
        val param = gson.toJson(map)
        LogUtils.printDebug("获取物料参数:${param}")
        val client = OkHttpClient()
        val requestBody = RequestBody.create(JSON, param)
        val request = Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/materiel/qmsManufactureMateriel/api/getMaterielByTmh")
                .build()
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.d(TAG, "onFailure: 失败")
            }

            @Throws(IOException::class)
            override fun onResponse(call: Call, response: Response) {
                val result = response.body()!!.string()
                runOnUiThread {
                    LogUtils.printDebug("获取物料:$result")
                    val jsonData = JSONObject(result)
                    if (jsonData.optString("retCode") == "0" && jsonData.optString("data") != null && !TextUtils.isEmpty(jsonData.optString("data"))) {
                        zhuangPeiWeiJianXiangQingWuLiaoList = gson.fromJson(jsonData.optString("data"), ZhuangPeiWeiJianXiangQingWuLiaoList::class.java)
                        if (zhuangPeiWeiJianXiangQingWuLiaoList != null) {
                            spWuLiao!!.text = zhuangPeiWeiJianXiangQingWuLiaoList?.materielName
                            sp_wuliaobianhao!!.text = zhuangPeiWeiJianXiangQingWuLiaoList!!.materielId
                        }
                    } else {
                        ToastUtils.show("获取物料失败,请联系管理员")
                    }
                }
            }
        })
    }
}