package com.zhuisu.fastdev.ui.lackhistory;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.util.ArrayMap;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import com.google.gson.reflect.TypeToken;
import com.zhuisu.fastdev.BaseActivity;
import com.zhuisu.fastdev.adapter.lackhistoryge.CarFrameLackHistoryAdapter;
import com.zhuisu.fastdev.adapter.lackhistoryge.LackHistoryAdapter;
import com.zhuisu.fastdev.beans.lack.LackHistoryListBean;
import com.zhuisu.fastdev.dialog.BasePopupWindowDialog;
import com.zhuisu.fastdev.ui.util.BroadCastConfig;
import com.zhuisu.fastdev.view.FastTitleLayout;
import com.zhuisu.qualityManagement.R;
import com.zhuisu.suppliermanagement.base.CaptureActivity;
import com.zhuisu.suppliermanagement.util.GlobalVar;
import com.zhuisu.suppliermanagement.util.ToastUtils;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 * @author cxh
 * @description
 * @date 2020/10/30.
 */
public class CarFrameLackStorageActivity extends BaseActivity {

    private RecyclerView recyclerView;
    private EditText tv_cjh;
    private Spinner sp_params;
    private String[] queryParams;
    private CarFrameLackHistoryAdapter adapter;
    private List<LackHistoryListBean> listBeans;

    BroadCastChange broadCast = new BroadCastChange();
    IntentFilter filter = new IntentFilter(BroadCastConfig.BROADCAST_ACTION);
    private String title;

    class BroadCastChange extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent != null && intent.getAction() != null && intent.getAction().equals(BroadCastConfig.BROADCAST_ACTION)) {
                tv_cjh.setText(intent.getExtras().getString(BroadCastConfig.BROADCAST_ACTION_TAG));
                tv_cjh.setSelection(tv_cjh.getText().toString().length());
                query();
            }
        }
    }

    @SuppressLint("SetTextI18n")
    @Override
    protected void initViews() {

        title = getIntent().getStringExtra("title");
        FastTitleLayout fastTitleLayout = findViewById(R.id.ftl_title);
        fastTitleLayout.setTitle(title);


        listBeans = new ArrayList<>();
        recyclerView = findViewById(R.id.recyclerview_lack);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(context);
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        recyclerView.setLayoutManager(linearLayoutManager);

        adapter = new CarFrameLackHistoryAdapter(listBeans, context);
        recyclerView.setAdapter(adapter);
        adapter.setOnCloseMenuClickListener(position -> {
            BasePopupWindowDialog dialog = new BasePopupWindowDialog();
            Bundle bundle = new Bundle();
            bundle.putString(BasePopupWindowDialog.ACTION_VALUE_TITLE, "确定要执行该操作吗?");
            dialog.setArguments(bundle);
            dialog.show(getSupportFragmentManager(), "");
            dialog.setOnConfirmClickListener(() -> {
                dialog.dismiss();
                closeLack(position);
            });

        });

        tv_cjh = findViewById(R.id.tv_cjh);
        sp_params = findViewById(R.id.sp_params);
        queryParams = new String[]{"已登记", "已关闭"};

        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<>(context, R.layout.simple_textview1, queryParams);
        sp_params.setAdapter(arrayAdapter);

        findViewById(R.id.tv_scanf).setOnClickListener(v -> {
            Intent intent = new Intent();
            intent.setClass(context, CaptureActivity.class);
            startActivityForResult(intent, 1073);
        });
        findViewById(R.id.btn_query).setOnClickListener(v -> {
            query();
        });

        TextView tv_user_name = findViewById(R.id.tv_user_name);
        tv_user_name.setText("\t" + GlobalVar.realname);


        filter.setPriority(Integer.MAX_VALUE);
        registerReceiver(broadCast, filter);


    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        unregisterReceiver(broadCast);
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == 1073 && resultCode == Activity.RESULT_OK) {
            tv_cjh.setText(data.getStringExtra("encoderesult"));
            query();
        }
    }


    @Override
    protected void onResume() {
        super.onResume();
        query();
    }

    private void closeLack(int position) {

        Intent intent = new Intent(context, CarFrameCloseLackDetailActivity.class);
        intent.putExtra("id", listBeans.get(position).getId());
        startActivity(intent);


//        ArrayMap<String, Object> map = new ArrayMap<>();
//        map.put("id", listBeans.get(position).getId());
//        map.put("instruction","");
//        map.put("imgStr","");
//        map.put("recordUser",GlobalVar.username);
//
//        String param = gson.toJson(map);
//
//        Log.e("参数",param);
//        OkHttpClient client = new OkHttpClient();
//        RequestBody requestBody = RequestBody.create(JSON, param);
//        Request request = new Request.Builder()
//                .post(requestBody)
//                .url(GlobalVar.url + "a/missingpartsmgr/qmsManufactureMissingparts/api/closeMissingPart")
//                .build();
//
//        client.newCall(request).enqueue(new Callback() {
//            @Override
//            public void onFailure(Call call, IOException e) {
//                Log.d(TAG, "onFailure: 失败");
//            }
//
//            @Override
//            public void onResponse(Call call, Response response) throws IOException {
//                final String result = response.body().string();
//                runOnUiThread(() -> {
//                    try {
//                        Log.e("--->",result);
//                        JSONObject jsonObject = new JSONObject(result);
//                        if (TextUtils.equals(jsonObject.optString("retCode"),"0")){
//                            ToastUtils.show("成功");
//                            finish();
//                        }
//                    } catch (JSONException jsonException) {
//                        jsonException.printStackTrace();
//                    }
//                });
//            }
//        });
    }

    @Override
    protected int getResId() {
        return R.layout.activity_car_frame_lack_history;
    }

    private void query() {
        ArrayMap<String, Object> map = new ArrayMap<>();
        map.put("carFrameNo", tv_cjh.getText().toString());
        map.put("status", sp_params.getSelectedItemPosition() == 0 ? "confirmed" : "closed");
        map.put("productModel", title.contains("车架") ? "cj" : "cs");
        map.put("pageNo", 1);
        map.put("pageSize", 30);

        String param = gson.toJson(map);

        Log.e("参数", param);
        OkHttpClient client = new OkHttpClient();
        RequestBody requestBody = RequestBody.create(JSON, param);
        Request request = new Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/missingpartsmgr/qmsManufactureMissingparts/api/qryMissingPartsList")
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                Log.d(TAG, "onFailure: 失败");
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                final String result = response.body().string();
                runOnUiThread(() -> showData(result));
            }
        });
    }

    private void showData(String result) {
        Log.e("--->缺件记录", result);
        listBeans.clear();
        try {
            JSONObject jsonObject = new JSONObject(result);
            if (jsonObject.optString("retCode").equals("0")) {
                if (jsonObject.optJSONObject("data").optString("list") != null && !TextUtils.isEmpty(jsonObject.optJSONObject("data").optString("list"))) {
                    listBeans.addAll(gson.fromJson(jsonObject.optJSONObject("data").optString("list"), new TypeToken<List<LackHistoryListBean>>() {
                    }.getType()));
                } else {
                    showEmptyMessage();
                }
            } else {
                ToastUtils.show(jsonObject.optString("retMessage"));
            }
            adapter.notifyDataSetChanged();
        } catch (JSONException jsonException) {
            jsonException.printStackTrace();
        }

    }

}
