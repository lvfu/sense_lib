package com.zhuisu.fastdev.ui.TempTaskUpload

import android.annotation.SuppressLint
import android.util.ArrayMap
import android.util.Log
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.TextView
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.zhuisu.fastdev.BaseActivity
import com.zhuisu.fastdev.ui.util.LogUtils
import com.zhuisu.qualityManagement.R
import com.zhuisu.suppliermanagement.util.GlobalVar
import okhttp3.*
import org.json.JSONObject
import java.io.IOException

/**
 * @author cxh
 * @description
 * @date 2021/2/23.
 */
class TempQueryDetailActivity : BaseActivity() {
    override fun initViews() {
        findViewById<Button>(R.id.btn_finish).setOnClickListener {
            finish()
        }
        query()
    }

    private fun query() {
        val map = ArrayMap<String, String>()
        map["userName"] = GlobalVar.username
        map["id"] = intent?.getStringExtra("id")
        val param = gson.toJson(map)
        Log.e("--->", param)
        val client = OkHttpClient()
        val requestBody = RequestBody.create(JSON, param)
        val request = Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/tempplan/qmsMaterialTempplan/api/getTempplanInfo")
                .build()
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.d(TAG, "onFailure: 失败")
            }

            @SuppressLint("SetTextI18n")
            @Throws(IOException::class)
            override fun onResponse(call: Call, response: Response) {
                val result = response.body()!!.string()
                runOnUiThread {
                    LogUtils.printDebug("查询状态: $result")
                    val jsonData = JSONObject(result)
                    if (jsonData.optString("retCode") == "0") {

                        val tvType: TextView = findViewById(R.id.tv_type)
                        val source: TextView = findViewById(R.id.tv_source);
                        val sendDept: TextView = findViewById(R.id.tv_send_dept) //发料单位
                        val registerDept: TextView = findViewById(R.id.tv_register_dept) //接收单位
                        val storage: TextView = findViewById(R.id.tv_register_storage) //接收仓库
                        val time: TextView = findViewById(R.id.tv_time) //到货时间
                        val metaNumber: TextView = findViewById(R.id.tv_wlh)
                        val metaName: TextView = findViewById(R.id.tv_wlmc)
                        val createDept: TextView = findViewById(R.id.tv_scdw) //生产单位
                        val sendNumber: TextView = findViewById(R.id.tv_flsl) //发料数量
                        val payNumber: TextView = findViewById(R.id.tv_ddh)// 订单号
                        val createUser: TextView = findViewById(R.id.tv_create_user) //创建人
                        val createDate: TextView = findViewById(R.id.tv_create_date) //创建时间
                        val commitUser: TextView = findViewById(R.id.tv_commit_people)// 提交人
                        val commitDate: TextView = findViewById(R.id.tv_commit_date) //提交时间

                        val data = jsonData.optJSONObject("data")

                        tvType.text = data.optString("plantype")
                        source.text = "领料原因: ${data.optString("reason")}"
                        sendDept.text = "发料单位: ${data.optString("senddepartmentname")}"
                        registerDept.text = "接收单位: ${data.optString("receivedepartmentname")}"
                        storage.text = "接收仓库: ${data.optString("receivestockname")}"
                        time.text = "要求到货时间: ${data.optString("requiredate")}"
                        metaNumber.text = "物料号: ${data.optString("materialcode")}"
                        metaName.text = "物料名: ${data.optString("materialname")}"
                        createDept.text = "生产单位: ${data.optString("suppliername")}"
                        sendNumber.text = "发料数量: ${data.optString("requireqty")}"
                        payNumber.text = "订单号: ${data.optString("orderno")}"
                        createUser.text = "创建人: ${data.optString("createbyName")}"
                        createDate.text = "创建时间: ${data.optString("createDate")}"
                        commitUser.text = "提交人: ${data.optString("updatebyName")}"
                        commitDate.text = "提交时间: ${data.optString("updateDate")}"

                    }
                }
            }
        })
    }

    override fun getResId(): Int {
        return R.layout.activity_temp_query_detail
    }
}