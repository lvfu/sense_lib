package com.zhuisu.fastdev.ui.onlinecar

import android.annotation.SuppressLint
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Handler
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.text.TextUtils
import android.util.ArrayMap
import android.util.Log
import android.view.View
import android.widget.*
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.zhuisu.fastdev.BaseActivity
import com.zhuisu.fastdev.adapter.online.OnLineListAdapter
import com.zhuisu.fastdev.beans.online.OnLineCarListBean
import com.zhuisu.fastdev.ui.util.BroadCastConfig
import com.zhuisu.fastdev.view.FastTitleLayout
import com.zhuisu.qualityManagement.R
import com.zhuisu.suppliermanagement.base.CaptureActivity
import com.zhuisu.suppliermanagement.util.GlobalVar
import com.zhuisu.suppliermanagement.util.ToastUtils
import okhttp3.*
import org.json.JSONException
import org.json.JSONObject
import java.io.IOException

/**
 * @author cxh
 * @description 在调车辆
 * @date 2020/11/9.
 */
class OnLineCarActivity : BaseActivity(), OnLineListAdapter.OnItemClickListener {

    var typeListBeans: ArrayList<OnLineTypeList>? = null
    var spType: Spinner? = null
    var recyclerview: RecyclerView? = null
    var etDph: EditText? = null
    var etOrderNumber: EditText? = null
    var etInfo: EditText? = null
    var startDate: TextView? = null
    var endDate: TextView? = null
    var dataList: ArrayList<OnLineCarListBean>? = null
    var adapter: OnLineListAdapter? = null
    var etCarType: EditText? = null
    var llQueryParams : LinearLayout? = null
    var tvNumber : TextView? = null


    private val broadCast : BroadCastChange = BroadCastChange()
    val filter : IntentFilter = IntentFilter(BroadCastConfig.BROADCAST_ACTION)

    inner class BroadCastChange : BroadcastReceiver(){
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent != null && intent.action != null && intent.action == BroadCastConfig.BROADCAST_ACTION){
                etDph!!.setText(intent.extras!!.getString(BroadCastConfig.BROADCAST_ACTION_TAG))
                etDph!!.setSelection(etDph!!.text.toString().length)
                if (llQueryParams?.visibility == View.VISIBLE) {
                    llQueryParams?.visibility = View.GONE
                }
                queryList()
            }
        }
    }

    @SuppressLint("SetTextI18n")
    override fun initViews() {
        typeListBeans = ArrayList()
        dataList = ArrayList()

        tvNumber = findViewById(R.id.tv_numbers)
        val fastTitle: FastTitleLayout = findViewById(R.id.ftl_online_car_title)
        findViewById<Button>(R.id.btn_scanf).setOnClickListener {
            val intent = Intent()
            intent.setClass(context, CaptureActivity::class.java)
            startActivityForResult(intent, 1073)
        }
        dataList = ArrayList()

        llQueryParams  = findViewById(R.id.ll_query_params)

        fastTitle.setOnRightClickListener {
            if (llQueryParams?.visibility == View.VISIBLE) {
                llQueryParams?.visibility = View.GONE
            } else {
                llQueryParams?.visibility = View.VISIBLE
            }
        }

        etCarType = findViewById(R.id.et_car_type)
        recyclerview = findViewById(R.id.recyclerview)
        val linearLayoutManager = LinearLayoutManager(this)
        linearLayoutManager.orientation = LinearLayoutManager.VERTICAL
        recyclerview!!.layoutManager = linearLayoutManager
        etDph = findViewById(R.id.et_dph_search) //底盘号
        etOrderNumber = findViewById(R.id.et_ddh_search) //订单号
        etInfo = findViewById(R.id.et_wtms_search) //描述
        spType = findViewById(R.id.sp_type) //类型
        startDate = findViewById(R.id.date1) //开始时间
        endDate = findViewById(R.id.date2) //结束时间

        //选择日期
        startDate!!.setOnClickListener(DateClickListener(startDate))
        endDate!!.setOnClickListener(DateClickListener(endDate))

        val btnSearch: Button = findViewById(R.id.btn_search)
        btnSearch.setOnClickListener {
            llQueryParams?.visibility = View.GONE
//            Handler().postDelayed({ queryList() }, 500)
            queryList()
        }


        adapter = OnLineListAdapter(dataList!!, context)
        recyclerview!!.adapter = adapter
        adapter!!.onItemClickListener = this

        val tv_user_name: TextView = findViewById(R.id.tv_user_name)
        tv_user_name.text = "\t" + GlobalVar.realname

        filter.priority = Int.MAX_VALUE
        registerReceiver(broadCast,filter)

        query()
        queryNumber()
    }


    override fun onDestroy() {
        super.onDestroy()
        unregisterReceiver(broadCast)
    }


    override fun getResId(): Int {
        return R.layout.activity_online_car
    }


    /**
     * 查询字典
     * */
    fun queryList() {
        dataList!!.clear()
        adapter!!.notifyDataSetChanged()
        val map = ArrayMap<String, String>()
        map["carFarmeNo"] = etDph!!.text.toString()
        map["orderNo"] = etOrderNumber!!.text.toString()
        map["carModelNo"] = etCarType!!.text.toString()
        map["problemDesc"] = etInfo!!.text.toString()
        map["offLineStatus"] = typeListBeans!![spType!!.selectedItemPosition].value
        map["startTime"] = startDate!!.text.toString()
        map["endTime"] = endDate!!.text.toString()


        val param = gson.toJson(map)
        Log.e("参数", param)
        val client = OkHttpClient()
        val requestBody = RequestBody.create(JSON, param)
        val request = Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/offlinedebuggingstatus/qmsOfflineStatus/api/findCarFrameNos")
                .build()


        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread {
                    Log.d(TAG, "onFailure: 失败")
                }
            }

            @SuppressLint("SetTextI18n")
            override fun onResponse(call: Call, response: Response) {
                val result = response.body()!!.string()
                runOnUiThread {
                    try {
                        Log.e("--->", result)
                        val jsonObject = JSONObject(result)
                        if (TextUtils.equals(jsonObject.optString("status"), "0")) {
                            val listType = object : TypeToken<List<OnLineCarListBean>>() {}.type
                            val temp: ArrayList<OnLineCarListBean> = Gson().fromJson(jsonObject.optString("data"), listType)
                            dataList!!.addAll(temp)
                            adapter!!.notifyDataSetChanged()
                            tvNumber?.text = "共计:${dataList?.size} 条数据"
                        }else{
                            ToastUtils.show(jsonObject.optString("message"))
                        }
                    } catch (jsonException: JSONException) {
                        jsonException.printStackTrace()
                    }
                }
            }
        })

    }


    /**
     * 查询数值
     * */
    fun queryNumber() {
        val map = ArrayMap<String, String>()
        map["type"] = "getStatusCount"
        val param = gson.toJson(map)
        Log.e("查询数值", param)
        val client = OkHttpClient()
        val requestBody = RequestBody.create(JSON, param)
        val request = Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/offlinedebuggingstatus/qmsOfflineStatus/api/statusCount")
                .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread {
                    Log.d(TAG, "onFailure: 失败")
                }
            }

            override fun onResponse(call: Call, response: Response) {
                val result = response.body()!!.string()
                runOnUiThread {
                    try {
                        Log.e("--->数值", result)
                        val resultJson = JSONObject(result)
                        if (TextUtils.equals(resultJson.optString("status"), "0")) {
                            val jsonObject: JSONObject = resultJson.optJSONObject("data")

                            //调试总数
                            val tvOnDebug: TextView = findViewById(R.id.on_debug_count)
                            tvOnDebug.text = jsonObject.optInt("count").toString()

                            //调试状态总数
                            val tvAllCount: TextView = findViewById(R.id.tv_on_all_count)
                            tvAllCount.text = jsonObject.optInt("debug").toString()


                            //送验总数
                            val tvOffLine: TextView = findViewById(R.id.now_day_offline_count)
                            tvOffLine.text = jsonObject.optInt("submitCheckSum").toString()
                            //当天送验
                            val tvNowDayCount: TextView = findViewById(R.id.tv_now_send_count)
                            tvNowDayCount.text = jsonObject.optInt("todaySubmitCheck").toString()

                            //当天接车数
                            val tvRegistAllCount: TextView = findViewById(R.id.tv_today_register_count)
                            tvRegistAllCount.text = jsonObject.optInt("today").toString()
                            //当天调试数
                            val tvDebugCount: TextView = findViewById(R.id.tv_today_debug_count)
                            tvDebugCount.text = jsonObject.optInt("todayDebug").toString()
                            //故障总数
                            val tvErrorCount: TextView = findViewById(R.id.tv_error_count)
                            tvErrorCount.text = jsonObject.optInt("troubleshooting").toString()
                            //当天终检数
                            val tvBreakCount: TextView = findViewById(R.id.tv_break_count)
                            tvBreakCount.text = jsonObject.optInt("todayWareHousingIn").toString()

                            val tvUpLineTime: TextView = findViewById(R.id.tv_today_upline)  //当天上线数
                            tvUpLineTime.text = jsonObject.optInt("todayOnLine").toString()

                            val tvOffLineTime: TextView = findViewById(R.id.tv_today_offline_time) //当天下线数
                            tvOffLineTime.text = jsonObject.optInt("todayDownLine").toString()

                            val tvFinishPullNumber : TextView = findViewById(R.id.tv_pull_finish_number)
                            tvFinishPullNumber.text = jsonObject.optInt("troubleshootingpassed").toString()
                        }
                    } catch (jsonException: JSONException) {
                        jsonException.printStackTrace()
                    }
                }
            }
        })
    }


    /**
     * 查询字典
     * */
    fun query() {
        val map = ArrayMap<String, String>()
        map["type"] = "OFFLINE_DEBUGGING_STATUS"
        val param = gson.toJson(map)
        Log.e("字典参数", param)
        val client = OkHttpClient()
        val requestBody = RequestBody.create(JSON, param)
        val request = Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/common/util/api/getDict")
                .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread {
                    Log.d(TAG, "onFailure: 失败")
                }
            }

            override fun onResponse(call: Call, response: Response) {
                val result = response.body()!!.string()
                runOnUiThread {
                    try {
                        Log.e("--->", result)
                        val jsonObject = JSONObject(result)
                        if (TextUtils.equals(jsonObject.optString("retCode"), "0")) {
                            val listType = object : TypeToken<ArrayList<OnLineTypeList>>() {}.type
                            val temp: ArrayList<OnLineTypeList> = Gson().fromJson(jsonObject.optString("data"), listType)
                            val all = OnLineTypeList("", "全部", "")
                            typeListBeans!!.add(all)
                            typeListBeans!!.addAll(temp)

                            val arr = ArrayAdapter(context, R.layout.simple_textview1, typeListBeans)
                            spType!!.adapter = arr
                        } else
                            showEmptyMessage()

                    } catch (jsonException: JSONException) {
                        jsonException.printStackTrace()
                    }
                }
            }
        })
    }


    data class OnLineTypeList(var id: String, var label: String, var value: String) {
        override fun toString(): String {
            return label
        }
    }

    override fun onItemClickListener(position: Int) {
        val intent = Intent(context, OnLineCarDetailActivity::class.java)
        intent.putExtra(OnLineCarDetailActivity.ACTION_DATA, dataList?.get(position))
        startActivity(intent)
    }


    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == 1073 && resultCode == RESULT_OK) {
            etDph!!.setText(data!!.getStringExtra("encoderesult"))
            queryList()
        }
        super.onActivityResult(requestCode, resultCode, data)
    }

}