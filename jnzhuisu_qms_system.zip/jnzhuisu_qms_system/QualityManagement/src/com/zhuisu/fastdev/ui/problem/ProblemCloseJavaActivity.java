package com.zhuisu.fastdev.ui.problem;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.util.ArrayMap;
import android.util.Log;
import android.widget.EditText;
import android.widget.TextView;

import com.google.gson.reflect.TypeToken;
import com.zhuisu.fastdev.BaseActivity;
import com.zhuisu.fastdev.adapter.lackhistoryge.ProblemCloseAdapter;
import com.zhuisu.fastdev.beans.ProblemCloseBean;
import com.zhuisu.fastdev.ui.lackhistory.CloseLackDetailActivity;
import com.zhuisu.qualityManagement.R;
import com.zhuisu.suppliermanagement.base.CaptureActivity;
import com.zhuisu.suppliermanagement.util.GlobalVar;
import com.zhuisu.suppliermanagement.util.ToastUtils;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 * @author cxh
 * @description
 * @date 2020/11/2.
 */
public class ProblemCloseJavaActivity extends BaseActivity {
    private RecyclerView recyclerView;
    private EditText tv_cjh;
    private String[] queryParams;
    private ProblemCloseAdapter adapter;
    private List<ProblemCloseBean> listBeans;
    private boolean isFirst = true;


    @Override
    protected void initViews() {
        listBeans = new ArrayList<>();
        recyclerView = findViewById(R.id.recyclerview_lack);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(context);
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        recyclerView.setLayoutManager(linearLayoutManager);

        adapter = new ProblemCloseAdapter(listBeans, context);
        recyclerView.setAdapter(adapter);
        adapter.setOnCloseMenuClickListener(position -> {
            isFirst = false;
            if (TextUtils.equals(listBeans.get(position).getProblemSource(),"missing_parts")){
                Intent intent = new Intent(context, CloseLackDetailActivity.class);
                intent.putExtra("id",listBeans.get(position).getId());
                startActivity(intent);
                return;
            }

            Intent intent = new Intent(context, ProblemDetailActivity.class);
            intent.putExtra(ProblemDetailActivity.REQUEST_DATA, listBeans.get(position));
            startActivity(intent);
        });

        tv_cjh = findViewById(R.id.tv_cjh);
        queryParams = new String[]{"已登记", "已关闭"};


        findViewById(R.id.btn_query).setOnClickListener(v -> {
            isFirst = false;
            query();
        });


        TextView tv_user_name = findViewById(R.id.tv_user_name);
        tv_user_name.setText("\t" + GlobalVar.realname);


        findViewById(R.id.tv_scanf).setOnClickListener(arg0 -> {
            Intent intent = new Intent();
            intent.setClass(context, CaptureActivity.class);
            startActivityForResult(intent, 1073);
        });

    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1073 && resultCode == Activity.RESULT_OK) {
            tv_cjh.setText(data.getStringExtra("encoderesult"));
            query();
        }
    }


    @Override
    protected void onResume() {
        super.onResume();
        if (!isFirst) {
            query();
        }
    }


    @Override
    protected int getResId() {
        return R.layout.activity_problem_close;
    }

    private void query() {
        ArrayMap<String, Object> map = new ArrayMap<>();
        map.put("problemSource", "");//offLineCheck
        map.put("problemLevel", "");
        map.put("beginOccurTime", "");
        map.put("endOccurTime", "");
        map.put("peoblemTitle", "");
        map.put("feedbackUser", "");
        map.put("carFrameNo", tv_cjh.getText().toString());
        map.put("pageNo", 1);
        map.put("pageSize", 100);

        String param = gson.toJson(map);

        Log.e("参数", param);
        OkHttpClient client = new OkHttpClient();
        RequestBody requestBody = RequestBody.create(JSON, param);
        Request request = new Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/checkfaildflow/qmsManufactureProblemflow/api/notCloseProblemPage")
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                Log.d(TAG, "onFailure: 失败");
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                final String result = response.body().string();
                runOnUiThread(() -> showData(result));
            }
        });
    }

    private void showData(String result) {
        Log.e("--->问题关闭列表", result);
        listBeans.clear();
        try {
            JSONObject jsonObject = new JSONObject(result);
            if (jsonObject.optString("retCode").equals("0")) {
                if (jsonObject.optJSONObject("data").optString("list") != null && !TextUtils.isEmpty(jsonObject.optJSONObject("data").optString("list")) ) {
                    listBeans.addAll(gson.fromJson(jsonObject.optJSONObject("data").optString("list"), new TypeToken<List<ProblemCloseBean>>() {}.getType()));
                    adapter.notifyDataSetChanged();
                } else {
                    if (adapter != null) adapter.notifyDataSetChanged();
                    ToastUtils.show("暂无数据");
                }
            }else{
                ToastUtils.show(jsonObject.optString("retMessage"));
            }
        } catch (JSONException jsonException) {
            jsonException.printStackTrace();
        }

    }

}
