package com.zhuisu.fastdev.ui.finishcheck;

import android.content.Context;
import android.graphics.Canvas;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.view.View;

/**
 * @author cxh
 * @description
 * @date 2021/1/19.
 */
public class SmartView extends View {
    public SmartView(Context context) {
        this(context,null);
    }

    public SmartView(Context context, @Nullable AttributeSet attrs) {
        this(context, attrs,0);
    }

    public SmartView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);

    }


   /*
   * reference：某一资源ID
   * color 颜色值
   * boolean 布尔值
   * dimension 尺寸值
   * float 浮点数
   * string 字符
   * fraction 百分数
   * enum 枚举值
   * flag 位或运算 可以有多个值  枚举值的增强版 <flag
   * | 混合类型
   *
   *
   *
   * EXACTLY 精准模式
   * AT_MOST 最大模式
   * UNSPECIFIED 无限制
   * */
    //自定义绘制三部曲
    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec); //测量
        int width = getWidth();
        int firWidth = getRight() - getLeft();
        int height = getHeight();
        int firHeight = getBottom() - getTop();


        // 获取测量模式
        int specMode = MeasureSpec.getMode(widthMeasureSpec);
    }


    @Override
    protected void onLayout(boolean changed, int left, int top, int right, int bottom) {
        super.onLayout(changed, left, top, right, bottom);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
    }
}
