package com.zhuisu.fastdev.ui.finishcheck

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Bundle
import android.os.Handler
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.text.TextUtils
import android.util.ArrayMap
import android.util.Log
import android.widget.*
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.zhuisu.fastdev.BaseActivity
import com.zhuisu.fastdev.adapter.finishcheck.FinishCheckAdapter
import com.zhuisu.fastdev.beans.FinishCheckList
import com.zhuisu.fastdev.dialog.BasePopupWindowDialog
import com.zhuisu.fastdev.ui.util.BroadCastConfig
import com.zhuisu.qualityManagement.R
import com.zhuisu.suppliermanagement.base.CaptureActivity
import com.zhuisu.suppliermanagement.util.GlobalVar
import com.zhuisu.suppliermanagement.util.ToastUtils
import okhttp3.*
import org.json.JSONException
import org.json.JSONObject
import java.io.IOException

/**
 * @author cxh
 * @description
 * @date 2020/11/16.
 */
class FinishCheckActivity : BaseActivity(), FinishCheckAdapter.FirstSuccess {
    var etCarNumber: EditText? = null
    var recyclerView: RecyclerView? = null
    var list: ArrayList<FinishCheckList>? = null
    private var adapter: FinishCheckAdapter? = null

    private val broadCast: BroadCastChange = BroadCastChange()
    val filter: IntentFilter = IntentFilter(BroadCastConfig.BROADCAST_ACTION)

    inner class BroadCastChange : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent != null && intent.action != null && intent.action == BroadCastConfig.BROADCAST_ACTION) {
                etCarNumber!!.setText(intent.extras!!.getString(BroadCastConfig.BROADCAST_ACTION_TAG))
                etCarNumber!!.setSelection(etCarNumber!!.text.toString().length)
                query()
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        unregisterReceiver(broadCast)
    }

    override fun initViews() {

        val tvUserName: TextView = findViewById(R.id.tv_user_name)
        recyclerView = findViewById(R.id.recyclerview)
        list = ArrayList();
        etCarNumber = findViewById(R.id.tv_cjh)
        tvUserName.text = "\t" + GlobalVar.realname
        val manager = LinearLayoutManager(context)
        manager.orientation = LinearLayoutManager.VERTICAL
        recyclerView!!.layoutManager = manager
        adapter = FinishCheckAdapter(list!!, context!!)
        recyclerView!!.adapter = adapter
        adapter?.firstSuccess = this


        findViewById<TextView>(R.id.tv_scanf).setOnClickListener {
            val intent = Intent(context, CaptureActivity::class.java)
            startActivityForResult(intent, 1073)
        }

        findViewById<Button>(R.id.btn_query).setOnClickListener {
            query()
        }

        filter.priority = Int.MAX_VALUE
        registerReceiver(broadCast, filter)
    }

    fun query() {
        list!!.clear()
        adapter!!.notifyDataSetChanged()
        val map = ArrayMap<String, String>()
        map["flowCarNo"] = ""
        map["carFarmeNo"] = etCarNumber!!.text.toString()
        map["pageNo"] = "1"
        map["pageSize"] = "100"
        map["status"] = "submitcheck"
        map["submitCheckOperType"] = "finalCheck"

        val param = gson.toJson(map)
        Log.e("参数", param)
        val client = OkHttpClient()
        val requestBody = RequestBody.create(JSON, param)
        val request = Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/offlinedebuggingstatus/qmsOfflineStatus/api/list")
                .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread {
                    Log.d(TAG, "onFailure: 失败")
                }
            }

            override fun onResponse(call: Call, response: Response) {
                val result = response.body()!!.string()
                runOnUiThread {
                    try {
                        Log.e("--->列表", result)
                        val jsonObject = JSONObject(result)
                        if (TextUtils.equals(jsonObject.optString("status"), "0")) {
                            val listType = object : TypeToken<ArrayList<FinishCheckList>>() {}.type
                            val temp: ArrayList<FinishCheckList> = Gson().fromJson(jsonObject.optJSONObject("data").optString("list"), listType)
                            list!!.addAll(temp)
                            adapter!!.notifyDataSetChanged()
                            if (list != null && list!!.isEmpty()) {
                                showEmptyMessage()
                            }
                        } else {
                            ToastUtils.show(jsonObject.optString("msg"))
                        }

                    } catch (jsonException: JSONException) {
                        jsonException.printStackTrace()
                    }
                }
            }
        })
    }


    override fun getResId(): Int {
        return R.layout.activity_finish_check
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (data != null) {
            val str = data!!.getStringExtra("encoderesult").toString()
            etCarNumber!!.setText(str)
            query()
        }
        super.onActivityResult(requestCode, resultCode, data)
    }

    override fun firstSuccess(position: Int) {

        val dialog = BasePopupWindowDialog()
        val arguments = Bundle()
        arguments.putString(BasePopupWindowDialog.ACTION_VALUE_TITLE, "提示")
        arguments.putString(BasePopupWindowDialog.ACTION_VALUE_MESSAGE, "是否初验完成?")
        dialog.arguments = arguments

        dialog.setOnConfirmClickListener {
            dialog.dismiss()
            commitData(position)
        }
        dialog.show(supportFragmentManager, "")
    }

    /**
     * 初验完成
     */
    private fun commitData(position: Int) {
        val map = ArrayMap<String, String>()
        map["carFarmeNo"] = list!![position].carFarmeNo
        map["status"] = "submitcheckpassed"
        map["userName"] = GlobalVar.username
        map["testProect"] = gson.toJson(list!![position].listZcproject)

        if (list!![position].location != null) {
            map["location"] = list!![position].location
        } else {
            map["location"] = ""
        }

        val param = gson.toJson(map)
        showCommitDialog()
        val client = OkHttpClient()
        val requestBody = RequestBody.create(JSON, param)
        val request = Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/offlinedebuggingstatus/qmsOfflineStatus/api/updateOffLineStatus")
                .build()
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.d(TAG, "onFailure: 失败")
                runOnUiThread {
                    showNetErrorMessage()
                    cancelDialog()
                }
            }

            @Throws(IOException::class)
            override fun onResponse(call: Call, response: Response) {
                val result = response.body()!!.string()
                Log.d(TAG, "onResponse: $result")
                runOnUiThread {
                    try {
                        cancelDialog()
                        val jsonObject = JSONObject(result)
                        if (jsonObject.optString("status") == "0") {

                            ToastUtils.show(jsonObject.optString("msg"))
                            Handler().postDelayed({
                                query()
                            }, 1300)

//                            val dialog = BasePopupWindowDialog()
//                            val arguments = Bundle()
//                            arguments.putString(BasePopupWindowDialog.ACTION_VALUE_TITLE, "提示")
//                            arguments.putString(BasePopupWindowDialog.ACTION_VALUE_MESSAGE, jsonObject.optString("msg"))
//                            dialog.arguments = arguments
//
//                            dialog.setOnConfirmClickListener {
//                                dialog.dismiss()
//                                query()
//                            }
//                            dialog.show(supportFragmentManager, "")
                        } else {
                            ToastUtils.show(jsonObject.optString("msg"))
                        }
                    } catch (e: JSONException) {
                        e.printStackTrace()
                    }
                }
            }
        })
    }


}