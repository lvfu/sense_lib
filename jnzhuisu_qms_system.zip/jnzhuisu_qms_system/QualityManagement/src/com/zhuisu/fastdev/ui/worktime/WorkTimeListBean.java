package com.zhuisu.fastdev.ui.worktime;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.List;

/**
 * @author cxh
 * @description
 * @date 2021/3/12.
 */

public class WorkTimeListBean implements Parcelable {

    /**
     * retCode : 0
     * data : {"pageNo":1,"pageSize":100,"count":1,"list":[{"id":"833c08dd2fc84041aa7a0c3dd7910831","isNewRecord":false,"createDate":"2021-03-12 16:42:38","updateDate":"2021-03-12 16:42:38","carFrameNo":"LJ192540","orderNo":"ASSJ20120040","replaceDate":"2021-03-12 00:00:00","location":"嘻嘻看","team":"NC065060001","joinUser":"5c1bad4dddcd4205b37b55ba0f4fdd71","joinUserNames":"5c1bad4dddcd4205b37b55ba0f4fdd71","produceName":"管夹(济南车轮厂)","productNo":"138091360181/1      ","reason":"行咯打","responseDepartment":"JC.23.62300         |中国重汽集团济南商用车有限公司（车轮厂）","num":"12","replaceType":"返修","accessoriesConsume":"弟弟","accessoriesConsumeFee":"对的","procStatus":"","workShop":"NC.10.51000","remark":"三日内未回复仲裁申请，将按以上考核金额从货款中扣除。"}],"maxResults":100,"firstResult":0}
     */


    /**
     * pageNo : 1
     * pageSize : 100
     * count : 1
     * list : [{"id":"833c08dd2fc84041aa7a0c3dd7910831","isNewRecord":false,"createDate":"2021-03-12 16:42:38","updateDate":"2021-03-12 16:42:38","carFrameNo":"LJ192540","orderNo":"ASSJ20120040","replaceDate":"2021-03-12 00:00:00","location":"嘻嘻看","team":"NC065060001","joinUser":"5c1bad4dddcd4205b37b55ba0f4fdd71","joinUserNames":"5c1bad4dddcd4205b37b55ba0f4fdd71","produceName":"管夹(济南车轮厂)","productNo":"138091360181/1      ","reason":"行咯打","responseDepartment":"JC.23.62300         |中国重汽集团济南商用车有限公司（车轮厂）","num":"12","replaceType":"返修","accessoriesConsume":"弟弟","accessoriesConsumeFee":"对的","procStatus":"","workShop":"NC.10.51000","remark":"三日内未回复仲裁申请，将按以上考核金额从货款中扣除。"}]
     * maxResults : 100
     * firstResult : 0
     */


    /**
     * id : 833c08dd2fc84041aa7a0c3dd7910831
     * isNewRecord : false
     * createDate : 2021-03-12 16:42:38
     * updateDate : 2021-03-12 16:42:38
     * carFrameNo : LJ192540
     * orderNo : ASSJ20120040
     * replaceDate : 2021-03-12 00:00:00
     * location : 嘻嘻看
     * team : NC065060001
     * joinUser : 5c1bad4dddcd4205b37b55ba0f4fdd71
     * joinUserNames : 5c1bad4dddcd4205b37b55ba0f4fdd71
     * produceName : 管夹(济南车轮厂)
     * productNo : 138091360181/1
     * reason : 行咯打
     * responseDepartment : JC.23.62300         |中国重汽集团济南商用车有限公司（车轮厂）
     * num : 12
     * replaceType : 返修
     * accessoriesConsume : 弟弟
     * accessoriesConsumeFee : 对的
     * procStatus :
     * workShop : NC.10.51000
     * remark : 三日内未回复仲裁申请，将按以上考核金额从货款中扣除。
     */

    private String id;
    private Boolean isNewRecord;
    private String createDate;
    private String updateDate;
    private String carFrameNo;
    private String orderNo;
    private String replaceDate;
    private String location;
    private String team;
    private String joinUser;
    private String joinUserNames;
    private String produceName;
    private String productNo;
    private String reason;
    private String responseDepartment;
    private String num;
    private String replaceType;
    private String accessoriesConsume;
    private String accessoriesConsumeFee;
    private String procStatus;
    private String workShop;
    private String remark;

    protected WorkTimeListBean(Parcel in) {
        id = in.readString();
        byte tmpIsNewRecord = in.readByte();
        isNewRecord = tmpIsNewRecord == 0 ? null : tmpIsNewRecord == 1;
        createDate = in.readString();
        updateDate = in.readString();
        carFrameNo = in.readString();
        orderNo = in.readString();
        replaceDate = in.readString();
        location = in.readString();
        team = in.readString();
        joinUser = in.readString();
        joinUserNames = in.readString();
        produceName = in.readString();
        productNo = in.readString();
        reason = in.readString();
        responseDepartment = in.readString();
        num = in.readString();
        replaceType = in.readString();
        accessoriesConsume = in.readString();
        accessoriesConsumeFee = in.readString();
        procStatus = in.readString();
        workShop = in.readString();
        remark = in.readString();
    }

    public static final Creator<WorkTimeListBean> CREATOR = new Creator<WorkTimeListBean>() {
        @Override
        public WorkTimeListBean createFromParcel(Parcel in) {
            return new WorkTimeListBean(in);
        }

        @Override
        public WorkTimeListBean[] newArray(int size) {
            return new WorkTimeListBean[size];
        }
    };

    public void setId(String id) {
        this.id = id;
    }

    public void setNewRecord(Boolean newRecord) {
        isNewRecord = newRecord;
    }

    public void setCreateDate(String createDate) {
        this.createDate = createDate;
    }

    public void setUpdateDate(String updateDate) {
        this.updateDate = updateDate;
    }

    public void setCarFrameNo(String carFrameNo) {
        this.carFrameNo = carFrameNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    public void setReplaceDate(String replaceDate) {
        this.replaceDate = replaceDate;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public void setTeam(String team) {
        this.team = team;
    }

    public void setJoinUser(String joinUser) {
        this.joinUser = joinUser;
    }

    public void setJoinUserNames(String joinUserNames) {
        this.joinUserNames = joinUserNames;
    }

    public void setProduceName(String produceName) {
        this.produceName = produceName;
    }

    public void setProductNo(String productNo) {
        this.productNo = productNo;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public void setResponseDepartment(String responseDepartment) {
        this.responseDepartment = responseDepartment;
    }

    public void setNum(String num) {
        this.num = num;
    }

    public void setReplaceType(String replaceType) {
        this.replaceType = replaceType;
    }

    public void setAccessoriesConsume(String accessoriesConsume) {
        this.accessoriesConsume = accessoriesConsume;
    }

    public void setAccessoriesConsumeFee(String accessoriesConsumeFee) {
        this.accessoriesConsumeFee = accessoriesConsumeFee;
    }

    public void setProcStatus(String procStatus) {
        this.procStatus = procStatus;
    }

    public void setWorkShop(String workShop) {
        this.workShop = workShop;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getId() {
        return id;
    }

    public Boolean getNewRecord() {
        return isNewRecord;
    }

    public String getCreateDate() {
        return createDate;
    }

    public String getUpdateDate() {
        return updateDate;
    }

    public String getCarFrameNo() {
        return carFrameNo;
    }

    public String getOrderNo() {
        return orderNo;
    }

    public String getReplaceDate() {
        return replaceDate;
    }

    public String getLocation() {
        return location;
    }

    public String getTeam() {
        return team;
    }

    public String getJoinUser() {
        return joinUser;
    }

    public String getJoinUserNames() {
        return joinUserNames;
    }

    public String getProduceName() {
        return produceName;
    }

    public String getProductNo() {
        return productNo;
    }

    public String getReason() {
        return reason;
    }

    public String getResponseDepartment() {
        return responseDepartment;
    }

    public String getNum() {
        return num;
    }

    public String getReplaceType() {
        return replaceType;
    }

    public String getAccessoriesConsume() {
        return accessoriesConsume;
    }

    public String getAccessoriesConsumeFee() {
        return accessoriesConsumeFee;
    }

    public String getProcStatus() {
        return procStatus;
    }

    public String getWorkShop() {
        return workShop;
    }

    public String getRemark() {
        return remark;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(id);
        dest.writeByte((byte) (isNewRecord == null ? 0 : isNewRecord ? 1 : 2));
        dest.writeString(createDate);
        dest.writeString(updateDate);
        dest.writeString(carFrameNo);
        dest.writeString(orderNo);
        dest.writeString(replaceDate);
        dest.writeString(location);
        dest.writeString(team);
        dest.writeString(joinUser);
        dest.writeString(joinUserNames);
        dest.writeString(produceName);
        dest.writeString(productNo);
        dest.writeString(reason);
        dest.writeString(responseDepartment);
        dest.writeString(num);
        dest.writeString(replaceType);
        dest.writeString(accessoriesConsume);
        dest.writeString(accessoriesConsumeFee);
        dest.writeString(procStatus);
        dest.writeString(workShop);
        dest.writeString(remark);
    }
}
