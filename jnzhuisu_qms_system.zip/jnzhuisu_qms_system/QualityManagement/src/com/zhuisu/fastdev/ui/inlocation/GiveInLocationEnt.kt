package com.zhuisu.fastdev.ui.inlocation

/**
 * @author cxh
 * @description
 * @date 2021/1/21.
 */
data class GiveInLocationEnt (var newRecord: Boolean?,var fldWlBh: String?,var fldWlMc: String?,var fldWlLy: String?,var supplierName: String?,var quantity: String?){
    /**
     * retCode : 0
     * data : [{"isNewRecord":true,"fldWlBh":"17017360015         ","fldWlMc":"管子12 直通/三通"},{"isNewRecord":true,"fldWlBh":"17017360015/1       ","fldWlMc":"管子12 直通/三通","fldWlLy":"37.01.00545         ","supplierName":"大正东智            "}]
     */
    /**
     * isNewRecord : true
     * fldWlBh : 17017360015
     * fldWlMc : 管子12 直通/三通
     * fldWlLy : 37.01.00545
     * supplierName : 大正东智
     */

}