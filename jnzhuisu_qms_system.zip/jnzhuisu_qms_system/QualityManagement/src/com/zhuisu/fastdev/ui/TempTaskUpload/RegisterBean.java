package com.zhuisu.fastdev.ui.TempTaskUpload;

/**
 * @author cxh
 * @description
 * @date 2021/2/4.
 */
public class RegisterBean {
    private String supcode;
    private String id;
    private String supnm;
    private String supsnm;
    private String orgCode;

    public void setSupcode(String supcode) {
        this.supcode = supcode;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setSupnm(String supnm) {
        this.supnm = supnm;
    }

    public void setSupsnm(String supsnm) {
        this.supsnm = supsnm;
    }

    public void setOrgCode(String orgCode) {
        this.orgCode = orgCode;
    }

    public String getSupcode() {
        return supcode;
    }

    public String getId() {
        return id;
    }

    public String getSupnm() {
        return supnm;
    }

    public String getSupsnm() {
        return supsnm;
    }

    public String getOrgCode() {
        return orgCode;
    }

    @Override
    public String toString() {
        return supcode+"\n\n"+supsnm;
    }
}
