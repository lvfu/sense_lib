package com.zhuisu.fastdev.ui.qualityaskquery

import android.content.Context
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import com.zhuisu.qualityManagement.R

/**
 * @author cxh
 * @description
 * @date 2021/3/1.
 */
class QualityAfterPeoblemQueryAdapter(list : ArrayList<AfterQualityProblemListBean>,context : Context) : RecyclerView.Adapter<QualityAfterPeoblemQueryAdapter.VH>() {

    private var list : ArrayList<AfterQualityProblemListBean>? = null
    private var context : Context? = null
    public var onItemClickListener : OnItemClickListener? = null


    init {
        this.list = list
        this.context = context
    }

    inner class VH(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val itemDate : TextView = itemView.findViewById(R.id.tv_item_date)
        val itemSource : TextView = itemView.findViewById(R.id.tv_item_source)
        val itemInfo : TextView = itemView.findViewById(R.id.tv_item_info)
        val llDetail : LinearLayout = itemView.findViewById(R.id.ll_root)
    }

    override fun onCreateViewHolder(p0: ViewGroup, p1: Int): VH {
       return VH(((context!!.getSystemService(Context.LAYOUT_INFLATER_SERVICE)) as LayoutInflater).inflate(R.layout.item_after_quality_problem_query,p0,false))
    }

    override fun onBindViewHolder(p0: VH, p1: Int) {
        p0.itemDate.text = list!![p0.adapterPosition].happenTime.split(" ")[0]

        val text: String = when{
            list!![p0.adapterPosition].problemSource.contains("problem_source_04") -> {
                "售后"
            }

            list!![p0.adapterPosition].problemSource.contains("problem_source_14") -> {
                "零公里"
            }
            else ->{
                "评审"
            }
        }

        p0.itemSource.text = text
        p0.itemInfo.text = list!![p0.adapterPosition].problemDesc
        p0.llDetail.setOnClickListener {
            if (onItemClickListener != null){
                onItemClickListener!!.onItemClickListener(p0.adapterPosition)
            }
        }
    }

    override fun getItemCount(): Int {
        return if (list == null) 0 else list!!.size
    }

    public interface OnItemClickListener{
        fun onItemClickListener(position : Int)
    }
}