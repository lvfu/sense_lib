package com.zhuisu.fastdev.ui.problem

import android.app.Dialog
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Bundle
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.text.TextUtils
import android.util.ArrayMap
import android.util.Log
import android.view.View
import android.widget.EditText
import android.widget.TextView
import com.google.gson.reflect.TypeToken
import com.zhuisu.fastdev.BaseActivity
import com.zhuisu.fastdev.adapter.lackhistoryge.ProblemCloseAdapter
import com.zhuisu.fastdev.beans.ProblemCloseBean
import com.zhuisu.fastdev.dialog.BasePopupWindowDialog
import com.zhuisu.fastdev.ui.lackhistory.CloseLackDetailActivity
import com.zhuisu.fastdev.ui.util.BroadCastConfig
import com.zhuisu.qualityManagement.R
import com.zhuisu.suppliermanagement.base.CaptureActivity
import com.zhuisu.suppliermanagement.util.GlobalVar
import com.zhuisu.suppliermanagement.util.ToastUtils
import com.zhuisu.suppliermanagement.util.Util
import okhttp3.*
import org.json.JSONException
import org.json.JSONObject
import java.io.IOException
import java.util.*

/**
 * @author cxh
 * @description
 * @date 2020/11/2.
 */
class ProblemCloseActivity : BaseActivity() {
    private var recyclerView: RecyclerView? = null
    private var tv_cjh: EditText? = null
    private var queryParams: Array<String>? = null
    private var adapter: ProblemCloseAdapter? = null
    private var listBeans: MutableList<ProblemCloseBean>? = null
    private var isFirst = true
    private var isFinishJump = false
    private var isFinishCheckJump = false //从整车初验跳过
    private var etProblemmTitle : EditText? = null

    private val broadCast : BroadCastChange = BroadCastChange()
    val filter : IntentFilter = IntentFilter(BroadCastConfig.BROADCAST_ACTION)
    var dialog: Dialog? = null

    inner class BroadCastChange : BroadcastReceiver(){
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent != null && intent.action != null && intent.action == BroadCastConfig.BROADCAST_ACTION){
                tv_cjh!!.setText(intent.extras!!.getString(BroadCastConfig.BROADCAST_ACTION_TAG))
                tv_cjh!!.setSelection(tv_cjh!!.text.toString().length)
                query()
            }
        }
    }

    override fun initViews() {
        listBeans = ArrayList()
        dialog = Util.createLoadingDialog(this, "正在查询...")
        etProblemmTitle = findViewById(R.id.et_problem);
        recyclerView = findViewById(R.id.recyclerview_lack)
        val linearLayoutManager = LinearLayoutManager(context)
        linearLayoutManager.orientation = LinearLayoutManager.VERTICAL
        recyclerView!!.layoutManager = linearLayoutManager
        adapter = ProblemCloseAdapter(listBeans, context)
        recyclerView!!.adapter = adapter
        adapter!!.setOnCloseMenuClickListener { position: Int ->
            isFirst = false
            if (TextUtils.equals(listBeans!!.get(position).problemSource, "missing_parts")) {
                val intent = Intent(context, CloseLackDetailActivity::class.java)
                intent.putExtra("id", listBeans!!.get(position).id)
                var addRemark = ""
                if (listBeans!!.get(position).addRemarks == null){
                    addRemark = ""
                }else{
                    addRemark = listBeans!!.get(position).addRemarks
                }
                intent.putExtra(CloseLackDetailActivity.STR_REMARK,addRemark)
                startActivity(intent)
                return@setOnCloseMenuClickListener
            }
            val intent = Intent(context, ProblemDetailActivity::class.java)
            intent.putExtra(ProblemDetailActivity.REQUEST_DATA, listBeans!![position])
            intent.putExtra(ProblemDetailActivity.ACTION_FINISH_CHECK_JUMP,isFinishCheckJump)
            startActivity(intent)
        }
        tv_cjh = findViewById(R.id.tv_cjh)
        queryParams = arrayOf("已登记", "已关闭")
        findViewById<View>(R.id.btn_query).setOnClickListener {
            isFirst = false
            query()
        }

        val tv_user_name = findViewById<TextView>(R.id.tv_user_name)
        tv_user_name.text = "\t" + GlobalVar.realname
        findViewById<View>(R.id.tv_scanf).setOnClickListener { arg0: View? ->
            val intent = Intent()
            intent.setClass(context, CaptureActivity::class.java)
            startActivityForResult(intent, 1073)
        }
        if (intent != null && intent.getStringExtra(ACTION_PARAMS) != null) {
            tv_cjh!!.setText(intent.getStringExtra(ACTION_PARAMS))
            isFinishJump = true
            adapter?.setShowClose(true)
            query()
        }

        if (intent != null && intent.getBooleanExtra(ACTION_FORM_FINISH_CHECK,false)){
            //冲整车初验跳过 不显示全部关闭
            findViewById<View>(R.id.btn_all_close).visibility = View.GONE
            isFinishCheckJump = true
            Log.e("----isFinishCheckJump",isFinishCheckJump.toString())
        }
        findViewById<View>(R.id.btn_all_close).setOnClickListener {
            val basePopupWindowDialog = BasePopupWindowDialog()
            val bundle = Bundle()
            bundle.putString(BasePopupWindowDialog.ACTION_VALUE_TITLE, "提示")
            bundle.putString(BasePopupWindowDialog.ACTION_VALUE_MESSAGE, "确认全部关闭吗")
            basePopupWindowDialog.arguments = bundle
            basePopupWindowDialog.show(supportFragmentManager, "")
            basePopupWindowDialog.setOnConfirmClickListener {
                basePopupWindowDialog.dismiss()
                if (listBeans == null || listBeans!!.isEmpty()) {
                    ToastUtils.show("暂无数据")
                    return@setOnConfirmClickListener
                }
                for (index in listBeans!!.indices) {

                    if (TextUtils.equals(listBeans!![index].problemSource, "missing_parts")) {
                        closeMissAllProblem(listBeans!![index], index)
                    } else {
                        submit(listBeans!![index], index)
                    }

                }
            }
        }

        filter.priority = Int.MAX_VALUE
        registerReceiver(broadCast,filter)
    }

    override fun onDestroy() {
        super.onDestroy()
        unregisterReceiver(broadCast)
    }

    /**
     * 缺件全部关闭
     */
    private fun closeMissAllProblem(data: ProblemCloseBean, index: Int) {
        val map = ArrayMap<String, Any>()
        map["id"] = data.id
        map["instruction"] = ""
        map["imgStr"] = ""
        map["recordUser"] = GlobalVar.username


        val param = gson.toJson(map)
        Log.e("关闭缺件参数", param)
        showCommitDialog()
        val client = OkHttpClient()
        val requestBody = RequestBody.create(JSON, param)
        val request = Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/missingpartsmgr/qmsManufactureMissingparts/api/closeMissingPart")
                .build()
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread {
                    showNetErrorMessage()
                    cancelDialog()
                }
            }

            @Throws(IOException::class)
            override fun onResponse(call: Call, response: Response) {
                val result = response.body()!!.string()
                runOnUiThread {
                    try {
                        cancelDialog()
                        Log.e("--->", result)
                        val jsonObject = JSONObject(result)
                        if (jsonObject.optString("retCode") == "0") {
                            if (index == listBeans!!.size - 1) {
                                ToastUtils.show("成功")
                                query()
                            }

                        } else {
                            ToastUtils.show(jsonObject.optString("retMessage"))
                        }
                    } catch (jsonException: JSONException) {
                        jsonException.printStackTrace()
                    }
                }
            }
        })
    }

    /**
     * 提交数据
     */
    private fun submit(data: ProblemCloseBean, position: Int) {
        val map = ArrayMap<String, Any>()
        map["problemSource"] = data.problemSource
        map["id"] = data.id
        map["closeUser"] = GlobalVar.username
        map["procInsId"] = ""
        map["closeRemark"] = ""
        map["imgStr"] = ""
        map["operType"] = "close"
        val param = gson.toJson(map)
        Log.e("参数", param)
        showCommitDialog()
        val client = OkHttpClient()
        val requestBody = RequestBody.create(JSON, param)
        val request = Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/checkfaildflow/qmsManufactureProblemflow/api/closeProblem")
                .build()
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread {
                    showNetErrorMessage()
                    cancelDialog()
                }
            }

            @Throws(IOException::class)
            override fun onResponse(call: Call, response: Response) {
                val result = response.body()!!.string()
                runOnUiThread {
                    try {
                        cancelDialog()
                        Log.e("--->", result)
                        val jsonObject = JSONObject(result)
                        if (jsonObject.optString("retCode") == "0") {
                            if (position == listBeans!!.size - 1) {
                                ToastUtils.show("成功")
                                query()
                            }
                        } else {
                            ToastUtils.show(jsonObject.optString("retMessage"))
                        }
                    } catch (jsonException: JSONException) {
                        jsonException.printStackTrace()
                    }
                }
            }
        })
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1073 && resultCode == RESULT_OK) {
            tv_cjh!!.setText(data!!.getStringExtra("encoderesult"))
            query()
        }
    }

    override fun onResume() {
        super.onResume()
        if (!isFirst) {
            query()
        }
    }

    override fun getResId(): Int {
        return R.layout.activity_problem_close
    }

    private fun query() {
        val map = ArrayMap<String, Any>()
        dialog?.show()
        map["problemSource"] = ""
        map["problemLevel"] = ""
        map["beginOccurTime"] = ""
        map["endOccurTime"] = ""
        map["peoblemTitle"] = etProblemmTitle?.text.toString()
        map["feedbackUser"] = ""
        map["carFrameNo"] = tv_cjh!!.text.toString()
        map["pageNo"] = 1
        map["pageSize"] = 100
        if (isFinishJump) {
            map["operType"] = "finalCheck"
        }

        val param = gson.toJson(map)
        Log.e("参数", param)
        val client = OkHttpClient()
        val requestBody = RequestBody.create(JSON, param)
        val request = Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/checkfaildflow/qmsManufactureProblemflow/api/notCloseProblemPage")
                .build()
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                dialog?.dismiss()
                Log.d(TAG, "onFailure: 失败")
            }

            @Throws(IOException::class)
            override fun onResponse(call: Call, response: Response) {
                dialog?.dismiss()
                val result = response.body()!!.string()
                runOnUiThread { showData(result) }
            }
        })
    }

    private fun showData(result: String) {
        Log.e("--->问题关闭列表", result)
        listBeans!!.clear()
        try {
            val jsonObject = JSONObject(result)
            if (jsonObject.optString("retCode") == "0") {
                if (jsonObject.optJSONObject("data").optString("list") != null && !TextUtils.isEmpty(jsonObject.optJSONObject("data").optString("list"))) {
                    listBeans!!.addAll(gson.fromJson(jsonObject.optJSONObject("data").optString("list"), object : TypeToken<List<ProblemCloseBean?>?>() {}.type))
                    adapter!!.notifyDataSetChanged()
                } else {
                    if (adapter != null) adapter!!.notifyDataSetChanged()
                    ToastUtils.show("暂无数据")
                }
            } else {
                ToastUtils.show(jsonObject.optString("retMessage"))
                adapter!!.notifyDataSetChanged()
            }
        } catch (jsonException: JSONException) {
            jsonException.printStackTrace()
        }
    }

    companion object {
        const val ACTION_PARAMS = "action_params"
        const val ACTION_FORM_FINISH_CHECK = "action_form_finish_check"
    }
}