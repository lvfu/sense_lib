package com.zhuisu.fastdev.ui.shengchanqingkuanggenzong

import android.content.Context
import android.graphics.Color
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.zhuisu.fastdev.view.QFolderTextView
import com.zhuisu.fastdev.view.SmartTextView
import com.zhuisu.qualityManagement.R

class shengchanAdapter(list: ArrayList<ShengchanList>, context: Context) :
    RecyclerView.Adapter<shengchanAdapter.Holder>() {
    private var list: ArrayList<ShengchanList>? = null
    private var context: Context? = null

    var firstSuccess: FirstSuccess? = null

    init {
        this.list = list
        this.context = context
    }

    public interface FirstSuccess {
        fun firstSuccess(position: Int)
    }

    class Holder(itemView: View) : RecyclerView.ViewHolder(itemView) {

        val tv_chejiahao: SmartTextView = itemView.findViewById(R.id.tv_chejiahao)
        val tv_dingdanhao: SmartTextView = itemView.findViewById(R.id.tv_dingdanhao)
        val tv_shangxianshijian: SmartTextView = itemView.findViewById(R.id.tv_shangxianshijian)
        val tv_xiaxianshijian: SmartTextView = itemView.findViewById(R.id.tv_xiaxianshijian)
        val tv_jiecheshijian: SmartTextView = itemView.findViewById(R.id.tv_jiecheshijian)
        val tv_jiecheren: SmartTextView = itemView.findViewById(R.id.tv_jiecheren)
        val tv_tiaoshishijian: SmartTextView = itemView.findViewById(R.id.tv_tiaoshishijian)
        val tv_tiaoshiren: SmartTextView = itemView.findViewById(R.id.tv_tiaoshiren)
        val tv_guzhangpaichuwanchengshijian: SmartTextView =
            itemView.findViewById(R.id.tv_guzhangpaichuwanchengshijian)
        val tv_guzhangpaichuwanchengren: SmartTextView =
            itemView.findViewById(R.id.tv_guzhangpaichuwanchengren)
        val tv_songyanshijian: SmartTextView = itemView.findViewById(R.id.tv_songyanshijian)
        val tv_songyanren: SmartTextView = itemView.findViewById(R.id.tv_songyanren)
        val tv_chuyanshijian: SmartTextView = itemView.findViewById(R.id.tv_chuyanshijian)
        val tv_chuyanren: SmartTextView = itemView.findViewById(R.id.tv_chuyanren)

        val tv_fuyanshijian: SmartTextView = itemView.findViewById(R.id.tv_fuyanshijian)
        val tv_fuyanren: SmartTextView = itemView.findViewById(R.id.tv_fuyanren)
        val tv_rukushijian: SmartTextView = itemView.findViewById(R.id.tv_rukushijian)

        val tv_carpipei: QFolderTextView = itemView.findViewById(R.id.tv_car_pipei)
    }

    override fun onCreateViewHolder(p0: ViewGroup, p1: Int): Holder {
        return Holder(
            ((context!!.getSystemService(Context.LAYOUT_INFLATER_SERVICE)) as LayoutInflater)
                .inflate(R.layout.activity_shengchanitem, p0, false)
        )
    }

    override fun onBindViewHolder(p0: Holder, p1: Int) {

        val data = list!![p1]

        p0.tv_chejiahao.text = data.carFarmeNo
        p0.tv_dingdanhao.text = data.orderNo
        p0.tv_shangxianshijian.text = data.HEMSonLineDate
        p0.tv_xiaxianshijian.text = data.HEMSDowmLineDate

        p0.tv_jiecheshijian.text = data.createDate
        p0.tv_jiecheren.text = data.operator

        p0.tv_tiaoshishijian.text = data.debugDate
        p0.tv_tiaoshiren.text = data.debugUser

        p0.tv_guzhangpaichuwanchengshijian.text = data.troubleShootingDate
        p0.tv_guzhangpaichuwanchengren.text = data.troubleShootingUser

        p0.tv_songyanshijian.text = data.submitCheckDate
        p0.tv_songyanren.text = data.submitCheckUser

        p0.tv_chuyanshijian.text = data.submitCheckPassedDate
        p0.tv_chuyanren.text = data.submitCheckPassedUser

        p0.tv_fuyanshijian.text = data.recheckDate
        p0.tv_fuyanren.text = data.recheckUser

        p0.tv_rukushijian.text = data.HEMSInWareHousingDate

//        p0.tv_carpipei.text = data.configDesc

        p0.tv_carpipei.setText(data.configDesc)
        p0.tv_carpipei.setForbidFold(false)
        p0.tv_carpipei.setFoldLine(1)
        p0.tv_carpipei.setEllipsize("...")
        p0.tv_carpipei.setUnfoldText("查看详情")

    }

    override fun getItemCount(): Int {
        return list!!.size
    }
}