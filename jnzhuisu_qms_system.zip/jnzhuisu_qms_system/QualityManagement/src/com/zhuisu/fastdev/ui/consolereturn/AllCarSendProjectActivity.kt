package com.zhuisu.fastdev.ui.consolereturn

import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Parcelable
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.text.TextUtils
import android.util.ArrayMap
import android.util.Log
import android.view.View
import android.widget.*
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.zhuisu.fastdev.BaseActivity
import com.zhuisu.fastdev.adapter.consolepull.PullProjectAdapter
import com.zhuisu.fastdev.adapter.consolework.ConsoleProjectAdapter
import com.zhuisu.fastdev.beans.ProblemCloseBean
import com.zhuisu.fastdev.beans.ProelemDetailBean
import com.zhuisu.fastdev.beans.consolepull.ConsolePullList
import com.zhuisu.fastdev.beans.consolework.ConsoleProjectInputActivity
import com.zhuisu.fastdev.beans.consolework.ConsoleProjectList
import com.zhuisu.fastdev.beans.registercar.RegisterCarDetails
import com.zhuisu.fastdev.beans.registercar.RegisterCarLocationListBean
import com.zhuisu.fastdev.dialog.BasePopupWindowDialog
import com.zhuisu.fastdev.ui.jieche.RegisterCarConfigChangeActivity
import com.zhuisu.fastdev.ui.lackhistory.CloseLackDetailActivity
import com.zhuisu.fastdev.ui.problem.ProblemDetailActivity
import com.zhuisu.qualityManagement.R
import com.zhuisu.suppliermanagement.util.GlobalVar
import com.zhuisu.suppliermanagement.util.ToastUtils
import okhttp3.*
import org.json.JSONException
import org.json.JSONObject
import java.io.IOException

/**
 * @author cxh
 * @description 调试返修项目列表
 */
class AllCarSendProjectActivity : BaseActivity(), PullProjectAdapter.OnClickListener,
    ConsoleProjectAdapter.OnItemClickListener {

    var firstData: ConsolePullList? = null
    var tvChange: TextView? = null
    var projectList: ArrayList<ConsoleProjectList>? = null
    var notCloseList: ArrayList<ProelemDetailBean>? = null
    var adapter: ConsoleProjectAdapter? = null
    var notCloseAdapter: PullProjectAdapter? = null
    var spSelectLocation: Spinner? = null
    private var locationListBeanList: MutableList<RegisterCarLocationListBean?>? = null
    private var registerCarLocationListBean: RegisterCarLocationListBean? = null

    companion object {
        const val ACTION_VALUE = "ACTION_VALUE"
    }

    override fun initViews() {

        projectList = ArrayList()
        notCloseList = ArrayList()
        locationListBeanList = ArrayList()
        adapter = ConsoleProjectAdapter(projectList!!, context)
        notCloseAdapter = PullProjectAdapter(notCloseList!!, context)

        //项目列表
        val rvProjectList: RecyclerView = findViewById(R.id.rv_projects)
        val manager = LinearLayoutManager(context)
        manager.orientation = LinearLayoutManager.VERTICAL
        rvProjectList.layoutManager = manager
        rvProjectList.adapter = adapter
        adapter!!.onItenClick = this


        //问题列表
        val rvNotClose = findViewById<RecyclerView>(R.id.rv_un_close_pro)
        val linearManager = LinearLayoutManager(context)
        linearManager.orientation = LinearLayoutManager.VERTICAL
        rvNotClose.layoutManager = linearManager
        rvNotClose.adapter = notCloseAdapter
        notCloseAdapter!!.onClicklistener = this
        tvChange = findViewById(R.id.tv_config_change)


        if (intent != null && intent.getParcelableExtra<ConsolePullList>(ACTION_VALUE) != null) {
            firstData = intent.getParcelableExtra(ACTION_VALUE)
            val tvFlowNumber: TextView = findViewById(R.id.tv_flow_number)
            val tvCarFrameNumber: TextView = findViewById(R.id.tv_car_frame_number)
            tvFlowNumber.text = firstData!!.flowCarNo
            tvCarFrameNumber.text = firstData!!.carFarmeNo

            queryDetail()
        }

        findViewById<Button>(R.id.btn_all_closed).setOnClickListener {
            closeAll()
        }

        spSelectLocation = findViewById(R.id.sp_select_location)

        findViewById<Button>(R.id.btn_all_successful).setOnClickListener {
            if (projectList == null || projectList.isNullOrEmpty()) {
                ToastUtils.show("暂无数据")
            } else {
                val dialog = BasePopupWindowDialog()
                val arguments = Bundle()
                arguments.putString(BasePopupWindowDialog.ACTION_VALUE_TITLE, "提示")
                arguments.putString(BasePopupWindowDialog.ACTION_VALUE_MESSAGE, "将待检状态全部改为合格,是否确认")
                dialog.arguments = arguments

                dialog.setOnConfirmClickListener {
                    dialog.dismiss()

                    var index = 0;
                    for (i in projectList!!.indices) {
                        val state =
                            if (projectList!![i].status == "passed") "合格" else if (projectList!![i].status == "failed") "不合格" else if (projectList!![i].status == "noCheck") "免检" else "待检验"
                        if (TextUtils.equals("待检验", state)) {
                            index++
                        }
                    }

                    for (i in projectList!!.indices) {
                        val state =
                            if (projectList!![i].status == "passed") "合格" else if (projectList!![i].status == "failed") "不合格" else if (projectList!![i].status == "noCheck") "免检" else "待检验"
                        if (TextUtils.equals("待检验", state)) {
                            checkSuccess(projectList!![i].id!!, index)
                        }
                    }
                }
                dialog.show(supportFragmentManager, "")
            }
        }


        //退回故障排除
        findViewById<Button>(R.id.btn_back_step).setOnClickListener {
            val dialog = BasePopupWindowDialog()
            val arguments = Bundle()
            arguments.putString(BasePopupWindowDialog.ACTION_VALUE_TITLE, "提示")
            arguments.putString(BasePopupWindowDialog.ACTION_VALUE_MESSAGE, "是否退回故障排除?")
            dialog.arguments = arguments

            dialog.setOnConfirmClickListener {
                dialog.dismiss()
                Log.e("status=======--->", firstData?.status + "")
//                if (TextUtils.equals(firstData?.status, "troubleshootingpassed") || TextUtils.equals(firstData?.status, "submitcheck") || TextUtils.equals(firstData?.status, "submitcheckpassed")) {
//                    submitCheck()
//                } else {
                commitData(null, true)
//                }

            }
            dialog.show(supportFragmentManager, "")
        }

        findViewById<Button>(R.id.btn_pull_confirm).setOnClickListener {
            val dialog = BasePopupWindowDialog()
            val arguments = Bundle()
            arguments.putString(BasePopupWindowDialog.ACTION_VALUE_TITLE, "提示")
            arguments.putString(BasePopupWindowDialog.ACTION_VALUE_MESSAGE, "是否送验?")
            dialog.arguments = arguments

            dialog.setOnConfirmClickListener {
                dialog.dismiss()
                Log.e("status=======--->", firstData?.status + "")
                if (TextUtils.equals(
                        firstData?.status,
                        "troubleshootingpassed"
                    ) || TextUtils.equals(firstData?.status, "submitcheck") || TextUtils.equals(
                        firstData?.status,
                        "submitcheckpassed"
                    )
                ) {
                    submitCheck()
                } else {
                    commitData(null, false)
                }

            }
            dialog.show(supportFragmentManager, "")
        }

        //缺件送验
        findViewById<Button>(R.id.btn_miss_check).setOnClickListener {
            val dialog = BasePopupWindowDialog()
            val arguments = Bundle()
            arguments.putString(BasePopupWindowDialog.ACTION_VALUE_TITLE, "提示")
            arguments.putString(BasePopupWindowDialog.ACTION_VALUE_MESSAGE, "是否缺件送验?")
            dialog.arguments = arguments

            dialog.setOnConfirmClickListener {
                dialog.dismiss()
                //必须输入备注
                val inputEditTextField = EditText(this)

                val remarkDialog = AlertDialog.Builder(context, R.style.MyAlertDialogStyle)
//                        .setTitle("备注")
                    .setMessage("请输入备注")
                    .setView(inputEditTextField)
                    .setPositiveButton("确定") { dialog, _ ->
                        val editTextInput = inputEditTextField.text.toString()
                        if (TextUtils.isEmpty(editTextInput)) {
                            ToastUtils.show("请输入备注!")
                            return@setPositiveButton
                        }
                        dialog.dismiss()
                        Log.d("onclick", "et value is: $editTextInput")
                        commitData(editTextInput, false)
                    }
                    .setNegativeButton("取消", null)
                    .setCancelable(false)
                    .create()
                remarkDialog.show();

            }
            dialog.show(supportFragmentManager, "")
        }

        val tvUserName: TextView = findViewById(R.id.tv_user_name)
        tvUserName.text = "\t" + GlobalVar.realname
        queryLocation()
    }

    /**
     * 查询详情
     * */
    fun queryDetail() {
        val map = ArrayMap<String, String>()
        map["carFarmeNo"] = firstData!!.carFarmeNo
        val param = gson.toJson(map)
        Log.e("获取详情", param)
        val client = OkHttpClient()
        val requestBody = RequestBody.create(JSON, param)
        val request = Request.Builder()
            .post(requestBody)
            .url(GlobalVar.url + "a/offlinedebuggingstatus/qmsOfflineStatus/api/carFrameInfo")
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread {
                    Log.d(TAG, "onFailure: 失败")
                }
            }

            override fun onResponse(call: Call, response: Response) {
                val result = response.body()!!.string()
                runOnUiThread {
                    try {
                        Log.e("--->获取详情", result)
                        val jsonObject = JSONObject(result)
                        if (jsonObject.optString("status") == "-1") {
                            ToastUtils.show(jsonObject.optString("msg"))
                        } else {

                            val current: RegisterCarDetails = gson.fromJson(
                                jsonObject.optString("data"),
                                RegisterCarDetails::class.java
                            )

                            val tvModel: TextView = findViewById(R.id.tv_carmodel)
                            tvModel.text =
                                "车型号: ${current!!.qmsManufactureProductionplan.carModelNo}"

                            val tvNumber: TextView = findViewById(R.id.tv_number)
                            tvNumber.text =
                                "发动机号: " + current.engineNumber + "\n" + "气瓶号: " + current.cylinderNumber//配置


                            val tvConfig: TextView = findViewById(R.id.tv_config_det)
                            tvConfig.text =
                                "配置: " + current.qmsManufactureProductionplan?.configDesc //配置
                            tvChange?.visibility =
                                if (current.configChange) View.VISIBLE else View.GONE
                            tvChange!!.setOnClickListener {
                                val configChangeIntent =
                                    Intent(context, RegisterCarConfigChangeActivity::class.java)
                                val data = RegisterCarDetails()
                                data.flowCarNo = firstData!!.flowCarNo
                                configChangeIntent.putExtra(
                                    RegisterCarConfigChangeActivity.ACTION_DATA,
                                    data
                                )
                                startActivity(configChangeIntent)
                            }

                        }

                    } catch (jsonException: JSONException) {
                        jsonException.printStackTrace()
                    }
                }
            }
        })
    }

    //查询送验问题
    private fun submitCheck() {
        val map = ArrayMap<String, String>()
        map["carFarmeNo"] = firstData?.carFarmeNo
        map["status"] = "submitcheck"
        val param = gson.toJson(map)
        Log.e("检查参数--->", param)
        val client = OkHttpClient()
        val requestBody = RequestBody.create(JSON, param)
        val request = Request.Builder()
            .post(requestBody)
            .url(GlobalVar.url + "a/offlinedebuggingstatus/qmsOfflineStatus/api/findTroubleNum")
            .build()
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.d(TAG, "onFailure: 失败")
            }

            @Throws(IOException::class)
            override fun onResponse(call: Call, response: Response) {
                val result = response.body()!!.string()
                runOnUiThread {
                    Log.e("--->检查数量", result);
                    val jsonObj = JSONObject(result)
                    if (TextUtils.equals(jsonObj.optString("retCode"), "-1")) {
                        val dialog = BasePopupWindowDialog()
                        val arguments = Bundle()
                        arguments.putString(BasePopupWindowDialog.ACTION_VALUE_TITLE, "提示")
                        arguments.putString(BasePopupWindowDialog.ACTION_SHOW_IMAGE, "data")
                        arguments.putString(
                            BasePopupWindowDialog.ACTION_VALUE_MESSAGE,
                            jsonObj.optString("retMessage")
                        )
                        dialog.arguments = arguments

                        dialog.setOnConfirmClickListener {
                            dialog.dismiss()
                        }
                        dialog.show(supportFragmentManager, "")
                    } else {
                        commitData(null, false)
                    }

                }
            }
        })
    }

    /**
     * 送复验提交
     */
    private fun commitData(remark: String?, isBack: Boolean) {
        val map = ArrayMap<String, String>()
        map["carFarmeNo"] = firstData!!.carFarmeNo
        if (isBack) {
            //退回故障排除
            map["status"] = "troubleshooting"
            map["isReturnOperating"] = "1"
        } else {
            map["status"] = "submitcheck"
        }

        map["userName"] = GlobalVar.username
        map["location"] = registerCarLocationListBean!!.value
        if (remark != null) {
            map["specialSubmitRemark"] = remark
            map["isSpecialSubmitCheck"] = "1"
        }


        val param = gson.toJson(map)
        Log.e("--->提交", param)
        showCommitDialog()
        val client = OkHttpClient()
        val requestBody = RequestBody.create(JSON, param)
        val request = Request.Builder()
            .post(requestBody)
            .url(GlobalVar.url + "a/offlinedebuggingstatus/qmsOfflineStatus/api/updateOffLineStatus")
            .build()
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.d(TAG, "onFailure: 失败")
                runOnUiThread {
                    showNetErrorMessage()
                    cancelDialog()
                }
            }

            @Throws(IOException::class)
            override fun onResponse(call: Call, response: Response) {
                val result = response.body()!!.string()
                Log.d(TAG, "onResponse: $result")
                runOnUiThread {
                    try {
                        cancelDialog()
                        val jsonObject = JSONObject(result)
                        if (jsonObject.optString("status") == "0") {
                            ToastUtils.show(jsonObject.optString("msg"))
                            Handler().postDelayed({ finish() }, 1000)
                        } else {
                            ToastUtils.show(jsonObject.optString("msg"))
                        }
                    } catch (e: JSONException) {
                        e.printStackTrace()
                    }
                }
            }
        })
    }


    /**
     * 获取接车的库位
     */
    private fun queryLocation() {
        val map = ArrayMap<String, String>()
        map["type"] = "CAR_LOCATION"
        val param = gson.toJson(map)
        val client = OkHttpClient()
        val requestBody = RequestBody.create(JSON, param)
        val request = Request.Builder()
            .post(requestBody)
            .url(GlobalVar.url + "a/common/util/api/getDict")
            .build()
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.d(TAG, "onFailure: 失败")
            }

            @Throws(IOException::class)
            override fun onResponse(call: Call, response: Response) {
                val result = response.body()!!.string()
                Log.d(TAG, "onResponse: 接车库位$result")
                runOnUiThread {
                    try {
                        val jsonObject = JSONObject(result)
                        locationListBeanList!!.addAll(
                            gson.fromJson(
                                jsonObject.optString("data"),
                                object : TypeToken<List<RegisterCarLocationListBean?>?>() {}.type
                            )
                        )
                        val adapter: ArrayAdapter<out Parcelable?> =
                            ArrayAdapter(context, R.layout.simple_textview1, locationListBeanList)
                        spSelectLocation!!.adapter = adapter


                        if (locationListBeanList != null && locationListBeanList!!.isNotEmpty()) {
                            registerCarLocationListBean = locationListBeanList!![0]
                        }

                        spSelectLocation!!.onItemSelectedListener =
                            object : AdapterView.OnItemSelectedListener {
                                override fun onItemSelected(
                                    parent: AdapterView<*>?,
                                    view: View,
                                    position: Int,
                                    id: Long
                                ) {
                                    registerCarLocationListBean = locationListBeanList!![position]
                                }

                                override fun onNothingSelected(parent: AdapterView<*>?) {}
                            }
                    } catch (e: JSONException) {
                        e.printStackTrace()
                    }
                }
            }
        })
    }

    /**
     * 检查合格
     */
    var temp = 0
    private fun checkSuccess(id: String, position: Int) {
        val map = ArrayMap<String, String>()
        map["id"] = id
        map["checkedBy"] = GlobalVar.username
        val param = gson.toJson(map)
        val client = OkHttpClient()
        val requestBody = RequestBody.create(JSON, param)
        val request = Request.Builder()
            .post(requestBody)
            .url(GlobalVar.url + "a/prduictionrelation/qmsManufactureProductionplanrelation/api/checkPassed")
            .build()
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread { ToastUtils.show("请求失败") }
            }

            @Throws(IOException::class)
            override fun onResponse(call: Call, response: Response) {
                val result = response.body()!!.string()
                Log.d(TAG, "onResponse: $result")
                runOnUiThread {
                    try {
                        val jsonObject = JSONObject(result)
                        if (TextUtils.equals("0", jsonObject.optString("retCode"))) {

                            if (position == -1) {
                                query()
                            } else {
                                temp++
                                if (temp == position) {
                                    ToastUtils.show("成功")
                                    Handler().postDelayed({ query() }, 1000)
                                }
                            }

                        } else {
                            ToastUtils.show(jsonObject.optString("retMessage"))
                            query()
                        }
                    } catch (e: JSONException) {
                        e.printStackTrace()
                    }
                }
            }
        })
    }

    /**
     * 全部关闭
     * */

    fun closeAll() {
        if (notCloseList == null || notCloseList!!.isEmpty()) {
            ToastUtils.show("暂无数据")
            return
        }

        val dialog = BasePopupWindowDialog()
        val arguments = Bundle()
        arguments.putString(BasePopupWindowDialog.ACTION_VALUE_TITLE, "提示")
        arguments.putString(BasePopupWindowDialog.ACTION_VALUE_MESSAGE, "将以上问题全部关闭,是否确认")
        dialog.arguments = arguments

        dialog.setOnConfirmClickListener {
            dialog.dismiss()
            for (index in notCloseList!!.indices) {
                if (TextUtils.equals(notCloseList!![index].problemSource, "missing_parts")) {
                    closeMissAllProblem(notCloseList!![index], index)
                } else {
                    closeAllProblem(notCloseList!![index], index)
                }
            }
        }
        dialog.show(supportFragmentManager, "")
    }

    /**
     * 缺件全部关闭
     */
    private fun closeMissAllProblem(data: ProelemDetailBean, index: Int) {
        val map = ArrayMap<String, Any>()

        map["id"] = data.id
        map["instruction"] = ""
        map["imgStr"] = ""
        map["recordUser"] = GlobalVar.username


        val param = gson.toJson(map)
        Log.e("关闭缺件参数", param)
        showCommitDialog()
        val client = OkHttpClient()
        val requestBody = RequestBody.create(JSON, param)
        val request = Request.Builder()
            .post(requestBody)
            .url(GlobalVar.url + "a/missingpartsmgr/qmsManufactureMissingparts/api/closeMissingPart")
            .build()
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread {
                    showNetErrorMessage()
                    cancelDialog()
                }
            }

            @Throws(IOException::class)
            override fun onResponse(call: Call, response: Response) {
                val result = response.body()!!.string()
                runOnUiThread {
                    try {
                        cancelDialog()
                        Log.e("--->", result)
                        val jsonObject = JSONObject(result)
                        if (jsonObject.optString("retCode") == "0") {
                            if (index == notCloseList!!.size - 1) {
                                ToastUtils.show("成功")
                                queryNotCloseList()
                            }

                        } else {
                            ToastUtils.show(jsonObject.optString("retMessage"))
                        }
                    } catch (jsonException: JSONException) {
                        jsonException.printStackTrace()
                    }
                }
            }
        })
    }

    /**
     * 全部关闭
     */
    private fun closeAllProblem(data: ProelemDetailBean, index: Int) {
        val map = ArrayMap<String, Any>()
        map["problemSource"] = if (data.problemSource == null) "" else data.problemSource
        map["id"] = data.id
        map["closeUser"] = GlobalVar.username
        map["procInsId"] = if (data.getProcInsId() == null) "" else data.getProcInsId()
        map["closeRemark"] = ""
        map["imgStr"] = ""
        map["operType"] = "close"

        val param = gson.toJson(map)
        Log.e("关闭缺件参数", param)
        showCommitDialog()
        val client = OkHttpClient()
        val requestBody = RequestBody.create(JSON, param)
        val request = Request.Builder()
            .post(requestBody)
            .url(GlobalVar.url + "a/checkfaildflow/qmsManufactureProblemflow/api/closeProblem")
            .build()
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread {
                    showNetErrorMessage()
                    cancelDialog()
                }
            }

            @Throws(IOException::class)
            override fun onResponse(call: Call, response: Response) {
                val result = response.body()!!.string()
                runOnUiThread {
                    try {
                        cancelDialog()
                        Log.e("--->", result)
                        val jsonObject = JSONObject(result)
                        if (jsonObject.optString("retCode") == "0") {
                            if (index == notCloseList!!.size - 1) {
                                ToastUtils.show("成功")
                                queryNotCloseList()
                            }

                        } else {
                            ToastUtils.show(jsonObject.optString("retMessage"))
                        }
                    } catch (jsonException: JSONException) {
                        jsonException.printStackTrace()
                    }
                }
            }
        })
    }


    /**
     * 查询问题列表
     */
    private fun queryNotCloseList() {

        notCloseList!!.clear()
        notCloseAdapter!!.notifyDataSetChanged()
        val map = ArrayMap<String, Any>()
        map["problemSource"] = "all" //offLineCheck
        map["problemLevel"] = ""
        map["beginOccurTime"] = ""
        map["endOccurTime"] = ""
        map["peoblemTitle"] = ""
        map["feedbackUser"] = ""
        map["carFrameNo"] = firstData!!.carFarmeNo
        map["pageNo"] = 1
        map["pageSize"] = 100


        val param = gson.toJson(map)
        Log.e("--->", param)
        val client = OkHttpClient()
        val requestBody = RequestBody.create(JSON, param)
        val request = Request.Builder()
            .post(requestBody)
            .url(GlobalVar.url + "a/checkfaildflow/qmsManufactureProblemflow/api/notCloseProblemPage")
            .build()
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.d(TAG, "onFailure: 失败")
            }

            @Throws(IOException::class)
            override fun onResponse(call: Call, response: Response) {
                val result = response.body()!!.string()
                Log.d(TAG, "onResponse: 问题列表$result")
                runOnUiThread {
                    try {
                        val jsonObject = JSONObject(result)
                        if (TextUtils.equals(jsonObject.optString("retCode"), "0") && jsonObject
                                .optJSONObject("data")
                                .optString("list") != null && !TextUtils.isEmpty(
                                jsonObject.optJSONObject("data")
                                    .optString("list")
                            )
                        ) {
                            notCloseList!!.addAll(
                                gson.fromJson(
                                    jsonObject.optJSONObject("data").optString("list"),
                                    object : TypeToken<ArrayList<ProelemDetailBean>>() {}.type
                                )
                            )
                            notCloseAdapter!!.notifyDataSetChanged()
                        } else {
                            notCloseAdapter!!.notifyDataSetChanged()
                        }
                    } catch (e: JSONException) {
                        e.printStackTrace()
                    }
                }
            }
        })
    }

    //查询项目列表
    fun query() {
        projectList!!.clear()
        adapter!!.notifyDataSetChanged()

        val map = ArrayMap<String, String>()
        map["carframeNo"] = firstData!!.carFarmeNo
        map["loginName"] = GlobalVar.username
        map["flowcarNo"] = firstData!!.flowCarNo

        val param = gson.toJson(map)
        Log.e("参数", param)
        val client = OkHttpClient()
        val requestBody = RequestBody.create(JSON, param)
        val request = Request.Builder()
            .post(requestBody)
            .url(GlobalVar.url + "a/prduictionrelation/qmsManufactureProductionplanrelation/api/qryCheckItems")
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread {
                    Log.d(TAG, "onFailure: 失败")
                }
            }

            override fun onResponse(call: Call, response: Response) {
                val result = response.body()!!.string()
                runOnUiThread {
                    try {
                        Log.e("qryCheckItems--->", result)
                        val jsonObject = JSONObject(result)
                        if (TextUtils.equals(
                                jsonObject.optString("retCode"),
                                "0"
                            ) && jsonObject.optString("data") != null && !jsonObject.optString("data")
                                .isBlank()
                        ) {
                            val listType =
                                object : TypeToken<ArrayList<ConsoleProjectList>>() {}.type
                            val temp: ArrayList<ConsoleProjectList> =
                                Gson().fromJson(jsonObject.optString("data"), listType)
                            projectList!!.addAll(temp)
                            adapter!!.notifyDataSetChanged()

                        } else {
                            adapter!!.notifyDataSetChanged()
                        }


                    } catch (jsonException: JSONException) {
                        jsonException.printStackTrace()
                    }
                }
            }
        })
    }


    override fun onResume() {
        super.onResume()
        query()
        queryNotCloseList()

    }

    override fun getResId(): Int {
        return R.layout.activity_allcar_send_project
    }

    //关闭问题
    override fun onItemCLickListener(position: Int) {

//        if (TextUtils.equals(notCloseList!![position].problemSource, "missing_parts")) {
//            val intent = Intent(context, CloseLackDetailActivity::class.java)
//            intent.putExtra("id", notCloseList!!.get(position).id)
//            startActivity(intent)
//            return
//        }

        val notCloseIntent = Intent(context, ProblemDetailActivity::class.java)
        val data = ProblemCloseBean()
        data.id = notCloseList!![position].id
        data.problemSource = notCloseList!![position].problemSource
        notCloseIntent.putExtra(ProblemDetailActivity.REQUEST_DATA, data)
        startActivity(notCloseIntent)
    }

    //点击检验项目
    override fun onItemClickListener(position: Int) {
        val intent = Intent(context, ConsoleProjectInputActivity::class.java)
        intent.putExtra(ConsoleProjectInputActivity.ACTION_DATA, projectList!![position])
        intent.putExtra(ConsoleProjectInputActivity.ACTION_FIRST_DATA, firstData?.status)
        startActivity(intent)
    }

    override fun onSuccessClick(position: Int) {
        val id = projectList!![position].id
        checkSuccess(id!!, -1)
    }

    //免检
    override fun onNotCheckClick(position: Int) {
        val map = ArrayMap<String, String>()
        map["id"] = projectList!![position].id
        map["checkedBy"] = GlobalVar.username
        val param = gson.toJson(map)
        val client = OkHttpClient()
        val requestBody = RequestBody.create(JSON, param)
        val request = Request.Builder()
            .post(requestBody)
            .url(GlobalVar.url + "a/prduictionrelation/qmsManufactureProductionplanrelation/api/noCheck")
            .build()
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread { ToastUtils.show("请求失败") }
            }

            @Throws(IOException::class)
            override fun onResponse(call: Call, response: Response) {
                val result = response.body()!!.string()
                Log.d(TAG, "onResponse: $result")
                runOnUiThread {
                    try {
                        val jsonObject = JSONObject(result)
                        if (TextUtils.equals("0", jsonObject.optString("retCode"))) {
                            ToastUtils.show("成功")
                            query()
                        } else {
                            ToastUtils.show(jsonObject.optString("retMessage"))
                        }
                    } catch (e: JSONException) {
                        e.printStackTrace()
                    }
                }
            }
        })
    }

}