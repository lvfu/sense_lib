package com.zhuisu.fastdev.ui.debugcar

import android.annotation.SuppressLint
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Bundle
import android.os.Handler
import android.os.Parcelable
import android.text.TextUtils
import android.util.ArrayMap
import android.util.Log
import android.view.View
import android.widget.*
import com.google.gson.reflect.TypeToken
import com.zhuisu.fastdev.BaseActivity
import com.zhuisu.fastdev.beans.registercar.RegisterCarDetails
import com.zhuisu.fastdev.beans.registercar.RegisterCarLocationListBean
import com.zhuisu.fastdev.dialog.BasePopupWindowDialog
import com.zhuisu.fastdev.ui.jieche.RegisterCarConfigChangeActivity
import com.zhuisu.fastdev.ui.util.BroadCastConfig
import com.zhuisu.fastdev.view.SmartTextView
import com.zhuisu.qualityManagement.R
import com.zhuisu.suppliermanagement.base.CaptureActivity
import com.zhuisu.suppliermanagement.util.GlobalVar
import com.zhuisu.suppliermanagement.util.ToastUtils
import okhttp3.*
import org.json.JSONException
import org.json.JSONObject
import java.io.IOException
import java.util.*

/**
 * @author cxh
 * @description
 * @date 2020/10/20.
 * 整车调试
 */
class DebugCarActivity : BaseActivity() {
    private var dialog: BasePopupWindowDialog? = null
    private var locationListBeanList: MutableList<RegisterCarLocationListBean?>? = null
    private var sp_select: Spinner? = null
    private var registerCarLocationListBean: RegisterCarLocationListBean? = null
    private var currentData: RegisterCarDetails? = null
    private var et_scanf_car_number: EditText? = null
    private var btn_register_car: Button? = null
    private var update_state = ""
    var isQuery = false


    private val broadCast : BroadCastChange = BroadCastChange()
    val filter : IntentFilter = IntentFilter(BroadCastConfig.BROADCAST_ACTION)

    inner class BroadCastChange : BroadcastReceiver(){
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent != null && intent.action != null && intent.action == BroadCastConfig.BROADCAST_ACTION){
                et_scanf_car_number!!.setText(intent.extras!!.getString(BroadCastConfig.BROADCAST_ACTION_TAG))
                et_scanf_car_number!!.setSelection(et_scanf_car_number!!.text.toString().length)
                query()
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        unregisterReceiver(broadCast)
    }

    @SuppressLint("SetTextI18n")
    override fun initViews() {
        locationListBeanList = ArrayList()
        sp_select = findViewById(R.id.sp_select)
        et_scanf_car_number = findViewById(R.id.et_scanf_car_number)
        btn_register_car = findViewById(R.id.btn_register_car)
        btn_register_car!!.setOnClickListener {
            dialog!!.setOnConfirmClickListener {
                dialog!!.dismiss()
                if (currentData != null) {
                    when {
                        TextUtils.equals(update_state, "warehousingin") -> {
                            submitCheckReCheck()
                        }
                        TextUtils.equals(update_state, "submitcheck") -> {
                            submitCheck()
                        }
                        else -> {
                            commitData()
                        }
                    }

                } else {
                    ToastUtils.show("数据不能为空")
                }
            }
            dialog!!.show(supportFragmentManager, "")
        }
        findViewById<View>(R.id.btn_query).setOnClickListener { query() }

        queryLocation()

        val tv_user_name = findViewById<TextView>(R.id.tv_user_name)
        tv_user_name.text = "\t" + GlobalVar.realname
        findViewById<View>(R.id.tv_scanf).setOnClickListener {
            val intent = Intent()
            intent.setClass(context, CaptureActivity::class.java)
            startActivityForResult(intent, 1073)
        }

        filter.priority = Int.MAX_VALUE
        registerReceiver(broadCast,filter)
    }


    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1073 && resultCode == RESULT_OK) {
            et_scanf_car_number!!.setText(data!!.getStringExtra("encoderesult"))
            query()
        }else if (resultCode == 0x61){
            commitData()
        }
    }


    override fun getResId(): Int {
        return R.layout.activity_debug_car
    }

    //查询复验问题
    private fun submitCheckReCheck() {
        val map = ArrayMap<String, String>()
        map["carFrameNo"] = et_scanf_car_number!!.text.toString()
        map["offLineStatus"] = "submitcheck"

        val param = gson.toJson(map)
        Log.e("-->",param)
        val client = OkHttpClient()
        val requestBody = RequestBody.create(JSON, param)
        val request = Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/offlineproblem/qmsManufactureOffLineProblem/api/isNotClose")
                .build()
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.d(TAG, "onFailure: 失败")
            }

            @Throws(IOException::class)
            override fun onResponse(call: Call, response: Response) {
                val result = response.body()!!.string()
                runOnUiThread {
                    Log.e("--->", result)
                    val jsonObj = JSONObject(result)
                    if (TextUtils.equals(jsonObj.optString("retCode"), "-1")) {
                        //复验存在未关闭问题
                        isQuery = true
                        val intent = Intent(context, RecheckActivity::class.java)
                        intent.putExtra(RecheckActivity.ACTION_DATA, currentData)
                        startActivityForResult(intent,0x12)
                    } else {
                        commitData()
                    }

                }
            }
        })
    }




    //查询送验问题
    private fun submitCheck() {
        val map = ArrayMap<String, String>()
        map["carFarmeNo"] = et_scanf_car_number!!.text.toString()
        val param = gson.toJson(map)
        val client = OkHttpClient()
        val requestBody = RequestBody.create(JSON, param)
        val request = Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/offlinedebuggingstatus/qmsOfflineStatus/api/findTroubleNum")
                .build()
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.d(TAG, "onFailure: 失败")
            }

            @Throws(IOException::class)
            override fun onResponse(call: Call, response: Response) {
                val result = response.body()!!.string()
                runOnUiThread {
                    Log.e("--->", result);
                    val jsonObj = JSONObject(result)
                    if (TextUtils.equals(jsonObj.optString("retCode"), "-1")) {
                        ToastUtils.show(jsonObj.optString("retMessage"))
                    } else {
                        commitData()
                    }
                }
            }
        })
    }

    private fun query() {
        val map = ArrayMap<String, String>()
        map["carFarmeNo"] = et_scanf_car_number!!.text.toString()
        map["status"] = "all"
        val param = gson.toJson(map)

        Log.e("参数",param)
        val client = OkHttpClient()
        val requestBody = RequestBody.create(JSON, param)
        val request = Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/offlinedebuggingstatus/qmsOfflineStatus/api/list")
                .build()
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.d(TAG, "onFailure: 失败")
            }

            @Throws(IOException::class)
            override fun onResponse(call: Call, response: Response) {
                val result = response.body()!!.string()
                runOnUiThread { showData(result) }
            }
        })
    }

    private fun showData(result: String) {
        Log.d(TAG, "onResponse: 调试数据$result")
        val tv_dingdanhao: SmartTextView //订单号
        val tv_suichedanhao: SmartTextView //随车单号
        val tv_car_number: SmartTextView //车架号
        val tv_car_type: SmartTextView //车型号
        val tv_info: SmartTextView //配置
        val tv_up_time: SmartTextView //上线时间
        val tvRecycker : TextView// 是否环保

        try {
            val jsonObject = JSONObject(result)
            if (jsonObject.optString("status") == "-1") {
                ToastUtils.show(jsonObject.optString("msg"))
                return
            }

            if (jsonObject.optJSONObject("data") != null && jsonObject.optJSONObject("data").optString("list") != null && !TextUtils.isEmpty(jsonObject.optJSONObject("data").optString("list"))){

                val jsonArr = jsonObject.optJSONObject("data").optJSONArray("list")
                if (jsonArr.length() == 0){
                    ToastUtils.show("暂无数据")
                    return
                }

                currentData = gson.fromJson(jsonArr.optJSONObject(0).toString(), RegisterCarDetails::class.java)
                if (currentData == null) return
                tv_dingdanhao = findViewById(R.id.tv_dingdanhao)
                tv_suichedanhao = findViewById(R.id.tv_suichedanhao)
                tv_car_number = findViewById(R.id.tv_car_number)
                tv_car_type = findViewById(R.id.tv_car_type)
                tv_info = findViewById(R.id.tv_info)
                tv_up_time = findViewById(R.id.tv_up_time)
                tvRecycker = findViewById(R.id.tv_recyclerable)

                if (currentData!!.qmsManufactureProductionplan != null) {
                    tv_dingdanhao.setText(currentData!!.qmsManufactureProductionplan.orderNo, TextView.BufferType.NORMAL)
                    tv_car_type.setText(currentData!!.qmsManufactureProductionplan.carModelNo, TextView.BufferType.NORMAL)
                    tv_info.setText(currentData!!.qmsManufactureProductionplan.configDesc, TextView.BufferType.NORMAL)
                }
                tv_suichedanhao.setText(currentData!!.flowCarNo, TextView.BufferType.NORMAL)
                tv_car_number.setText(currentData!!.carFarmeNo, TextView.BufferType.NORMAL)
                tv_up_time.setText(currentData!!.createDate, TextView.BufferType.NORMAL)


                //是否有变更记录
                if (currentData!!.configChange) {
                    findViewById<View>(R.id.ll_show_config_change).visibility = View.VISIBLE
                    findViewById<View>(R.id.ll_show_config_change).setOnClickListener {
                        val intent = Intent(context, RegisterCarConfigChangeActivity::class.java)
                        intent.putExtra(RegisterCarConfigChangeActivity.ACTION_DATA, currentData)
                        startActivity(intent)
                    }
                } else {
                    findViewById<View>(R.id.ll_show_config_change).visibility = View.GONE
                }

                if (currentData?.environmentalLabel != null){
                    when(currentData?.environmentalLabel){
                        "1" ->{
                            tvRecycker.text = "是"
                        }

                        "0" ->{
                            tvRecycker.text = "否"
                        }
                    }
                }

                if (locationListBeanList != null && locationListBeanList!!.isNotEmpty()) {
                    for (i in locationListBeanList!!.indices) {
                        if (locationListBeanList!![i]!!.value == currentData!!.location) {
                            sp_select!!.setSelection(i)
                        }
                    }
                }

                when (currentData!!.status) {
                    "debug" -> {
                        btn_register_car!!.text = "故障排除"
                        update_state = "troubleshooting"
                        btn_register_car!!.visibility = View.VISIBLE
                    }
                    "troubleshooting" -> {
                        btn_register_car!!.text = "故障排除确认"
                        update_state = "troubleshootingpassed"
                        btn_register_car!!.visibility = View.VISIBLE
                    }
                    "troubleshootingpassed" -> {
                        btn_register_car!!.text = "送验"
                        update_state = "submitcheck"
                        btn_register_car!!.visibility = View.VISIBLE
                    }
                    "submitcheck" -> {
                        btn_register_car!!.text = "初验完成"
                        update_state = "submitcheckpassed"
                        btn_register_car!!.visibility = View.VISIBLE
                    }
                    "submitcheckpassed" -> {
                        btn_register_car!!.text = "复验"
                        update_state = "recheck"
                        btn_register_car!!.visibility = View.VISIBLE
                    }
                    "recheck" -> {
                        btn_register_car!!.text = "复验作业"
                        update_state = "warehousingin"
                        btn_register_car!!.visibility = View.VISIBLE
                    }
                }
            }

        } catch (e: JSONException) {
            e.printStackTrace()
        }
    }

    /**
     * 提交
     */
    private fun commitData() {
        val map = ArrayMap<String, String>()
        map["carFarmeNo"] = currentData!!.carFarmeNo
        map["status"] = update_state
        map["userName"] = GlobalVar.username
        map["location"] = locationListBeanList!![sp_select!!.selectedItemPosition]!!.value

        val param = gson.toJson(map)
        showCommitDialog()
        val client = OkHttpClient()
        val requestBody = RequestBody.create(JSON, param)
        val request = Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/offlinedebuggingstatus/qmsOfflineStatus/api/updateOffLineStatus")
                .build()
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.d(TAG, "onFailure: 失败")
                runOnUiThread {
                    showNetErrorMessage()
                    cancelDialog()
                }
            }

            @Throws(IOException::class)
            override fun onResponse(call: Call, response: Response) {
                val result = response.body()!!.string()
                Log.d(TAG, "onResponse: 在调车辆$result")
                runOnUiThread {
                    try {
                        cancelDialog()
                        val jsonObject = JSONObject(result)
                        if (jsonObject.optString("status") == "0") {
                            ToastUtils.show(jsonObject.optString("msg"))
                            Handler().postDelayed({ finish() }, 1000)
                        }else{
                            ToastUtils.show(jsonObject.optString("msg"))
                        }
                    } catch (e: JSONException) {
                        e.printStackTrace()
                    }
                }
            }
        })
    }

    /**
     * 获取接车的库位
     */
    private fun queryLocation() {
        val map = ArrayMap<String, String>()
        map["type"] = "CAR_LOCATION"
        val param = gson.toJson(map)
        val client = OkHttpClient()
        val requestBody = RequestBody.create(JSON, param)
        val request = Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/common/util/api/getDict")
                .build()
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.d(TAG, "onFailure: 失败")
            }

            @Throws(IOException::class)
            override fun onResponse(call: Call, response: Response) {
                val result = response.body()!!.string()
                Log.d(TAG, "onResponse: 接车库位$result")
                runOnUiThread {
                    try {
                        val jsonObject = JSONObject(result)
                        locationListBeanList!!.addAll(gson.fromJson(jsonObject.optString("data"), object : TypeToken<List<RegisterCarLocationListBean?>?>() {}.type))
                        val adapter: ArrayAdapter<out Parcelable?> = ArrayAdapter(context, R.layout.simple_textview1, locationListBeanList)
                        sp_select!!.adapter = adapter
                        sp_select!!.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                            override fun onItemSelected(parent: AdapterView<*>?, view: View, position: Int, id: Long) {
                                registerCarLocationListBean = locationListBeanList!![position]
                            }

                            override fun onNothingSelected(parent: AdapterView<*>?) {}
                        }
                        dialog = BasePopupWindowDialog()
                        val bundle = Bundle()
                        bundle.putString(BasePopupWindowDialog.ACTION_VALUE_TITLE, "确认执行该操作吗?")
                        dialog!!.arguments = bundle
                    } catch (e: JSONException) {
                        e.printStackTrace()
                    }
                }
            }
        })
    }

    companion object {
        const val ACTION = "action_data"
    }
}