package com.zhuisu.fastdev.ui.aftermarket;

import org.jetbrains.annotations.NotNull;

import java.util.List;

/**
 * @author cxh
 * @description
 * @date 2021/3/1.
 */

public class AfterMarketSourceListBean {

    /**
     * retCode : 0
     * data : [{"id":"B2146AF08A4544FABAABA583D6A5BFA2","isNewRecord":false,"remarks":"","createDate":"2020-11-25 13:26:46","updateDate":"2020-11-25 13:26:46","value":"problem_source_04_01","label":"售后反馈","type":"problem_source","description":"问题来源","sort":10,"parentId":"problem_source_04"},{"id":"2C6E6D9A166541EF8E30EBB08C23191A","isNewRecord":false,"remarks":"","createDate":"2020-11-25 13:27:05","updateDate":"2020-11-25 13:27:05","value":"problem_source_04_02","label":"主动走访","type":"problem_source","description":"问题来源","sort":20,"parentId":"problem_source_04"},{"id":"18A7B7F4BBE9420281F836CDBFAAC769","isNewRecord":false,"remarks":"","createDate":"2020-11-25 13:27:25","updateDate":"2020-11-25 13:27:25","value":"problem_source_04_03","label":"PDI检查","type":"problem_source","description":"问题来源","sort":30,"parentId":"problem_source_04"}]
     * <p>
     * id : B2146AF08A4544FABAABA583D6A5BFA2
     * isNewRecord : false
     * remarks :
     * createDate : 2020-11-25 13:26:46
     * updateDate : 2020-11-25 13:26:46
     * value : problem_source_04_01
     * label : 售后反馈
     * type : problem_source
     * description : 问题来源
     * sort : 10
     * parentId : problem_source_04
     */

    private String id;
    private Boolean isNewRecord;
    private String remarks;
    private String createDate;
    private String updateDate;
    private String value;
    private String label;
    private String type;
    private String description;
    private Integer sort;
    private String parentId;

    public void setId(String id) {
        this.id = id;
    }

    public void setNewRecord(Boolean newRecord) {
        isNewRecord = newRecord;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public void setCreateDate(String createDate) {
        this.createDate = createDate;
    }

    public void setUpdateDate(String updateDate) {
        this.updateDate = updateDate;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public void setType(String type) {
        this.type = type;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setSort(Integer sort) {
        this.sort = sort;
    }

    public void setParentId(String parentId) {
        this.parentId = parentId;
    }

    public String getId() {
        return id;
    }

    public Boolean getNewRecord() {
        return isNewRecord;
    }

    public String getRemarks() {
        return remarks;
    }

    public String getCreateDate() {
        return createDate;
    }

    public String getUpdateDate() {
        return updateDate;
    }

    public String getValue() {
        return value;
    }

    public String getLabel() {
        return label;
    }

    public String getType() {
        return type;
    }

    public String getDescription() {
        return description;
    }

    public Integer getSort() {
        return sort;
    }

    public String getParentId() {
        return parentId;
    }


    @Override
    public String toString(){
        return label;
    }
}
