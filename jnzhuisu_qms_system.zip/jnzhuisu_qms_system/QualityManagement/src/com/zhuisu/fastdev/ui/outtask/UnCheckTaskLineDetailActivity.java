package com.zhuisu.fastdev.ui.outtask;


import android.app.AlertDialog;
import android.content.Intent;
import android.text.TextUtils;
import android.util.ArrayMap;
import android.util.Log;
import android.view.View;
import android.widget.ListView;
import android.widget.TextView;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.zhuisu.fastdev.BaseActivity;
import com.zhuisu.fastdev.beans.AdmissionDictListBean;
import com.zhuisu.fastdev.view.FastTitleLayout;
import com.zhuisu.qualityManagement.R;
import com.zhuisu.suppliermanagement.adapter.UnCheckTaskLineDetailAdapter;
import com.zhuisu.suppliermanagement.base.CustomToast;

import com.zhuisu.suppliermanagement.ui.LineFileList;
import com.zhuisu.suppliermanagement.ui.PDFLookActivity;
import com.zhuisu.suppliermanagement.ui.ShowImageDisplayActivity;
import com.zhuisu.suppliermanagement.ui.UnCheckLineBean;
import com.zhuisu.suppliermanagement.ui.UnCheckListData;
import com.zhuisu.suppliermanagement.ui.UnCheckTaskDetailsActivity;
import com.zhuisu.suppliermanagement.util.GlobalVar;
import com.zhuisu.suppliermanagement.util.ToastUtils;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 * 行项目
 */
public class UnCheckTaskLineDetailActivity extends BaseActivity {

    private UnCheckTaskLineDetailAdapter adapter;
    private List<UnCheckLineBean> list;
    public static final String ACTION_DATA = "action_data";
    public static final String ACTION_STATE = "action_state";
    private CustomToast cToast;
    private UnCheckListData currentData;
    private boolean isLoadChecked = false;


    @Override
    protected void initViews() {
        cToast = new CustomToast(context);
        ListView listView = findViewById(R.id.lv_list);
        list = new ArrayList<>();
        TextView tv_bh1 = findViewById(R.id.tv_bh1);
        TextView tv_bh2 = findViewById(R.id.tv_bh2);
        TextView tv_bh3 = findViewById(R.id.tv_bh3);
        TextView tv_bh4 = findViewById(R.id.tv_bh4);
        TextView tv_bh5 = findViewById(R.id.tv_bh5);
        TextView tv_bh6 = findViewById(R.id.tv_bh6);
        TextView tv13 = findViewById(R.id.tv13);//抽检数量
        TextView tv_bh16 = findViewById(R.id.tv_bh16);//质检库位
        TextView tvDataSource = findViewById(R.id.tv_data_source);

        if (getIntent() != null && getIntent().getBooleanExtra(ACTION_STATE, false)) {
            isLoadChecked = getIntent().getBooleanExtra(ACTION_STATE, false);
            if (isLoadChecked) {
                findViewById(R.id.tv_all_not_).setVisibility(View.GONE);
                findViewById(R.id.tv_all_ok).setVisibility(View.GONE);
            }
        }

        if (getIntent() != null && getIntent().getSerializableExtra(ACTION_DATA) != null) {
            currentData = (UnCheckListData) getIntent().getSerializableExtra(ACTION_DATA);
            tv_bh1.setText(currentData.getMaterialcode());
            tv_bh2.setText("【" + currentData.getReceivedate().substring(0, 10) + "】");
            tv_bh3.setText("【" + currentData.getQty() + "】");
            tv_bh4.setText(currentData.getMaterialname());
            tv_bh5.setText(currentData.getSuppliercode() == null ? "" : currentData.getSuppliercode());
            tv_bh6.setText(currentData.getSuppliername() == null ? "" : currentData.getSuppliername());
            tv13.setText(currentData.getCheckqty() + currentData.getUnit());

            if (currentData.getCheckposition() == null) {
                tv_bh16.setText("");
            } else {
                tv_bh16.setText(currentData.getCheckposition());
            }

            if (!currentData.getDatasource().isEmpty()) {
                if (currentData.getDatasource().equals("fwzk")) {
                    tvDataSource.setText("试制");
                } else {
                    tvDataSource.setText("");
                }
            }

        }

        adapter = new UnCheckTaskLineDetailAdapter(list, this);
        listView.setAdapter(adapter);
        adapter.setOnDetailClickListener(position -> {
            UnCheckLineBean data = list.get(position);
            Intent intent = new Intent(UnCheckTaskLineDetailActivity.this, UnCheckTaskDetailsActivity.class);
            intent.putExtra(UnCheckTaskDetailsActivity.ACTION_DATA, data);
            intent.putExtra(UnCheckTaskDetailsActivity.ACTION_FIRST_DATA, currentData);
            startActivity(intent);
        });


        findViewById(R.id.tv_all_ok).setOnClickListener(arg0 -> {
            AlertDialog.Builder builder = new AlertDialog.Builder(context);
            builder.setTitle("提示");
            builder.setMessage("确认提交结果为全部合格吗?");
            builder.setPositiveButton("取消", (arg014, arg1) -> arg014.dismiss());
            builder.setNegativeButton("确定", (arg013, arg1) -> {
                arg013.dismiss();
                submitData("0");
            });
            builder.show();
        });

        findViewById(R.id.tv_all_not_).setOnClickListener(arg0 -> {

            AlertDialog.Builder builder = new AlertDialog.Builder(context);
            builder.setTitle("提示");
            builder.setMessage("确认提交结果为全部不合格吗?");
            builder.setPositiveButton("取消", (arg01, arg1) -> arg01.dismiss());
            builder.setNegativeButton("确定", (arg012, arg1) -> {
                arg012.dismiss();
                submitData("1");
            });
            builder.show();

        });

        findViewById(R.id.tv_return_ok).setOnClickListener(arg0 -> {

            AlertDialog.Builder builder = new AlertDialog.Builder(context);
            builder.setTitle("提示");
            builder.setMessage("确认提交结果为返修合格吗?");
            builder.setPositiveButton("取消", (arg01, arg1) -> arg01.dismiss());
            builder.setNegativeButton("确定", (arg012, arg1) -> {
                arg012.dismiss();
                submitData("3");
            });
            builder.show();

        });

        adapter.setOnChangeClickListener(position -> {
            Intent intent = new Intent(context, AdmissionAndUpdateActivity.class);
            intent.putExtra(AdmissionAndUpdateActivity.ACTION_DATA, list.get(position));
            intent.putExtra(AdmissionAndUpdateActivity.ACTION_ADD_DATA, currentData);
            startActivity(intent);
        });


        adapter.setOnDeleteClickListener(this::deleteItem);

        FastTitleLayout fastTitleLayout = findViewById(R.id.fast);
        fastTitleLayout.setOnRightClickListener(view -> {
            Intent intent = new Intent(context, AdmissionAndUpdateActivity.class);
            intent.putExtra(AdmissionAndUpdateActivity.ACTION_ADD_DATA, currentData);
            startActivity(intent);
        });
    }

    private void deleteItem(int position) {
        String path = GlobalVar.url + "a/checktaskitem/qmsPurchasecheckChecktaskitem/api/deleteChecktaskItem";

        ArrayMap<String, String> map = new ArrayMap<>();
        map.put("userName", GlobalVar.username);
        map.put("id", list.get(position).getId());
        map.put("checktaskid", currentData.getId());
        map.put("checkitem", list.get(position).getCheckitem());

        String param = gson.toJson(map);
        Log.e("参数", param);
        showCommitDialog();

        OkHttpClient client = new OkHttpClient();
        RequestBody requestBody = RequestBody.create(JSON, param);
        Request request = new Request.Builder()
                .post(requestBody)
                .url(path)
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                Log.d(TAG, "onFailure: 失败");
                runOnUiThread(() -> {
                    showNetErrorMessage();
                    cancelDialog();
                });
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                final String responseString = response.body().string();
                Log.d(TAG, "onResponse: 删除" + responseString);
                runOnUiThread(() -> {
                    try {
                        cancelDialog();
                        Log.e("---->", responseString);
                        JSONObject jsonObject2 = new JSONObject(responseString);
                        String issuccess = jsonObject2.getString("retCode");
                        if ("0".equals(issuccess)) {
                            cToast.show("删除成功", 1000);
                            search();
                        } else {
                            String meesage = jsonObject2.getString("retMessage");
                            ToastUtils.show(meesage);
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                });
            }
        });
    }


    @Override
    protected int getResId() {
        return R.layout.activity_un_check_line_details;
    }

    private void submitData(String action) {
        String path = GlobalVar.url + "a/checktask/qmsPurchasecheckChecktask/api/batchsave";

        ArrayMap<String, String> map = new ArrayMap<>();
        map.put("id", currentData.getId());
        map.put("remark", "");
        map.put("checkResult", action);
        map.put("checkPerson", GlobalVar.username);
        String param = gson.toJson(map);
        Log.e("参数", param);
        showCommitDialog();

        OkHttpClient client = new OkHttpClient();
        RequestBody requestBody = RequestBody.create(JSON, param);
        Request request = new Request.Builder()
                .post(requestBody)
                .url(path)
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                Log.d(TAG, "onFailure: 失败");
                runOnUiThread(() -> {
                    showNetErrorMessage();
                    cancelDialog();
                });
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                final String responseString = response.body().string();
                Log.d(TAG, "onResponse: 整批合格or不合格" + responseString);
                runOnUiThread(() -> {
                    try {
                        cancelDialog();
                        Log.e("---->", responseString);
                        JSONObject jsonObject2 = new JSONObject(responseString);
                        String issuccess = jsonObject2.getString("retCode");
                        if ("0".equals(issuccess)) {
                            cToast.show("提交成功", 1000);
                            finish();
                        } else {
                            String meesage = jsonObject2.getString("retMessage");
                            new CustomToast(context).show(meesage, 1000);
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                });
            }
        });
    }


    private void queryFiles() {

        if (fileLists != null && !fileLists.isEmpty()) {
            return;
        }
        ArrayMap<String, String> map = new ArrayMap<>();
        map.put("userName", GlobalVar.username);
        map.put("materialCode", currentData.getMaterialcode());
        String param = gson.toJson(map);
        Log.e("--->文件列表参数", param);
        OkHttpClient client = new OkHttpClient();
        RequestBody requestBody = RequestBody.create(JSON, param);
        Request request = new Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/checktask/qmsPurchasecheckChecktask/api/viewDrawing")
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                Log.d(TAG, "onFailure: 失败");
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                final String result = response.body().string();
                runOnUiThread(() -> {
                    //文件列表
                    try {
                        Log.e("文件列表", result);
                        JSONObject jsonObject = new JSONObject(result);

                        TextView tv_draw_change = findViewById(R.id.tv_draw_change);
                        if (jsonObject.optBoolean("isHaveMoreVersion")) {
                            tv_draw_change.setVisibility(View.VISIBLE);
                            tv_draw_change.setText("图纸发生变更");
                        } else {
                            tv_draw_change.setVisibility(View.GONE);
                        }

                        if (jsonObject.optString("retCode").equals("0") && jsonObject.optString("data") != null && !TextUtils.isEmpty(jsonObject.optString("data"))) {
                            List<LineFileList> temp1 = new Gson().fromJson(jsonObject.optString("data"),
                                    new TypeToken<List<LineFileList>>() {
                                    }.getType());
                            fileLists.addAll(temp1);

                            findViewById(R.id.tv_guid_book).setOnClickListener(arg0 -> {
                                if (fileLists == null || fileLists.isEmpty()) {
                                    ToastUtils.show("暂无指导书");
                                    return;
                                }
                                String[] strings = new String[fileLists.size()];
                                for (int i = 0; i < fileLists.size(); i++) {
                                    strings[i] = fileLists.get(i).getFilename();
                                }
                                AlertDialog.Builder builder = new AlertDialog.Builder(context)
                                        .setTitle("选择")
                                        .setSingleChoiceItems(strings, 0, (arg01, arg1) -> {
                                            arg01.dismiss();
                                            Intent intent;
                                            if (fileLists.get(arg1).getFileextent().equals("pdf")) {
                                                intent = new Intent(context, PDFLookActivity.class);
                                                intent.putExtra(PDFLookActivity.PDF_DATA, fileLists.get(arg1).getFileStr());
                                            } else {
                                                intent = new Intent(context, ShowImageDisplayActivity.class);
                                                GlobalVar.IMGBASE64 = fileLists.get(arg1).getFileStr();
                                            }
                                            startActivity(intent);
                                        });
                                AlertDialog alertDialog = builder.create();
                                alertDialog.show();
                            });
                        } else {
                            findViewById(R.id.tv_guid_book).setOnClickListener(arg0 -> {
                                ToastUtils.show("暂无指导书");
                            });
                        }

                    } catch (JSONException jsonException) {
                        jsonException.printStackTrace();
                    }

                });
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        search();
        queryFiles();
    }


    List<LineFileList> fileLists = new ArrayList<>();

    public void search() {

        if (list != null) {
            list.clear();
            adapter.notifyDataSetChanged();
        }
        ArrayMap<String, Object> params = new ArrayMap<>();
        params.put("userName", GlobalVar.username);
        params.put("checkTaskid", currentData.getId());
        String param = gson.toJson(params);
        Log.e("参数", param);
        OkHttpClient client = new OkHttpClient();
        RequestBody requestBody = RequestBody.create(JSON, param);
        Request request = new Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/checktaskitem/qmsPurchasecheckChecktaskitem/api/getChecktaskItem")
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                Log.d(TAG, "onFailure: 失败");
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                final String responseString = response.body().string();
                runOnUiThread(() -> {
                    try {
                        Log.e("---->", responseString);
                        JSONObject jsonObject2 = new JSONObject(responseString);
                        String issuccess = jsonObject2.getString("retCode");
                        String meesage = jsonObject2.getString("retMessage");
                        if ("0".equals(issuccess)) {
                            List<UnCheckLineBean> temp = new Gson().fromJson(jsonObject2.optString("data"), new TypeToken<List<UnCheckLineBean>>() {
                            }.getType());
                            list.addAll(temp);
                            adapter.notifyDataSetChanged();
                        } else {
                            ToastUtils.show(meesage);
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                });
            }
        });

    }

}
