package com.zhuisu.fastdev.ui.aftermarket

import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Parcelable
import android.provider.MediaStore
import android.support.v4.content.FileProvider
import android.text.TextUtils
import android.util.ArrayMap
import android.util.Log
import android.view.View
import android.widget.*
import android.widget.AdapterView.OnItemSelectedListener
import com.bumptech.glide.Glide
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.zhuisu.fastdev.BaseActivity
import com.zhuisu.fastdev.beans.xiaxian.XiaXianWeiJianXiangQingBuMenList
import com.zhuisu.fastdev.beans.zhuangpei.ZhuangPeiWeiJianGuZhangXinxiBean
import com.zhuisu.fastdev.ui.gracelog.GradeProblemProjectListBean
import com.zhuisu.fastdev.ui.util.LogUtils
import com.zhuisu.fastdev.ui.zhuangpei.SelectItemActivity
import com.zhuisu.fastdev.view.SmartTextView
import com.zhuisu.qualityManagement.R
import com.zhuisu.suppliermanagement.util.FileUtil
import com.zhuisu.suppliermanagement.util.GlobalVar
import com.zhuisu.suppliermanagement.util.ToastUtils
import com.zhuisu.suppliermanagement.util.Util
import okhttp3.*
import org.json.JSONException
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.*
import kotlin.collections.ArrayList

/**
 * @author cxh
 * @description  评审问题录入
 * @date 2021/2/25.
 */
class AftermarketActivity : BaseActivity() {

    private var spSource: Spinner? = null
    private var tvErrorCode: TextView? = null
    private var tvErrorName: TextView? = null
    private var tvErrorLevel: TextView? = null
    private var tvErrorType: TextView? = null
    private var spDept: Spinner? = null
    private var showimage: ImageView? = null
    private var etInfo: EditText? = null
    private var stvDate: SmartTextView? = null
    private var etNumber: EditText? = null
    private var etHeadDept: EditText? = null //牵头部门
    private var etMarkArea: EditText? = null //走访地区
    private var tvMarkDate: TextView? = null //走访日期
    private var tvMarkPeople: TextView? = null
    private var etUserServiceDespatch: EditText? = null //用户 服务站 经销少 分公司
    private var etEatAnd: EditText? = null //处置方案

    @SuppressLint("ClickableViewAccessibility")
    override fun initViews() {
        spSource = findViewById(R.id.sp_source)

        tvErrorCode = findViewById(R.id.tv_error_coder)
        tvErrorName = findViewById(R.id.tv_error_name)
        tvErrorLevel = findViewById(R.id.tv_error_level)
        tvErrorType = findViewById(R.id.tv_error_type)
        showimage = findViewById(R.id.showimage)
        spDept = findViewById(R.id.sp_dept)
        etInfo = findViewById(R.id.et_info)
        stvDate = findViewById(R.id.tv_create_date)
        stvDate!!.setOnClickListener(DateClickListener(stvDate))
        etNumber = findViewById(R.id.et_number)
        etHeadDept = findViewById(R.id.et_head_dept)
        etMarkArea = findViewById(R.id.et_mark_area)
        tvMarkDate = findViewById(R.id.tv_mark_date)
        tvMarkDate!!.setOnClickListener(DateClickListener(tvMarkDate))
        etUserServiceDespatch = findViewById(R.id.et_user_service_dispatch)
        tvMarkPeople = findViewById(R.id.tv_mark_people)
        tvMarkPeople!!.text = GlobalVar.realname
        etEatAnd = findViewById(R.id.et_dept_project)

        tvErrorCode!!.setOnClickListener {
            val intent = Intent(context, SelectItemActivity::class.java)
            startActivityForResult(intent, 0x11)
        }

        findViewById<View>(R.id.btn_save).setOnClickListener {
            submit("")
        }

        findViewById<View>(R.id.btn_submit).setOnClickListener {
            submit("1")
        }
        findViewById<View>(R.id.iv_select_image).setOnClickListener { selectImage() }
        querySource()
        queryDept()
    }

    override fun getResId(): Int {
        return R.layout.activity_aftermarket
    }


    //提交数据
    private fun submit(state : String) {

        if (zhuangPeiWeiJianGuZhangXinxiBean == null) {
            ToastUtils.show("请选择故障编码")
            return
        }

        if (sourceListBean.isEmpty()) {
            ToastUtils.show("请选择问题来源")
            return
        }

        if (TextUtils.isEmpty(stvDate!!.text.toString())){
            ToastUtils.show("请选择发生时间")
            return
        }

        if (TextUtils.isEmpty(etNumber!!.text.toString())){
            ToastUtils.show("请输入数量")
            return
        }

        if (TextUtils.isEmpty(etHeadDept!!.text.toString())){
            ToastUtils.show("请输入牵头部门")
            return
        }

        if (TextUtils.isEmpty(etMarkArea!!.text.toString())){
            ToastUtils.show("请输入走访地区")
            return
        }

        if (TextUtils.isEmpty(tvMarkDate!!.text.toString())){
            ToastUtils.show("请选择时间")
            return
        }

        if (TextUtils.isEmpty(etUserServiceDespatch!!.text.toString())){
            ToastUtils.show("请输入用户、服务站、经销商")
            return
        }

        if (TextUtils.isEmpty(etEatAnd!!.text.toString())){
            ToastUtils.show("请输入处置方案")
            return
        }

        val map = ArrayMap<String, String>()
        map["isStartProcess"] = state
        map["mobileCreateLoginName"] = GlobalVar.username
        map["mobileStartProcessLoginName"] = if (TextUtils.isEmpty(state)) "" else GlobalVar.username

        map["problemSource"] = sourceListBean[spSource!!.selectedItemPosition].value
        map["responsibleDepartment"] = if (deptList[spDept!!.selectedItemPosition].dept == null) "" else deptList[spDept!!.selectedItemPosition].dept
        map["faultCode"] = zhuangPeiWeiJianGuZhangXinxiBean!!.malfunctionNo
        map["faultName"] = zhuangPeiWeiJianGuZhangXinxiBean!!.malfunctionName
        map["faultType"] = zhuangPeiWeiJianGuZhangXinxiBean!!.malfunctionType
        map["faultLevel"] = zhuangPeiWeiJianGuZhangXinxiBean!!.malfunctionLevel
        map["problemDesc"] = etInfo!!.text.toString()
        map["imgStr1"] = if (uploadFilePath != null) bitmapToBase64(getLoacalBitmap(uploadFilePath)) else ""
        map["happenTime"] = stvDate!!.text.toString()
        map["happenNum"] = etNumber!!.text.toString()
        map["leadDepartment"] = etHeadDept!!.text.toString()
        map["visitLocation"] = etHeadDept!!.text.toString()
        map["visitTime"] = tvMarkDate!!.text.toString()
        map["visitUser"] = GlobalVar.username
        map["serviceStation"] = etUserServiceDespatch!!.text.toString()
        map["solutionDesc"] = etEatAnd!!.text.toString()


        val param = gson.toJson(map)
        Log.e("--->", param)
        val client = OkHttpClient()
        val requestBody = RequestBody.create(JSON, param)
        val request = Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/aftersales/qmsImprovementAfterSalesInfos/api/save")
                .build()
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.d(TAG, "onFailure: 失败")
            }

            @Throws(IOException::class)
            override fun onResponse(call: Call, response: Response) {
                val result = response.body()!!.string()
                runOnUiThread {
                    LogUtils.printDebug("提交售后: $result")
                    val jsonData = JSONObject(result)
                    if (jsonData.optString("retCode") == "0") {
                        ToastUtils.show("提交成功")
                        Handler().postDelayed({ finish() }, 1000)
                    } else {
                        ToastUtils.show(jsonData.optString("retMessage"))
                    }
                }
            }
        })
    }


    /**
     * 获取问题来源
     * */
    private var sourceListBean: ArrayList<AfterMarketSourceListBean> = ArrayList()
    private fun querySource() {
        val map = ArrayMap<String, String>()
        val param = gson.toJson(map)
        val client = OkHttpClient()
        val requestBody = RequestBody.create(JSON, param)
        val request = Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/aftersales/qmsImprovementAfterSalesInfos/api/getProblemSource")
                .build()
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.d(TAG, "onFailure: 失败")
            }

            @Throws(IOException::class)
            override fun onResponse(call: Call, response: Response) {
                val result = response.body()!!.string()
                runOnUiThread {
                    LogUtils.printDebug("获取来源: $result")
                    val jsonData = JSONObject(result)
                    if (jsonData.optString("retCode") == "0" && !TextUtils.isEmpty(jsonData.optString("data"))) {
                        val listType = object : TypeToken<java.util.ArrayList<AfterMarketSourceListBean>>() {}.type
                        val temp: ArrayList<AfterMarketSourceListBean> = Gson().fromJson(jsonData.optString("data"), listType)
                        sourceListBean.clear()
                        sourceListBean.addAll(temp)

                        val registerFormAdapter = ArrayAdapter(context!!, R.layout.simple_textview1, sourceListBean)
                        spSource!!.adapter = registerFormAdapter

                        spSource!!.onItemSelectedListener = object : OnItemSelectedListener {
                            override fun onItemSelected(parent: AdapterView<*>?, view: View, position: Int, id: Long) {

                            }
                            override fun onNothingSelected(parent: AdapterView<*>?) {}
                        }

                    } else {
                        ToastUtils.show("获取来源失败")
                    }
                }
            }
        })
    }

    /**
     * 查询部门
     */
    private var deptList: ArrayList<XiaXianWeiJianXiangQingBuMenList> = ArrayList()
    private fun queryDept() {
        val client = OkHttpClient()
        val requestBody = RequestBody.create(JSON, "")
        val request = Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/sys/office/api/getOfficeList")
                .build()
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.d(TAG, "onFailure: 失败")
            }

            @Throws(IOException::class)
            override fun onResponse(call: Call, response: Response) {
                val result = response.body()!!.string()
                runOnUiThread {
                    Log.d(TAG, "onResponse: 部门$result")
                    try {
                        val jsonObject = JSONObject(result)
                        deptList = gson.fromJson(jsonObject.optString("data"), object : TypeToken<List<XiaXianWeiJianXiangQingBuMenList?>?>() {}.type)
                        val arrayAdapter = ArrayAdapter(context, R.layout.simple_textview1, deptList)
                        spDept!!.adapter = arrayAdapter
                    } catch (e: JSONException) {
                        e.printStackTrace()
                    }
                }
            }
        })
    }

    private var zhuangPeiWeiJianGuZhangXinxiBean: ZhuangPeiWeiJianGuZhangXinxiBean? = null
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (resultCode == 0x18) {
            if (data!!.getParcelableExtra<Parcelable?>("data") != null) {
                zhuangPeiWeiJianGuZhangXinxiBean = data.getParcelableExtra("data")
                tvErrorCode!!.text = zhuangPeiWeiJianGuZhangXinxiBean!!.malfunctionNo
                tvErrorName!!.text = zhuangPeiWeiJianGuZhangXinxiBean!!.malfunctionName
                tvErrorLevel!!.text = zhuangPeiWeiJianGuZhangXinxiBean!!.malfunctionLevel
                tvErrorType!!.text = zhuangPeiWeiJianGuZhangXinxiBean!!.malfunctionType
            }
        } else {
            if (resultCode == RESULT_OK && requestCode == IMAGE_CODE) {
                // 选择文件
                if (data == null) return
                val path: String = FileUtil.getImageAbsolutePath(context as Activity, data)
                        ?: return
                uploadFilePath = path
                Glide.with(context).load(path).into(showimage!!)
            } else if (requestCode == 1 && resultCode == RESULT_OK) {
                Glide.with(context).load(uploadFilePath).into(showimage!!)
            }
        }
        super.onActivityResult(requestCode, resultCode, data)
    }

    var alertdialog: AlertDialog? = null
    var fileDir = Environment.getExternalStorageDirectory().absolutePath + "/qualitymanagement/files/media/"
    var uploadFilePath: String? = null
    var imageUri: Uri? = null
    private val IMAGE_CODE = 200 // 这里的IMAGE_CODE是自己任意定义的

    private fun selectImage() {
        alertdialog = Util.getDialog(context, "选择图像", 0, { _, _, position, _ ->
            if (alertdialog!!.isShowing) {
                alertdialog!!.dismiss()
            }
            val f: File?
            when (position) {
                0 -> {
                    val capimgIntent = Intent()
                    val fileName: String = SimpleDateFormat("yyyyMMddHHmmss", Locale.CHINA).format(Date()) + ".jpg"
                    FileUtil.checkDir(fileDir + "_/")
                    f = File(fileDir + "_", fileName)
                    uploadFilePath = fileDir + "_/" + fileName
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                        imageUri = FileProvider.getUriForFile(context, "com.jnqms.fileprovider", f)
                        capimgIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    } else {
                        imageUri = Uri.fromFile(f)
                    }
                    capimgIntent.putExtra(MediaStore.EXTRA_OUTPUT, imageUri)
                    capimgIntent.action = MediaStore.ACTION_IMAGE_CAPTURE
                    capimgIntent.addCategory(Intent.CATEGORY_DEFAULT)
                    startActivityForResult(capimgIntent, 1)
                }
                1 -> {
                    val intent = Intent(Intent.ACTION_GET_CONTENT)
                    intent.type = "image/*"
                    intent.addCategory(Intent.CATEGORY_OPENABLE)
                    try {
                        startActivityForResult(Intent.createChooser(intent, "Select a File to Upload"),
                                IMAGE_CODE)
                    } catch (ex: ActivityNotFoundException) {
                        Toast.makeText(context, "Please install a File Manager.", Toast.LENGTH_SHORT)
                                .show()
                    }
                }
                else -> {
                }
            }
        }, arrayOf("拍照", "文件"), arrayOf(R.drawable.i_camera, R.drawable.i_image))
        alertdialog!!.show()
    }
}