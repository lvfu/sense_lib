package com.zhuisu.fastdev.ui.qualityaskquery

import android.annotation.SuppressLint
import android.content.Intent
import android.text.TextUtils
import android.util.ArrayMap
import android.util.Log
import android.view.View
import android.widget.*

import com.zhuisu.fastdev.BaseActivity
import com.zhuisu.fastdev.ui.util.LogUtils
import com.zhuisu.fastdev.view.SmartTextView
import com.zhuisu.qualityManagement.R
import com.zhuisu.suppliermanagement.ui.ShowImageDisplayActivity
import com.zhuisu.suppliermanagement.util.GlobalVar
import okhttp3.*
import org.json.JSONObject
import java.io.IOException

/**
 * @author cxh
 * @description 问题详情
 * @date 2021/3/1.
 */
class AfterQualityProblemDetailActivity : BaseActivity() {

    //售后质量
    private var tvSource: TextView? = null
    private var tvErrorCode: TextView? = null
    private var tvErrorName: TextView? = null
    private var tvErrorLevel: TextView? = null
    private var tvErrorType: TextView? = null
    private var spDept: TextView? = null
    private var showimage: ImageView? = null
    private var etInfo: TextView? = null
    private var stvDate: SmartTextView? = null
    private var etNumber: TextView? = null
    private var etHeadDept: TextView? = null //牵头部门
    private var etMarkArea: TextView? = null //走访地区
    private var tvMarkDate: TextView? = null //走访日期
    private var tvMarkPeople: TextView? = null
    private var etUserServiceDespatch: TextView? = null //用户 服务站 经销少 分公司
    private var etEatAnd: TextView? = null //处置方案

    //

    private var firstData: AfterQualityProblemListBean? = null

    companion object {
        const val PARAMS_DATA = "params_data"
    }

    override fun initViews() {
        tvSource = findViewById(R.id.sp_source)
        tvErrorCode = findViewById(R.id.tv_error_coder)
        tvErrorName = findViewById(R.id.tv_error_name)
        tvErrorLevel = findViewById(R.id.tv_error_level)
        tvErrorType = findViewById(R.id.tv_error_type)
        showimage = findViewById(R.id.showimage)
        spDept = findViewById(R.id.sp_dept)
        etInfo = findViewById(R.id.et_info)
        stvDate = findViewById(R.id.tv_create_date)
        stvDate!!.setOnClickListener(DateClickListener(stvDate))
        etNumber = findViewById(R.id.et_number)
        etHeadDept = findViewById(R.id.et_head_dept)
        etMarkArea = findViewById(R.id.et_mark_area)
        tvMarkDate = findViewById(R.id.tv_mark_date)
        tvMarkDate!!.setOnClickListener(DateClickListener(tvMarkDate))
        etUserServiceDespatch = findViewById(R.id.et_user_service_dispatch)
        tvMarkPeople = findViewById(R.id.tv_mark_people)
        tvMarkPeople!!.text = GlobalVar.realname
        etEatAnd = findViewById(R.id.et_dept_project)

        firstData = intent?.getParcelableExtra(PARAMS_DATA)
        findViewById<Button>(R.id.btn_submit).setOnClickListener {
            finish()
        }
        queryDetail()
    }

    //查询详情信息
    private fun queryDetail() {
        val map = ArrayMap<String, String>()
        map["problemSource"] = firstData!!.problemSource
        map["id"] = firstData!!.id

        val param = gson.toJson(map)
        Log.e("-->", param)
        val client = OkHttpClient()
        val requestBody = RequestBody.create(JSON, param)
        val request = Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/zerokmproblem/qmsImprovementZeroKmProblem/api/getSingleProblemInfo")
                .build()
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.d(TAG, "onFailure: 失败")
            }

            @Throws(IOException::class)
            override fun onResponse(call: Call, response: Response) {
                val result = response.body()!!.string()
                runOnUiThread {
                    LogUtils.printDebug("获取问题详情: $result")
                    val jsonData = JSONObject(result)
                    if (jsonData.optString("retCode") == "0" && !TextUtils.isEmpty(jsonData.optString("data"))) {
                        when {
                            firstData!!.problemSource.contains("problem_source_04") -> {
                                //售后
                                findViewById<LinearLayout>(R.id.ll_zero).visibility = View.GONE
                                findViewById<LinearLayout>(R.id.ll_after).visibility = View.GONE
                                findViewById<LinearLayout>(R.id.ll_quality).visibility = View.VISIBLE
                                showAfterQuality(jsonData.optJSONObject("data"))
                            }
                            firstData!!.problemSource.contains("problem_source_14") -> {
                                //零公里
                                findViewById<LinearLayout>(R.id.ll_after).visibility = View.GONE
                                findViewById<LinearLayout>(R.id.ll_quality).visibility = View.GONE
                                findViewById<LinearLayout>(R.id.ll_zero).visibility = View.VISIBLE
                                showZeroDetail(jsonData.optJSONObject("data"))
                            }
                            else -> {
                                //评审
                                findViewById<LinearLayout>(R.id.ll_quality).visibility = View.GONE
                                findViewById<LinearLayout>(R.id.ll_zero).visibility = View.GONE
                                findViewById<LinearLayout>(R.id.ll_after).visibility = View.VISIBLE
                                showAfterProjectDetail(jsonData.optJSONObject("data"))
                            }
                        }

                        val jsonBase = jsonData.optJSONObject("data")
                        val tvRectifier = findViewById<TextView>(R.id.tv_rectifier) //整改人
                        tvRectifier.text = jsonBase.optString("rectifierName")

                        val tvRectifierTime = findViewById<TextView>(R.id.tv_rectifier_date) //整改时间
                        tvRectifierTime.text = jsonBase.optString("rectifiTime")

                        val tvRectifierPeople = findViewById<TextView>(R.id.tv_rectifier_people) //验证人
                        tvRectifierPeople.text = jsonBase.optString("verificaUserName")

                        val tvReDate = findViewById<TextView>(R.id.tv_re_date) //验证人
                        tvReDate.text = jsonBase.optString("verificaTime")

                        val tvCreateUser = findViewById<TextView>(R.id.tv_create_user) //创建人
                        tvCreateUser.text = jsonBase.optString("createUserStr")

                        val tvCreateDate = findViewById<TextView>(R.id.tv_create_time) //创建时间
                        tvCreateDate.text = jsonBase.optString("createDate")

                    }
                }
            }
        })
    }

    /**
     * 显示评审项目
     * */
    private fun showAfterProjectDetail(jsonObject: JSONObject) {
        val tvProject = findViewById<TextView>(R.id.sp_after_project)
        tvProject.text = jsonObject.optString("reviewProject")

        val etCarFrameNumber = findViewById<TextView>(R.id.et_car_frame_number)
        etCarFrameNumber.text = jsonObject.optString("carFrameNo")

        val tvErrorCode = findViewById<TextView>(R.id.tv_after_error_coder)
        tvErrorCode.text = jsonObject.optString("faultCode")

        val tvErrorName = findViewById<TextView>(R.id.tv_after_error_name)
        tvErrorName.text = jsonObject.optString("faultName")

        val tvLevel = findViewById<TextView>(R.id.tv_after_error_level)
        tvLevel.text = jsonObject.optString("faultLevel")

        val tvType = findViewById<TextView>(R.id.tv_after_error_type)
        tvType.text = jsonObject.optString("faultType")

        val tvInfo = findViewById<TextView>(R.id.tv_error_after_info)
        tvInfo.text = jsonObject.optString("faultDes")

        val tvDept = findViewById<TextView>(R.id.tv_after_dept)
        tvDept.text = jsonObject.optString("responsibleDepartmentName")

        val ivImage = findViewById<ImageView>(R.id.show_after_image)
        if (!TextUtils.isEmpty(jsonObject.optString("imgStr"))) {
            ivImage.setImageBitmap(base64ToBitmap(jsonObject.optString("imgStr")))
            ivImage.setOnClickListener {
                val intent = Intent(context, ShowImageDisplayActivity::class.java)
                GlobalVar.IMGBASE64 = jsonObject.optString("imgStr")
                context?.startActivity(intent)
            }
        }

        if (!TextUtils.isEmpty(jsonObject.optString("imgStr1"))) {
            ivImage.setImageBitmap(base64ToBitmap(jsonObject.optString("imgStr1")))
            ivImage.setOnClickListener {
                val intent = Intent(context, ShowImageDisplayActivity::class.java)
                GlobalVar.IMGBASE64 = jsonObject.optString("imgStr1")
                context?.startActivity(intent)
            }
        }

        if (!TextUtils.isEmpty(jsonObject.optString("imgStr2"))) {
            ivImage.setImageBitmap(base64ToBitmap(jsonObject.optString("imgStr2")))
            ivImage.setOnClickListener {
                val intent = Intent(context, ShowImageDisplayActivity::class.java)
                GlobalVar.IMGBASE64 = jsonObject.optString("imgStr2")
                context?.startActivity(intent)
            }
        }

    }

    /**
     * 零公里
     * */
    private fun showZeroDetail(jsonObject: JSONObject) {
        val tvZeroMetaNumber = findViewById<TextView>(R.id.tv_zero_meta_name) //物料编号
        tvZeroMetaNumber.text = jsonObject.optString("productCode")

        val tvZeroMetaNumberOnt = findViewById<TextView>(R.id.tv_zero_meta_name_ont) //供应商编号
        tvZeroMetaNumberOnt.text = jsonObject.optString("factoryCode")


        val tvZeroMetaNumberQ = findViewById<TextView>(R.id.tv_zero_meta_name_onq) //责任部门
        tvZeroMetaNumberQ.text = jsonObject.optString("responsibleDepartmentName")


        val tvZeroMetaNumberW = findViewById<TextView>(R.id.tv_zero_meta_name_onw) //物料编号
        tvZeroMetaNumberW.text = jsonObject.optString("faultSolution")


        val tvZeroMetaNumbere = findViewById<TextView>(R.id.tv_zero_meta_name_one) //物料编号
        tvZeroMetaNumbere.text = jsonObject.optString("problemLevel")


        val tvZeroMetaNumberr = findViewById<TextView>(R.id.tv_zero_meta_name_onr) //物料编号
        tvZeroMetaNumberr.text = jsonObject.optString("problemDesc")


        val zeroImage = findViewById<ImageView>(R.id.show_zero_image) //物料编号
        if (!TextUtils.isEmpty(jsonObject.optString("imgStr1"))) {
            zeroImage.setImageBitmap(base64ToBitmap(jsonObject.optString("imgStr1")))
            zeroImage.setOnClickListener {
                val intent = Intent(context, ShowImageDisplayActivity::class.java)
                GlobalVar.IMGBASE64 = jsonObject.optString("imgStr1")
                context?.startActivity(intent)
            }
        }

        if (!TextUtils.isEmpty(jsonObject.optString("imgStr2"))) {
            zeroImage.setImageBitmap(base64ToBitmap(jsonObject.optString("imgStr2")))
            zeroImage.setOnClickListener {
                val intent = Intent(context, ShowImageDisplayActivity::class.java)
                GlobalVar.IMGBASE64 = jsonObject.optString("imgStr2")
                context?.startActivity(intent)
            }
        }


    }

    /**
     * 售后质量
     * */
    @SuppressLint("SetTextI18n")
    private fun showAfterQuality(jsonObject: JSONObject) {
        tvMarkPeople!!.text = GlobalVar.realname

        val text: String = when {
            jsonObject.optString("problemSource").contains("problem_source_04") -> {
                "售后"
            }

            jsonObject.optString("problemSource").contains("problem_source_14") -> {
                "零公里"
            }
            else -> {
                "评审"
            }
        }
        tvSource!!.text = text
        tvErrorCode!!.text = jsonObject.optString("faultCode")
        tvErrorName!!.text = jsonObject.optString("faultName")
        tvErrorLevel!!.text = jsonObject.optString("faultLevel")
        tvErrorType!!.text = jsonObject.optString("faultType")

        if (!TextUtils.isEmpty(jsonObject.optString("imgStr1"))) {
            showimage!!.setImageBitmap(base64ToBitmap(jsonObject.optString("imgStr1")))
            showimage!!.setOnClickListener {
                val intent = Intent(context, ShowImageDisplayActivity::class.java)
                GlobalVar.IMGBASE64 = jsonObject.optString("imgStr1")
                context?.startActivity(intent)
            }
        }
        if (!TextUtils.isEmpty(jsonObject.optString("imgStr2"))) {
            showimage!!.setImageBitmap(base64ToBitmap(jsonObject.optString("imgStr2")))
            showimage!!.setOnClickListener {
                val intent = Intent(context, ShowImageDisplayActivity::class.java)
                GlobalVar.IMGBASE64 = jsonObject.optString("imgStr2")
                context?.startActivity(intent)
            }
        }

        spDept!!.text = jsonObject.optString("responsibleDepartmentName")
        etInfo!!.text = jsonObject.optString("problemDesc")
        stvDate!!.text = jsonObject.optString("happenTime")
        etNumber!!.text = jsonObject.optString("happenNum")
        etHeadDept!!.text = jsonObject.optString("leadDepartment")
        etMarkArea!!.text = jsonObject.optString("visitLocation")
        tvMarkDate!!.text = jsonObject.optString("visitTime")
        etUserServiceDespatch!!.text = "用户/服务站经销商/分公司: ${jsonObject.optString("serviceStation")}"
        etEatAnd!!.text = jsonObject.optString("solutionDesc")
    }

    override fun getResId(): Int {
        return R.layout.activity_after_problem_detail
    }
}