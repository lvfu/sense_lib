package com.zhuisu.fastdev.ui.jieche;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Parcelable;
import android.util.ArrayMap;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;

import com.google.gson.reflect.TypeToken;
import com.zhuisu.fastdev.BaseActivity;
import com.zhuisu.fastdev.beans.registercar.RegisterCarListBean;
import com.zhuisu.fastdev.beans.registercar.RegisterCarLocationListBean;
import com.zhuisu.fastdev.dialog.BasePopupWindowDialog;
import com.zhuisu.fastdev.ui.util.LogUtils;
import com.zhuisu.fastdev.view.SmartTextView;
import com.zhuisu.qualityManagement.R;
import com.zhuisu.suppliermanagement.util.GlobalVar;
import com.zhuisu.suppliermanagement.util.ToastUtils;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 * @author cxh
 * @description
 * @date 2020/10/20.
 */
public class RegisterDetailActivity extends BaseActivity {
    private RegisterCarListBean data;
    public static final String ACTION = "action_data";
    private BasePopupWindowDialog dialog;
    private List<RegisterCarLocationListBean> locationListBeanList;
    private Spinner sp_select;
    private RegisterCarLocationListBean registerCarLocationListBean;

    @Override
    protected void initViews() {
        locationListBeanList = new ArrayList<>();
        sp_select = findViewById(R.id.sp_select);

        findViewById(R.id.btn_register_car).setOnClickListener(v -> {
            dialog.setOnConfirmClickListener(() -> {
                dialog.dismiss();
                if (data != null) {
                    commitData(data);
                }else{
                    ToastUtils.show("暂无数据");
                }
            });
            dialog.show(getSupportFragmentManager(), "");
        });

        if (getIntent() != null && getIntent().hasExtra(ACTION)) {
            this.data = getIntent().getParcelableExtra(ACTION);
            showData();
//            query();
            queryLocation();
        }
    }

    @Override
    protected int getResId() {
        return R.layout.activity_register_details;
    }

//

    private void showData() {
        SmartTextView tv_dingdanhao;//订单号
        SmartTextView tv_suichedanhao;//随车单号
        SmartTextView tv_car_number;//车架号
        SmartTextView tv_car_type;//车型号
        SmartTextView tv_info;//配置
        SmartTextView tv_up_time;//上线时间
        try {

            if (data == null) return;
            tv_dingdanhao = findViewById(R.id.tv_dingdanhao);
            tv_suichedanhao = findViewById(R.id.tv_suichedanhao);
            tv_car_number = findViewById(R.id.tv_car_number);
            tv_car_type = findViewById(R.id.tv_car_type);
            tv_info = findViewById(R.id.tv_info);
            tv_up_time = findViewById(R.id.tv_up_time);

            tv_dingdanhao.setText(data.getQmsManufactureProductionplan().getOrderNo(), TextView.BufferType.NORMAL);
            tv_suichedanhao.setText(data.getFlowCarNo(), TextView.BufferType.NORMAL);
            tv_car_number.setText(data.getCarFarmeNo(), TextView.BufferType.NORMAL);
            tv_car_type.setText(data.getQmsManufactureProductionplan().getCarModelNo(), TextView.BufferType.NORMAL);
            tv_info.setText(data.getQmsManufactureProductionplan().getConfigDesc(), TextView.BufferType.NORMAL);
            tv_up_time.setText(data.getCreateDate(), TextView.BufferType.NORMAL);

            if (data.getConfigChange()) {
                findViewById(R.id.ll_show_config_change).setVisibility(View.VISIBLE);
                findViewById(R.id.ll_show_config_change).setOnClickListener(v -> {
                    Intent intent = new Intent(context, RegisterCarConfigChangeActivity.class);
                    intent.putExtra(RegisterCarConfigChangeActivity.ACTION_DATA, data);
                    startActivity(intent);
                });
            } else {
                findViewById(R.id.ll_show_config_change).setVisibility(View.GONE);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 提交
     */
    private void commitData(RegisterCarListBean data) {
        ArrayMap<String, String> map = new ArrayMap<>();
        map.put("location", registerCarLocationListBean.getValue());
        map.put("carFarmeNo", this.data.getCarFarmeNo());
        map.put("status", "debug");
        map.put("userName", GlobalVar.username);

        String param = gson.toJson(map);
        LogUtils.printDebug(param);
        showCommitDialog();


        OkHttpClient client = new OkHttpClient();
        RequestBody requestBody = RequestBody.create(JSON, param);
        Request request = new Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/offlinedebuggingstatus/qmsOfflineStatus/api/saveOffLineStatus")
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                Log.d(TAG, "onFailure: 失败");
                runOnUiThread(()->{
                    showNetErrorMessage();
                    cancelDialog();
                });
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                final String result = response.body().string();
                Log.d(TAG, "onResponse: 接车" + result);
                runOnUiThread(() -> {
                    try {
                        cancelDialog();
                        JSONObject jsonObject = new JSONObject(result);
                        if (jsonObject.optString("status").equals("0")) {
                            ToastUtils.show(jsonObject.optString("msg"));
                            new Handler().postDelayed(() -> finish(), 2000);
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                });
            }
        });
    }

    /**
     * 获取接车的库位
     */
    private void queryLocation() {
        ArrayMap<String, String> map = new ArrayMap<>();
        map.put("type", "CAR_LOCATION");

        String param = gson.toJson(map);
        OkHttpClient client = new OkHttpClient();
        RequestBody requestBody = RequestBody.create(JSON, param);
        Request request = new Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/common/util/api/getDict")
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                Log.d(TAG, "onFailure: 失败");
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                final String result = response.body().string();
                Log.d(TAG, "onResponse: 接车库位" + result);
                runOnUiThread(() -> {
                    try {
                        JSONObject jsonObject = new JSONObject(result);
                        locationListBeanList.addAll(gson.fromJson(jsonObject.optString("data"), new TypeToken<List<RegisterCarLocationListBean>>() {
                        }.getType()));
                        ArrayAdapter<? extends Parcelable> adapter = new ArrayAdapter<>(context, R.layout.simple_textview1, locationListBeanList);
                        sp_select.setAdapter(adapter);
                        sp_select.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                            @Override
                            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                                registerCarLocationListBean = locationListBeanList.get(position);
                            }

                            @Override
                            public void onNothingSelected(AdapterView<?> parent) {

                            }
                        });
                        dialog = new BasePopupWindowDialog();
                        Bundle bundle = new Bundle();
                        bundle.putString(BasePopupWindowDialog.ACTION_VALUE_TITLE,"确认执行该操作吗");
                        dialog.setArguments(bundle);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                });
            }
        });
    }
}
