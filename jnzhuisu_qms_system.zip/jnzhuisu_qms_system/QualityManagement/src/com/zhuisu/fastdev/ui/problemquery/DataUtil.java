package com.zhuisu.fastdev.ui.problemquery;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class DataUtil {
    public static String getVoiceFileName() {
        long getNowTimeLong = System.currentTimeMillis();
        SimpleDateFormat time = new SimpleDateFormat("yyyy-MM-dd");
        String result = time.format(getNowTimeLong);
        return result;
    }



    public static String getDatajian7() {
        Date currentTime =  null;
        Date edate = new Date();
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        Calendar rightNow = Calendar.getInstance();
        rightNow.setTime(edate);
        rightNow.add(Calendar.DAY_OF_YEAR, -7);// 日期加1天
        String dateString = formatter.format(rightNow.getTime());
        /*try {
            currentTime = formatter.parse(dateString);
        } catch (ParseException e) {
            e.printStackTrace();
        }*/
        return dateString;
    }

    public static String getDatajia1() {
        Date currentTime =  null;
        Date edate = new Date();
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        Calendar rightNow = Calendar.getInstance();
        rightNow.setTime(edate);
        rightNow.add(Calendar.DAY_OF_YEAR, +1);// 日期加1天
        String dateString = formatter.format(rightNow.getTime());
        /*try {
            currentTime = formatter.parse(dateString);
        } catch (ParseException e) {
            e.printStackTrace();
        }*/
        return dateString;
    }
}
