package com.zhuisu.fastdev.ui.qualityaskquery;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.List;

/**
 * @author cxh
 * @description
 * @date 2021/3/1.
 */

public class AfterQualityProblemListBean implements Parcelable {

    /**
     * retCode : 0
     * data : {"pageNo":1,"pageSize":100,"count":5,"list":[{"id":"04d8d5f9a12247289a5975b4827b6cd9","isNewRecord":false,"createDate":"2021-02-25 16:17:53","updateDate":"2021-02-25 16:17:53","happenTime":"2021-02-25 16:17:53","happenNum":"1","productCode":"LJ177350","productNames":"ZZ4255V3846F1L/U9VDM38-标运","problemLevel":"B","problemDesc":"edd","solutionDesc":"","responsibleDepartment":"NC0450400","filePath1":"","fileName1":"","procInsId":"","faultReason":"","faultSolution":"","remark":"","problemSource":"problem_source_11_04","createUserStr":"系统管理员","faultCode":"ZDABS01B","faultName":"ABS阀错漏装","faultType":"错漏装"},{"id":"565b5c7c0a6146928638bedc193304c7","isNewRecord":false,"createDate":"2021-03-01 13:43:34","updateDate":"2021-03-01 13:43:34","happenTime":"2021-03-01 00:00:00","happenNum":"12","productCode":"","productNames":"","problemLevel":"B","problemDesc":"测试","solutionDesc":"测试","responsibleDepartment":"2","filePath1":"","fileName1":"","procInsId":"","faultReason":"","faultSolution":"","remark":"","problemSource":"problem_source_04_01","createUserStr":"系统管理员","faultCode":"ZDABS01B","faultName":"ABS阀错漏装","faultType":"错漏装"},{"id":"6286f87d52fc49a1bec4ca9a5ba2dbc8","isNewRecord":false,"createDate":"2021-02-26 14:14:16","updateDate":"2021-02-26 14:14:16","happenTime":"2021-02-26 00:00:00","happenNum":"","productCode":"020V47104-0024/1","productNames":"同步件（南京ZF）","problemLevel":"E","problemDesc":"dfff","solutionDesc":"","responsibleDepartment":"NC0350300","filePath1":"","fileName1":"","procInsId":"","faultReason":"","faultSolution":"fdd","remark":"","problemSource":"problem_source_14_01","createUserStr":"系统管理员","faultCode":"零公里质量","faultName":"零公里质量","faultType":"零公里质量"},{"id":"91fecf8b662b410aac3423a1c0a1c037","isNewRecord":false,"createDate":"2021-03-01 14:36:18","updateDate":"2021-03-01 14:36:18","happenTime":"2021-03-01 00:00:00","happenNum":"1","productCode":"","productNames":"","problemLevel":"D","problemDesc":"q","solutionDesc":"q","responsibleDepartment":"NC0550500","filePath1":"","fileName1":"","procInsId":"","faultReason":"","faultSolution":"","remark":"","problemSource":"problem_source_04_01","createUserStr":"系统管理员","faultCode":"ZDABX34D","faultName":"ABS线束管线干涉","faultType":"管线干涉"},{"id":"a35a11917caf4b5982959d5f3527889a","isNewRecord":false,"createDate":"2020-12-23 10:31:51","updateDate":"2020-12-23 10:31:58","happenTime":"2020-12-23 00:00:00","happenNum":"2","productCode":"","productNames":"","problemLevel":"D","problemDesc":"","solutionDesc":"","responsibleDepartment":"NC.06.50600","filePath1":"","fileName1":"","procInsId":"","faultReason":"","faultSolution":"","remark":"","problemSource":"problem_source_04_01","createUserStr":"系统管理员","faultCode":"LQPZX36D","faultName":"膨胀水箱及管路捆扎过紧","faultType":"捆扎过紧"}],"maxResults":100,"firstResult":0}
     * pageNo : 1
     * pageSize : 100
     * count : 5
     * list : [{"id":"04d8d5f9a12247289a5975b4827b6cd9","isNewRecord":false,"createDate":"2021-02-25 16:17:53","updateDate":"2021-02-25 16:17:53","happenTime":"2021-02-25 16:17:53","happenNum":"1","productCode":"LJ177350","productNames":"ZZ4255V3846F1L/U9VDM38-标运","problemLevel":"B","problemDesc":"edd","solutionDesc":"","responsibleDepartment":"NC0450400","filePath1":"","fileName1":"","procInsId":"","faultReason":"","faultSolution":"","remark":"","problemSource":"problem_source_11_04","createUserStr":"系统管理员","faultCode":"ZDABS01B","faultName":"ABS阀错漏装","faultType":"错漏装"},{"id":"565b5c7c0a6146928638bedc193304c7","isNewRecord":false,"createDate":"2021-03-01 13:43:34","updateDate":"2021-03-01 13:43:34","happenTime":"2021-03-01 00:00:00","happenNum":"12","productCode":"","productNames":"","problemLevel":"B","problemDesc":"测试","solutionDesc":"测试","responsibleDepartment":"2","filePath1":"","fileName1":"","procInsId":"","faultReason":"","faultSolution":"","remark":"","problemSource":"problem_source_04_01","createUserStr":"系统管理员","faultCode":"ZDABS01B","faultName":"ABS阀错漏装","faultType":"错漏装"},{"id":"6286f87d52fc49a1bec4ca9a5ba2dbc8","isNewRecord":false,"createDate":"2021-02-26 14:14:16","updateDate":"2021-02-26 14:14:16","happenTime":"2021-02-26 00:00:00","happenNum":"","productCode":"020V47104-0024/1","productNames":"同步件（南京ZF）","problemLevel":"E","problemDesc":"dfff","solutionDesc":"","responsibleDepartment":"NC0350300","filePath1":"","fileName1":"","procInsId":"","faultReason":"","faultSolution":"fdd","remark":"","problemSource":"problem_source_14_01","createUserStr":"系统管理员","faultCode":"零公里质量","faultName":"零公里质量","faultType":"零公里质量"},{"id":"91fecf8b662b410aac3423a1c0a1c037","isNewRecord":false,"createDate":"2021-03-01 14:36:18","updateDate":"2021-03-01 14:36:18","happenTime":"2021-03-01 00:00:00","happenNum":"1","productCode":"","productNames":"","problemLevel":"D","problemDesc":"q","solutionDesc":"q","responsibleDepartment":"NC0550500","filePath1":"","fileName1":"","procInsId":"","faultReason":"","faultSolution":"","remark":"","problemSource":"problem_source_04_01","createUserStr":"系统管理员","faultCode":"ZDABX34D","faultName":"ABS线束管线干涉","faultType":"管线干涉"},{"id":"a35a11917caf4b5982959d5f3527889a","isNewRecord":false,"createDate":"2020-12-23 10:31:51","updateDate":"2020-12-23 10:31:58","happenTime":"2020-12-23 00:00:00","happenNum":"2","productCode":"","productNames":"","problemLevel":"D","problemDesc":"","solutionDesc":"","responsibleDepartment":"NC.06.50600","filePath1":"","fileName1":"","procInsId":"","faultReason":"","faultSolution":"","remark":"","problemSource":"problem_source_04_01","createUserStr":"系统管理员","faultCode":"LQPZX36D","faultName":"膨胀水箱及管路捆扎过紧","faultType":"捆扎过紧"}]
     * maxResults : 100
     * firstResult : 0
     */

    /**
     * id : 04d8d5f9a12247289a5975b4827b6cd9
     * isNewRecord : false
     * createDate : 2021-02-25 16:17:53
     * updateDate : 2021-02-25 16:17:53
     * happenTime : 2021-02-25 16:17:53
     * happenNum : 1
     * productCode : LJ177350
     * productNames : ZZ4255V3846F1L/U9VDM38-标运
     * problemLevel : B
     * problemDesc : edd
     * solutionDesc :
     * responsibleDepartment : NC0450400
     * filePath1 :
     * fileName1 :
     * procInsId :
     * faultReason :
     * faultSolution :
     * remark :
     * problemSource : problem_source_11_04
     * createUserStr : 系统管理员
     * faultCode : ZDABS01B
     * faultName : ABS阀错漏装
     * faultType : 错漏装
     */

    private String id;
    private Boolean isNewRecord;
    private String createDate;
    private String updateDate;
    private String happenTime;
    private String happenNum;
    private String productCode;
    private String productNames;
    private String problemLevel;
    private String problemDesc;
    private String solutionDesc;
    private String responsibleDepartment;
    private String filePath1;
    private String fileName1;
    private String procInsId;
    private String faultReason;
    private String faultSolution;
    private String remark;
    private String problemSource;
    private String createUserStr;
    private String faultCode;
    private String faultName;
    private String faultType;


    protected AfterQualityProblemListBean(Parcel in) {
        id = in.readString();
        byte tmpIsNewRecord = in.readByte();
        isNewRecord = tmpIsNewRecord == 0 ? null : tmpIsNewRecord == 1;
        createDate = in.readString();
        updateDate = in.readString();
        happenTime = in.readString();
        happenNum = in.readString();
        productCode = in.readString();
        productNames = in.readString();
        problemLevel = in.readString();
        problemDesc = in.readString();
        solutionDesc = in.readString();
        responsibleDepartment = in.readString();
        filePath1 = in.readString();
        fileName1 = in.readString();
        procInsId = in.readString();
        faultReason = in.readString();
        faultSolution = in.readString();
        remark = in.readString();
        problemSource = in.readString();
        createUserStr = in.readString();
        faultCode = in.readString();
        faultName = in.readString();
        faultType = in.readString();
    }

    public static final Creator<AfterQualityProblemListBean> CREATOR = new Creator<AfterQualityProblemListBean>() {
        @Override
        public AfterQualityProblemListBean createFromParcel(Parcel in) {
            return new AfterQualityProblemListBean(in);
        }

        @Override
        public AfterQualityProblemListBean[] newArray(int size) {
            return new AfterQualityProblemListBean[size];
        }
    };

    public void setId(String id) {
        this.id = id;
    }

    public void setNewRecord(Boolean newRecord) {
        isNewRecord = newRecord;
    }

    public void setCreateDate(String createDate) {
        this.createDate = createDate;
    }

    public void setUpdateDate(String updateDate) {
        this.updateDate = updateDate;
    }

    public void setHappenTime(String happenTime) {
        this.happenTime = happenTime;
    }

    public void setHappenNum(String happenNum) {
        this.happenNum = happenNum;
    }

    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    public void setProductNames(String productNames) {
        this.productNames = productNames;
    }

    public void setProblemLevel(String problemLevel) {
        this.problemLevel = problemLevel;
    }

    public void setProblemDesc(String problemDesc) {
        this.problemDesc = problemDesc;
    }

    public void setSolutionDesc(String solutionDesc) {
        this.solutionDesc = solutionDesc;
    }

    public void setResponsibleDepartment(String responsibleDepartment) {
        this.responsibleDepartment = responsibleDepartment;
    }

    public void setFilePath1(String filePath1) {
        this.filePath1 = filePath1;
    }

    public void setFileName1(String fileName1) {
        this.fileName1 = fileName1;
    }

    public void setProcInsId(String procInsId) {
        this.procInsId = procInsId;
    }

    public void setFaultReason(String faultReason) {
        this.faultReason = faultReason;
    }

    public void setFaultSolution(String faultSolution) {
        this.faultSolution = faultSolution;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public void setProblemSource(String problemSource) {
        this.problemSource = problemSource;
    }

    public void setCreateUserStr(String createUserStr) {
        this.createUserStr = createUserStr;
    }

    public void setFaultCode(String faultCode) {
        this.faultCode = faultCode;
    }

    public void setFaultName(String faultName) {
        this.faultName = faultName;
    }

    public void setFaultType(String faultType) {
        this.faultType = faultType;
    }

    public String getId() {
        return id;
    }

    public Boolean getNewRecord() {
        return isNewRecord;
    }

    public String getCreateDate() {
        return createDate;
    }

    public String getUpdateDate() {
        return updateDate;
    }

    public String getHappenTime() {
        return happenTime;
    }

    public String getHappenNum() {
        return happenNum;
    }

    public String getProductCode() {
        return productCode;
    }

    public String getProductNames() {
        return productNames;
    }

    public String getProblemLevel() {
        return problemLevel;
    }

    public String getProblemDesc() {
        return problemDesc;
    }

    public String getSolutionDesc() {
        return solutionDesc;
    }

    public String getResponsibleDepartment() {
        return responsibleDepartment;
    }

    public String getFilePath1() {
        return filePath1;
    }

    public String getFileName1() {
        return fileName1;
    }

    public String getProcInsId() {
        return procInsId;
    }

    public String getFaultReason() {
        return faultReason;
    }

    public String getFaultSolution() {
        return faultSolution;
    }

    public String getRemark() {
        return remark;
    }

    public String getProblemSource() {
        return problemSource;
    }

    public String getCreateUserStr() {
        return createUserStr;
    }

    public String getFaultCode() {
        return faultCode;
    }

    public String getFaultName() {
        return faultName;
    }

    public String getFaultType() {
        return faultType;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(id);
        dest.writeByte((byte) (isNewRecord == null ? 0 : isNewRecord ? 1 : 2));
        dest.writeString(createDate);
        dest.writeString(updateDate);
        dest.writeString(happenTime);
        dest.writeString(happenNum);
        dest.writeString(productCode);
        dest.writeString(productNames);
        dest.writeString(problemLevel);
        dest.writeString(problemDesc);
        dest.writeString(solutionDesc);
        dest.writeString(responsibleDepartment);
        dest.writeString(filePath1);
        dest.writeString(fileName1);
        dest.writeString(procInsId);
        dest.writeString(faultReason);
        dest.writeString(faultSolution);
        dest.writeString(remark);
        dest.writeString(problemSource);
        dest.writeString(createUserStr);
        dest.writeString(faultCode);
        dest.writeString(faultName);
        dest.writeString(faultType);
    }
}
