package com.zhuisu.fastdev.ui.recheckconfirm

import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.text.TextUtils
import android.util.ArrayMap
import android.util.Log

import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import com.google.gson.reflect.TypeToken
import com.zhuisu.fastdev.BaseActivity
import com.zhuisu.fastdev.adapter.recheckcar.ReCheckConfirmListAdapter
import com.zhuisu.fastdev.beans.registercar.ReCheckCarList
import com.zhuisu.fastdev.beans.registercar.RegisterCarDetails
import com.zhuisu.fastdev.dialog.BasePopupWindowDialog
import com.zhuisu.qualityManagement.R
import com.zhuisu.suppliermanagement.util.GlobalVar
import com.zhuisu.suppliermanagement.util.ToastUtils
import okhttp3.*
import org.json.JSONException
import org.json.JSONObject
import java.io.IOException


/**
 * @author cxh
 * @description
 * @date 2020/11/11.
 */
class RecheckConfirmActivity : BaseActivity(), ReCheckConfirmListAdapter.OnClickListener {

    var adapter: ReCheckConfirmListAdapter? = null
    private var currentData: RegisterCarDetails? = null
    private var list: ArrayList<ReCheckCarList>? = null
    private var isAllSuccess = false

    companion object {
        const val ACTION_DATA = "action_data"
    }

    override fun initViews() {
        list = ArrayList()
        adapter = ReCheckConfirmListAdapter(list!!, context)

        //批量提交
        findViewById<Button>(R.id.btn_success).setOnClickListener {
            if (list != null && list!!.isNotEmpty()) {
                val dialog = BasePopupWindowDialog()
                val argument = Bundle()
                argument.putString(BasePopupWindowDialog.ACTION_VALUE_TITLE, "是否确认全部合格?")
                argument.putString(BasePopupWindowDialog.ACTION_VALUE_MESSAGE, "是否确认全部合格并进入复验完成状态?")
                dialog.arguments = argument
                dialog.setOnConfirmClickListener {
                    var ids = ""
                    for (value in list!!) {
                        ids += value.id + ","
                    }
                    ids = ids.substring(0, ids.length - 1)
                    dialog.dismiss()
                    isAllSuccess = true
                    commitData(ids, "1", "") //提交数据
                }
                dialog.show(supportFragmentManager, "")
            } else {
                val dialog = BasePopupWindowDialog()
                val argument = Bundle()
                argument.putString(BasePopupWindowDialog.ACTION_VALUE_TITLE, "提示")
                argument.putString(BasePopupWindowDialog.ACTION_VALUE_MESSAGE, "是否执行该操作?")
                dialog.arguments = argument
                dialog.setOnConfirmClickListener {
                    dialog.dismiss()
                    updateStatus()
                }
                dialog.show(supportFragmentManager, "")

            }
        }


        val rvRecheck: RecyclerView = findViewById(R.id.rv_recheck)
        val manager = LinearLayoutManager(this)
        manager.orientation = LinearLayoutManager.VERTICAL
        rvRecheck.layoutManager = manager
        rvRecheck.adapter = adapter
        adapter!!.onClicklistener = this

        val tvRandom: TextView = findViewById(R.id.tv_suichedan)
        val tvCarNumber: TextView = findViewById(R.id.tv_car_number) //车架号
        val tvReCheckUser: TextView = findViewById(R.id.tv_recheck_user)
        val tvRecheckDate: TextView = findViewById(R.id.tv_recheck_date)

        if (intent != null && intent.getParcelableExtra<RegisterCarDetails>(ACTION_DATA) != null) {
            currentData = intent.getParcelableExtra(ACTION_DATA)
            tvCarNumber.text = currentData?.carFarmeNo
            tvRandom.text = currentData?.flowCarNo
            tvReCheckUser.text = if (currentData?.recheckUser == null) "" else currentData?.recheckUser
            tvRecheckDate.text = if (currentData?.recheckDate == null) "" else currentData?.recheckDate
        }

        //整车退回
        findViewById<Button>(R.id.btn_car_return).setOnClickListener {
            val dialog = BasePopupWindowDialog()
            val argument = Bundle()
            argument.putString(BasePopupWindowDialog.ACTION_VALUE_TITLE, "提示?")
            argument.putString(BasePopupWindowDialog.ACTION_VALUE_MESSAGE, "由复验状态退回初验完成状态?")
            dialog.arguments = argument
            dialog.setOnConfirmClickListener {
                dialog.dismiss()
                commitReturn() //提交数据
            }

            dialog.show(supportFragmentManager, "")
        }

        queryList()
    }


    //整车退回
    private fun commitReturn() {
        val map = ArrayMap<String, String>()
        map["carFarmeNo"] = currentData?.carFarmeNo
        map["status"] = "submitcheckpassed"
        map["userName"] = GlobalVar.username
        map["location"] = currentData?.location
        val param = gson.toJson(map)

        Log.e("--->提交数据", param)
        val client = OkHttpClient()
        val requestBody = RequestBody.create(JSON, param)
        val request = Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/offlinedebuggingstatus/qmsOfflineStatus/api/updateToSubmitCheckPassed")
                .build()
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.d(TAG, "onFailure: 失败")
            }

            @Throws(IOException::class)
            override fun onResponse(call: Call, response: Response) {
                val result = response.body()!!.string()
                Log.d(TAG, "onResponse: 整车退回$result ----  ----- ----$isAllSuccess")
                runOnUiThread {
                    try {
                        val jsonObject = JSONObject(result)
                        if (TextUtils.equals(jsonObject.optString("status"), "0")) {
                            ToastUtils.show("成功")
                            finish()
                        } else {
                            ToastUtils.show(jsonObject.optString("msg"))
                        }
                    } catch (e: JSONException) {
                        e.printStackTrace()
                    }
                }
            }
        })
    }

    override fun getResId(): Int {
        return R.layout.activity_recheck_confirm
    }

    /**
     * 获取问题列表
     */
    private fun queryList() {
//        if (list != null){
//            list!!.clear()
//            if (adapter != null){
//                adapter!!.notifyDataSetChanged()
//            }
//        }
        val map = ArrayMap<String, Any>()
        map["problemSource"] = ""
        map["problemLevel"] = ""
        map["beginOccurTime"] = ""
        map["endOccurTime"] = ""
        map["peoblemTitle"] = ""
        map["feedbackUser"] = ""
        map["carFrameNo"] = currentData!!.carFarmeNo
        map["pageNo"] = 1
        map["pageSize"] = 100
        map["offLineStatus"] = "submitcheck"
        map["operType"] = "recheckPassForm"


        val param = gson.toJson(map)
        Log.e("--->", param)
        val client = OkHttpClient()
        val requestBody = RequestBody.create(JSON, param)
        val request = Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/checkfaildflow/qmsManufactureProblemflow/api/notCloseProblemPage")
                .build()
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.d(TAG, "onFailure: 失败")
            }

            @Throws(IOException::class)
            override fun onResponse(call: Call, response: Response) {
                val result = response.body()!!.string()
                Log.d(TAG, "onResponse: 复验问题列表$result")
                runOnUiThread {
                    try {
                        val jsonObject = JSONObject(result)
                        if (TextUtils.equals(jsonObject.optString("retCode"), "0") && jsonObject.optJSONObject("data").optString("list") != null && !TextUtils.isEmpty(jsonObject.optJSONObject("data")
                                        .optString("list"))) {
                            list!!.addAll(gson.fromJson(jsonObject.optJSONObject("data").optString("list"), object : TypeToken<ArrayList<ReCheckCarList>>() {}.type))
                            adapter!!.notifyDataSetChanged()
                        }
                    } catch (e: JSONException) {
                        e.printStackTrace()
                    }
                }
            }
        })
    }


    /**
     * 提交
     */
    private fun commitData(ids: String, recheckOperator: String, remark: String) {

        val map = ArrayMap<String, String>()
        map["ids"] = ids
        map["recheckOperator"] = recheckOperator
        if (TextUtils.equals("0", recheckOperator)) {
            map["closeRemark"] = remark
        }
        val param = gson.toJson(map)
        Log.e("--->提交数据", param)
        val client = OkHttpClient()
        val requestBody = RequestBody.create(JSON, param)
        val request = Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/offlineproblem/qmsManufactureOffLineProblem/api/batchRecheckOperator")
                .build()
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.d(TAG, "onFailure: 失败")
            }

            @Throws(IOException::class)
            override fun onResponse(call: Call, response: Response) {
                val result = response.body()!!.string()
                Log.d(TAG, "onResponse: 保存状态$result ----  ----- ----$isAllSuccess")
                runOnUiThread {
                    try {
                        val jsonObject = JSONObject(result)
                        if (TextUtils.equals(jsonObject.optString("retCode"), "0")) {
                            ToastUtils.show("成功")
                            if (isAllSuccess) {
                                updateStatus()
                            }
                        } else {
                            ToastUtils.show(jsonObject.optString("retMessage"))
                        }
                    } catch (e: JSONException) {
                        e.printStackTrace()
                    }
                }
            }
        })
    }


    /**
     * 提交
     */
    private fun updateStatus() {

        val map = ArrayMap<String, String>()
        map["carFarmeNo"] = currentData!!.carFarmeNo
        map["status"] = "warehousingin"
        map["userName"] = GlobalVar.username
        map["location"] = currentData?.location

        val param = gson.toJson(map)
        Log.e("--->提交数据", param)
        val client = OkHttpClient()
        val requestBody = RequestBody.create(JSON, param)
        val request = Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/offlinedebuggingstatus/qmsOfflineStatus/api/updateOffLineStatus")
                .build()
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.d(TAG, "onFailure: 失败")
            }

            @Throws(IOException::class)
            override fun onResponse(call: Call, response: Response) {
                val result = response.body()!!.string()
                Log.d(TAG, "onResponse: 更新状态$result ----  ----- ----$isAllSuccess")
                runOnUiThread {
                    try {
                        val jsonObject = JSONObject(result)
                        if (TextUtils.equals(jsonObject.optString("status"), "0")) {
                            ToastUtils.show("成功")
//                            if (isAllSuccess) {
                                val intent = Intent()
                                setResult(0x61, intent)
                                finish()
//                            }
                        } else {
                            ToastUtils.show(jsonObject.optString("msg"))
                        }
                    } catch (e: JSONException) {
                        e.printStackTrace()
                    }
                }
            }
        })
    }

    //合格 1
    override fun onSuccessClick(position: Int) {
        isAllSuccess = false
        commitData(list!![position].id, "1", "")
    }

    //不合格 0
    override fun onFailureClick(position: Int) {
        isAllSuccess = false
        val inputServer = EditText(this)
        inputServer.isFocusable = true
        inputServer.hint = "请输入备注"
        inputServer.textSize = 20f

        val builder: AlertDialog.Builder = AlertDialog.Builder(this, R.style.MyAlertDialogStyle)
        builder.setTitle("提示").setView(inputServer).setNegativeButton("取消", null)
        builder.setPositiveButton("确定"
        ) { _, _ ->
            val inputText = inputServer.text.toString()
            commitData(list!![position].id, "0", inputText)
        }

        builder.show()

    }

}