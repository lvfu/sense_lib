package com.zhuisu.fastdev.ui.worktime;

/**
 * @author cxh
 * @description
 * @date 2021/3/13.
 */

public class WorkTimeDetailBean {


    /**
     * retCode : 0
     * data : {"id":"833c08dd2fc84041aa7a0c3dd7910831","isNewRecord":false,"createDate":"2021-03-12 16:42:38","updateDate":"2021-03-12 16:42:38","carFrameNo":"LJ192540","orderNo":"ASSJ20120040","replaceDate":"2021-03-12 00:00:00","location":"嘻嘻看","team":"NC065060001","joinUser":"5c1bad4dddcd4205b37b55ba0f4fdd71","produceName":"管夹(济南车轮厂)","productNo":"138091360181/1      ","reason":"行咯打","responseDepartment":"JC.23.62300         |中国重汽集团济南商用车有限公司（车轮厂）","num":"12","replaceType":"1","accessoriesConsume":"弟弟","accessoriesConsumeFee":"对的","procStatus":"","workShop":"NC.10.51000","remark":"三日内未回复仲裁申请，将按以上考核金额从货款中扣除。"}
     */


    /**
     * id : 833c08dd2fc84041aa7a0c3dd7910831
     * isNewRecord : false
     * createDate : 2021-03-12 16:42:38
     * updateDate : 2021-03-12 16:42:38
     * carFrameNo : LJ192540
     * orderNo : ASSJ20120040
     * replaceDate : 2021-03-12 00:00:00
     * location : 嘻嘻看
     * team : NC065060001
     * joinUser : 5c1bad4dddcd4205b37b55ba0f4fdd71
     * produceName : 管夹(济南车轮厂)
     * productNo : 138091360181/1
     * reason : 行咯打
     * responseDepartment : JC.23.62300         |中国重汽集团济南商用车有限公司（车轮厂）
     * num : 12
     * replaceType : 1
     * accessoriesConsume : 弟弟
     * accessoriesConsumeFee : 对的
     * procStatus :
     * workShop : NC.10.51000
     * remark : 三日内未回复仲裁申请，将按以上考核金额从货款中扣除。
     */

    private String id;
    private Boolean isNewRecord;
    private String createDate;
    private String updateDate;
    private String carFrameNo;
    private String orderNo;
    private String flowCarNo;
    private String replaceDate;
    private String location;
    private String team;
    private String joinUser;
    private String joinUserNames;
    private String produceName;
    private String productNo;
    private String reason;
    private String responseDepartment;
    private String teamNames;

    private String num;
    private String replaceType;
    private String replaceTypeName;
    private String accessoriesConsume;
    private String accessoriesConsumeFee;
    private String procStatus;
    private String workShop;
    private String workShopName;
    private String remark;
    private String isStartProcess;
    private String imgStr;
    private String faultBarcode;

    private String newBarcode;
    private String newProductNo;
    private String newProductName;
    private String newResponseDepartment;

    public void setFaultBarcode(String faultBarcode) {
        this.faultBarcode = faultBarcode;
    }

    public void setNewBarcode(String newBarcode) {
        this.newBarcode = newBarcode;
    }

    public void setNewProductNo(String newProductNo) {
        this.newProductNo = newProductNo;
    }

    public void setNewProductName(String newProductName) {
        this.newProductName = newProductName;
    }

    public void setNewResponseDepartment(String newResponseDepartment) {
        this.newResponseDepartment = newResponseDepartment;
    }

    public String getFaultBarcode() {
        return faultBarcode;
    }

    public String getNewBarcode() {
        return newBarcode;
    }

    public String getNewProductNo() {
        return newProductNo;
    }

    public String getNewProductName() {
        return newProductName;
    }

    public String getNewResponseDepartment() {
        return newResponseDepartment;
    }

    public void setWorkShopName(String workShopName) {
        this.workShopName = workShopName;
    }

    public String getWorkShopName() {
        return workShopName;
    }

    public void setJoinUserNames(String joinUserNames) {
        this.joinUserNames = joinUserNames;
    }

    public String getJoinUserNames() {
        return joinUserNames;
    }

    public void setTeamNames(String teamNames) {
        this.teamNames = teamNames;
    }

    public String getTeamNames() {
        return teamNames;
    }

    public void setReplaceTypeName(String replaceTypeName) {
        this.replaceTypeName = replaceTypeName;
    }

    public String getReplaceTypeName() {
        return replaceTypeName;
    }

    public void setFlowCarNo(String flowCarNo) {
        this.flowCarNo = flowCarNo;
    }

    public String getFlowCarNo() {
        return flowCarNo;
    }

    public void setImgStr(String imgStr) {
        this.imgStr = imgStr;
    }

    public String getImgStr() {
        return imgStr;
    }

    public void setIsStartProcess(String isStartProcess) {
        this.isStartProcess = isStartProcess;
    }

    public String getIsStartProcess() {
        return isStartProcess;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setNewRecord(Boolean newRecord) {
        isNewRecord = newRecord;
    }

    public void setCreateDate(String createDate) {
        this.createDate = createDate;
    }

    public void setUpdateDate(String updateDate) {
        this.updateDate = updateDate;
    }

    public void setCarFrameNo(String carFrameNo) {
        this.carFrameNo = carFrameNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    public void setReplaceDate(String replaceDate) {
        this.replaceDate = replaceDate;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public void setTeam(String team) {
        this.team = team;
    }

    public void setJoinUser(String joinUser) {
        this.joinUser = joinUser;
    }

    public void setProduceName(String produceName) {
        this.produceName = produceName;
    }

    public void setProductNo(String productNo) {
        this.productNo = productNo;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public void setResponseDepartment(String responseDepartment) {
        this.responseDepartment = responseDepartment;
    }

    public void setNum(String num) {
        this.num = num;
    }

    public void setReplaceType(String replaceType) {
        this.replaceType = replaceType;
    }

    public void setAccessoriesConsume(String accessoriesConsume) {
        this.accessoriesConsume = accessoriesConsume;
    }

    public void setAccessoriesConsumeFee(String accessoriesConsumeFee) {
        this.accessoriesConsumeFee = accessoriesConsumeFee;
    }

    public void setProcStatus(String procStatus) {
        this.procStatus = procStatus;
    }

    public void setWorkShop(String workShop) {
        this.workShop = workShop;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getId() {
        return id;
    }

    public Boolean getNewRecord() {
        return isNewRecord;
    }

    public String getCreateDate() {
        return createDate;
    }

    public String getUpdateDate() {
        return updateDate;
    }

    public String getCarFrameNo() {
        return carFrameNo;
    }

    public String getOrderNo() {
        return orderNo;
    }

    public String getReplaceDate() {
        return replaceDate;
    }

    public String getLocation() {
        return location;
    }

    public String getTeam() {
        return team;
    }

    public String getJoinUser() {
        return joinUser;
    }

    public String getProduceName() {
        return produceName;
    }

    public String getProductNo() {
        return productNo;
    }

    public String getReason() {
        return reason;
    }

    public String getResponseDepartment() {
        return responseDepartment;
    }

    public String getNum() {
        return num;
    }

    public String getReplaceType() {
        return replaceType;
    }

    public String getAccessoriesConsume() {
        return accessoriesConsume;
    }

    public String getAccessoriesConsumeFee() {
        return accessoriesConsumeFee;
    }

    public String getProcStatus() {
        return procStatus;
    }

    public String getWorkShop() {
        return workShop;
    }

    public String getRemark() {
        return remark;
    }
}
