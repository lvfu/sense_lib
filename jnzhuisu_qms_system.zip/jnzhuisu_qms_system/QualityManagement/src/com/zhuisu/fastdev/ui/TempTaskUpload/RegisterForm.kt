package com.zhuisu.fastdev.ui.TempTaskUpload

/**
 * @author cxh
 * @description
 * @date 2021/2/4.
 */
data class RegisterForm(var code : String?,var reason : String?,var remark: String?) {
    override fun toString(): String {
        return reason!!
    }
}