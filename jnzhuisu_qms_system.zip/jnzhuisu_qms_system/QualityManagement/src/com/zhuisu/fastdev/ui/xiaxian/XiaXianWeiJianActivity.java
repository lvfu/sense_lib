package com.zhuisu.fastdev.ui.xiaxian;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.ArrayMap;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.zhuisu.fastdev.BaseActivity;
import com.zhuisu.fastdev.adapter.xiaxian.XiaXianWeiJianFirAdapter;
import com.zhuisu.fastdev.beans.xiaxian.XiaXianWeiJianFirstBean;
import com.zhuisu.fastdev.dialog.BasePopupWindowDialog;
import com.zhuisu.fastdev.ui.util.BroadCastConfig;
import com.zhuisu.fastdev.view.FastTitleLayout;
import com.zhuisu.qualityManagement.R;
import com.zhuisu.suppliermanagement.base.CaptureActivity;
import com.zhuisu.suppliermanagement.util.GlobalVar;
import com.zhuisu.suppliermanagement.util.ToastUtils;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;


/**
 * 下线未检
 */
public class XiaXianWeiJianActivity extends BaseActivity {

    private EditText et_barcode;
    private List<XiaXianWeiJianFirstBean> list;
    private ListView listview;
    private boolean isFinished = false;
    private boolean isFirst = true;
    private XiaXianWeiJianFirAdapter adapter;


    BroadCastChange broadCast = new BroadCastChange();
    IntentFilter filter = new IntentFilter(BroadCastConfig.BROADCAST_ACTION);

    class BroadCastChange extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent != null && intent.getAction() != null && intent.getAction().equals(BroadCastConfig.BROADCAST_ACTION)) {
                et_barcode.setText(intent.getExtras().getString(BroadCastConfig.BROADCAST_ACTION_TAG));
                et_barcode.setSelection(et_barcode.getText().toString().length());
                queryData();
            }
        }
    }


    @SuppressLint("SetTextI18n")
    @Override
    protected void initViews() {


        et_barcode = findViewById(R.id.et_barcode);
        listview = findViewById(R.id.listview);
        findViewById(R.id.btn_ok).setOnClickListener(v -> queryData());
        if (getIntent() != null && getIntent().hasExtra("url")) {
            isFinished = getIntent().getStringExtra("url").equals("下线作业已检");
            FastTitleLayout fastTitleLayout = findViewById(R.id.fast);
            fastTitleLayout.setTitle(getIntent().getStringExtra("url"));
        }

        Log.d("ZhuangPeiWeiJian", isFinished + "");

        TextView tv_user_name = findViewById(R.id.tv_user_name);
        tv_user_name.setText("\t" + GlobalVar.realname);

        findViewById(R.id.tv_scanf).setOnClickListener(arg0 -> {
            Intent intent = new Intent();
            intent.setClass(context, CaptureActivity.class);
            startActivityForResult(intent, 1073);
        });


        if (isFinished) {
            findViewById(R.id.btn_all_success).setVisibility(View.GONE);
        } else {
            findViewById(R.id.btn_all_success).setOnClickListener(v -> {
                if (list == null || list.isEmpty()) {
                    ToastUtils.show("暂无数据");
                    return;
                }

                BasePopupWindowDialog dialog = new BasePopupWindowDialog();
                Bundle bundle = new Bundle();
                bundle.putString(BasePopupWindowDialog.ACTION_VALUE_TITLE, "确定要执行该操作吗?");
                dialog.setArguments(bundle);
                dialog.show(getSupportFragmentManager(), "");
                dialog.setOnConfirmClickListener(() -> {
                    dialog.dismiss();
                    for (int i = 0; i < list.size(); i++) {
                        checkSuccess(list.get(i).getId(), true, i);
                    }
                });
            });
        }

        filter.setPriority(Integer.MAX_VALUE);
        registerReceiver(broadCast, filter);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        unregisterReceiver(broadCast);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1073 && resultCode == Activity.RESULT_OK) {
            et_barcode.setText(data.getStringExtra("encoderesult"));
            queryData();
        }
    }


    @Override
    protected int getResId() {
        return R.layout.activity_xia_xian_wei_jian;
    }

    private void queryData() {
        ArrayMap<String, String> map = new ArrayMap<>();
        map.put("carframeNo", et_barcode.getText().toString());
        map.put("loginName", GlobalVar.username);
        map.put("checkedType", isFinished ? "checked" : "notChecked");//未检 checked 检验
        String param = gson.toJson(map);
        OkHttpClient client = new OkHttpClient();
        RequestBody requestBody = RequestBody.create(JSON, param);
        Request request = new Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/prduictionrelation/qmsManufactureProductionplanrelation/api/qryCheckItems")
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                Log.d(TAG, "onFailure: 失败");
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                final String result = response.body().string();
                Log.d(TAG, "onResponse: " + result);
                runOnUiThread(() -> showData(result));
            }
        });

    }

    private void showData(String result) {
        try {
            JSONObject jsonObject = new JSONObject(result);
            if (list != null) {
                list.clear();
                if (adapter != null) {
                    adapter.notifyDataSetChanged();
                }
            }

            if (jsonObject.optString("data") != null) {
                list = gson.fromJson(jsonObject.optString("data"), new TypeToken<List<XiaXianWeiJianFirstBean>>() {
                }.getType());
                adapter = new XiaXianWeiJianFirAdapter(list, context);
                adapter.setCanCheck(isFinished);
                listview.setAdapter(adapter);
                adapter.notifyDataSetChanged();

                if (list == null || list.isEmpty()) {
                    showEmptyMessage();
                }

                adapter.setOnItemClick(new XiaXianWeiJianFirAdapter.OnItemClick() {
                    @Override
                    public void onOkClick(int position) {
                        BasePopupWindowDialog dialog = new BasePopupWindowDialog();
                        Bundle bundle = new Bundle();
                        bundle.putString(BasePopupWindowDialog.ACTION_VALUE_TITLE, "确定要执行该操作吗?");
                        dialog.setArguments(bundle);
                        dialog.show(getSupportFragmentManager(), "");
                        dialog.setOnConfirmClickListener(() -> {
                            dialog.dismiss();
                            checkSuccess(list.get(position).getId(), false, position);
                        });

                    }

                    @Override
                    public void onNoClick(int position) {
                        checkFailure(list.get(position).getId(), position);
                    }

                    @Override
                    public void onDetailClickLisen(int position) {
                        //点击明细
                        isFirst = false;
                        Intent intent = new Intent(context, XiaXianWeiJianMingXingActivity.class);
                        intent.putExtra(XiaXianWeiJianMingXingActivity.ACTION_DETAIL_DATA, list.get(position));
                        intent.putExtra(XiaXianWeiJianMingXingActivity.ACTION_CHECKSUCCESS, isFinished);
                        startActivity(intent);
                    }

                    @Override
                    public void onPass(int position) {
                        onNotCheckClick(position);
                    }
                });
            } else {
                showEmptyMessage();
            }


        } catch (JSONException e) {
            e.printStackTrace();
        }
    }


    //免检
    public void onNotCheckClick(int position) {

        Map<String, String> map = new HashMap<>();
        map.put("id", list.get(position).getId());
        map.put("checkedBy", GlobalVar.username);

        String param = gson.toJson(map);
        Log.e("-->", param);
        OkHttpClient client = new OkHttpClient();
        RequestBody requestBody = RequestBody.create(JSON, param);
        Request request = new Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/prduictionrelation/qmsManufactureProductionplanrelation/api/noCheck")
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                runOnUiThread(() -> {
                    Log.d(TAG, "onFailure: 失败");
                });
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                final String result = response.body().string();
                Log.d(TAG, "onResponse: " + result);
                runOnUiThread(() -> queryData());
            }
        });


//        map[] = list !![position].id
//        map["checkedBy"] = GlobalVar.username
//        val param = gson.toJson(map)
//        Log.e("-->", param)
//        Log.e(
//                "url:",
//                GlobalVar.url + "a/prduictionrelation/qmsManufactureProductionplanrelation/api/noCheck"
//        )
//        val client = OkHttpClient()
//        val requestBody = RequestBody.create(JSON, param)
//        val request = Request.Builder()
//                .post(requestBody)
//                .url(GlobalVar.url + "a/prduictionrelation/qmsManufactureProductionplanrelation/api/noCheck")
//                .build()
//        client.newCall(request).enqueue(object :Callback {
//            override fun onFailure(call:Call, e:IOException){
//                runOnUiThread {
//                    ToastUtils.show("请求失败")
//                }
//            }
//
//            @Throws(IOException::class)
//            override fun onResponse(call:Call, response:Response){
//                val result = response.body() !!.string()
//                Log.d(TAG, "onResponse: $result")
//                runOnUiThread {
//                    try {
//                        val jsonObject = JSONObject(result)
//                        if (TextUtils.equals("0", jsonObject.optString("retCode"))) {
//                            ToastUtils.show("成功")
//                            query()
//                        } else {
//                            ToastUtils.show(jsonObject.optString("retMessage"))
//                        }
//                    } catch (e:JSONException){
//                        e.printStackTrace()
//                    }
//                }
//            }
//        })
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (!isFirst) queryData();
    }

    /**
     * 检查不合格
     */
    private void checkFailure(String id, int position) {
        isFirst = false;
        Intent intent = new Intent(context, XiaXianWeiJianBuHeGeActivity.class);
        intent.putExtra(XiaXianWeiJianBuHeGeActivity.ACTION_DATA, list.get(position));
        startActivity(intent);

    }

    /**
     * 检查合格
     */
    private void checkSuccess(String id, boolean isAll, int position) {
        ArrayMap<String, String> map = new ArrayMap<>();
        map.put("id", id);
        map.put("checkedBy", GlobalVar.username);
        String param = gson.toJson(map);
        OkHttpClient client = new OkHttpClient();
        RequestBody requestBody = RequestBody.create(JSON, param);
        Request request = new Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/prduictionrelation/qmsManufactureProductionplanrelation/api/checkPassed")
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        ToastUtils.show("请求失败");
                    }
                });
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                final String result = response.body().string();
                Log.d(TAG, "onResponse: " + result);
                runOnUiThread(() -> {
                    try {
                        JSONObject jsonObject = new JSONObject(result);
                        if (TextUtils.equals("0", jsonObject.optString("retCode"))) {
                            ToastUtils.show("成功");
                            if (!isAll) {
                                queryData();
                                return;
                            }
                            if (list.size() - 1 == position) {
                                queryData();
                            }
                        } else {
                            ToastUtils.show(jsonObject.optString("retMessage"));
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                });
            }
        });

    }
}