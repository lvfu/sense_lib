package com.zhuisu.fastdev.ui.gracelog

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import com.bumptech.glide.Glide
import com.zhuisu.qualityManagement.R

class PictureAdapter(list: ArrayList<String>, context: Context) : RecyclerView.Adapter<PictureAdapter.Holder>() {

    var list : ArrayList<String>? = null
    var context : Context? = null
    var onItenClick : OnItemClickListener? = null
    var onLongClick : OnItemLongClickListener? = null

    init {
        this.list = list
        this.context = context
    }

    interface OnItemClickListener{
        fun onItemClickListener(position : Int)
    }
    interface OnItemLongClickListener{
        fun onItemLongClickListener(position : Int)
    }

    class Holder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val item_showpre : ImageView = itemView.findViewById(R.id.item_showpre)
        val llParent : LinearLayout = itemView.findViewById(R.id.llParent)
    }

    override fun onCreateViewHolder(p0: ViewGroup, p1: Int): Holder {
        return Holder(((context!!.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater).inflate(R.layout.adapter_picture_item, p0, false)))
    }

    @SuppressLint("SetTextI18n")
    override fun onBindViewHolder(p0: Holder, p1: Int) {
        Glide.with(context!!).load(list!![p1]).into(p0.item_showpre)
        p0.llParent.setOnClickListener{
            if (onItenClick != null){
                onItenClick!!.onItemClickListener(p1)
            }
        }
        p0.llParent.setOnLongClickListener{
            if (onLongClick != null){
                onLongClick!!.onItemLongClickListener(p1)
            }
            true
        }
    }

    override fun getItemCount(): Int {
        return list!!.size
    }

}