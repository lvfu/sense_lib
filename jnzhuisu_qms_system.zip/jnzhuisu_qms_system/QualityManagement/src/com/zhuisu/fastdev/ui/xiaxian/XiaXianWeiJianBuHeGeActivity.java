package com.zhuisu.fastdev.ui.xiaxian;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.provider.MediaStore;
import android.support.v4.content.FileProvider;
import android.util.ArrayMap;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.gson.reflect.TypeToken;
import com.zhuisu.fastdev.BaseActivity;
import com.zhuisu.fastdev.beans.registercar.ZhiLiangMenConfigDetails;
import com.zhuisu.fastdev.beans.xiaxian.XiaXianWeiJianFirstBean;
import com.zhuisu.fastdev.beans.xiaxian.XiaXianWeiJianXiangQingBuMenList;
import com.zhuisu.fastdev.beans.xiaxian.XiaXianWeiJianXiangQingongNengMok;
import com.zhuisu.fastdev.beans.zhuangpei.ZhuangPeiWeiJianGuZhangXinxiBean;
import com.zhuisu.fastdev.beans.zhuangpei.ZhuangPeiWeiJianXiangQingGongYingShangList;
import com.zhuisu.fastdev.beans.zhuangpei.ZhuangPeiWeiJianXiangQingWuLiaoList;
import com.zhuisu.fastdev.ui.problem.OffLineProblemListActivity;
import com.zhuisu.fastdev.ui.zhuangpei.SelectGongYingShangActivity;
import com.zhuisu.fastdev.ui.zhuangpei.SelectItemActivity;
import com.zhuisu.fastdev.ui.zhuangpei.SelectWuLiaoActivity;
import com.zhuisu.qualityManagement.R;
import com.zhuisu.suppliermanagement.util.FileUtil;
import com.zhuisu.suppliermanagement.util.GlobalVar;
import com.zhuisu.suppliermanagement.util.ToastUtils;
import com.zhuisu.suppliermanagement.util.Util;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;


/**
 * 下线不合格
 */
public class XiaXianWeiJianBuHeGeActivity extends BaseActivity {

    public static String ACTION_DATA = "action_data";
    private XiaXianWeiJianFirstBean data;
    private TextView sp_wt_title;//标题
    private Spinner sp_function;//功能模块
    private TextView sp_gongyingshang;//供应商
    private TextView sp_wuliao;//物料
    private Spinner sp_dept;
    private EditText tv_question_level;//问题等级
    private EditText et_wentilaiyuan;//问题来源
    private EditText et_guzhangshuliang;//故障数量
    private EditText et_wentimiaoshu;//问题描述
    private EditText et_wenti_beizhu;//问题备注
    private ImageView iv_select_image;//选择照片
    private ImageView showimage;//显示的照片

    private List<XiaXianWeiJianXiangQingongNengMok> qingongNengMokList;//功能模块
    private List<XiaXianWeiJianXiangQingBuMenList> buMenLists;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getIntent() != null && getIntent().hasExtra(ACTION_DATA)) {
            data = getIntent().getParcelableExtra(ACTION_DATA);

            TextView tv_name1 = findViewById(R.id.tv_name1);
            TextView tv_name2 = findViewById(R.id.tv_name2);
            TextView tv_name3 = findViewById(R.id.tv_name3);
            TextView tv_name4 = findViewById(R.id.tv_name4);
            TextView tv_name5 = findViewById(R.id.tv_name5);


            tv_name1.setText("" + data.getOpnm());
            tv_name2.setText("" + data.getOpno());
            tv_name3.setText("" + data.getMation());
            tv_name4.setText("" + ("" + (data.getStatus().equals("passed") ? "合格" : data.getStatus().equals("failed") ? "不合格" : "待检验")));
            tv_name5.setText("" + data.getFlowcarNo());
            queryDetail();
            queryFunction();
            queryDept();

        }
    }

    private void queryDetail() {
        ArrayMap<String, String> map = new ArrayMap<>();
        map.put("carFarmeNo", data.getCarframeNo());
        String param = gson.toJson(map);
        Log.e("查询详情", param);
        OkHttpClient client = new OkHttpClient();
        RequestBody requestBody = RequestBody.create(JSON, param);
        Request request = new Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/offlinedebuggingstatus/qmsOfflineStatus/api/carFrameInfo")
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                Log.d(TAG, "onFailure: 失败");
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                final String result = response.body().string();

                runOnUiThread(() -> {
                    JSONObject jsonObject = null;
                    try {
                        Log.e("查询详情", result);
                        jsonObject = new JSONObject(result);
                        if (jsonObject.optString("status").equals("-1")) {
                            ToastUtils.show(jsonObject.optString("msg"));
                        } else {
                            ZhiLiangMenConfigDetails details = gson.fromJson(jsonObject.optString("data"), ZhiLiangMenConfigDetails.class);
                            if (details != null) {
                                data.setStatus(details.getStatus());
                            }
                        }

                    } catch (JSONException jsonException) {
                        jsonException.printStackTrace();
                    }

                });
            }

        });
    }

    @Override
    protected void initViews() {
        sp_wt_title = findViewById(R.id.sp_wt_title);
        sp_function = findViewById(R.id.sp_function);
        sp_gongyingshang = findViewById(R.id.sp_gongyingshang);
        sp_wuliao = findViewById(R.id.sp_wuliao);
        sp_dept = findViewById(R.id.sp_dept);
        tv_question_level = findViewById(R.id.tv_question_level);
        et_wentilaiyuan = findViewById(R.id.et_wentilaiyuan);
        et_wentimiaoshu = findViewById(R.id.et_wentimiaoshu);
        et_guzhangshuliang = findViewById(R.id.et_guzhangshuliang);
        et_wenti_beizhu = findViewById(R.id.et_wenti_beizhu);
        showimage = findViewById(R.id.showimage);

        findViewById(R.id.btn_submit_sun).setOnClickListener(view -> submit());
        findViewById(R.id.iv_select_image).setOnClickListener(view -> selectImage());


        sp_wt_title.setOnClickListener(v -> {
            Intent intent = new Intent(context, SelectItemActivity.class);
            startActivityForResult(intent, 0x11);
        });
        sp_gongyingshang.setOnClickListener(v -> {
            Intent intent = new Intent(context, SelectGongYingShangActivity.class);
            startActivityForResult(intent, 0x12);
        });

        sp_wuliao.setOnClickListener(v -> {
            Intent intent = new Intent(context, SelectWuLiaoActivity.class);
            startActivityForResult(intent, 0x13);
        });


        findViewById(R.id.btn_ask_list).setOnClickListener(v -> {
            Intent intent = new Intent(context, OffLineProblemListActivity.class);
            intent.putExtra(OffLineProblemListActivity.ACTION_PARAMS,data.getCarframeNo());
            intent.putExtra(OffLineProblemListActivity.ACTION_ID,data.getOpno());
            startActivity(intent);
        });
    }

    @Override
    protected int getResId() {
        return R.layout.activity_xia_xian_wei_jian_bu_he_ge;
    }

    /**
     * 选择照片
     */
    AlertDialog alertdialog;
    public static String fileDir = Environment.getExternalStorageDirectory().getAbsolutePath() + "/qualitymanagement/files/media/";
    String uploadFilePath;
    private final int IMAGE_CODE = 200; // 这里的IMAGE_CODE是自己任意定义的
    Uri imageUri;

    private void selectImage() {
        alertdialog = Util.getDialog(context, "选择图像", 0, new AdapterView.OnItemClickListener() {
            @SuppressLint("SimpleDateFormat")
            @Override
            public void onItemClick(AdapterView<?> arg0, View view, int position, long arg3) {
                if (alertdialog.isShowing()) {
                    alertdialog.dismiss();
                }
                File f;
                switch (position) {
                    case 0:
                        String fileName = "";
                        Intent capimgIntent = new Intent();
                        fileName = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date()) + ".jpg";
                        FileUtil.checkDir(fileDir + "_/");
                        f = new File(fileDir + "_", fileName);
                        uploadFilePath = fileDir + "_/" + fileName;

                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                            // 7.0+以上版本
                            //与manifest中定义的provider中的authorities="cn.wlantv.kznk.fileprovider"保持一致
                            imageUri = FileProvider.getUriForFile(context, "com.jnqms.fileprovider", f);
                            capimgIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        } else {
                            imageUri = Uri.fromFile(f);
                        }
                        capimgIntent.putExtra(MediaStore.EXTRA_OUTPUT, imageUri);
                        capimgIntent.setAction(MediaStore.ACTION_IMAGE_CAPTURE);
                        capimgIntent.addCategory(Intent.CATEGORY_DEFAULT);


                        startActivityForResult(capimgIntent, 1);
                        break;
                    case 1:// 添加文件
                        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                        intent.setType("image/*");
                        intent.addCategory(Intent.CATEGORY_OPENABLE);

                        try {

                            startActivityForResult(Intent.createChooser(intent, "Select a File to Upload"),
                                    IMAGE_CODE);
                        } catch (android.content.ActivityNotFoundException ex) {
                            Toast.makeText(context, "Please install a File Manager.", Toast.LENGTH_SHORT)
                                    .show();
                        }
                        break;
                    default:
                        break;
                }
            }
        }, new String[]{"拍照", "文件"}, new Integer[]{R.drawable.i_camera, R.drawable.i_image});
        alertdialog.show();
    }

    private ZhuangPeiWeiJianGuZhangXinxiBean zhuangPeiWeiJianGuZhangXinxiBean;
    private ZhuangPeiWeiJianXiangQingWuLiaoList zhuangPeiWeiJianXiangQingWuLiaoList;
    private ZhuangPeiWeiJianXiangQingGongYingShangList zhuangPeiWeiJianXiangQingGongYingShangList;

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == Activity.RESULT_OK && requestCode == IMAGE_CODE) {
            // 选择文件
            String path = null;
            if (data == null)
                return;
            path = FileUtil.getImageAbsolutePath((Activity) context, data);
            if (path == null) {
                return;
            }
            uploadFilePath = path;
            showimage.setVisibility(View.VISIBLE);
            Glide.with(context).load(path).into(showimage);

        } else if (requestCode == 1 && resultCode == Activity.RESULT_OK) {
            showimage.setVisibility(View.VISIBLE);
            Glide.with(context).load(uploadFilePath).into(showimage);
        } else if (resultCode == 0x18) {
            if (data.getParcelableExtra("data") != null) {
                zhuangPeiWeiJianGuZhangXinxiBean = data.getParcelableExtra("data");
                Log.e("获取数据", zhuangPeiWeiJianGuZhangXinxiBean.getMalfunctionName());
                sp_wt_title.setText(zhuangPeiWeiJianGuZhangXinxiBean.getMalfunctionName());
                tv_question_level.setText(zhuangPeiWeiJianGuZhangXinxiBean.getMalfunctionLevel());
            }
        } else if (resultCode == 0x19) {
            if (data.getParcelableExtra("data") != null) {
                zhuangPeiWeiJianXiangQingWuLiaoList = data.getParcelableExtra("data");
                sp_wuliao.setText(zhuangPeiWeiJianXiangQingWuLiaoList.getMaterielName());
            }
        } else if (resultCode == 0x20) {
            if (data.getParcelableExtra("data") != null) {
                zhuangPeiWeiJianXiangQingGongYingShangList = data.getParcelableExtra("data");
                sp_gongyingshang.setText(zhuangPeiWeiJianXiangQingGongYingShangList.getText());
            }
        }
    }

    /**
     * 提交
     */
    private void submit() {
        ArrayMap<String, String> map = new ArrayMap<>();
        if (zhuangPeiWeiJianGuZhangXinxiBean == null) {
            ToastUtils.show("问题名称不能为空");
            return;
        } else {
            map.put("peoblemTitle", zhuangPeiWeiJianGuZhangXinxiBean.getMalfunctionName());//问题名称
        }

        map.put("problemSource", "offLineCheck");//问题来源
        map.put("rce", "assemble_quality_door");
        map.put("malfunctionCode", zhuangPeiWeiJianGuZhangXinxiBean.getMalfunctionNo());//故障编码
        map.put("flowCarNo", data.getFlowcarNo());//随车单号
        map.put("carFrameNo", data.getCarframeNo());//车架号
        map.put("assembleStation", "");//装配工位
        map.put("carModelNo", data.getCarModelNo());//车型号
        map.put("checkItemNo", data.getOpno());//项目号码
        map.put("checkItemName", data.getOpnm());//检验项目名称
//        if (qingongNengMokList != null && !qingongNengMokList.isEmpty()) {
//            map.put("functionModel", qingongNengMokList.get(sp_function.getSelectedItemPosition()).getId());//功能模块
//        } else {
        map.put("functionModel", "");//功能模块
//        }

        map.put("occurTimeStr", new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date(System.currentTimeMillis())));
//        map.put("problemLevel", zhuangPeiWeiJianGuZhangXinxiBean.getMalfunctionLevel());//问题级别
        map.put("problemLevel", tv_question_level.getText().toString());//问题级别
        if (zhuangPeiWeiJianXiangQingWuLiaoList == null) {
            map.put("materiel", "");//物料号
        } else {
            map.put("materiel", zhuangPeiWeiJianXiangQingWuLiaoList.getMaterielId());//物料号
        }
        map.put("malfunctionNumber", et_guzhangshuliang.getText().toString());//故障数量
        if (buMenLists != null && !buMenLists.isEmpty()) {
            map.put("depts", buMenLists.get(sp_dept.getSelectedItemPosition()).getCode());//责任部门
        } else {
            map.put("depts", "");
        }

        map.put("problemDesc", et_wentimiaoshu.getText().toString());//问题描述
        map.put("problemRemarks", et_wenti_beizhu.getText().toString());
        if (uploadFilePath != null && !uploadFilePath.isEmpty()) {
            map.put("imgStr", bitmapToBase64(getLoacalBitmap(uploadFilePath)));//图片
        } else {
            map.put("imgStr", "");//图片
        }
        if (zhuangPeiWeiJianXiangQingGongYingShangList != null) {
            map.put("supplier", zhuangPeiWeiJianXiangQingGongYingShangList.getId()); //供应商
        } else {
            map.put("supplier", "");
        }

        map.put("operType", "app"); //固定 app
        map.put("currentUserLoginName", GlobalVar.username); //登录人
        map.put("checkItemsId", data.getId());
        map.put("offLineStatus", data.getStatus() == null ? "" : data.getStatus());


        String param = gson.toJson(map);
        Log.e("---->", param);
        showCommitDialog();


        OkHttpClient client = new OkHttpClient();
        RequestBody requestBody = RequestBody.create(JSON, param);
        Request request = new Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/checkfaildflow/qmsManufactureProblemflow/api/saveAsyn")
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                Log.d(TAG, "onFailure: 失败");
                runOnUiThread(() -> {
                    showNetErrorMessage();
                    cancelDialog();
                });
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                final String result = response.body().string();
                runOnUiThread(() -> {
                    Log.d(TAG, "onResponse: 功能模块" + result);
                    try {
                        cancelDialog();
                        JSONObject jsonObject = new JSONObject(result);
                        if (jsonObject.optString("retCode").equals("0")) {
                            ToastUtils.show("提交成功");
//                            new Handler().postDelayed(() -> finish(), 1500);

                            zhuangPeiWeiJianGuZhangXinxiBean = null;
                            sp_wt_title.setText("");
                            tv_question_level.setText("");
                            et_wentimiaoshu.setText("");
                            showimage.setVisibility(View.GONE);
                            ArrayAdapter<XiaXianWeiJianXiangQingBuMenList> arrayAdapter = new ArrayAdapter<>(context, R.layout.simple_textview1, buMenLists);
                            sp_dept.setAdapter(arrayAdapter);
                            et_guzhangshuliang.setText("");
                            zhuangPeiWeiJianXiangQingGongYingShangList = null;
                            sp_gongyingshang.setText("");
                            zhuangPeiWeiJianXiangQingWuLiaoList = null;
                            sp_wuliao.setText("");

                        } else {
                            ToastUtils.show(jsonObject.optString("retMessage"));
                        }

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                });
            }
        });
    }


    /**
     * 查询功能模块
     */
    private void queryFunction() {
        ArrayMap<String, String> map = new ArrayMap<>();
        map.put("type", "qms_module");
        String param = gson.toJson(map);
        OkHttpClient client = new OkHttpClient();
        RequestBody requestBody = RequestBody.create(JSON, param);
        Request request = new Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/common/util/api/getDict")
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                Log.d(TAG, "onFailure: 失败");
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                final String result = response.body().string();
                runOnUiThread(() -> {
                    Log.d(TAG, "onResponse: 功能模块" + result);
                    try {
                        JSONObject jsonObject = new JSONObject(result);
                        qingongNengMokList = gson.fromJson(jsonObject.optString("data"), new TypeToken<List<XiaXianWeiJianXiangQingongNengMok>>() {
                        }.getType());
                        if (qingongNengMokList == null) return;
                        ArrayAdapter<XiaXianWeiJianXiangQingongNengMok> arrayAdapter = new ArrayAdapter<>(context, R.layout.simple_textview1, qingongNengMokList);
                        sp_function.setAdapter(arrayAdapter);

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                });
            }
        });
    }


    /**
     * 查询部门
     */
    private void queryDept() {
        ArrayMap<String, String> map = new ArrayMap<>();
        OkHttpClient client = new OkHttpClient();
        RequestBody requestBody = RequestBody.create(JSON, "");
        Request request = new Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/sys/office/api/getOfficeList")
                .build();
        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                Log.d(TAG, "onFailure: 失败");
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                final String result = response.body().string();
                runOnUiThread(() -> {
                    Log.d(TAG, "onResponse: 部门" + result);
                    try {
                        JSONObject jsonObject = new JSONObject(result);
                        buMenLists = gson.fromJson(jsonObject.optString("data"), new TypeToken<List<XiaXianWeiJianXiangQingBuMenList>>() {
                        }.getType());
                        if (buMenLists == null) return;
                        ArrayAdapter<XiaXianWeiJianXiangQingBuMenList> arrayAdapter = new ArrayAdapter<>(context, R.layout.simple_textview1, buMenLists);
                        sp_dept.setAdapter(arrayAdapter);

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                });
            }
        });
    }
}