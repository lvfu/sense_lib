package com.zhuisu.fastdev.ui.consolereturn

import android.annotation.SuppressLint
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.text.TextUtils
import android.util.ArrayMap
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.zhuisu.fastdev.BaseActivity
import com.zhuisu.fastdev.adapter.consolepull.ConsolePullAdapter
import com.zhuisu.fastdev.adapter.consolereturn.ConsoleReturnAdapter
import com.zhuisu.fastdev.beans.consolepull.ConsolePullList
import com.zhuisu.fastdev.ui.util.BroadCastConfig
import com.zhuisu.qualityManagement.R
import com.zhuisu.suppliermanagement.base.CaptureActivity
import com.zhuisu.suppliermanagement.util.GlobalVar
import com.zhuisu.suppliermanagement.util.ToastUtils
import okhttp3.*
import org.json.JSONException
import org.json.JSONObject
import java.io.IOException

/**
 * @author cxh
 * @description 故障排除作业
 * @date 2020/11/13.
 */
class ConsoleReturnActivity : BaseActivity(), ConsoleReturnAdapter.OnItemClickListener {

    var etCarNumber: EditText? = null
    var list: ArrayList<ConsolePullList>? = null
    var adapter: ConsoleReturnAdapter? = null


    private val broadCast : BroadCastChange = BroadCastChange()
    val filter : IntentFilter = IntentFilter(BroadCastConfig.BROADCAST_ACTION)

    inner class BroadCastChange : BroadcastReceiver(){
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent != null && intent.action != null && intent.action == BroadCastConfig.BROADCAST_ACTION){
                etCarNumber!!.setText(intent.extras!!.getString(BroadCastConfig.BROADCAST_ACTION_TAG))
                etCarNumber!!.setSelection(etCarNumber!!.text.toString().length)
                query()
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        unregisterReceiver(broadCast)
    }

    @SuppressLint("SetTextI18n")
    override fun initViews() {
        val tvUserName: TextView = findViewById(R.id.tv_user_name)
        tvUserName.text = "\t" + GlobalVar.realname

        list = ArrayList()
        adapter = ConsoleReturnAdapter(list!!, context)
        val recyclerview = findViewById<RecyclerView>(R.id.recyclerview)
        val manager = LinearLayoutManager(context)
        etCarNumber = findViewById(R.id.tv_cjh)

        manager.orientation = LinearLayoutManager.VERTICAL
        recyclerview.layoutManager = manager
        recyclerview.adapter = adapter
        adapter!!.onItemCLick = this

        findViewById<TextView>(R.id.tv_scanf).setOnClickListener {
            val intent = Intent(context, CaptureActivity::class.java)
            startActivityForResult(intent, 1073)
        }

        findViewById<Button>(R.id.btn_query).setOnClickListener {
            query()
        }

        filter.priority = Int.MAX_VALUE
        registerReceiver(broadCast,filter)
    }


    fun query() {
        showLoadingDialog()
        list!!.clear()
        adapter!!.notifyDataSetChanged()
        val map = ArrayMap<String, String>()
        map["flowCarNo"] = ""
        map["carFarmeNo"] = etCarNumber!!.text.toString()
        map["status"] = "submitcheckpassed"
        map["pageNo"] = "1"
        map["pageSize"] = "100"

        val param = gson.toJson(map)
        Log.e("参数", param)
        val client = OkHttpClient()
        val requestBody = RequestBody.create(JSON, param)
        val request = Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/offlinedebuggingstatus/qmsOfflineStatus/api/list")
                .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread {
                    Log.d(TAG, "onFailure: 失败")
                    cancelLoadingDialog()
                    ToastUtils.show("请求数据失败")
                }
            }

            override fun onResponse(call: Call, response: Response) {
                val result = response.body()!!.string()
                runOnUiThread {
                    try {
                        cancelLoadingDialog()
                        Log.e("--->", result)
                        val jsonObject = JSONObject(result)
                        if (TextUtils.equals(jsonObject.optString("status"), "0")) {
                            val listType = object : TypeToken<ArrayList<ConsolePullList>>() {}.type
                            val temp: ArrayList<ConsolePullList> = Gson().fromJson(jsonObject.optJSONObject("data").optString("list"), listType)
                            list!!.addAll(temp)
                            adapter!!.notifyDataSetChanged()
                            if (list!!.isEmpty()){
                                showEmptyMessage()
                            }
                        } else {
                            showEmptyMessage()
                            adapter!!.notifyDataSetChanged()
                        }

                    } catch (jsonException: JSONException) {
                        jsonException.printStackTrace()
                    }
                }
            }
        })
    }

    override fun getResId(): Int {
        return R.layout.activity_console_return
    }

    override fun onResume() {
        super.onResume()
        query()
    }


    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (data != null) {
            val str = data!!.getStringExtra("encoderesult").toString()
            etCarNumber!!.setText(str)
        }
        super.onActivityResult(requestCode, resultCode, data)
    }

    override fun onItemCLicked(position: Int) {
        val pullIntent = Intent(context, ConsoleReturnProjectActivity::class.java)
        pullIntent.putExtra(ConsoleReturnProjectActivity.ACTION_VALUE, list!![position])
        startActivity(pullIntent)
    }

}