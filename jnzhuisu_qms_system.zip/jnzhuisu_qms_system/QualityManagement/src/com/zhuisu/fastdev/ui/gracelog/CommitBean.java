package com.zhuisu.fastdev.ui.gracelog;

import java.util.ArrayList;

public class CommitBean {
    private String isStartProcess;
    private String mobileCreateLoginName;
    private String mobileStartProcessLoginName;
    private String problemType;
    private String reviewProjectType;
    private String reviewProject;
    private String carFrameNo;
    private String unqualifiedSort;
    private String isMax;
    private String happenNum;
    private String responsibleDepartment;
    private String faultCode;
    private String faultName;
    private String faultType;
    private String faultLevel;
    private String faultDes;
    private String imgStr;
    private String loginName;
    private String problemDesc;
    private String department;
    private ArrayList<FilePathBean> listFile;


    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getProblemDesc() {
        return problemDesc;
    }

    public void setProblemDesc(String problemDesc) {
        this.problemDesc = problemDesc;
    }

    public String getLoginName() {
        return loginName;
    }

    public void setLoginName(String loginName) {
        this.loginName = loginName;
    }

    public String getIsStartProcess() {
        return isStartProcess;
    }

    public void setIsStartProcess(String isStartProcess) {
        this.isStartProcess = isStartProcess;
    }

    public String getMobileCreateLoginName() {
        return mobileCreateLoginName;
    }

    public void setMobileCreateLoginName(String mobileCreateLoginName) {
        this.mobileCreateLoginName = mobileCreateLoginName;
    }

    public String getMobileStartProcessLoginName() {
        return mobileStartProcessLoginName;
    }

    public void setMobileStartProcessLoginName(String mobileStartProcessLoginName) {
        this.mobileStartProcessLoginName = mobileStartProcessLoginName;
    }

    public String getProblemType() {
        return problemType;
    }

    public void setProblemType(String problemType) {
        this.problemType = problemType;
    }

    public String getReviewProjectType() {
        return reviewProjectType;
    }

    public void setReviewProjectType(String reviewProjectType) {
        this.reviewProjectType = reviewProjectType;
    }

    public String getReviewProject() {
        return reviewProject;
    }

    public void setReviewProject(String reviewProject) {
        this.reviewProject = reviewProject;
    }

    public String getCarFrameNo() {
        return carFrameNo;
    }

    public void setCarFrameNo(String carFrameNo) {
        this.carFrameNo = carFrameNo;
    }

    public String getUnqualifiedSort() {
        return unqualifiedSort;
    }

    public void setUnqualifiedSort(String unqualifiedSort) {
        this.unqualifiedSort = unqualifiedSort;
    }

    public String getIsMax() {
        return isMax;
    }

    public void setIsMax(String isMax) {
        this.isMax = isMax;
    }

    public String getHappenNum() {
        return happenNum;
    }

    public void setHappenNum(String happenNum) {
        this.happenNum = happenNum;
    }

    public String getResponsibleDepartment() {
        return responsibleDepartment;
    }

    public void setResponsibleDepartment(String responsibleDepartment) {
        this.responsibleDepartment = responsibleDepartment;
    }

    public String getFaultCode() {
        return faultCode;
    }

    public void setFaultCode(String faultCode) {
        this.faultCode = faultCode;
    }

    public String getFaultName() {
        return faultName;
    }

    public void setFaultName(String faultName) {
        this.faultName = faultName;
    }

    public String getFaultType() {
        return faultType;
    }

    public void setFaultType(String faultType) {
        this.faultType = faultType;
    }

    public String getFaultLevel() {
        return faultLevel;
    }

    public void setFaultLevel(String faultLevel) {
        this.faultLevel = faultLevel;
    }

    public String getFaultDes() {
        return faultDes;
    }

    public void setFaultDes(String faultDes) {
        this.faultDes = faultDes;
    }

    public String getImgStr() {
        return imgStr;
    }

    public void setImgStr(String imgStr) {
        this.imgStr = imgStr;
    }

    public ArrayList<FilePathBean> getListFile() {
        return listFile;
    }

    public void setListFile(ArrayList<FilePathBean> listFile) {
        this.listFile = listFile;
    }


}
