package com.zhuisu.fastdev.ui.rain;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.v4.content.FileProvider;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.ArrayMap;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.gson.reflect.TypeToken;
import com.zhuisu.fastdev.BaseActivity;
import com.zhuisu.fastdev.adapter.rain.RainLogAdapter;
import com.zhuisu.fastdev.beans.rain.RainHistoryListBean;
import com.zhuisu.fastdev.beans.rain.RainLogListBean;
import com.zhuisu.fastdev.dialog.BasePopupWindowDialog;
import com.zhuisu.fastdev.view.FastTitleLayout;
import com.zhuisu.qualityManagement.R;
import com.zhuisu.suppliermanagement.util.FileUtil;
import com.zhuisu.suppliermanagement.util.GlobalVar;
import com.zhuisu.suppliermanagement.util.ToastUtils;
import com.zhuisu.suppliermanagement.util.Util;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 * @author cxh
 * @description
 * @date 2020/10/23.
 */
public class RainLogActivity extends BaseActivity {

    public static final String ACTION_RAIN = "action_rain";
    private RecyclerView recyclerView;
    private RainLogAdapter adapter;
    private List<RainLogListBean> list;
    private int currentPosition = -1;
    private RainHistoryListBean bean;

    @Override
    protected void initViews() {
        if (getIntent() != null && getIntent().hasExtra(ACTION_RAIN)) {
            bean = getIntent().getParcelableExtra(ACTION_RAIN);
        }
        list = new ArrayList<>();
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(context);
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        recyclerView = findViewById(R.id.recyclerview);
        recyclerView.setLayoutManager(linearLayoutManager);
        adapter = new RainLogAdapter(list, context);
        recyclerView.setAdapter(adapter);
        adapter.setOnImageSelectListener(this::selectImage);
        adapter.setOnCommitClickListener(this::commitData);
        query();

        ImageView ft = findViewById(R.id.iv_left);
        ft.setOnClickListener(view -> {
            BasePopupWindowDialog basePopupWindowDialog = new BasePopupWindowDialog();
            Bundle bundle = new Bundle();
            bundle.putString(BasePopupWindowDialog.ACTION_VALUE_TITLE, "提示");
            bundle.putString(BasePopupWindowDialog.ACTION_VALUE_MESSAGE, "确认返回上一级吗?");
            basePopupWindowDialog.setArguments(bundle);
            basePopupWindowDialog.show(getSupportFragmentManager(), "");
            basePopupWindowDialog.setOnConfirmClickListener(this::finish);
        });
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            if (super.onKeyDown(keyCode, event)) {
                BasePopupWindowDialog basePopupWindowDialog = new BasePopupWindowDialog();
                Bundle bundle = new Bundle();
                bundle.putString(BasePopupWindowDialog.ACTION_VALUE_TITLE, "提示");
                bundle.putString(BasePopupWindowDialog.ACTION_VALUE_MESSAGE, "确认返回上一级吗?");
                basePopupWindowDialog.setArguments(bundle);
                basePopupWindowDialog.show(getSupportFragmentManager(), "");
                basePopupWindowDialog.setOnConfirmClickListener(this::finish);
            }
            return false;
        }
        return super.onKeyDown(keyCode, event);
    }

    private void commitData(int position) {
        try {
            JSONArray jsonArray = new JSONArray();
            JSONObject map = new JSONObject();
            map.put("carFarmeNo", bean.getCarFarmeNo());
            map.put("yesNo", list.get(position).getYesNo());
            map.put("part", list.get(position).getPart());
            map.put("partNo", list.get(position).getPartNo());
            map.put("remark", list.get(position).getRemark());
            map.put("rainConfirmOperator", GlobalVar.username);

            if (list.get(position).getImgStr() != null) {
                map.put("imgStr", bitmapToBase64(getLoacalBitmap(list.get(position).getImgStr())));
            } else {
                map.put("imgStr", "");
            }

//           map.put("userName", GlobalVar.username);
            jsonArray.put(map);

            OkHttpClient client = new OkHttpClient();
            Log.e("--->", jsonArray.toString());
            RequestBody requestBody = RequestBody.create(JSON, jsonArray.toString());
            Request request = new Request.Builder()
                    .post(requestBody)
                    .url(GlobalVar.url + "a/offlinedebuggingstatus/qmsOfflineStatus/api/saveRainFailedData")
                    .build();

            client.newCall(request).enqueue(new Callback() {
                @Override
                public void onFailure(Call call, IOException e) {
                    Log.d(TAG, "onFailure: 失败");
                }

                @Override
                public void onResponse(Call call, Response response) throws IOException {
                    final String result = response.body().string();
                    Log.e("--->单项保存淋雨", result);
                    runOnUiThread(() -> {
                        try {
                            JSONObject jsonObject = new JSONObject(result);
                            if (jsonObject.optString("retCode").equals("0")) {
                                ToastUtils.show("成功");
                                query();

                            }
                            ToastUtils.show(jsonObject.optString("retMessage"));
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    });
                }
            });

        } catch (JSONException jsonException) {
            jsonException.printStackTrace();
        }
    }


    public void query() {
        ArrayMap<String, String> map = new ArrayMap<>();
        map.put("type", "rainPart");
        String param = gson.toJson(map);
        OkHttpClient client = new OkHttpClient();
        RequestBody requestBody = RequestBody.create(JSON, param);
        Request request = new Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/offlinedebuggingstatus/qmsOfflineStatus/api/rainPart")
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                Log.d(TAG, "onFailure: 失败");
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                final String result = response.body().string();

                runOnUiThread(() -> showlistBean(result));
            }
        });
    }

    private void showlistBean(String result) {
        Log.e("-->淋雨", result);
        list.clear();
        try {
            JSONObject jsonObject = new JSONObject(result);
            if (jsonObject.optString("status").equals("0")) {
                list.clear();
                list.addAll(gson.fromJson(jsonObject.optString("data"), new TypeToken<List<RainLogListBean>>() {
                }.getType()));
                adapter.notifyDataSetChanged();
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }


    @Override
    protected int getResId() {
        return R.layout.activity_rain_log;
    }

    /**
     * 选择照片
     */
    AlertDialog alertdialog;
    public static String fileDir = Environment.getExternalStorageDirectory().getAbsolutePath() + "/qualitymanagement/files/media/";
    String uploadFilePath;
    private final int IMAGE_CODE = 200; // 这里的IMAGE_CODE是自己任意定义的

    Uri imageUri;

    private void selectImage(int selectPosition) {
        alertdialog = Util.getDialog(context, "选择图像", 0, new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> arg0, View view, int position, long arg3) {
                if (alertdialog.isShowing()) {
                    alertdialog.dismiss();
                }

                File f = null;
                Uri uri = null;
                currentPosition = selectPosition;
                switch (position) {
                    case 0:
                        String fileName = "";
                        Intent capimgIntent = new Intent();
                        fileName = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date()) + ".jpg";
                        FileUtil.checkDir(fileDir + "_/");
                        f = new File(fileDir + "_", fileName);
                        uploadFilePath = fileDir + "_/" + fileName;

                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                            // 7.0+以上版本
                            //与manifest中定义的provider中的authorities="cn.wlantv.kznk.fileprovider"保持一致
                            imageUri = FileProvider.getUriForFile(context, "com.jnqms.fileprovider", f);
                            capimgIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        } else {
                            imageUri = Uri.fromFile(f);
                        }
                        capimgIntent.putExtra(MediaStore.EXTRA_OUTPUT, imageUri);
                        capimgIntent.setAction(MediaStore.ACTION_IMAGE_CAPTURE);
                        capimgIntent.addCategory(Intent.CATEGORY_DEFAULT);


                        startActivityForResult(capimgIntent, 1);

                        break;
                    case 1:// 添加文件
                        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                        intent.setType("image/*");
                        intent.addCategory(Intent.CATEGORY_OPENABLE);
                        try {
                            startActivityForResult(Intent.createChooser(intent, "Select a File to Upload"),
                                    IMAGE_CODE);
                        } catch (android.content.ActivityNotFoundException ex) {
                            Toast.makeText(context, "Please install a File Manager.", Toast.LENGTH_SHORT).show();
                        }
                        break;
                }
            }
        }, new String[]{"拍照", "文件"}, new Integer[]{R.drawable.i_camera, R.drawable.i_image});
        alertdialog.show();
    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == Activity.RESULT_OK && requestCode == IMAGE_CODE) {
            // 选择文件
            String path = null;
            if (data == null)
                return;
            path = FileUtil.getImageAbsolutePath((Activity) context, data);
            if (path == null) {
                return;
            }
            uploadFilePath = path;
            list.get(currentPosition).setImgStr(uploadFilePath);
            adapter.notifyDataSetChanged();
        } else if (requestCode == 1 && resultCode == Activity.RESULT_OK) {
            list.get(currentPosition).setImgStr(uploadFilePath);
            adapter.notifyDataSetChanged();
        }
    }


}
