package com.zhuisu.fastdev.ui.lownumber;

import android.content.Intent;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.util.ArrayMap;
import android.util.Log;
import android.widget.EditText;

import com.google.gson.reflect.TypeToken;
import com.zhuisu.fastdev.BaseActivity;
import com.zhuisu.fastdev.adapter.lack.LackCommitDetailAdapter;
import com.zhuisu.fastdev.beans.LackCommitDetailListBean;
import com.zhuisu.qualityManagement.R;
import com.zhuisu.suppliermanagement.util.GlobalVar;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 * @author cxh
 * @description
 * @date 2020/10/27.
 */
public class QueryResouceActivity extends BaseActivity {

    private RecyclerView recycler;
    private EditText et_inputs;
    private EditText et_wlnumber;
    private List<LackCommitDetailListBean> listBeans;
    private LackCommitDetailAdapter adapter;

    @Override
    protected void initViews() {
        listBeans = new ArrayList<>();
        recycler = findViewById(R.id.recyclerview_query1);
        et_wlnumber = findViewById(R.id.et_wlnumber);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(context);
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        recycler.setLayoutManager(linearLayoutManager);

        et_inputs = findViewById(R.id.et_inputs);
        findViewById(R.id.btn_query_search).setOnClickListener(v -> queWl());
        adapter = new LackCommitDetailAdapter(listBeans,context);
        recycler.setAdapter(adapter);
        adapter.setOnItemSelectListener(position -> {
            Intent intent = new Intent();
            intent.putExtra(LackCommitActivity.ACTION_EXT_DATA,listBeans.get(position));
            setResult(0x07,intent);
            finish();
        });
    }

    @Override
    protected int getResId() {
        return R.layout.activity_query_resuouce;
    }

    private void queWl() {
        //查询物料
        ArrayMap<String, Object> map = new ArrayMap<>();
        map.put("materielId", et_wlnumber.getText().toString());
        map.put("materielIdOld", "");
        map.put("materielName", et_inputs.getText().toString());
        map.put("pageNo", 1);
        map.put("pageSize", 100);

        String param = gson.toJson(map);
        OkHttpClient client = new OkHttpClient();
        RequestBody requestBody = RequestBody.create(JSON, param);
        Request request = new Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/materiel/qmsManufactureMateriel/api/qryMateriel")
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                Log.d(TAG, "onFailure: 失败");
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                final String result = response.body().string();
                runOnUiThread(() -> {
                    try {
                        Log.e("--->物料",result);
                        listBeans.clear();
                        JSONObject jsonObject = new JSONObject(result);
                        if (jsonObject.optString("retCode").equals("0") && jsonObject.optJSONObject("data") != null && jsonObject.optJSONObject("data").optString("list") != null
                        && !TextUtils.isEmpty(jsonObject.optJSONObject("data").optString("list"))){
                            listBeans.addAll(gson.fromJson(jsonObject.optJSONObject("data").optString("list"),new TypeToken<List<LackCommitDetailListBean>>(){}.getType()));
                            adapter.notifyDataSetChanged();
                        }else{
                            listBeans.clear();
                            adapter.notifyDataSetChanged();
                        }
                    } catch (JSONException jsonException) {
                        jsonException.printStackTrace();
                    }

                });
            }
        });
    }

}
