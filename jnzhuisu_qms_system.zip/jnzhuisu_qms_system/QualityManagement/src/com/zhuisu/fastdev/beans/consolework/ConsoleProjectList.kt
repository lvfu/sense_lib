package com.zhuisu.fastdev.beans.consolework

import android.os.Parcel
import android.os.Parcelable

/**
 * @author cxh
 * @description
 * @date 2020/11/16.
 */


/**
 * "id": "f24541fd1ee84b7a963b53ba80e5d957",
"isNewRecord": false,
"createDate": "2020-10-10 18:14:39",
"updateDate": "2020-10-10 18:14:39",
"checkItemId": "1bb97f03b5a74113a2ee3c5c918ce4e2",
"carframeNo": "LJ177060",
"productModel": "zc",
"flowcarNo": "JTYJ20080010/0010-0006",
"carModelNo": "ZZ4255V3846F1L/U9VDM38-标运",
"status": "init",
"workshop": "NC.10.51001",
"planFinishDate": "2020-10-10 00:00:00",
"orderNo": "JTYJ20080010",
"productOrder": "FO2008210113",
"opno": "XJ-02-02",
"opnm": "巡检-后桥做工检测",
"mation": "巡检-后桥做工检测：边缘是否光滑，是否有毛边",
"projectCode": "1",
"parentCode": "",
"dayShiftSelf": "",
"dayShiftMutua": "sense,",
"dayShiftSpecial": "",
"nightShftSelf": "",
"nightShftMutual": "",
"nightShftSpecial": "",
"middleShftSelf": "",
"middleShftMutual": "",
"middleShftSpecial": "",
"configChange": false
 *
 * */
data class ConsoleProjectList(
        var opnm: String?, var opno: String?, var flowcarNo: String?, var mation: String?,
        var carframeNo: String?, var carModelNo: String?, var id: String?, var checkItemId: String?,
        var status: String?,var configChange : Boolean,var checkedBy : String?,var checkedDate : String?,var checkValue : String?,var checkRemarks  : String?,var imgStr : String?,var orderNo : String?,
        var checkedItemsTotal : String?,var notCheckedItemsTotal : String?,var checkItemsTotal : String?,var hasProblem : String?,var gljybz : String?
) : Parcelable {
    constructor(parcel: Parcel) : this(
            parcel.readString(),
            parcel.readString(),
            parcel.readString(),
            parcel.readString(),
            parcel.readString(),
            parcel.readString(),
            parcel.readString(),
            parcel.readString(),
            parcel.readString(),
            parcel.readByte() != 0.toByte(),
            parcel.readString(),
            parcel.readString(),
            parcel.readString(),
            parcel.readString(),
            parcel.readString(),
            parcel.readString(),parcel.readString(),parcel.readString(),parcel.readString(),parcel.readString(),parcel.readString()) {
    }

    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeString(opnm)
        parcel.writeString(opno)
        parcel.writeString(flowcarNo)
        parcel.writeString(mation)
        parcel.writeString(carframeNo)
        parcel.writeString(carModelNo)
        parcel.writeString(id)
        parcel.writeString(checkItemId)
        parcel.writeString(status)
        parcel.writeByte(if (configChange) 1 else 0)
        parcel.writeString(checkedBy)
        parcel.writeString(checkedDate)
        parcel.writeString(checkValue)
        parcel.writeString(checkRemarks)
        parcel.writeString(imgStr)
        parcel.writeString(orderNo)
        parcel.writeString(checkedItemsTotal)
        parcel.writeString(notCheckedItemsTotal)
        parcel.writeString(checkItemsTotal)
        parcel.writeString(hasProblem)
        parcel.writeString(gljybz)
    }

    override fun describeContents(): Int {
        return 0
    }

    companion object CREATOR : Parcelable.Creator<ConsoleProjectList> {
        override fun createFromParcel(parcel: Parcel): ConsoleProjectList {
            return ConsoleProjectList(parcel)
        }

        override fun newArray(size: Int): Array<ConsoleProjectList?> {
            return arrayOfNulls(size)
        }
    }


}