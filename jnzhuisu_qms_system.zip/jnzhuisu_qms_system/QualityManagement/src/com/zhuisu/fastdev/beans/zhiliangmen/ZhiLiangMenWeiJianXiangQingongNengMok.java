package com.zhuisu.fastdev.beans.zhiliangmen;

/**
 * @author cxh
 * @description
 * @date 2020/10/12.
 */
public class ZhiLiangMenWeiJianXiangQingongNengMok {
    private String id;
    private String value;
    private String label;
    private String type;
    private String description;

    public void setId(String id) {
        this.id = id;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public void setType(String type) {
        this.type = type;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getId() {
        return id;
    }

    public String getValue() {
        return value;
    }

    public String getLabel() {
        return label;
    }

    public String getType() {
        return type;
    }

    public String getDescription() {
        return description;
    }

    @Override
    public String toString() {
        return label;
    }
}
