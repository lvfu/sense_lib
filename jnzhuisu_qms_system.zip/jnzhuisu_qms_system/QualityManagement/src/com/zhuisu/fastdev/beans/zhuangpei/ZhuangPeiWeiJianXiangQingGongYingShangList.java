package com.zhuisu.fastdev.beans.zhuangpei;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * @author cxh
 * @description
 * @date 2020/10/12.
 */
public class ZhuangPeiWeiJianXiangQingGongYingShangList implements Parcelable {
    private String id;
    private String text;
    private String isNewRecord;

    public ZhuangPeiWeiJianXiangQingGongYingShangList() {
    }

    protected ZhuangPeiWeiJianXiangQingGongYingShangList(Parcel in) {
        id = in.readString();
        text = in.readString();
        isNewRecord = in.readString();
    }

    public static final Creator<ZhuangPeiWeiJianXiangQingGongYingShangList> CREATOR = new Creator<ZhuangPeiWeiJianXiangQingGongYingShangList>() {
        @Override
        public ZhuangPeiWeiJianXiangQingGongYingShangList createFromParcel(Parcel in) {
            return new ZhuangPeiWeiJianXiangQingGongYingShangList(in);
        }

        @Override
        public ZhuangPeiWeiJianXiangQingGongYingShangList[] newArray(int size) {
            return new ZhuangPeiWeiJianXiangQingGongYingShangList[size];
        }
    };

    public String getId() {
        return id;
    }

    public String getText() {
        return text;
    }

    public String getIsNewRecord() {
        return isNewRecord;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setText(String text) {
        this.text = text;
    }

    public void setIsNewRecord(String isNewRecord) {
        this.isNewRecord = isNewRecord;
    }

    @Override
    public String toString() {
        return text;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(id);
        dest.writeString(text);
        dest.writeString(isNewRecord);
    }
}
