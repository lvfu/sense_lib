package com.zhuisu.fastdev.beans.xiaxian;

/**
 * @author cxh
 * @description
 * @date 2020/10/12.
 */
public class ZhiLiangMenWeiJianXiangQingWuLiaoList {
    private String id;
    private String materielId;
    private String materielIdOld;
    private String materielName;
    private String barCode;

    public void setId(String id) {
        this.id = id;
    }

    public void setMaterielId(String materielId) {
        this.materielId = materielId;
    }

    public void setMaterielIdOld(String materielIdOld) {
        this.materielIdOld = materielIdOld;
    }

    public void setMaterielName(String materielName) {
        this.materielName = materielName;
    }

    public void setBarCode(String barCode) {
        this.barCode = barCode;
    }

    public String getId() {
        return id;
    }

    public String getMaterielId() {
        return materielId;
    }

    public String getMaterielIdOld() {
        return materielIdOld;
    }

    public String getMaterielName() {
        return materielName;
    }

    public String getBarCode() {
        return barCode;
    }

    @Override
    public String toString() {
       return materielName;
    }
}
