package com.zhuisu.fastdev.beans.xiaxian;

/**
 * @author cxh
 * @description
 * @date 2020/10/12.
 */
public class XiaXianWeiJianXiangQingBuMenList {
    private String code;
    private String name;
    private String dept;

    public void setDept(String dept) {
        this.dept = dept;
    }

    public String getDept() {
        return dept;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCode() {
        return code;
    }

    public String getName() {
        return name;
    }

    @Override
    public String toString() {
       return name;
    }
}
