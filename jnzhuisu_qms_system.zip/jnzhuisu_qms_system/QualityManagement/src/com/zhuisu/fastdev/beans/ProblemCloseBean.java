package com.zhuisu.fastdev.beans;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.List;

/**
 * @author cxh
 * @description
 * @date 2020/11/2.
 */

public class ProblemCloseBean implements Parcelable {

    /**
     * retCode : 0
     * retMessage : 获取数据成功
     * data : {"pageNo":1,"count":4,"pageSize":100,"list":[{"id":"776DF90A2E23472983A80D0616BF1FEB","isNewRecord":false,"createDate":"2020-10-26 13:34:00","problemSource":"offLineCheck","problemDesc":"张莉莉下线测试","peoblemTitle":"dddd","malfunctionCode":"q111","flowCarNo":"ABJK20080006/0030-0026","carFrameNo":"LA644780","assembleStation":"","carModelNo":"ZZ1317N306GE1/N7W8V30-标重","checkItemNo":"GXMC_2495","checkItemName":"安装空气悬架中后桥减震器","functionModel":"","occurTime":"2020-10-26 13:33:19","problemLevel":"","materiel":"","supplier":"","actualizeDept":"","problemRemarks":"","solution":"","fileName":"","filePath":"","offLineStatus":"submitcheck","depts":"NC.00.5009001003"},{"id":"0395DB32A0444040B46E8FD772D5C5D7","isNewRecord":false,"createDate":"2020-10-26 14:26:39","problemSource":"offLineCheck","problemDesc":"","peoblemTitle":"中桥管线漏气","malfunctionCode":"XSZQG54C","flowCarNo":"ABJK20080006/0030-0026","carFrameNo":"LA644780","assembleStation":"","carModelNo":"ZZ1317N306GE1/N7W8V30-标重","checkItemNo":"GXMC_2495","checkItemName":"安装空气悬架中后桥减震器","functionModel":"","occurTime":"2020-10-26 14:26:15","problemLevel":"C","materiel":"","supplier":"","actualizeDept":"","problemRemarks":"","solution":"[]","fileName":"","filePath":"","offLineStatus":"submitcheck","depts":"NC.00.5009001003"},{"id":"1564495DC1FC444ABC4DCC147974279D","isNewRecord":false,"createDate":"2020-10-31 13:41:10","problemSource":"offLineCheck","problemDesc":"","peoblemTitle":"2020年10月31日13:40:48测试责任部门","malfunctionCode":"BZXFX2511","flowCarNo":"ASSJ20080008/0010-0008","carFrameNo":"LJ177040","assembleStation":"gw001","carModelNo":"ZZ4185H3613E1/J7V7M36-标运质赢","checkItemNo":"XJ-02-02","checkItemName":"巡检-后桥做工检测","functionModel":"割台模块","occurTime":"2020-10-31 13:39:54","problemLevel":"D","materiel":"[020V47104-0024      ]同步件","supplier":"","malfunctionNumber":2,"actualizeDept":"","problemRemarks":"","solution":"","fileName":"","filePath":"","offLineStatus":"recheck","depts":"NC.00.5001,NC.00.5002"},{"id":"67313A9850314CA39664BB67774A4F1B","isNewRecord":false,"createDate":"2020-10-31 13:55:15","problemSource":"offLineCheck","problemDesc":"萨达是","peoblemTitle":"转向助力缸工作中有干涉","malfunctionCode":"BZXFX2511","flowCarNo":"JJNJ20080039/0001-0001","carFrameNo":"LJ177000","assembleStation":"gw001","carModelNo":"ZZ5185XXYN7113E1/J7V7M71-20标运","checkItemNo":"XJ-02-02","checkItemName":"巡检-后桥做工检测","functionModel":"润滑系统","occurTime":"2020-10-31 13:54:33","problemLevel":"","materiel":"[020V47104-0024/1    ]同步件（南京ZF）","supplier":"32.01.01052","malfunctionNumber":2,"actualizeDept":"NC.00.5004","problemRemarks":"","solution":"as大萨达asasas","fileName":"","filePath":"","offLineStatus":"submitcheck","depts":"NC.00.5003"}]}
     */


    /**
     * pageNo : 1
     * count : 4
     * pageSize : 100
     * list : [{"id":"776DF90A2E23472983A80D0616BF1FEB","isNewRecord":false,"createDate":"2020-10-26 13:34:00","problemSource":"offLineCheck","problemDesc":"张莉莉下线测试","peoblemTitle":"dddd","malfunctionCode":"q111","flowCarNo":"ABJK20080006/0030-0026","carFrameNo":"LA644780","assembleStation":"","carModelNo":"ZZ1317N306GE1/N7W8V30-标重","checkItemNo":"GXMC_2495","checkItemName":"安装空气悬架中后桥减震器","functionModel":"","occurTime":"2020-10-26 13:33:19","problemLevel":"","materiel":"","supplier":"","actualizeDept":"","problemRemarks":"","solution":"","fileName":"","filePath":"","offLineStatus":"submitcheck","depts":"NC.00.5009001003"},{"id":"0395DB32A0444040B46E8FD772D5C5D7","isNewRecord":false,"createDate":"2020-10-26 14:26:39","problemSource":"offLineCheck","problemDesc":"","peoblemTitle":"中桥管线漏气","malfunctionCode":"XSZQG54C","flowCarNo":"ABJK20080006/0030-0026","carFrameNo":"LA644780","assembleStation":"","carModelNo":"ZZ1317N306GE1/N7W8V30-标重","checkItemNo":"GXMC_2495","checkItemName":"安装空气悬架中后桥减震器","functionModel":"","occurTime":"2020-10-26 14:26:15","problemLevel":"C","materiel":"","supplier":"","actualizeDept":"","problemRemarks":"","solution":"[]","fileName":"","filePath":"","offLineStatus":"submitcheck","depts":"NC.00.5009001003"},{"id":"1564495DC1FC444ABC4DCC147974279D","isNewRecord":false,"createDate":"2020-10-31 13:41:10","problemSource":"offLineCheck","problemDesc":"","peoblemTitle":"2020年10月31日13:40:48测试责任部门","malfunctionCode":"BZXFX2511","flowCarNo":"ASSJ20080008/0010-0008","carFrameNo":"LJ177040","assembleStation":"gw001","carModelNo":"ZZ4185H3613E1/J7V7M36-标运质赢","checkItemNo":"XJ-02-02","checkItemName":"巡检-后桥做工检测","functionModel":"割台模块","occurTime":"2020-10-31 13:39:54","problemLevel":"D","materiel":"[020V47104-0024      ]同步件","supplier":"","malfunctionNumber":2,"actualizeDept":"","problemRemarks":"","solution":"","fileName":"","filePath":"","offLineStatus":"recheck","depts":"NC.00.5001,NC.00.5002"},{"id":"67313A9850314CA39664BB67774A4F1B","isNewRecord":false,"createDate":"2020-10-31 13:55:15","problemSource":"offLineCheck","problemDesc":"萨达是","peoblemTitle":"转向助力缸工作中有干涉","malfunctionCode":"BZXFX2511","flowCarNo":"JJNJ20080039/0001-0001","carFrameNo":"LJ177000","assembleStation":"gw001","carModelNo":"ZZ5185XXYN7113E1/J7V7M71-20标运","checkItemNo":"XJ-02-02","checkItemName":"巡检-后桥做工检测","functionModel":"润滑系统","occurTime":"2020-10-31 13:54:33","problemLevel":"","materiel":"[020V47104-0024/1    ]同步件（南京ZF）","supplier":"32.01.01052","malfunctionNumber":2,"actualizeDept":"NC.00.5004","problemRemarks":"","solution":"as大萨达asasas","fileName":"","filePath":"","offLineStatus":"submitcheck","depts":"NC.00.5003"}]
     */

    /**
     * id : 776DF90A2E23472983A80D0616BF1FEB
     * isNewRecord : false
     * createDate : 2020-10-26 13:34:00
     * problemSource : offLineCheck
     * problemDesc : 张莉莉下线测试
     * peoblemTitle : dddd
     * malfunctionCode : q111
     * flowCarNo : ABJK20080006/0030-0026
     * carFrameNo : LA644780
     * assembleStation :
     * carModelNo : ZZ1317N306GE1/N7W8V30-标重
     * checkItemNo : GXMC_2495
     * checkItemName : 安装空气悬架中后桥减震器
     * functionModel :
     * occurTime : 2020-10-26 13:33:19
     * problemLevel :
     * materiel :
     * supplier :
     * actualizeDept :
     * problemRemarks :
     * solution :
     * fileName :
     * filePath :
     * offLineStatus : submitcheck
     * depts : NC.00.5009001003
     * malfunctionNumber : 2
     */

    private String id;
    private Boolean isNewRecord;
    private String createDate;
    private String problemSource;
    private String problemDesc;
    private String peoblemTitle;
    private String malfunctionCode;
    private String flowCarNo;
    private String carFrameNo;
    private String assembleStation;
    private String carModelNo;
    private String checkItemNo;
    private String checkItemName;
    private String functionModel;
    private String occurTime;
    private String problemLevel;
    private String materiel;
    private String supplier;
    private String actualizeDept;
    private String problemRemarks;
    private String solution;
    private String fileName;
    private String filePath;
    private String offLineStatus;
    private String depts;
    private Integer malfunctionNumber;
    private String isClose;
    private String createBy;
    private String addRemarks;

    public void setAddRemarks(String addRemarks) {
        this.addRemarks = addRemarks;
    }

    public String getAddRemarks() {
        return addRemarks;
    }

    public void setCreateBy(String createBy) {
        this.createBy = createBy;
    }

    public String getCreateBy() {
        return createBy;
    }

    public static Creator<ProblemCloseBean> getCREATOR() {
        return CREATOR;
    }

    public void setIsClose(String isClose) {
        this.isClose = isClose;
    }

    public String getIsClose() {
        return isClose;
    }

    public ProblemCloseBean() {
    }

    protected ProblemCloseBean(Parcel in) {


        id = in.readString();
        byte tmpIsNewRecord = in.readByte();
        isNewRecord = tmpIsNewRecord == 0 ? null : tmpIsNewRecord == 1;
        createDate = in.readString();
        problemSource = in.readString();
        problemDesc = in.readString();
        peoblemTitle = in.readString();
        malfunctionCode = in.readString();
        flowCarNo = in.readString();
        carFrameNo = in.readString();
        assembleStation = in.readString();
        carModelNo = in.readString();
        checkItemNo = in.readString();
        checkItemName = in.readString();
        functionModel = in.readString();
        occurTime = in.readString();
        problemLevel = in.readString();
        materiel = in.readString();
        supplier = in.readString();
        actualizeDept = in.readString();
        problemRemarks = in.readString();
        solution = in.readString();
        fileName = in.readString();
        filePath = in.readString();
        offLineStatus = in.readString();
        depts = in.readString();
        if (in.readByte() == 0) {
            malfunctionNumber = null;
        } else {
            malfunctionNumber = in.readInt();
        }
        addRemarks = in.readString();
    }

    public static final Creator<ProblemCloseBean> CREATOR = new Creator<ProblemCloseBean>() {
        @Override
        public ProblemCloseBean createFromParcel(Parcel in) {
            return new ProblemCloseBean(in);
        }

        @Override
        public ProblemCloseBean[] newArray(int size) {
            return new ProblemCloseBean[size];
        }
    };

    public void setId(String id) {
        this.id = id;
    }

    public void setNewRecord(Boolean newRecord) {
        isNewRecord = newRecord;
    }

    public void setCreateDate(String createDate) {
        this.createDate = createDate;
    }

    public void setProblemSource(String problemSource) {
        this.problemSource = problemSource;
    }

    public void setProblemDesc(String problemDesc) {
        this.problemDesc = problemDesc;
    }

    public void setPeoblemTitle(String peoblemTitle) {
        this.peoblemTitle = peoblemTitle;
    }

    public void setMalfunctionCode(String malfunctionCode) {
        this.malfunctionCode = malfunctionCode;
    }

    public void setFlowCarNo(String flowCarNo) {
        this.flowCarNo = flowCarNo;
    }

    public void setCarFrameNo(String carFrameNo) {
        this.carFrameNo = carFrameNo;
    }

    public void setAssembleStation(String assembleStation) {
        this.assembleStation = assembleStation;
    }

    public void setCarModelNo(String carModelNo) {
        this.carModelNo = carModelNo;
    }

    public void setCheckItemNo(String checkItemNo) {
        this.checkItemNo = checkItemNo;
    }

    public void setCheckItemName(String checkItemName) {
        this.checkItemName = checkItemName;
    }

    public void setFunctionModel(String functionModel) {
        this.functionModel = functionModel;
    }

    public void setOccurTime(String occurTime) {
        this.occurTime = occurTime;
    }

    public void setProblemLevel(String problemLevel) {
        this.problemLevel = problemLevel;
    }

    public void setMateriel(String materiel) {
        this.materiel = materiel;
    }

    public void setSupplier(String supplier) {
        this.supplier = supplier;
    }

    public void setActualizeDept(String actualizeDept) {
        this.actualizeDept = actualizeDept;
    }

    public void setProblemRemarks(String problemRemarks) {
        this.problemRemarks = problemRemarks;
    }

    public void setSolution(String solution) {
        this.solution = solution;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }

    public void setOffLineStatus(String offLineStatus) {
        this.offLineStatus = offLineStatus;
    }

    public void setDepts(String depts) {
        this.depts = depts;
    }

    public void setMalfunctionNumber(Integer malfunctionNumber) {
        this.malfunctionNumber = malfunctionNumber;
    }

    public String getId() {
        return id;
    }

    public Boolean getNewRecord() {
        return isNewRecord;
    }

    public String getCreateDate() {
        return createDate;
    }

    public String getProblemSource() {
        return problemSource;
    }

    public String getProblemDesc() {
        return problemDesc;
    }

    public String getPeoblemTitle() {
        return peoblemTitle;
    }

    public String getMalfunctionCode() {
        return malfunctionCode;
    }

    public String getFlowCarNo() {
        return flowCarNo;
    }

    public String getCarFrameNo() {
        return carFrameNo;
    }

    public String getAssembleStation() {
        return assembleStation;
    }

    public String getCarModelNo() {
        return carModelNo;
    }

    public String getCheckItemNo() {
        return checkItemNo;
    }

    public String getCheckItemName() {
        return checkItemName;
    }

    public String getFunctionModel() {
        return functionModel;
    }

    public String getOccurTime() {
        return occurTime;
    }

    public String getProblemLevel() {
        return problemLevel;
    }

    public String getMateriel() {
        return materiel;
    }

    public String getSupplier() {
        return supplier;
    }

    public String getActualizeDept() {
        return actualizeDept;
    }

    public String getProblemRemarks() {
        return problemRemarks;
    }

    public String getSolution() {
        return solution;
    }

    public String getFileName() {
        return fileName;
    }

    public String getFilePath() {
        return filePath;
    }

    public String getOffLineStatus() {
        return offLineStatus;
    }

    public String getDepts() {
        return depts;
    }

    public Integer getMalfunctionNumber() {
        return malfunctionNumber;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(id);
        dest.writeByte((byte) (isNewRecord == null ? 0 : isNewRecord ? 1 : 2));
        dest.writeString(createDate);
        dest.writeString(problemSource);
        dest.writeString(problemDesc);
        dest.writeString(peoblemTitle);
        dest.writeString(malfunctionCode);
        dest.writeString(flowCarNo);
        dest.writeString(carFrameNo);
        dest.writeString(assembleStation);
        dest.writeString(carModelNo);
        dest.writeString(checkItemNo);
        dest.writeString(checkItemName);
        dest.writeString(functionModel);
        dest.writeString(occurTime);
        dest.writeString(problemLevel);
        dest.writeString(materiel);
        dest.writeString(supplier);
        dest.writeString(actualizeDept);
        dest.writeString(problemRemarks);
        dest.writeString(solution);
        dest.writeString(fileName);
        dest.writeString(filePath);
        dest.writeString(offLineStatus);
        dest.writeString(depts);
        if (malfunctionNumber == null) {
            dest.writeByte((byte) 0);
        } else {
            dest.writeByte((byte) 1);
            dest.writeInt(malfunctionNumber);
        }
        dest.writeString(addRemarks);
    }

}
