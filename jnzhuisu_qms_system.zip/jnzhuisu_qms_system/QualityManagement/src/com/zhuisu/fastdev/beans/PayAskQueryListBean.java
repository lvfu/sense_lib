package com.zhuisu.fastdev.beans;

/**
 * @author cxh
 * @description
 * @date 2021/4/14.
 */
public class PayAskQueryListBean {
    private String id;
    private String createDate;
    private String updateDate;
    private String billCode;
    private String checktaskid;
    private String receiveBillcode;
    private String materialCode;
    private String itemName;
    private String receiveDate;
    private String checkUser;
    private String supplierName;
    private String supplierNo;
    private String checkTime;
    private String checkResult;
    private String datasource;
    private String checkposition;
    private String submitCheckNum;

    public void setCreateDate(String createDate) {
        this.createDate = createDate;
    }

    public void setUpdateDate(String updateDate) {
        this.updateDate = updateDate;
    }

    public void setBillCode(String billCode) {
        this.billCode = billCode;
    }

    public void setChecktaskid(String checktaskid) {
        this.checktaskid = checktaskid;
    }

    public void setReceiveBillcode(String receiveBillcode) {
        this.receiveBillcode = receiveBillcode;
    }

    public void setMaterialCode(String materialCode) {
        this.materialCode = materialCode;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public void setReceiveDate(String receiveDate) {
        this.receiveDate = receiveDate;
    }

    public void setCheckUser(String checkUser) {
        this.checkUser = checkUser;
    }

    public void setSupplierName(String supplierName) {
        this.supplierName = supplierName;
    }

    public void setSupplierNo(String supplierNo) {
        this.supplierNo = supplierNo;
    }

    public void setCheckTime(String checkTime) {
        this.checkTime = checkTime;
    }

    public void setCheckResult(String checkResult) {
        this.checkResult = checkResult;
    }

    public void setDatasource(String datasource) {
        this.datasource = datasource;
    }

    public void setCheckposition(String checkposition) {
        this.checkposition = checkposition;
    }

    public void setSubmitCheckNum(String submitCheckNum) {
        this.submitCheckNum = submitCheckNum;
    }

    public String getSubmitCheckNum() {
        return submitCheckNum;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    public String getCreateDate() {
        return createDate;
    }

    public String getUpdateDate() {
        return updateDate;
    }

    public String getBillCode() {
        return billCode;
    }

    public String getChecktaskid() {
        return checktaskid;
    }

    public String getReceiveBillcode() {
        return receiveBillcode;
    }

    public String getMaterialCode() {
        return materialCode;
    }

    public String getItemName() {
        return itemName;
    }

    public String getReceiveDate() {
        return receiveDate;
    }

    public String getCheckUser() {
        return checkUser;
    }

    public String getSupplierName() {
        return supplierName;
    }

    public String getSupplierNo() {
        return supplierNo;
    }

    public String getCheckTime() {
        return checkTime;
    }

    public String getCheckResult() {
        return checkResult;
    }

    public String getDatasource() {
        return datasource;
    }

    public String getCheckposition() {
        return checkposition;
    }
}
