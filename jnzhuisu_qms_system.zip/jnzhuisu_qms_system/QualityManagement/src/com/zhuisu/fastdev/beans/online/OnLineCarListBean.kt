package com.zhuisu.fastdev.beans.online

import android.os.Parcel
import android.os.Parcelable

/**
 * @author lxf
 * @description
 * @date 2020/11/9.
 */
data class OnLineCarListBean(var id: String?,
                             var flowCarNo: String?,
                             var carFrameNo: String?,
                             var offLineStatus: String?,
                             var orderNo : String?,
                             var carModelNo : String?,
                             var startTime : String? ,
                             var endTime : String?,
                             var configDesc : String?,
                             var status : String?) : Parcelable {
    constructor(parcel: Parcel) : this(
            parcel.readString(),
            parcel.readString(),
            parcel.readString(),
            parcel.readString(),
            parcel.readString(),
            parcel.readString(),
            parcel.readString(),
            parcel.readString(),
            parcel.readString(),
            parcel.readString())

    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeString(id)
        parcel.writeString(flowCarNo)
        parcel.writeString(carFrameNo)
        parcel.writeString(offLineStatus)
        parcel.writeString(orderNo)
        parcel.writeString(carModelNo)
        parcel.writeString(startTime)
        parcel.writeString(endTime)
        parcel.writeString(configDesc)
        parcel.writeString(status)
    }

    override fun describeContents(): Int {
        return 0
    }

    companion object CREATOR : Parcelable.Creator<OnLineCarListBean> {
        override fun createFromParcel(parcel: Parcel): OnLineCarListBean {
            return OnLineCarListBean(parcel)
        }

        override fun newArray(size: Int): Array<OnLineCarListBean?> {
            return arrayOfNulls(size)
        }
    }
}