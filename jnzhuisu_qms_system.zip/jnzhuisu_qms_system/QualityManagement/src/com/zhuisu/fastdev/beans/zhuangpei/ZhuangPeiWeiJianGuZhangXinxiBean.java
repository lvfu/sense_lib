package com.zhuisu.fastdev.beans.zhuangpei;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * @author cxh
 * @description
 * @date 2020/10/12.
 */
public class ZhuangPeiWeiJianGuZhangXinxiBean implements Parcelable {
    private String malfunctionLevel;
    private String malfunctionNo;
    private String malfunctionName;
    private String malfunctionType;

    protected ZhuangPeiWeiJianGuZhangXinxiBean(Parcel in) {
        malfunctionLevel = in.readString();
        malfunctionNo = in.readString();
        malfunctionName = in.readString();
        malfunctionType = in.readString();
    }

    public static final Creator<ZhuangPeiWeiJianGuZhangXinxiBean> CREATOR = new Creator<ZhuangPeiWeiJianGuZhangXinxiBean>() {
        @Override
        public ZhuangPeiWeiJianGuZhangXinxiBean createFromParcel(Parcel in) {
            return new ZhuangPeiWeiJianGuZhangXinxiBean(in);
        }

        @Override
        public ZhuangPeiWeiJianGuZhangXinxiBean[] newArray(int size) {
            return new ZhuangPeiWeiJianGuZhangXinxiBean[size];
        }
    };

    public void setMalfunctionType(String malfunctionType) {
        this.malfunctionType = malfunctionType;
    }

    public String getMalfunctionType() {
        return malfunctionType;
    }

    public void setMalfunctionLevel(String malfunctionLevel) {
        this.malfunctionLevel = malfunctionLevel;
    }

    public void setMalfunctionNo(String malfunctionNo) {
        this.malfunctionNo = malfunctionNo;
    }

    public void setMalfunctionName(String malfunctionName) {
        this.malfunctionName = malfunctionName;
    }

    public String getMalfunctionLevel() {
        return malfunctionLevel;
    }

    public String getMalfunctionNo() {
        return malfunctionNo;
    }

    public String getMalfunctionName() {
        return malfunctionName;
    }

    @Override
    public String toString() {
        return malfunctionName+"-"+malfunctionLevel;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(malfunctionLevel);
        dest.writeString(malfunctionNo);
        dest.writeString(malfunctionName);
        dest.writeString(malfunctionType);
    }
}
