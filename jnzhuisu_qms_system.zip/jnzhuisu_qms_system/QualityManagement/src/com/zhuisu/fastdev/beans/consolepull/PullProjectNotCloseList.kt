package com.zhuisu.fastdev.beans.consolepull

/**
 * @author cxh
 * @description
 * @date 2020/11/12.
 */
data class PullProjectNotCloseList(var id : String, var peoblemTitle: String?, var problemDesc : String?, var malfunctionCode : String?, var problemLevel : String?, var result : String?,var carFrameNo : String?)