package com.zhuisu.fastdev.beans.xiaxian;

public class MaxBean {
    private int code;
    private String codeName;

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getCodeName() {
        return codeName;
    }

    public void setCodeName(String codeName) {
        this.codeName = codeName;
    }

    @Override
    public String toString() {
        return codeName;
    }
}
