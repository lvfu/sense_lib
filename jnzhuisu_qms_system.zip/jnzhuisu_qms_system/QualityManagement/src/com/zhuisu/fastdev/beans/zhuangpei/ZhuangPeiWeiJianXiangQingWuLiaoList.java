package com.zhuisu.fastdev.beans.zhuangpei;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * @author cxh
 * @description
 * @date 2020/10/12.
 */
public class ZhuangPeiWeiJianXiangQingWuLiaoList implements Parcelable {
    private String id;
    private String materielId;
    private String materielIdOld;
    private String materielName;
    private String barCode;
    private String supplierName;
    private String supplierNo;
    private String unit;

    public void setUnit(String unit) {
        this.unit = unit;
    }

    public String getUnit() {
        return unit;
    }

    public void setSupplierName(String supplierName) {
        this.supplierName = supplierName;
    }

    public void setSupplierNo(String supplierNo) {
        this.supplierNo = supplierNo;
    }

    public String getSupplierName() {
        return supplierName;
    }

    public String getSupplierNo() {
        return supplierNo;
    }

    protected ZhuangPeiWeiJianXiangQingWuLiaoList(Parcel in) {
        id = in.readString();
        materielId = in.readString();
        materielIdOld = in.readString();
        materielName = in.readString();
        barCode = in.readString();
        supplierName = in.readString();
        supplierNo = in.readString();
        unit = in.readString();
    }

    public static final Creator<ZhuangPeiWeiJianXiangQingWuLiaoList> CREATOR = new Creator<ZhuangPeiWeiJianXiangQingWuLiaoList>() {
        @Override
        public ZhuangPeiWeiJianXiangQingWuLiaoList createFromParcel(Parcel in) {
            return new ZhuangPeiWeiJianXiangQingWuLiaoList(in);
        }

        @Override
        public ZhuangPeiWeiJianXiangQingWuLiaoList[] newArray(int size) {
            return new ZhuangPeiWeiJianXiangQingWuLiaoList[size];
        }
    };

    public void setId(String id) {
        this.id = id;
    }

    public void setMaterielId(String materielId) {
        this.materielId = materielId;
    }

    public void setMaterielIdOld(String materielIdOld) {
        this.materielIdOld = materielIdOld;
    }

    public void setMaterielName(String materielName) {
        this.materielName = materielName;
    }

    public void setBarCode(String barCode) {
        this.barCode = barCode;
    }

    public String getId() {
        return id;
    }

    public String getMaterielId() {
        return materielId;
    }

    public String getMaterielIdOld() {
        return materielIdOld;
    }

    public String getMaterielName() {
        return materielName;
    }

    public String getBarCode() {
        return barCode;
    }

    @Override
    public String toString() {
       return materielName;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(id);
        dest.writeString(materielId);
        dest.writeString(materielIdOld);
        dest.writeString(materielName);
        dest.writeString(barCode);
        dest.writeString(supplierName);
        dest.writeString(supplierNo);
        dest.writeString(unit);
    }
}
