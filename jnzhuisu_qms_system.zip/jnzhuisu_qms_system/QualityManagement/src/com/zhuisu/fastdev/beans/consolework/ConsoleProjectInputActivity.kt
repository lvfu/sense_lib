package com.zhuisu.fastdev.beans.consolework

import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.*
import android.provider.MediaStore
import android.support.v4.content.FileProvider
import android.text.TextUtils
import android.util.ArrayMap
import android.util.Log
import android.view.View
import android.widget.*
import com.bumptech.glide.Glide
import com.google.gson.reflect.TypeToken
import com.zhuisu.fastdev.BaseActivity
import com.zhuisu.fastdev.beans.xiaxian.XiaXianWeiJianXiangQingBuMenList
import com.zhuisu.fastdev.beans.xiaxian.XiaXianWeiJianXiangQingongNengMok
import com.zhuisu.fastdev.beans.xunjian.XunJianWeiJianMingXiListBean
import com.zhuisu.fastdev.beans.zhuangpei.ZhuangPeiWeiJianGuZhangXinxiBean
import com.zhuisu.fastdev.beans.zhuangpei.ZhuangPeiWeiJianXiangQingGongYingShangList
import com.zhuisu.fastdev.beans.zhuangpei.ZhuangPeiWeiJianXiangQingWuLiaoList
import com.zhuisu.fastdev.ui.problem.OffLineProblemListActivity
import com.zhuisu.fastdev.ui.util.LogUtils
import com.zhuisu.fastdev.ui.zhuangpei.SelectGongYingShangActivity
import com.zhuisu.fastdev.ui.zhuangpei.SelectItemActivity
import com.zhuisu.fastdev.ui.zhuangpei.SelectWuLiaoActivity
import com.zhuisu.qualityManagement.R
import com.zhuisu.suppliermanagement.util.FileUtil
import com.zhuisu.suppliermanagement.util.GlobalVar
import com.zhuisu.suppliermanagement.util.ToastUtils
import com.zhuisu.suppliermanagement.util.Util
import okhttp3.*
import org.json.JSONException
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.*

/**
 * 录入问题
 */
class ConsoleProjectInputActivity : BaseActivity() {
    private var data: ConsoleProjectList? = null
    private var spTitle: TextView? = null//标题
    private var spFunction: Spinner? = null //功能模块
    private var spGongYing: TextView? = null //供应商
    private var spWuLiao: TextView? = null //物料
    private var sp_dept: Spinner? = null
    private var etLevel: EditText? = null//问题等级
    private var etForm: EditText? = null  //问题来源
    private var etNumber: EditText? = null //故障数量
    private var etInfo: EditText? = null //问题描述
    private var etRemark: EditText? = null //问题备注
    private var showimage: ImageView? = null //显示的照片
    private var qingongNengMokList: List<XiaXianWeiJianXiangQingongNengMok>? = null //功能模块
    private var buMenLists: List<XiaXianWeiJianXiangQingBuMenList>? = null
    private var et_check_number: EditText? = null //检验值
    private var et_check_info: EditText? = null //检验备注
    private var status: String? = ""
    private var checkValueImage: ImageView? = null  //检验值的照片



    @SuppressLint("SetTextI18n")
    override fun initViews() {


        spTitle = findViewById(R.id.sp_wt_title)
        spFunction = findViewById(R.id.sp_function)
        spGongYing = findViewById(R.id.sp_gongyingshang)
        spWuLiao = findViewById(R.id.sp_wuliao)
        sp_dept = findViewById(R.id.sp_dept)
        etLevel = findViewById(R.id.tv_question_level)
        etForm = findViewById(R.id.et_wentilaiyuan)
        etInfo = findViewById(R.id.et_wentimiaoshu)
        etNumber = findViewById(R.id.et_guzhangshuliang)
        etRemark = findViewById(R.id.et_wenti_beizhu)
        showimage = findViewById(R.id.showimage)
        findViewById<View>(R.id.btn_submit_sun).setOnClickListener { submit() }
        findViewById<View>(R.id.iv_select_image).setOnClickListener {
            isCheckValue = false
            selectImage()
        }
        spTitle!!.setOnClickListener {
            val intent = Intent(context, SelectItemActivity::class.java)
            startActivityForResult(intent, 0x11)
        }
        spGongYing!!.setOnClickListener {
            val intent = Intent(context, SelectGongYingShangActivity::class.java)
            startActivityForResult(intent, 0x12)
        }
        spWuLiao!!.setOnClickListener {
            val intent = Intent(context, SelectWuLiaoActivity::class.java)
            startActivityForResult(intent, 0x13)
        }

        et_check_number = findViewById(R.id.et_check_number)
        checkValueImage = findViewById(R.id.showimage1)
        et_check_info = findViewById(R.id.et_check_info)

        findViewById<View>(R.id.iv_select_image1).setOnClickListener {
            isCheckValue = true
            selectImage1()
        }

        findViewById<Button>(R.id.btn_submit_value).setOnClickListener{
            submitValue()
        }

        if (intent != null && intent.hasExtra(ACTION_DATA)) {
            data = intent.getParcelableExtra(ACTION_DATA)
            val tv_name1 = findViewById<TextView>(R.id.tv_name1)
            val tv_name2 = findViewById<TextView>(R.id.tv_name2)
            val tv_name3 = findViewById<TextView>(R.id.tv_name3)
            val tv_name4 = findViewById<TextView>(R.id.tv_name4)
            val tv_name5 = findViewById<TextView>(R.id.tv_name5)
            tv_name1.text = "" + data!!.opnm
            tv_name2.text = "" + data!!.opno
            tv_name3.text = "" + data!!.mation
            tv_name4.text = "" + ("" + if (data!!.status == "passed") "合格" else if (data!!.status == "failed") "不合格" else if (data!!.status == "noCheck") "免检" else "待检验")
            tv_name5.text = "" + data!!.flowcarNo
            queryFunction()
            queryDept()
            queryDetailData()
        }


        if (intent != null && intent.getStringExtra(ACTION_FIRST_DATA) != null){
            status = intent.getStringExtra(ACTION_FIRST_DATA)
        }

        //问题列表
        findViewById<Button>(R.id.btn_ask_list).setOnClickListener {
            val intent = Intent(context, OffLineProblemListActivity::class.java)
            intent.putExtra(OffLineProblemListActivity.ACTION_PARAMS,data?.carframeNo)
            intent.putExtra(OffLineProblemListActivity.ACTION_ID,data?.opno)
            startActivity(intent)
        }
    }

    override fun getResId(): Int {
        return R.layout.activity_console_project_input
    }

    //查询检验值
    private fun queryDetailData() {
        val map = ArrayMap<String, String>()
        map["id"] = data!!.id
        val param = gson.toJson(map)
        val client = OkHttpClient()
        val requestBody = RequestBody.create(JSON, param)
        val request = Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/prduictionrelation/qmsManufactureProductionplanrelation/api/getCheckItemDetail")
                .build()
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.d(TAG, "onFailure: 失败")
            }

            @Throws(IOException::class)
            override fun onResponse(call: Call, response: Response) {
                val result = response.body()!!.string()

                runOnUiThread {
                    try {
                        Log.d(TAG, "onResponse: 明细$result")
                        val jsonObject = JSONObject(result)
                        if (jsonObject.optString("retCode") == "0") {
                            //成功
                            val bean = gson.fromJson(jsonObject.optString("data"), XunJianWeiJianMingXiListBean::class.java)
                            if (bean.checkValue != null){
                                et_check_number!!.setText(bean.checkValue.toString())
                            }

                            if (bean.checkRemarks != null){
                                et_check_info!!.setText(bean.checkRemarks.toString())
                            }

                            if (bean.imgStr != null && !TextUtils.isEmpty(bean.imgStr)){
                                checkValueImage?.setImageBitmap(base64ToBitmap(bean.imgStr))
                            }

                        }
                    } catch (e: JSONException) {
                        e.printStackTrace()
                    }
                }
            }
        })
    }

    /**
     * 选择照片
     */
    var alertdialog: AlertDialog? = null
    var uploadFilePath: String? = null
    var checkImageStr : String? = null
    private val IMAGE_CODE = 200 //
    var isCheckValue = false


    private fun selectImage1() {
        var imageUri : Uri? = null
        alertdialog = Util.getDialog(context, "选择图像", 0, { arg0, view, position, arg3 ->
            if (alertdialog!!.isShowing) {
                alertdialog!!.dismiss()
            }
            val f: File?
            val uri: Uri?
            when (position) {
                0 -> {
                    val capimgIntent = Intent()
                    val fileName: String = SimpleDateFormat("yyyyMMddHHmmss", Locale.CHINA).format(Date()) + ".jpg"
                    FileUtil.checkDir(fileDir + "_/")
                    f = File(fileDir + "_", fileName)
                    checkImageStr = fileDir + "_/" + fileName
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                        // 7.0+以上版本
                        //与manifest中定义的provider中的authorities="cn.wlantv.kznk.fileprovider"保持一致
                        imageUri = FileProvider.getUriForFile(this, "com.jnqms.fileprovider", f)
                        capimgIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    } else {
                        imageUri = Uri.fromFile(f)
                    }
                    capimgIntent.putExtra(MediaStore.EXTRA_OUTPUT, imageUri)
                    capimgIntent.action = MediaStore.ACTION_IMAGE_CAPTURE
                    capimgIntent.addCategory(Intent.CATEGORY_DEFAULT)

                    startActivityForResult(capimgIntent, 1)
                }
                1 -> {
                    val intent = Intent(Intent.ACTION_GET_CONTENT)
                    intent.type = "image/*"
                    intent.addCategory(Intent.CATEGORY_OPENABLE)
                    try {
                        startActivityForResult(Intent.createChooser(intent, "Select a File to Upload"),
                                IMAGE_CODE)
                    } catch (ex: ActivityNotFoundException) {
                        Toast.makeText(context, "Please install a File Manager.", Toast.LENGTH_SHORT)
                                .show()
                    }
                }
                else -> {
                }
            }
        }, arrayOf("拍照", "文件"), arrayOf(R.drawable.i_camera, R.drawable.i_image))
        alertdialog!!.show()
    }

    private fun selectImage() {
        var imageUri : Uri? = null
        alertdialog = Util.getDialog(context, "选择图像", 0, { arg0, view, position, arg3 ->
            if (alertdialog!!.isShowing) {
                alertdialog!!.dismiss()
            }
            val f: File?
            val uri: Uri?
            when (position) {
                0 -> {
                    val capimgIntent = Intent()
                    val fileName: String = SimpleDateFormat("yyyyMMddHHmmss", Locale.CHINA).format(Date()) + ".jpg"
                    FileUtil.checkDir(fileDir + "_/")
                    f = File(fileDir + "_", fileName)
                    uploadFilePath = fileDir + "_/" + fileName
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                        // 7.0+以上版本
                        //与manifest中定义的provider中的authorities="cn.wlantv.kznk.fileprovider"保持一致
                        imageUri = FileProvider.getUriForFile(this, "com.jnqms.fileprovider", f)
                        capimgIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    } else {
                        imageUri = Uri.fromFile(f)
                    }
                    capimgIntent.putExtra(MediaStore.EXTRA_OUTPUT, imageUri)
                    capimgIntent.action = MediaStore.ACTION_IMAGE_CAPTURE
                    capimgIntent.addCategory(Intent.CATEGORY_DEFAULT)

                    startActivityForResult(capimgIntent, 1)
                }
                1 -> {
                    val intent = Intent(Intent.ACTION_GET_CONTENT)
                    intent.type = "image/*"
                    intent.addCategory(Intent.CATEGORY_OPENABLE)
                    try {
                        startActivityForResult(Intent.createChooser(intent, "Select a File to Upload"),
                                IMAGE_CODE)
                    } catch (ex: ActivityNotFoundException) {
                        Toast.makeText(context, "Please install a File Manager.", Toast.LENGTH_SHORT)
                                .show()
                    }
                }
                else -> {
                }
            }
        }, arrayOf("拍照", "文件"), arrayOf(R.drawable.i_camera, R.drawable.i_image))
        alertdialog!!.show()
    }

    private var zhuangPeiWeiJianGuZhangXinxiBean: ZhuangPeiWeiJianGuZhangXinxiBean? = null
    private var zhuangPeiWeiJianXiangQingWuLiaoList: ZhuangPeiWeiJianXiangQingWuLiaoList? = null
    private var zhuangPeiWeiJianXiangQingGongYingShangList: ZhuangPeiWeiJianXiangQingGongYingShangList? = null
    public override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == RESULT_OK && requestCode == IMAGE_CODE) {
            // 选择文件
            if (data == null) return
            val path: String = FileUtil.getImageAbsolutePath(context as Activity, data) ?: return
            if (isCheckValue){
                checkImageStr = path
                Glide.with(context).load(path).into(checkValueImage!!)
            }else{
                uploadFilePath = path
                showimage?.visibility = View.VISIBLE
                Glide.with(context).load(path).into(showimage!!)
            }

        } else if (requestCode == 1 && resultCode == RESULT_OK) {
            if (isCheckValue){
                Glide.with(context).load(checkImageStr).into(checkValueImage!!)
            }else{
                showimage?.visibility = View.VISIBLE
                Glide.with(context).load(uploadFilePath).into(showimage!!)
            }

        } else if (resultCode == 0x18) {
            if (data!!.getParcelableExtra<Parcelable?>("data") != null) {
                zhuangPeiWeiJianGuZhangXinxiBean = data.getParcelableExtra("data")
                Log.e("获取数据", zhuangPeiWeiJianGuZhangXinxiBean!!.malfunctionName)
                spTitle!!.text = zhuangPeiWeiJianGuZhangXinxiBean!!.malfunctionName
                etLevel!!.setText(zhuangPeiWeiJianGuZhangXinxiBean!!.malfunctionLevel)
            }
        } else if (resultCode == 0x19) {
            if (data!!.getParcelableExtra<Parcelable?>("data") != null) {
                zhuangPeiWeiJianXiangQingWuLiaoList = data.getParcelableExtra("data")
                spWuLiao!!.text = zhuangPeiWeiJianXiangQingWuLiaoList!!.materielName
            }
        } else if (resultCode == 0x20) {
            if (data!!.getParcelableExtra<Parcelable?>("data") != null) {
                zhuangPeiWeiJianXiangQingGongYingShangList = data.getParcelableExtra("data")
                spGongYing!!.text = zhuangPeiWeiJianXiangQingGongYingShangList!!.text
            }
        }
    }



    /***
     * 提交检验结果
     *
     */
    private fun submitValue() {
        val map = ArrayMap<String, String>()
        map["id"] = data!!.id
        map["checkValue"] = et_check_number!!.text.toString()
        map["checkRemarks"] = et_check_info!!.text.toString()
        if (checkImageStr == null || checkImageStr!!.isEmpty()) {
            map["imgStr"] = ""
        } else {
            map["imgStr"] = bitmapToBase64(getLoacalBitmap(checkImageStr))
        }

        val param = gson.toJson(map)
        LogUtils.printDebug(param)
        showCommitDialog()
        val client = OkHttpClient()
        val requestBody = RequestBody.create(JSON, param)
        val request = Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/prduictionrelation/qmsManufactureProductionplanrelation/api/updateCheckValueById")
                .build()
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.d(TAG, "onFailure: 失败")
                runOnUiThread {
                    showNetErrorMessage()
                    cancelDialog()
                }
            }

            @Throws(IOException::class)
            override fun onResponse(call: Call, response: Response) {
                val result = response.body()!!.string()
                Log.d(TAG, "onResponse: 提交检验值$result")
                runOnUiThread {
                    try {
                        cancelDialog()
                        val jsonObject = JSONObject(result)
                        if (jsonObject.optString("retCode") == "0") {
                            ToastUtils.show("成功")
                            Handler().postDelayed({ finish() }, 1500)
                        }
                    } catch (e: JSONException) {
                        e.printStackTrace()
                    }
                }
            }
        })
    }
    /**
     * 提交
     */
    private fun submit() {
        val map = ArrayMap<String, String>()
        if (zhuangPeiWeiJianGuZhangXinxiBean == null) {
            ToastUtils.show("问题名称不能为空")
            return
        } else {
            map["peoblemTitle"] = zhuangPeiWeiJianGuZhangXinxiBean!!.malfunctionName //问题名称
        }
        map["problemSource"] = "offLineCheck" //问题来源
        map["malfunctionCode"] = zhuangPeiWeiJianGuZhangXinxiBean!!.malfunctionNo //故障编码
        map["flowCarNo"] = data!!.flowcarNo //随车单号
        map["carFrameNo"] = data!!.carframeNo //车架号
        map["assembleStation"] = "" //装配工位
        map["carModelNo"] = data!!.carModelNo //车型号
        map["checkItemNo"] = data!!.opno //项目号码
        map["checkItemName"] = data!!.opnm //检验项目名称
        if (qingongNengMokList != null && !qingongNengMokList!!.isEmpty()) {
            map["functionModel"] = qingongNengMokList!![spFunction!!.selectedItemPosition].id //功能模块
        } else {
            map["functionModel"] = "" //功能模块
        }

        
        map["occurTimeStr"] = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.CHINA).format(Date(System.currentTimeMillis()))
        //        map.put("problemLevel", zhuangPeiWeiJianGuZhangXinxiBean.getMalfunctionLevel());//问题级别
        map["problemLevel"] = etLevel!!.text.toString() //问题级别
        if (zhuangPeiWeiJianXiangQingWuLiaoList == null) {
            map["materiel"] = "" //物料号
        } else {
            map["materiel"] = zhuangPeiWeiJianXiangQingWuLiaoList!!.materielId //物料号
        }
        map["malfunctionNumber"] = etNumber!!.text.toString() //故障数量
        if (buMenLists != null && !buMenLists!!.isEmpty()) {
            map["depts"] = buMenLists!![sp_dept!!.selectedItemPosition].code //责任部门
        } else {
            map["depts"] = ""
        }
        map["problemDesc"] = etInfo!!.text.toString() //问题描述
        map["problemRemarks"] = etRemark!!.text.toString()
        if (uploadFilePath != null && !uploadFilePath!!.isEmpty()) {
            map["imgStr"] = bitmapToBase64(getLoacalBitmap(uploadFilePath)) //图片
        } else {
            map["imgStr"] = "" //图片
        }
        if (zhuangPeiWeiJianXiangQingGongYingShangList != null) {
            map["supplier"] = zhuangPeiWeiJianXiangQingGongYingShangList!!.id //供应商
        } else {
            map["supplier"] = ""
        }
        map["operType"] = "app" //固定 app
        map["currentUserLoginName"] = GlobalVar.username //登录人
        map["checkItemsId"] = data!!.id
        map["offLineStatus"] = status

        val param = gson.toJson(map)
        Log.e("---->", param)
        showCommitDialog()
        val client = OkHttpClient()
        val requestBody = RequestBody.create(JSON, param)
        val request = Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/checkfaildflow/qmsManufactureProblemflow/api/saveAsyn")
                .build()
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.d(TAG, "onFailure: 失败")
                runOnUiThread {
                    showNetErrorMessage()
                    cancelDialog()
                }
            }

            @Throws(IOException::class)
            override fun onResponse(call: Call, response: Response) {
                val result = response.body()!!.string()
                runOnUiThread {
                    Log.d(TAG, "onResponse: 提交数据$result")
                    try {
                        cancelDialog()
                        val jsonObject = JSONObject(result)
                        if (jsonObject.optString("retCode") == "0") {
                            ToastUtils.show("提交成功")
//                            Handler().postDelayed({ finish() }, 1500)  清空页面
                            zhuangPeiWeiJianGuZhangXinxiBean = null
                            spTitle?.text = ""
                            etLevel?.setText("")
                            etInfo?.setText("")
                            showimage?.visibility = View.GONE
                            uploadFilePath = ""
                            val arrayAdapter = ArrayAdapter(context, R.layout.simple_textview1, buMenLists)
                            sp_dept!!.adapter = arrayAdapter

                        } else {
                            ToastUtils.show(jsonObject.optString("retMessage"))
                        }
                    } catch (e: JSONException) {
                        e.printStackTrace()
                    }
                }
            }
        })
    }

    /**
     * 查询功能模块
     */
    private fun queryFunction() {
        val map = ArrayMap<String, String>()
        map["type"] = "qms_module"
        val param = gson.toJson(map)
        val client = OkHttpClient()
        val requestBody = RequestBody.create(JSON, param)
        val request = Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/common/util/api/getDict")
                .build()
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.d(TAG, "onFailure: 失败")
            }

            @Throws(IOException::class)
            override fun onResponse(call: Call, response: Response) {
                val result = response.body()!!.string()
                runOnUiThread {
                    Log.d(TAG, "onResponse: 功能模块$result")
                    try {
                        val jsonObject = JSONObject(result)
                        qingongNengMokList = gson.fromJson(jsonObject.optString("data"), object : TypeToken<List<XiaXianWeiJianXiangQingongNengMok?>?>() {}.type)
                        if (qingongNengMokList == null) return@runOnUiThread
                        val arrayAdapter = ArrayAdapter(context, R.layout.simple_textview1, qingongNengMokList)
                        spFunction!!.adapter = arrayAdapter
                    } catch (e: JSONException) {
                        e.printStackTrace()
                    }
                }
            }
        })
    }

    /**
     * 查询部门
     */
    private fun queryDept() {
        val map = ArrayMap<String, String>()
        val client = OkHttpClient()
        val requestBody = RequestBody.create(JSON, "")
        val request = Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/sys/office/api/getOfficeList")
                .build()
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.d(TAG, "onFailure: 失败")
            }

            @Throws(IOException::class)
            override fun onResponse(call: Call, response: Response) {
                val result = response.body()!!.string()
                runOnUiThread {
                    Log.d(TAG, "onResponse: 部门$result")
                    try {
                        val jsonObject = JSONObject(result)
                        buMenLists = gson.fromJson(jsonObject.optString("data"), object : TypeToken<List<XiaXianWeiJianXiangQingBuMenList?>?>() {}.type)
                        if (buMenLists == null) return@runOnUiThread
                        val arrayAdapter = ArrayAdapter(context, R.layout.simple_textview1, buMenLists)
                        sp_dept!!.adapter = arrayAdapter
                    } catch (e: JSONException) {
                        e.printStackTrace()
                    }
                }
            }
        })
    }

    companion object {
        var ACTION_DATA = "action_data"
        var ACTION_FIRST_DATA = "action_first_data_status"
        var fileDir = Environment.getExternalStorageDirectory().absolutePath + "/qualitymanagement/files/media/"
    }
}