package com.zhuisu.fastdev.beans.printhard;

/**
 * @author cxh
 * @description
 * @date 2020/10/23.
 */

public class PrintHardListBean {
    /**
     * msg : 获取成功！
     * data : {"pageNo":1,"pageSize":30,"count":211,"list":[{"id":"73524392-f0ed-42ba-b02b-8a99fdeda5c7","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"ASSJ20080005/0010-0004","carFarmeNo":"LJ177026","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185H3613E1/J7V7M36-标运质赢","basicDevices":null,"orderNo":"ASSJ20080005","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲豪瀚N：玛瑙红,;豪瀚 N5；牵引车；豪瀚H78B驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；MC07.24-50发动机；8JS95TE-C变速箱；H653自调臂前轴(鼓)；MCJ09BG自调臂单后桥(鼓)；速比4.63；单层车架(7/250)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；295/80R22.5；50#JOST鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"69c2c291-a30d-4ac9-bb80-49276beace2b","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"ASSJ20080005/0010-0005","carFarmeNo":"LJ177027","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185H3613E1/J7V7M36-标运质赢","basicDevices":null,"orderNo":"ASSJ20080005","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲豪瀚N：玛瑙红,;豪瀚 N5；牵引车；豪瀚H78B驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；MC07.24-50发动机；8JS95TE-C变速箱；H653自调臂前轴(鼓)；MCJ09BG自调臂单后桥(鼓)；速比4.63；单层车架(7/250)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；295/80R22.5；50#JOST鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"9b989e34-abf7-4dcb-8d32-c5dde96f3733","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"ASSJ20080005/0010-0006","carFarmeNo":"LJ177028","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185H3613E1/J7V7M36-标运质赢","basicDevices":null,"orderNo":"ASSJ20080005","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲豪瀚N：玛瑙红,;豪瀚 N5；牵引车；豪瀚H78B驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；MC07.24-50发动机；8JS95TE-C变速箱；H653自调臂前轴(鼓)；MCJ09BG自调臂单后桥(鼓)；速比4.63；单层车架(7/250)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；295/80R22.5；50#JOST鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"bb89c0db-73ad-4b94-8fbe-da7661c74ed8","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"ASSJ20080005/0010-0008","carFarmeNo":"LJ177030","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185H3613E1/J7V7M36-标运质赢","basicDevices":null,"orderNo":"ASSJ20080005","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲豪瀚N：玛瑙红,;豪瀚 N5；牵引车；豪瀚H78B驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；MC07.24-50发动机；8JS95TE-C变速箱；H653自调臂前轴(鼓)；MCJ09BG自调臂单后桥(鼓)；速比4.63；单层车架(7/250)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；295/80R22.5；50#JOST鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"8a90d468-e2e2-4435-b30d-30c68a718ed2","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"ASSJ20080005/0010-0009","carFarmeNo":"LJ177031","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185H3613E1/J7V7M36-标运质赢","basicDevices":null,"orderNo":"ASSJ20080005","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲豪瀚N：玛瑙红,;豪瀚 N5；牵引车；豪瀚H78B驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；MC07.24-50发动机；8JS95TE-C变速箱；H653自调臂前轴(鼓)；MCJ09BG自调臂单后桥(鼓)；速比4.63；单层车架(7/250)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；295/80R22.5；50#JOST鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"6c13b4dd-ba9d-4891-a367-8915c4f2d3ff","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"ASSJ20080005/0010-0010","carFarmeNo":"LJ177032","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185H3613E1/J7V7M36-标运质赢","basicDevices":null,"orderNo":"ASSJ20080005","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲豪瀚N：玛瑙红,;豪瀚 N5；牵引车；豪瀚H78B驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；MC07.24-50发动机；8JS95TE-C变速箱；H653自调臂前轴(鼓)；MCJ09BG自调臂单后桥(鼓)；速比4.63；单层车架(7/250)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；295/80R22.5；50#JOST鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"f5c7d5b9-e31a-49aa-becb-47a63d8befa8","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"ASSJ20080008/0010-0001","carFarmeNo":"LJ177033","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185H3613E1/J7V7M36-标运质赢","basicDevices":null,"orderNo":"ASSJ20080008","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲豪瀚N：玛瑙红,;豪瀚 N5；牵引车；豪瀚H78B驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；MC07.24-50发动机；8JS95TE-C变速箱；H653自调臂前轴(鼓)；MCJ09BG自调臂单后桥(鼓)；速比4.63；单层车架(7/250)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；295/80R22.5；50#JOST鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"0594a265-2467-4249-b410-50852862d6c3","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"ASSJ20080008/0010-0002","carFarmeNo":"LJ177034","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185H3613E1/J7V7M36-标运质赢","basicDevices":null,"orderNo":"ASSJ20080008","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲豪瀚N：玛瑙红,;豪瀚 N5；牵引车；豪瀚H78B驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；MC07.24-50发动机；8JS95TE-C变速箱；H653自调臂前轴(鼓)；MCJ09BG自调臂单后桥(鼓)；速比4.63；单层车架(7/250)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；295/80R22.5；50#JOST鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"6dd7b279-2f7c-4dd2-8c58-0b2f3e61853d","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"ASSJ20080008/0010-0003","carFarmeNo":"LJ177035","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185H3613E1/J7V7M36-标运质赢","basicDevices":null,"orderNo":"ASSJ20080008","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲豪瀚N：玛瑙红,;豪瀚 N5；牵引车；豪瀚H78B驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；MC07.24-50发动机；8JS95TE-C变速箱；H653自调臂前轴(鼓)；MCJ09BG自调臂单后桥(鼓)；速比4.63；单层车架(7/250)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；295/80R22.5；50#JOST鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"a77831d3-7cc4-4ba4-a81d-4aecc117de6f","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"ASSJ20080008/0010-0004","carFarmeNo":"LJ177036","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185H3613E1/J7V7M36-标运质赢","basicDevices":null,"orderNo":"ASSJ20080008","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲豪瀚N：玛瑙红,;豪瀚 N5；牵引车；豪瀚H78B驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；MC07.24-50发动机；8JS95TE-C变速箱；H653自调臂前轴(鼓)；MCJ09BG自调臂单后桥(鼓)；速比4.63；单层车架(7/250)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；295/80R22.5；50#JOST鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"91481cda-81d5-44da-b5ba-ae0ff128ea2c","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"ASSJ20080008/0010-0005","carFarmeNo":"LJ177037","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185H3613E1/J7V7M36-标运质赢","basicDevices":null,"orderNo":"ASSJ20080008","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲豪瀚N：玛瑙红,;豪瀚 N5；牵引车；豪瀚H78B驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；MC07.24-50发动机；8JS95TE-C变速箱；H653自调臂前轴(鼓)；MCJ09BG自调臂单后桥(鼓)；速比4.63；单层车架(7/250)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；295/80R22.5；50#JOST鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"921f8c53-102e-465a-83fb-1796115f3aaa","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"ASSJ20080008/0010-0006","carFarmeNo":"LJ177038","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185H3613E1/J7V7M36-标运质赢","basicDevices":null,"orderNo":"ASSJ20080008","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲豪瀚N：玛瑙红,;豪瀚 N5；牵引车；豪瀚H78B驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；MC07.24-50发动机；8JS95TE-C变速箱；H653自调臂前轴(鼓)；MCJ09BG自调臂单后桥(鼓)；速比4.63；单层车架(7/250)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；295/80R22.5；50#JOST鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"a9140916-9398-4cc4-9109-74041d819f5f","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"ASSJ20080008/0010-0007","carFarmeNo":"LJ177039","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185H3613E1/J7V7M36-标运质赢","basicDevices":null,"orderNo":"ASSJ20080008","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲豪瀚N：玛瑙红,;豪瀚 N5；牵引车；豪瀚H78B驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；MC07.24-50发动机；8JS95TE-C变速箱；H653自调臂前轴(鼓)；MCJ09BG自调臂单后桥(鼓)；速比4.63；单层车架(7/250)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；295/80R22.5；50#JOST鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"a26d8006-1bde-4a71-b433-155dc5ce827d","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"ASSJ20080008/0010-0008","carFarmeNo":"LJ177040","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185H3613E1/J7V7M36-标运质赢","basicDevices":null,"orderNo":"ASSJ20080008","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲豪瀚N：玛瑙红,;豪瀚 N5；牵引车；豪瀚H78B驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；MC07.24-50发动机；8JS95TE-C变速箱；H653自调臂前轴(鼓)；MCJ09BG自调臂单后桥(鼓)；速比4.63；单层车架(7/250)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；295/80R22.5；50#JOST鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"08548963-0663-4db2-80ec-2bff7077d5e2","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"ASSJ20080008/0010-0009","carFarmeNo":"LJ177041","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185H3613E1/J7V7M36-标运质赢","basicDevices":null,"orderNo":"ASSJ20080008","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲豪瀚N：玛瑙红,;豪瀚 N5；牵引车；豪瀚H78B驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；MC07.24-50发动机；8JS95TE-C变速箱；H653自调臂前轴(鼓)；MCJ09BG自调臂单后桥(鼓)；速比4.63；单层车架(7/250)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；295/80R22.5；50#JOST鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"41d58274-9267-4b54-a27e-61175fe3cd43","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"ASSJ20080008/0010-0010","carFarmeNo":"LJ177042","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185H3613E1/J7V7M36-标运质赢","basicDevices":null,"orderNo":"ASSJ20080008","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲豪瀚N：玛瑙红,;豪瀚 N5；牵引车；豪瀚H78B驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；MC07.24-50发动机；8JS95TE-C变速箱；H653自调臂前轴(鼓)；MCJ09BG自调臂单后桥(鼓)；速比4.63；单层车架(7/250)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；295/80R22.5；50#JOST鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"2a7cee20-082f-4705-92ad-2527c545dd2d","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"ASSJ20080006/0010-0001","carFarmeNo":"LJ177043","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185H3613E1/J7V7M36-标运质赢","basicDevices":null,"orderNo":"ASSJ20080006","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲豪瀚N：新曼白,;豪瀚 N5；牵引车；豪瀚H78B驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；MC07.24-50发动机；8JS95TE-C变速箱；H653自调臂前轴(鼓)；MCJ09BG自调臂单后桥(鼓)；速比4.63；单层车架(7/250)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；295/80R22.5；50#JOST鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"ea8a618b-7bd0-4000-8b4c-3253e8c626ce","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"ASSJ20080006/0010-0002","carFarmeNo":"LJ177044","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185H3613E1/J7V7M36-标运质赢","basicDevices":null,"orderNo":"ASSJ20080006","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲豪瀚N：新曼白,;豪瀚 N5；牵引车；豪瀚H78B驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；MC07.24-50发动机；8JS95TE-C变速箱；H653自调臂前轴(鼓)；MCJ09BG自调臂单后桥(鼓)；速比4.63；单层车架(7/250)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；295/80R22.5；50#JOST鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"3f5cf6d3-c59f-47f3-8064-58782d7badf6","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"ASSJ20080006/0010-0003","carFarmeNo":"LJ177045","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185H3613E1/J7V7M36-标运质赢","basicDevices":null,"orderNo":"ASSJ20080006","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲豪瀚N：新曼白,;豪瀚 N5；牵引车；豪瀚H78B驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；MC07.24-50发动机；8JS95TE-C变速箱；H653自调臂前轴(鼓)；MCJ09BG自调臂单后桥(鼓)；速比4.63；单层车架(7/250)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；295/80R22.5；50#JOST鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"ca44e604-ecdd-4663-9e6c-5c1ed575d8d1","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"ASSJ20080006/0010-0004","carFarmeNo":"LJ177046","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185H3613E1/J7V7M36-标运质赢","basicDevices":null,"orderNo":"ASSJ20080006","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲豪瀚N：新曼白,;豪瀚 N5；牵引车；豪瀚H78B驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；MC07.24-50发动机；8JS95TE-C变速箱；H653自调臂前轴(鼓)；MCJ09BG自调臂单后桥(鼓)；速比4.63；单层车架(7/250)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；295/80R22.5；50#JOST鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"e161344a-a58a-405f-bc5d-123f962ccb18","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"ASSJ20080006/0010-0005","carFarmeNo":"LJ177047","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185H3613E1/J7V7M36-标运质赢","basicDevices":null,"orderNo":"ASSJ20080006","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲豪瀚N：新曼白,;豪瀚 N5；牵引车；豪瀚H78B驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；MC07.24-50发动机；8JS95TE-C变速箱；H653自调臂前轴(鼓)；MCJ09BG自调臂单后桥(鼓)；速比4.63；单层车架(7/250)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；295/80R22.5；50#JOST鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"5b02feb4-b37e-458b-8301-673c70bee718","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"ASSJ20080006/0010-0006","carFarmeNo":"LJ177048","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185H3613E1/J7V7M36-标运质赢","basicDevices":null,"orderNo":"ASSJ20080006","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲豪瀚N：新曼白,;豪瀚 N5；牵引车；豪瀚H78B驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；MC07.24-50发动机；8JS95TE-C变速箱；H653自调臂前轴(鼓)；MCJ09BG自调臂单后桥(鼓)；速比4.63；单层车架(7/250)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；295/80R22.5；50#JOST鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"293d6029-3e36-4016-9a94-1da4baf8e2c8","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"ASSJ20080006/0010-0007","carFarmeNo":"LJ177049","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185H3613E1/J7V7M36-标运质赢","basicDevices":null,"orderNo":"ASSJ20080006","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲豪瀚N：新曼白,;豪瀚 N5；牵引车；豪瀚H78B驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；MC07.24-50发动机；8JS95TE-C变速箱；H653自调臂前轴(鼓)；MCJ09BG自调臂单后桥(鼓)；速比4.63；单层车架(7/250)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；295/80R22.5；50#JOST鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"cdfb6903-8c23-443f-a3f0-d0d1c3d5a233","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"ASSJ20080006/0010-0008","carFarmeNo":"LJ177050","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185H3613E1/J7V7M36-标运质赢","basicDevices":null,"orderNo":"ASSJ20080006","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲豪瀚N：新曼白,;豪瀚 N5；牵引车；豪瀚H78B驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；MC07.24-50发动机；8JS95TE-C变速箱；H653自调臂前轴(鼓)；MCJ09BG自调臂单后桥(鼓)；速比4.63；单层车架(7/250)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；295/80R22.5；50#JOST鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"562e1b2e-383e-4402-a943-6026c59661bf","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"ASSJ20080006/0010-0009","carFarmeNo":"LJ177051","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185H3613E1/J7V7M36-标运质赢","basicDevices":null,"orderNo":"ASSJ20080006","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲豪瀚N：新曼白,;豪瀚 N5；牵引车；豪瀚H78B驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；MC07.24-50发动机；8JS95TE-C变速箱；H653自调臂前轴(鼓)；MCJ09BG自调臂单后桥(鼓)；速比4.63；单层车架(7/250)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；295/80R22.5；50#JOST鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"cd45ea9e-39cf-4b48-91b2-4056223603bf","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"ASSJ20080006/0010-0010","carFarmeNo":"LJ177052","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185H3613E1/J7V7M36-标运质赢","basicDevices":null,"orderNo":"ASSJ20080006","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲豪瀚N：新曼白,;豪瀚 N5；牵引车；豪瀚H78B驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；MC07.24-50发动机；8JS95TE-C变速箱；H653自调臂前轴(鼓)；MCJ09BG自调臂单后桥(鼓)；速比4.63；单层车架(7/250)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；295/80R22.5；50#JOST鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"b3f2ddc2-c4fb-4dc3-95da-0df86ec2ef01","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"ASHJ20080023/0001-0001","carFarmeNo":"LJ177053","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185N3613E1/N7V7M36-标运","basicDevices":null,"orderNo":"ASHJ20080023","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲加急订单,豪瀚N：玛瑙红,双星轮胎；;豪瀚 N5；牵引车；豪瀚H78L驾驶室 轻奢版；导流罩和侧导风板；多功能方向盘；电动电加热后视镜；主气囊+副简易型座椅；220V-1000W逆变电源；MC07.34-50(A)发动机；HW15710L变速箱；H653K自调臂前轴(鼓)；MCY12JGK自调臂单后桥(鼓)；速比3.7；单层车架(8/280)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；12R22.5；50#JOST鞍座；整体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通B版；钢制储气筒；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"151673d0-8b05-479b-bf17-f9ccbc647851","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"JJNJ20080053/0001-0001","carFarmeNo":"LJ177054","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185N3613E1/N7V7M36-标运","basicDevices":null,"orderNo":"JJNJ20080053","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲豪瀚N：白金灰,;豪瀚 N5；牵引车；豪瀚H78L驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；220V-1000W逆变电源；MC07.34-50(A)发动机；HW15710CL变速箱；H653K自调臂前轴(鼓)；MCY12JGK自调臂单后桥(鼓)；速比3.7；单层车架(8/280)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；12R22.5；90#金刚鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；钢制储气筒；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"070772de-64d5-44d9-a475-2f6deaa90b6d","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"JTYJ20080010/0010-0001","carFarmeNo":"LJ177055","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4255V3846F1L/U9VDM38-标运","basicDevices":null,"orderNo":"JTYJ20080010","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"豪瀚N：玛瑙红,;豪瀚 N7；牵引车；豪瀚H78L驾驶室 轻奢版；多功能方向盘；电动电加热后视镜；主气囊+副简易型座椅；220V-1000W逆变电源；MT13.44-60发动机；HW25712XSTL变速箱；H653K自调臂前轴(鼓)；MCY12BGS自调臂双后桥(鼓)；速比3.08；单层车架(8/280)；前后少片簧(2/3)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；ABS(4S/4M)；低位保险杠(非金属)；前铝合金车轮(国产)+后轻量化车轮；12R22.5；90#金刚鞍座；手电一体电动举升；分体式挡泥板；后置1000L气瓶；LDWS+FCWS(带雷达)；中国重汽智能通B版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"9246a743-763f-46e3-a1fb-6a9dddee254c","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"JTYJ20080010/0010-0002","carFarmeNo":"LJ177056","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4255V3846F1L/U9VDM38-标运","basicDevices":null,"orderNo":"JTYJ20080010","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"豪瀚N：玛瑙红,;豪瀚 N7；牵引车；豪瀚H78L驾驶室 轻奢版；多功能方向盘；电动电加热后视镜；主气囊+副简易型座椅；220V-1000W逆变电源；MT13.44-60发动机；HW25712XSTL变速箱；H653K自调臂前轴(鼓)；MCY12BGS自调臂双后桥(鼓)；速比3.08；单层车架(8/280)；前后少片簧(2/3)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；ABS(4S/4M)；低位保险杠(非金属)；前铝合金车轮(国产)+后轻量化车轮；12R22.5；90#金刚鞍座；手电一体电动举升；分体式挡泥板；后置1000L气瓶；LDWS+FCWS(带雷达)；中国重汽智能通B版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false}],"firstResult":0,"maxResults":30}
     * status : 0
     */


    /**
     * pageNo : 1
     * pageSize : 30
     * count : 211
     * list : [{"id":"73524392-f0ed-42ba-b02b-8a99fdeda5c7","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"ASSJ20080005/0010-0004","carFarmeNo":"LJ177026","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185H3613E1/J7V7M36-标运质赢","basicDevices":null,"orderNo":"ASSJ20080005","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲豪瀚N：玛瑙红,;豪瀚 N5；牵引车；豪瀚H78B驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；MC07.24-50发动机；8JS95TE-C变速箱；H653自调臂前轴(鼓)；MCJ09BG自调臂单后桥(鼓)；速比4.63；单层车架(7/250)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；295/80R22.5；50#JOST鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"69c2c291-a30d-4ac9-bb80-49276beace2b","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"ASSJ20080005/0010-0005","carFarmeNo":"LJ177027","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185H3613E1/J7V7M36-标运质赢","basicDevices":null,"orderNo":"ASSJ20080005","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲豪瀚N：玛瑙红,;豪瀚 N5；牵引车；豪瀚H78B驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；MC07.24-50发动机；8JS95TE-C变速箱；H653自调臂前轴(鼓)；MCJ09BG自调臂单后桥(鼓)；速比4.63；单层车架(7/250)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；295/80R22.5；50#JOST鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"9b989e34-abf7-4dcb-8d32-c5dde96f3733","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"ASSJ20080005/0010-0006","carFarmeNo":"LJ177028","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185H3613E1/J7V7M36-标运质赢","basicDevices":null,"orderNo":"ASSJ20080005","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲豪瀚N：玛瑙红,;豪瀚 N5；牵引车；豪瀚H78B驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；MC07.24-50发动机；8JS95TE-C变速箱；H653自调臂前轴(鼓)；MCJ09BG自调臂单后桥(鼓)；速比4.63；单层车架(7/250)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；295/80R22.5；50#JOST鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"bb89c0db-73ad-4b94-8fbe-da7661c74ed8","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"ASSJ20080005/0010-0008","carFarmeNo":"LJ177030","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185H3613E1/J7V7M36-标运质赢","basicDevices":null,"orderNo":"ASSJ20080005","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲豪瀚N：玛瑙红,;豪瀚 N5；牵引车；豪瀚H78B驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；MC07.24-50发动机；8JS95TE-C变速箱；H653自调臂前轴(鼓)；MCJ09BG自调臂单后桥(鼓)；速比4.63；单层车架(7/250)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；295/80R22.5；50#JOST鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"8a90d468-e2e2-4435-b30d-30c68a718ed2","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"ASSJ20080005/0010-0009","carFarmeNo":"LJ177031","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185H3613E1/J7V7M36-标运质赢","basicDevices":null,"orderNo":"ASSJ20080005","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲豪瀚N：玛瑙红,;豪瀚 N5；牵引车；豪瀚H78B驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；MC07.24-50发动机；8JS95TE-C变速箱；H653自调臂前轴(鼓)；MCJ09BG自调臂单后桥(鼓)；速比4.63；单层车架(7/250)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；295/80R22.5；50#JOST鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"6c13b4dd-ba9d-4891-a367-8915c4f2d3ff","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"ASSJ20080005/0010-0010","carFarmeNo":"LJ177032","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185H3613E1/J7V7M36-标运质赢","basicDevices":null,"orderNo":"ASSJ20080005","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲豪瀚N：玛瑙红,;豪瀚 N5；牵引车；豪瀚H78B驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；MC07.24-50发动机；8JS95TE-C变速箱；H653自调臂前轴(鼓)；MCJ09BG自调臂单后桥(鼓)；速比4.63；单层车架(7/250)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；295/80R22.5；50#JOST鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"f5c7d5b9-e31a-49aa-becb-47a63d8befa8","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"ASSJ20080008/0010-0001","carFarmeNo":"LJ177033","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185H3613E1/J7V7M36-标运质赢","basicDevices":null,"orderNo":"ASSJ20080008","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲豪瀚N：玛瑙红,;豪瀚 N5；牵引车；豪瀚H78B驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；MC07.24-50发动机；8JS95TE-C变速箱；H653自调臂前轴(鼓)；MCJ09BG自调臂单后桥(鼓)；速比4.63；单层车架(7/250)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；295/80R22.5；50#JOST鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"0594a265-2467-4249-b410-50852862d6c3","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"ASSJ20080008/0010-0002","carFarmeNo":"LJ177034","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185H3613E1/J7V7M36-标运质赢","basicDevices":null,"orderNo":"ASSJ20080008","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲豪瀚N：玛瑙红,;豪瀚 N5；牵引车；豪瀚H78B驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；MC07.24-50发动机；8JS95TE-C变速箱；H653自调臂前轴(鼓)；MCJ09BG自调臂单后桥(鼓)；速比4.63；单层车架(7/250)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；295/80R22.5；50#JOST鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"6dd7b279-2f7c-4dd2-8c58-0b2f3e61853d","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"ASSJ20080008/0010-0003","carFarmeNo":"LJ177035","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185H3613E1/J7V7M36-标运质赢","basicDevices":null,"orderNo":"ASSJ20080008","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲豪瀚N：玛瑙红,;豪瀚 N5；牵引车；豪瀚H78B驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；MC07.24-50发动机；8JS95TE-C变速箱；H653自调臂前轴(鼓)；MCJ09BG自调臂单后桥(鼓)；速比4.63；单层车架(7/250)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；295/80R22.5；50#JOST鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"a77831d3-7cc4-4ba4-a81d-4aecc117de6f","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"ASSJ20080008/0010-0004","carFarmeNo":"LJ177036","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185H3613E1/J7V7M36-标运质赢","basicDevices":null,"orderNo":"ASSJ20080008","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲豪瀚N：玛瑙红,;豪瀚 N5；牵引车；豪瀚H78B驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；MC07.24-50发动机；8JS95TE-C变速箱；H653自调臂前轴(鼓)；MCJ09BG自调臂单后桥(鼓)；速比4.63；单层车架(7/250)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；295/80R22.5；50#JOST鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"91481cda-81d5-44da-b5ba-ae0ff128ea2c","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"ASSJ20080008/0010-0005","carFarmeNo":"LJ177037","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185H3613E1/J7V7M36-标运质赢","basicDevices":null,"orderNo":"ASSJ20080008","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲豪瀚N：玛瑙红,;豪瀚 N5；牵引车；豪瀚H78B驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；MC07.24-50发动机；8JS95TE-C变速箱；H653自调臂前轴(鼓)；MCJ09BG自调臂单后桥(鼓)；速比4.63；单层车架(7/250)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；295/80R22.5；50#JOST鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"921f8c53-102e-465a-83fb-1796115f3aaa","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"ASSJ20080008/0010-0006","carFarmeNo":"LJ177038","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185H3613E1/J7V7M36-标运质赢","basicDevices":null,"orderNo":"ASSJ20080008","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲豪瀚N：玛瑙红,;豪瀚 N5；牵引车；豪瀚H78B驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；MC07.24-50发动机；8JS95TE-C变速箱；H653自调臂前轴(鼓)；MCJ09BG自调臂单后桥(鼓)；速比4.63；单层车架(7/250)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；295/80R22.5；50#JOST鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"a9140916-9398-4cc4-9109-74041d819f5f","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"ASSJ20080008/0010-0007","carFarmeNo":"LJ177039","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185H3613E1/J7V7M36-标运质赢","basicDevices":null,"orderNo":"ASSJ20080008","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲豪瀚N：玛瑙红,;豪瀚 N5；牵引车；豪瀚H78B驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；MC07.24-50发动机；8JS95TE-C变速箱；H653自调臂前轴(鼓)；MCJ09BG自调臂单后桥(鼓)；速比4.63；单层车架(7/250)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；295/80R22.5；50#JOST鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"a26d8006-1bde-4a71-b433-155dc5ce827d","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"ASSJ20080008/0010-0008","carFarmeNo":"LJ177040","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185H3613E1/J7V7M36-标运质赢","basicDevices":null,"orderNo":"ASSJ20080008","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲豪瀚N：玛瑙红,;豪瀚 N5；牵引车；豪瀚H78B驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；MC07.24-50发动机；8JS95TE-C变速箱；H653自调臂前轴(鼓)；MCJ09BG自调臂单后桥(鼓)；速比4.63；单层车架(7/250)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；295/80R22.5；50#JOST鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"08548963-0663-4db2-80ec-2bff7077d5e2","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"ASSJ20080008/0010-0009","carFarmeNo":"LJ177041","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185H3613E1/J7V7M36-标运质赢","basicDevices":null,"orderNo":"ASSJ20080008","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲豪瀚N：玛瑙红,;豪瀚 N5；牵引车；豪瀚H78B驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；MC07.24-50发动机；8JS95TE-C变速箱；H653自调臂前轴(鼓)；MCJ09BG自调臂单后桥(鼓)；速比4.63；单层车架(7/250)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；295/80R22.5；50#JOST鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"41d58274-9267-4b54-a27e-61175fe3cd43","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"ASSJ20080008/0010-0010","carFarmeNo":"LJ177042","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185H3613E1/J7V7M36-标运质赢","basicDevices":null,"orderNo":"ASSJ20080008","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲豪瀚N：玛瑙红,;豪瀚 N5；牵引车；豪瀚H78B驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；MC07.24-50发动机；8JS95TE-C变速箱；H653自调臂前轴(鼓)；MCJ09BG自调臂单后桥(鼓)；速比4.63；单层车架(7/250)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；295/80R22.5；50#JOST鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"2a7cee20-082f-4705-92ad-2527c545dd2d","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"ASSJ20080006/0010-0001","carFarmeNo":"LJ177043","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185H3613E1/J7V7M36-标运质赢","basicDevices":null,"orderNo":"ASSJ20080006","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲豪瀚N：新曼白,;豪瀚 N5；牵引车；豪瀚H78B驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；MC07.24-50发动机；8JS95TE-C变速箱；H653自调臂前轴(鼓)；MCJ09BG自调臂单后桥(鼓)；速比4.63；单层车架(7/250)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；295/80R22.5；50#JOST鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"ea8a618b-7bd0-4000-8b4c-3253e8c626ce","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"ASSJ20080006/0010-0002","carFarmeNo":"LJ177044","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185H3613E1/J7V7M36-标运质赢","basicDevices":null,"orderNo":"ASSJ20080006","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲豪瀚N：新曼白,;豪瀚 N5；牵引车；豪瀚H78B驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；MC07.24-50发动机；8JS95TE-C变速箱；H653自调臂前轴(鼓)；MCJ09BG自调臂单后桥(鼓)；速比4.63；单层车架(7/250)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；295/80R22.5；50#JOST鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"3f5cf6d3-c59f-47f3-8064-58782d7badf6","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"ASSJ20080006/0010-0003","carFarmeNo":"LJ177045","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185H3613E1/J7V7M36-标运质赢","basicDevices":null,"orderNo":"ASSJ20080006","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲豪瀚N：新曼白,;豪瀚 N5；牵引车；豪瀚H78B驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；MC07.24-50发动机；8JS95TE-C变速箱；H653自调臂前轴(鼓)；MCJ09BG自调臂单后桥(鼓)；速比4.63；单层车架(7/250)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；295/80R22.5；50#JOST鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"ca44e604-ecdd-4663-9e6c-5c1ed575d8d1","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"ASSJ20080006/0010-0004","carFarmeNo":"LJ177046","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185H3613E1/J7V7M36-标运质赢","basicDevices":null,"orderNo":"ASSJ20080006","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲豪瀚N：新曼白,;豪瀚 N5；牵引车；豪瀚H78B驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；MC07.24-50发动机；8JS95TE-C变速箱；H653自调臂前轴(鼓)；MCJ09BG自调臂单后桥(鼓)；速比4.63；单层车架(7/250)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；295/80R22.5；50#JOST鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"e161344a-a58a-405f-bc5d-123f962ccb18","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"ASSJ20080006/0010-0005","carFarmeNo":"LJ177047","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185H3613E1/J7V7M36-标运质赢","basicDevices":null,"orderNo":"ASSJ20080006","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲豪瀚N：新曼白,;豪瀚 N5；牵引车；豪瀚H78B驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；MC07.24-50发动机；8JS95TE-C变速箱；H653自调臂前轴(鼓)；MCJ09BG自调臂单后桥(鼓)；速比4.63；单层车架(7/250)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；295/80R22.5；50#JOST鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"5b02feb4-b37e-458b-8301-673c70bee718","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"ASSJ20080006/0010-0006","carFarmeNo":"LJ177048","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185H3613E1/J7V7M36-标运质赢","basicDevices":null,"orderNo":"ASSJ20080006","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲豪瀚N：新曼白,;豪瀚 N5；牵引车；豪瀚H78B驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；MC07.24-50发动机；8JS95TE-C变速箱；H653自调臂前轴(鼓)；MCJ09BG自调臂单后桥(鼓)；速比4.63；单层车架(7/250)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；295/80R22.5；50#JOST鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"293d6029-3e36-4016-9a94-1da4baf8e2c8","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"ASSJ20080006/0010-0007","carFarmeNo":"LJ177049","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185H3613E1/J7V7M36-标运质赢","basicDevices":null,"orderNo":"ASSJ20080006","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲豪瀚N：新曼白,;豪瀚 N5；牵引车；豪瀚H78B驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；MC07.24-50发动机；8JS95TE-C变速箱；H653自调臂前轴(鼓)；MCJ09BG自调臂单后桥(鼓)；速比4.63；单层车架(7/250)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；295/80R22.5；50#JOST鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"cdfb6903-8c23-443f-a3f0-d0d1c3d5a233","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"ASSJ20080006/0010-0008","carFarmeNo":"LJ177050","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185H3613E1/J7V7M36-标运质赢","basicDevices":null,"orderNo":"ASSJ20080006","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲豪瀚N：新曼白,;豪瀚 N5；牵引车；豪瀚H78B驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；MC07.24-50发动机；8JS95TE-C变速箱；H653自调臂前轴(鼓)；MCJ09BG自调臂单后桥(鼓)；速比4.63；单层车架(7/250)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；295/80R22.5；50#JOST鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"562e1b2e-383e-4402-a943-6026c59661bf","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"ASSJ20080006/0010-0009","carFarmeNo":"LJ177051","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185H3613E1/J7V7M36-标运质赢","basicDevices":null,"orderNo":"ASSJ20080006","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲豪瀚N：新曼白,;豪瀚 N5；牵引车；豪瀚H78B驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；MC07.24-50发动机；8JS95TE-C变速箱；H653自调臂前轴(鼓)；MCJ09BG自调臂单后桥(鼓)；速比4.63；单层车架(7/250)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；295/80R22.5；50#JOST鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"cd45ea9e-39cf-4b48-91b2-4056223603bf","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"ASSJ20080006/0010-0010","carFarmeNo":"LJ177052","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185H3613E1/J7V7M36-标运质赢","basicDevices":null,"orderNo":"ASSJ20080006","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲豪瀚N：新曼白,;豪瀚 N5；牵引车；豪瀚H78B驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；MC07.24-50发动机；8JS95TE-C变速箱；H653自调臂前轴(鼓)；MCJ09BG自调臂单后桥(鼓)；速比4.63；单层车架(7/250)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；295/80R22.5；50#JOST鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"b3f2ddc2-c4fb-4dc3-95da-0df86ec2ef01","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"ASHJ20080023/0001-0001","carFarmeNo":"LJ177053","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185N3613E1/N7V7M36-标运","basicDevices":null,"orderNo":"ASHJ20080023","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲加急订单,豪瀚N：玛瑙红,双星轮胎；;豪瀚 N5；牵引车；豪瀚H78L驾驶室 轻奢版；导流罩和侧导风板；多功能方向盘；电动电加热后视镜；主气囊+副简易型座椅；220V-1000W逆变电源；MC07.34-50(A)发动机；HW15710L变速箱；H653K自调臂前轴(鼓)；MCY12JGK自调臂单后桥(鼓)；速比3.7；单层车架(8/280)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；12R22.5；50#JOST鞍座；整体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通B版；钢制储气筒；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"151673d0-8b05-479b-bf17-f9ccbc647851","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"JJNJ20080053/0001-0001","carFarmeNo":"LJ177054","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185N3613E1/N7V7M36-标运","basicDevices":null,"orderNo":"JJNJ20080053","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲豪瀚N：白金灰,;豪瀚 N5；牵引车；豪瀚H78L驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；220V-1000W逆变电源；MC07.34-50(A)发动机；HW15710CL变速箱；H653K自调臂前轴(鼓)；MCY12JGK自调臂单后桥(鼓)；速比3.7；单层车架(8/280)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；12R22.5；90#金刚鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；钢制储气筒；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"070772de-64d5-44d9-a475-2f6deaa90b6d","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"JTYJ20080010/0010-0001","carFarmeNo":"LJ177055","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4255V3846F1L/U9VDM38-标运","basicDevices":null,"orderNo":"JTYJ20080010","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"豪瀚N：玛瑙红,;豪瀚 N7；牵引车；豪瀚H78L驾驶室 轻奢版；多功能方向盘；电动电加热后视镜；主气囊+副简易型座椅；220V-1000W逆变电源；MT13.44-60发动机；HW25712XSTL变速箱；H653K自调臂前轴(鼓)；MCY12BGS自调臂双后桥(鼓)；速比3.08；单层车架(8/280)；前后少片簧(2/3)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；ABS(4S/4M)；低位保险杠(非金属)；前铝合金车轮(国产)+后轻量化车轮；12R22.5；90#金刚鞍座；手电一体电动举升；分体式挡泥板；后置1000L气瓶；LDWS+FCWS(带雷达)；中国重汽智能通B版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"9246a743-763f-46e3-a1fb-6a9dddee254c","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"JTYJ20080010/0010-0002","carFarmeNo":"LJ177056","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4255V3846F1L/U9VDM38-标运","basicDevices":null,"orderNo":"JTYJ20080010","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"豪瀚N：玛瑙红,;豪瀚 N7；牵引车；豪瀚H78L驾驶室 轻奢版；多功能方向盘；电动电加热后视镜；主气囊+副简易型座椅；220V-1000W逆变电源；MT13.44-60发动机；HW25712XSTL变速箱；H653K自调臂前轴(鼓)；MCY12BGS自调臂双后桥(鼓)；速比3.08；单层车架(8/280)；前后少片簧(2/3)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；ABS(4S/4M)；低位保险杠(非金属)；前铝合金车轮(国产)+后轻量化车轮；12R22.5；90#金刚鞍座；手电一体电动举升；分体式挡泥板；后置1000L气瓶；LDWS+FCWS(带雷达)；中国重汽智能通B版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false}]
     * firstResult : 0
     * maxResults : 30
     */

    /**
     * id : 73524392-f0ed-42ba-b02b-8a99fdeda5c7
     * isNewRecord : false
     * remarks : null
     * createDate : 2020-10-15 16:00:00
     * updateDate : null
     * supcodes : null
     * menuid : null
     * flowCarNo : ASSJ20080005/0010-0004
     * carFarmeNo : LJ177026
     * status : null
     * submitCheckStatus : null
     * varnishStatus : null
     * varnishOperator : null
     * varnishDate : null
     * location : null
     * environmentalLabel : null
     * isSpecialSubmitCheck : null
     * isExistCloseTrouble : 0
     * submitCheckOperType : null
     * rainResult : null
     * rainCount : null
     * rainPart : null
     * rainBridgeType : null
     * rainItem : null
     * startTime : null
     * endTime : null
     * searchStatus : null
     * qmsManufactureProductionplan : {"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185H3613E1/J7V7M36-标运质赢","basicDevices":null,"orderNo":"ASSJ20080005","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲豪瀚N：玛瑙红,;豪瀚 N5；牵引车；豪瀚H78B驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；MC07.24-50发动机；8JS95TE-C变速箱；H653自调臂前轴(鼓)；MCJ09BG自调臂单后桥(鼓)；速比4.63；单层车架(7/250)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；295/80R22.5；50#JOST鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null}
     * qmsZcproject : null
     * specialSubmitRemark : null
     * fileName : null
     * filePath : null
     * configChange : false
     *
     * environmentalLabel  1-是 0-否
     */

    private String id;
    private Boolean isNewRecord;
    private Object remarks;
    private String createDate;
    private Object updateDate;
    private Object supcodes;
    private Object menuid;
    private String flowCarNo;
    private String carFarmeNo;
    private Object status;
    private Object submitCheckStatus;
    private Object varnishStatus;
    private Object varnishOperator;
    private Object varnishDate;
    private Object location;
    private String environmentalLabel;
    private Object isSpecialSubmitCheck;
    private Integer isExistCloseTrouble;
    private Object submitCheckOperType;
    private Object rainResult;
    private Object rainCount;
    private Object rainPart;
    private Object rainBridgeType;
    private Object rainItem;
    private Object startTime;
    private Object endTime;
    private Object searchStatus;
    private QmsManufactureProductionplanBean qmsManufactureProductionplan;
    private Object qmsZcproject;
    private Object specialSubmitRemark;
    private Object fileName;
    private Object filePath;
    private Boolean configChange;

    public void setId(String id) {
        this.id = id;
    }

    public void setNewRecord(Boolean newRecord) {
        isNewRecord = newRecord;
    }

    public void setRemarks(Object remarks) {
        this.remarks = remarks;
    }

    public void setCreateDate(String createDate) {
        this.createDate = createDate;
    }

    public void setUpdateDate(Object updateDate) {
        this.updateDate = updateDate;
    }

    public void setSupcodes(Object supcodes) {
        this.supcodes = supcodes;
    }

    public void setMenuid(Object menuid) {
        this.menuid = menuid;
    }

    public void setFlowCarNo(String flowCarNo) {
        this.flowCarNo = flowCarNo;
    }

    public void setCarFarmeNo(String carFarmeNo) {
        this.carFarmeNo = carFarmeNo;
    }

    public void setStatus(Object status) {
        this.status = status;
    }

    public void setSubmitCheckStatus(Object submitCheckStatus) {
        this.submitCheckStatus = submitCheckStatus;
    }

    public void setVarnishStatus(Object varnishStatus) {
        this.varnishStatus = varnishStatus;
    }

    public void setVarnishOperator(Object varnishOperator) {
        this.varnishOperator = varnishOperator;
    }

    public void setVarnishDate(Object varnishDate) {
        this.varnishDate = varnishDate;
    }

    public void setLocation(Object location) {
        this.location = location;
    }

    public void setEnvironmentalLabel(String environmentalLabel) {
        this.environmentalLabel = environmentalLabel;
    }

    public void setIsSpecialSubmitCheck(Object isSpecialSubmitCheck) {
        this.isSpecialSubmitCheck = isSpecialSubmitCheck;
    }

    public void setIsExistCloseTrouble(Integer isExistCloseTrouble) {
        this.isExistCloseTrouble = isExistCloseTrouble;
    }

    public void setSubmitCheckOperType(Object submitCheckOperType) {
        this.submitCheckOperType = submitCheckOperType;
    }

    public void setRainResult(Object rainResult) {
        this.rainResult = rainResult;
    }

    public void setRainCount(Object rainCount) {
        this.rainCount = rainCount;
    }

    public void setRainPart(Object rainPart) {
        this.rainPart = rainPart;
    }

    public void setRainBridgeType(Object rainBridgeType) {
        this.rainBridgeType = rainBridgeType;
    }

    public void setRainItem(Object rainItem) {
        this.rainItem = rainItem;
    }

    public void setStartTime(Object startTime) {
        this.startTime = startTime;
    }

    public void setEndTime(Object endTime) {
        this.endTime = endTime;
    }

    public void setSearchStatus(Object searchStatus) {
        this.searchStatus = searchStatus;
    }

    public void setQmsManufactureProductionplan(QmsManufactureProductionplanBean qmsManufactureProductionplan) {
        this.qmsManufactureProductionplan = qmsManufactureProductionplan;
    }

    public void setQmsZcproject(Object qmsZcproject) {
        this.qmsZcproject = qmsZcproject;
    }

    public void setSpecialSubmitRemark(Object specialSubmitRemark) {
        this.specialSubmitRemark = specialSubmitRemark;
    }

    public void setFileName(Object fileName) {
        this.fileName = fileName;
    }

    public void setFilePath(Object filePath) {
        this.filePath = filePath;
    }

    public void setConfigChange(Boolean configChange) {
        this.configChange = configChange;
    }

    public String getId() {
        return id;
    }

    public Boolean getNewRecord() {
        return isNewRecord;
    }

    public Object getRemarks() {
        return remarks;
    }

    public String getCreateDate() {
        return createDate;
    }

    public Object getUpdateDate() {
        return updateDate;
    }

    public Object getSupcodes() {
        return supcodes;
    }

    public Object getMenuid() {
        return menuid;
    }

    public String getFlowCarNo() {
        return flowCarNo;
    }

    public String getCarFarmeNo() {
        return carFarmeNo;
    }

    public Object getStatus() {
        return status;
    }

    public Object getSubmitCheckStatus() {
        return submitCheckStatus;
    }

    public Object getVarnishStatus() {
        return varnishStatus;
    }

    public Object getVarnishOperator() {
        return varnishOperator;
    }

    public Object getVarnishDate() {
        return varnishDate;
    }

    public Object getLocation() {
        return location;
    }

    public String getEnvironmentalLabel() {
        return environmentalLabel;
    }

    public Object getIsSpecialSubmitCheck() {
        return isSpecialSubmitCheck;
    }

    public Integer getIsExistCloseTrouble() {
        return isExistCloseTrouble;
    }

    public Object getSubmitCheckOperType() {
        return submitCheckOperType;
    }

    public Object getRainResult() {
        return rainResult;
    }

    public Object getRainCount() {
        return rainCount;
    }

    public Object getRainPart() {
        return rainPart;
    }

    public Object getRainBridgeType() {
        return rainBridgeType;
    }

    public Object getRainItem() {
        return rainItem;
    }

    public Object getStartTime() {
        return startTime;
    }

    public Object getEndTime() {
        return endTime;
    }

    public Object getSearchStatus() {
        return searchStatus;
    }

    public QmsManufactureProductionplanBean getQmsManufactureProductionplan() {
        return qmsManufactureProductionplan;
    }

    public Object getQmsZcproject() {
        return qmsZcproject;
    }

    public Object getSpecialSubmitRemark() {
        return specialSubmitRemark;
    }

    public Object getFileName() {
        return fileName;
    }

    public Object getFilePath() {
        return filePath;
    }

    public Boolean getConfigChange() {
        return configChange;
    }

    public static class QmsManufactureProductionplanBean {
        /**
         * id : null
         * isNewRecord : true
         * remarks : null
         * createDate : null
         * updateDate : null
         * supcodes : null
         * menuid : null
         * flowCarNo : null
         * carFrameNo : null
         * productionDate : null
         * productionDateStringIn : null
         * productionDateStringOut : null
         * carModelNo : ZZ4185H3613E1/J7V7M36-标运质赢
         * basicDevices : null
         * orderNo : ASSJ20080005
         * planOnlineDate : 2020-10-09 16:00:00
         * planOnlineDateStringIn : null
         * planOnlineDateStringOut : null
         * configDesc : ▲豪瀚N：玛瑙红,;豪瀚 N5；牵引车；豪瀚H78B驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；MC07.24-50发动机；8JS95TE-C变速箱；H653自调臂前轴(鼓)；MCJ09BG自调臂单后桥(鼓)；速比4.63；单层车架(7/250)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；295/80R22.5；50#JOST鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；。,送车
         * status : null
         * beginPlanOnlineDate : null
         * endPlanOnlineDate : null
         * workShop : null
         * productModel : null
         * productOrder : null
         * operType : null
         */

        private Object id;
        private Boolean isNewRecord;
        private Object remarks;
        private Object createDate;
        private Object updateDate;
        private Object supcodes;
        private Object menuid;
        private Object flowCarNo;
        private Object carFrameNo;
        private Object productionDate;
        private Object productionDateStringIn;
        private Object productionDateStringOut;
        private String carModelNo;
        private Object basicDevices;
        private String orderNo;
        private String planOnlineDate;
        private Object planOnlineDateStringIn;
        private Object planOnlineDateStringOut;
        private String configDesc;
        private Object status;
        private Object beginPlanOnlineDate;
        private Object endPlanOnlineDate;
        private Object workShop;
        private Object productModel;
        private Object productOrder;
        private Object operType;

        public void setId(Object id) {
            this.id = id;
        }

        public void setNewRecord(Boolean newRecord) {
            isNewRecord = newRecord;
        }

        public void setRemarks(Object remarks) {
            this.remarks = remarks;
        }

        public void setCreateDate(Object createDate) {
            this.createDate = createDate;
        }

        public void setUpdateDate(Object updateDate) {
            this.updateDate = updateDate;
        }

        public void setSupcodes(Object supcodes) {
            this.supcodes = supcodes;
        }

        public void setMenuid(Object menuid) {
            this.menuid = menuid;
        }

        public void setFlowCarNo(Object flowCarNo) {
            this.flowCarNo = flowCarNo;
        }

        public void setCarFrameNo(Object carFrameNo) {
            this.carFrameNo = carFrameNo;
        }

        public void setProductionDate(Object productionDate) {
            this.productionDate = productionDate;
        }

        public void setProductionDateStringIn(Object productionDateStringIn) {
            this.productionDateStringIn = productionDateStringIn;
        }

        public void setProductionDateStringOut(Object productionDateStringOut) {
            this.productionDateStringOut = productionDateStringOut;
        }

        public void setCarModelNo(String carModelNo) {
            this.carModelNo = carModelNo;
        }

        public void setBasicDevices(Object basicDevices) {
            this.basicDevices = basicDevices;
        }

        public void setOrderNo(String orderNo) {
            this.orderNo = orderNo;
        }

        public void setPlanOnlineDate(String planOnlineDate) {
            this.planOnlineDate = planOnlineDate;
        }

        public void setPlanOnlineDateStringIn(Object planOnlineDateStringIn) {
            this.planOnlineDateStringIn = planOnlineDateStringIn;
        }

        public void setPlanOnlineDateStringOut(Object planOnlineDateStringOut) {
            this.planOnlineDateStringOut = planOnlineDateStringOut;
        }

        public void setConfigDesc(String configDesc) {
            this.configDesc = configDesc;
        }

        public void setStatus(Object status) {
            this.status = status;
        }

        public void setBeginPlanOnlineDate(Object beginPlanOnlineDate) {
            this.beginPlanOnlineDate = beginPlanOnlineDate;
        }

        public void setEndPlanOnlineDate(Object endPlanOnlineDate) {
            this.endPlanOnlineDate = endPlanOnlineDate;
        }

        public void setWorkShop(Object workShop) {
            this.workShop = workShop;
        }

        public void setProductModel(Object productModel) {
            this.productModel = productModel;
        }

        public void setProductOrder(Object productOrder) {
            this.productOrder = productOrder;
        }

        public void setOperType(Object operType) {
            this.operType = operType;
        }

        public Object getId() {
            return id;
        }

        public Boolean getNewRecord() {
            return isNewRecord;
        }

        public Object getRemarks() {
            return remarks;
        }

        public Object getCreateDate() {
            return createDate;
        }

        public Object getUpdateDate() {
            return updateDate;
        }

        public Object getSupcodes() {
            return supcodes;
        }

        public Object getMenuid() {
            return menuid;
        }

        public Object getFlowCarNo() {
            return flowCarNo;
        }

        public Object getCarFrameNo() {
            return carFrameNo;
        }

        public Object getProductionDate() {
            return productionDate;
        }

        public Object getProductionDateStringIn() {
            return productionDateStringIn;
        }

        public Object getProductionDateStringOut() {
            return productionDateStringOut;
        }

        public String getCarModelNo() {
            return carModelNo;
        }

        public Object getBasicDevices() {
            return basicDevices;
        }

        public String getOrderNo() {
            return orderNo;
        }

        public String getPlanOnlineDate() {
            return planOnlineDate;
        }

        public Object getPlanOnlineDateStringIn() {
            return planOnlineDateStringIn;
        }

        public Object getPlanOnlineDateStringOut() {
            return planOnlineDateStringOut;
        }

        public String getConfigDesc() {
            return configDesc;
        }

        public Object getStatus() {
            return status;
        }

        public Object getBeginPlanOnlineDate() {
            return beginPlanOnlineDate;
        }

        public Object getEndPlanOnlineDate() {
            return endPlanOnlineDate;
        }

        public Object getWorkShop() {
            return workShop;
        }

        public Object getProductModel() {
            return productModel;
        }

        public Object getProductOrder() {
            return productOrder;
        }

        public Object getOperType() {
            return operType;
        }
    }


}
