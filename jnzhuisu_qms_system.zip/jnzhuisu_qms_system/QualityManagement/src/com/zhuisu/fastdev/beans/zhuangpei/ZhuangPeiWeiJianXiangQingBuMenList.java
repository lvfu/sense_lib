package com.zhuisu.fastdev.beans.zhuangpei;

/**
 * @author cxh
 * @description
 * @date 2020/10/12.
 */
public class ZhuangPeiWeiJianXiangQingBuMenList {
    private String code;
    private String name;

    public void setCode(String code) {
        this.code = code;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCode() {
        return code;
    }

    public String getName() {
        return name;
    }

    @Override
    public String toString() {
       return name;
    }
}
