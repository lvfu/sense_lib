package com.zhuisu.fastdev.beans.lack;

import java.util.List;

/**
 * @author cxh
 * @description
 * @date 2020/10/30.
 */

public class LackHistoryListBean {


    /**
     * pageNo : 1
     * pageSize : 100
     * count : 1
     * list : [{"id":"c8908cf3e99e40eb9a33d63ee174bfd3","isNewRecord":false,"createDate":"2020-10-30 10:41:01","updateDate":"2020-10-30 10:41:01","carFrameNo":"L77L29930","productOrder":"FO2008300007","orderNo":"CS200600640","bomId":"020V47104-0024/1    ","bomName":"同步件（南京ZF）","quantity":12,"source":"MATERIEL","recordUser":"sense","recordDate":"2020-10-30 10:41:01","status":"confirmed","wzkStore":0}]
     * firstResult : 0
     * maxResults : 100
     */


    /**
     * id : c8908cf3e99e40eb9a33d63ee174bfd3
     * isNewRecord : false
     * createDate : 2020-10-30 10:41:01
     * updateDate : 2020-10-30 10:41:01
     * carFrameNo : L77L29930
     * productOrder : FO2008300007
     * orderNo : CS200600640
     * bomId : 020V47104-0024/1
     * bomName : 同步件（南京ZF）
     * quantity : 12
     * source : MATERIEL
     * recordUser : sense
     * recordDate : 2020-10-30 10:41:01
     * status : confirmed
     * wzkStore : 0
     */

    private String id;
    private Boolean isNewRecord;
    private String createDate;
    private String updateDate;
    private String carFrameNo;
    private String productOrder;
    private String orderNo;
    private String bomId;
    private String bomName;
    private Integer quantity;
    private String source;
    private String recordUser;
    private String recordDate;
    private String status;
    private Integer wzkStore;
    private String recordUserName;

    public String getRecordUserName() {
        return recordUserName;
    }

    public void setRecordUserName(String recordUserName) {
        this.recordUserName = recordUserName;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setNewRecord(Boolean newRecord) {
        isNewRecord = newRecord;
    }

    public void setCreateDate(String createDate) {
        this.createDate = createDate;
    }

    public void setUpdateDate(String updateDate) {
        this.updateDate = updateDate;
    }

    public void setCarFrameNo(String carFrameNo) {
        this.carFrameNo = carFrameNo;
    }

    public void setProductOrder(String productOrder) {
        this.productOrder = productOrder;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    public void setBomId(String bomId) {
        this.bomId = bomId;
    }

    public void setBomName(String bomName) {
        this.bomName = bomName;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public void setRecordUser(String recordUser) {
        this.recordUser = recordUser;
    }

    public void setRecordDate(String recordDate) {
        this.recordDate = recordDate;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public void setWzkStore(Integer wzkStore) {
        this.wzkStore = wzkStore;
    }

    public String getId() {
        return id;
    }

    public Boolean getNewRecord() {
        return isNewRecord;
    }

    public String getCreateDate() {
        return createDate;
    }

    public String getUpdateDate() {
        return updateDate;
    }

    public String getCarFrameNo() {
        return carFrameNo;
    }

    public String getProductOrder() {
        return productOrder;
    }

    public String getOrderNo() {
        return orderNo;
    }

    public String getBomId() {
        return bomId;
    }

    public String getBomName() {
        return bomName;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public String getSource() {
        return source;
    }

    public String getRecordUser() {
        return recordUser;
    }

    public String getRecordDate() {
        return recordDate;
    }

    public String getStatus() {
        return status;
    }

    public Integer getWzkStore() {
        return wzkStore;
    }


}
