package com.zhuisu.fastdev.beans.online

/**
 * @author cxh
 * @description
 * @date 2020/11/10.
 */
data class OnLineDeHistoryBean(var operator : String? , var createDate : String?,var status : String?)