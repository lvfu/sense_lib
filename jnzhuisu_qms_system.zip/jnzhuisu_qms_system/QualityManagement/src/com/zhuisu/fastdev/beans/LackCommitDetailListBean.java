package com.zhuisu.fastdev.beans;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * @author cxh
 * @description
 * @date 2020/10/27.
 */
public class LackCommitDetailListBean implements Parcelable {
    private String materielIdOld;
    private String materielName;
    private String id;
    private String materielId;


    protected LackCommitDetailListBean(Parcel in) {
        materielIdOld = in.readString();
        materielName = in.readString();
        id = in.readString();
        materielId = in.readString();
    }

    public static final Creator<LackCommitDetailListBean> CREATOR = new Creator<LackCommitDetailListBean>() {
        @Override
        public LackCommitDetailListBean createFromParcel(Parcel in) {
            return new LackCommitDetailListBean(in);
        }

        @Override
        public LackCommitDetailListBean[] newArray(int size) {
            return new LackCommitDetailListBean[size];
        }
    };

    public void setMaterielIdOld(String materielIdOld) {
        this.materielIdOld = materielIdOld;
    }

    public void setMaterielName(String materielName) {
        this.materielName = materielName;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setMaterielId(String materielId) {
        this.materielId = materielId;
    }

    public String getMaterielIdOld() {
        return materielIdOld;
    }

    public String getMaterielName() {
        return materielName;
    }

    public String getId() {
        return id;
    }

    public String getMaterielId() {
        return materielId;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(materielIdOld);
        dest.writeString(materielName);
        dest.writeString(id);
        dest.writeString(materielId);
    }
}
