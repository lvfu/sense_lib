package com.zhuisu.fastdev.beans.consolework

import android.os.Parcel
import android.os.Parcelable

data class QualityDoorBean(
        var fdjh: String?, var nsxh: String?, var hclqh: String?
) : Parcelable {
    constructor(parcel: Parcel) : this(
            parcel.readString(),
            parcel.readString(),
            parcel.readString()) {
    }

    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeString(fdjh)
        parcel.writeString(nsxh)
        parcel.writeString(hclqh)
    }

    override fun describeContents(): Int {
        return 0
    }

    companion object CREATOR : Parcelable.Creator<QualityDoorBean> {
        override fun createFromParcel(parcel: Parcel): QualityDoorBean {
            return QualityDoorBean(parcel)
        }

        override fun newArray(size: Int): Array<QualityDoorBean?> {
            return arrayOfNulls(size)
        }
    }


}