package com.zhuisu.fastdev.beans.rain;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.List;

/**
 * @author cxh
 * @description
 * @date 2020/10/23.
 */


public class RainHistoryListBean implements Parcelable {

    /**
     * msg : 查询成功！
     * data : {"pageNo":1,"pageSize":-1,"count":0,"list":[{"id":"4C8B11AE540E4CA3AFB33906F203DB0C","isNewRecord":false,"remarks":null,"createDate":"2020-10-25 05:15:02","updateDate":null,"supcodes":null,"menuid":null,"operType":null,"flowCarNo":null,"carFarmeNo":"LA644780","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"locationName":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":"0","rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"rainOperator":"sense","startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":null,"basicDevices":null,"orderNo":"ABJK20080006","planOnlineDate":null,"planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":null,"status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"problemSource":null,"fileName":null,"filePath":null,"qmsRainPart":null,"distinguishType":null,"accordingDateType":null,"configChange":false},{"id":"4C2F8BACAB524D08A2BE635A1DD85BC9","isNewRecord":false,"remarks":null,"createDate":"2020-10-28 06:50:21","updateDate":null,"supcodes":null,"menuid":null,"operType":null,"flowCarNo":null,"carFarmeNo":"LA644780","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"locationName":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":"0","rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"rainOperator":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":null,"basicDevices":null,"orderNo":"ABJK20080006","planOnlineDate":null,"planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":null,"status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"problemSource":null,"fileName":null,"filePath":null,"qmsRainPart":null,"distinguishType":null,"accordingDateType":null,"configChange":false}],"firstResult":0,"maxResults":-1}
     * status : 0
     */


    /**
     * id : 4C8B11AE540E4CA3AFB33906F203DB0C
     * isNewRecord : false
     * remarks : null
     * createDate : 2020-10-25 05:15:02
     * updateDate : null
     * supcodes : null
     * menuid : null
     * operType : null
     * flowCarNo : null
     * carFarmeNo : LA644780
     * status : null
     * submitCheckStatus : null
     * varnishStatus : null
     * varnishOperator : null
     * varnishDate : null
     * location : null
     * locationName : null
     * environmentalLabel : null
     * isSpecialSubmitCheck : null
     * isExistCloseTrouble : 0
     * submitCheckOperType : null
     * rainResult : 0
     * rainCount : null
     * rainPart : null
     * rainBridgeType : null
     * rainItem : null
     * rainOperator : sense
     * startTime : null
     * endTime : null
     * searchStatus : null
     * qmsManufactureProductionplan : {"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":null,"basicDevices":null,"orderNo":"ABJK20080006","planOnlineDate":null,"planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":null,"status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null}
     * qmsZcproject : null
     * specialSubmitRemark : null
     * problemSource : null
     * fileName : null
     * filePath : null
     * qmsRainPart : null
     * distinguishType : null
     * accordingDateType : null
     * configChange : false
     */

    private String id;
    private Boolean isNewRecord;
    private Object remarks;
    private String createDate;
    private Object updateDate;
    private Object supcodes;
    private Object menuid;
    private Object operType;
    private Object flowCarNo;
    private String carFarmeNo;
    private Object status;
    private Object submitCheckStatus;
    private Object varnishStatus;
    private Object varnishOperator;
    private Object varnishDate;
    private Object location;
    private Object locationName;
    private Object environmentalLabel;
    private Object isSpecialSubmitCheck;
    private Integer isExistCloseTrouble;
    private Object submitCheckOperType;
    private String rainResult;
    private Object rainCount;
    private Object rainPart;
    private Object rainBridgeType;
    private Object rainItem;
    private String rainOperator;
    private Object startTime;
    private Object endTime;
    private Object searchStatus;
    private QmsManufactureProductionplanBean qmsManufactureProductionplan;
    private Object qmsZcproject;
    private Object specialSubmitRemark;
    private Object problemSource;
    private Object fileName;
    private Object filePath;
    private Object qmsRainPart;
    private Object distinguishType;
    private Object accordingDateType;
    private Boolean configChange;

    protected RainHistoryListBean(Parcel in) {
        id = in.readString();
        byte tmpIsNewRecord = in.readByte();
        isNewRecord = tmpIsNewRecord == 0 ? null : tmpIsNewRecord == 1;
        createDate = in.readString();
        carFarmeNo = in.readString();
        if (in.readByte() == 0) {
            isExistCloseTrouble = null;
        } else {
            isExistCloseTrouble = in.readInt();
        }
        rainResult = in.readString();
        rainOperator = in.readString();
        qmsManufactureProductionplan = in.readParcelable(QmsManufactureProductionplanBean.class.getClassLoader());
        byte tmpConfigChange = in.readByte();
        configChange = tmpConfigChange == 0 ? null : tmpConfigChange == 1;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(id);
        dest.writeByte((byte) (isNewRecord == null ? 0 : isNewRecord ? 1 : 2));
        dest.writeString(createDate);
        dest.writeString(carFarmeNo);
        if (isExistCloseTrouble == null) {
            dest.writeByte((byte) 0);
        } else {
            dest.writeByte((byte) 1);
            dest.writeInt(isExistCloseTrouble);
        }
        dest.writeString(rainResult);
        dest.writeString(rainOperator);
        dest.writeParcelable(qmsManufactureProductionplan, flags);
        dest.writeByte((byte) (configChange == null ? 0 : configChange ? 1 : 2));
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<RainHistoryListBean> CREATOR = new Creator<RainHistoryListBean>() {
        @Override
        public RainHistoryListBean createFromParcel(Parcel in) {
            return new RainHistoryListBean(in);
        }

        @Override
        public RainHistoryListBean[] newArray(int size) {
            return new RainHistoryListBean[size];
        }
    };

    public void setId(String id) {
        this.id = id;
    }

    public void setNewRecord(Boolean newRecord) {
        isNewRecord = newRecord;
    }

    public void setRemarks(Object remarks) {
        this.remarks = remarks;
    }

    public void setCreateDate(String createDate) {
        this.createDate = createDate;
    }

    public void setUpdateDate(Object updateDate) {
        this.updateDate = updateDate;
    }

    public void setSupcodes(Object supcodes) {
        this.supcodes = supcodes;
    }

    public void setMenuid(Object menuid) {
        this.menuid = menuid;
    }

    public void setOperType(Object operType) {
        this.operType = operType;
    }

    public void setFlowCarNo(Object flowCarNo) {
        this.flowCarNo = flowCarNo;
    }

    public void setCarFarmeNo(String carFarmeNo) {
        this.carFarmeNo = carFarmeNo;
    }

    public void setStatus(Object status) {
        this.status = status;
    }

    public void setSubmitCheckStatus(Object submitCheckStatus) {
        this.submitCheckStatus = submitCheckStatus;
    }

    public void setVarnishStatus(Object varnishStatus) {
        this.varnishStatus = varnishStatus;
    }

    public void setVarnishOperator(Object varnishOperator) {
        this.varnishOperator = varnishOperator;
    }

    public void setVarnishDate(Object varnishDate) {
        this.varnishDate = varnishDate;
    }

    public void setLocation(Object location) {
        this.location = location;
    }

    public void setLocationName(Object locationName) {
        this.locationName = locationName;
    }

    public void setEnvironmentalLabel(Object environmentalLabel) {
        this.environmentalLabel = environmentalLabel;
    }

    public void setIsSpecialSubmitCheck(Object isSpecialSubmitCheck) {
        this.isSpecialSubmitCheck = isSpecialSubmitCheck;
    }

    public void setIsExistCloseTrouble(Integer isExistCloseTrouble) {
        this.isExistCloseTrouble = isExistCloseTrouble;
    }

    public void setSubmitCheckOperType(Object submitCheckOperType) {
        this.submitCheckOperType = submitCheckOperType;
    }

    public void setRainResult(String rainResult) {
        this.rainResult = rainResult;
    }

    public void setRainCount(Object rainCount) {
        this.rainCount = rainCount;
    }

    public void setRainPart(Object rainPart) {
        this.rainPart = rainPart;
    }

    public void setRainBridgeType(Object rainBridgeType) {
        this.rainBridgeType = rainBridgeType;
    }

    public void setRainItem(Object rainItem) {
        this.rainItem = rainItem;
    }

    public void setRainOperator(String rainOperator) {
        this.rainOperator = rainOperator;
    }

    public void setStartTime(Object startTime) {
        this.startTime = startTime;
    }

    public void setEndTime(Object endTime) {
        this.endTime = endTime;
    }

    public void setSearchStatus(Object searchStatus) {
        this.searchStatus = searchStatus;
    }

    public void setQmsManufactureProductionplan(QmsManufactureProductionplanBean qmsManufactureProductionplan) {
        this.qmsManufactureProductionplan = qmsManufactureProductionplan;
    }

    public void setQmsZcproject(Object qmsZcproject) {
        this.qmsZcproject = qmsZcproject;
    }

    public void setSpecialSubmitRemark(Object specialSubmitRemark) {
        this.specialSubmitRemark = specialSubmitRemark;
    }

    public void setProblemSource(Object problemSource) {
        this.problemSource = problemSource;
    }

    public void setFileName(Object fileName) {
        this.fileName = fileName;
    }

    public void setFilePath(Object filePath) {
        this.filePath = filePath;
    }

    public void setQmsRainPart(Object qmsRainPart) {
        this.qmsRainPart = qmsRainPart;
    }

    public void setDistinguishType(Object distinguishType) {
        this.distinguishType = distinguishType;
    }

    public void setAccordingDateType(Object accordingDateType) {
        this.accordingDateType = accordingDateType;
    }

    public void setConfigChange(Boolean configChange) {
        this.configChange = configChange;
    }

    public String getId() {
        return id;
    }

    public Boolean getNewRecord() {
        return isNewRecord;
    }

    public Object getRemarks() {
        return remarks;
    }

    public String getCreateDate() {
        return createDate;
    }

    public Object getUpdateDate() {
        return updateDate;
    }

    public Object getSupcodes() {
        return supcodes;
    }

    public Object getMenuid() {
        return menuid;
    }

    public Object getOperType() {
        return operType;
    }

    public Object getFlowCarNo() {
        return flowCarNo;
    }

    public String getCarFarmeNo() {
        return carFarmeNo;
    }

    public Object getStatus() {
        return status;
    }

    public Object getSubmitCheckStatus() {
        return submitCheckStatus;
    }

    public Object getVarnishStatus() {
        return varnishStatus;
    }

    public Object getVarnishOperator() {
        return varnishOperator;
    }

    public Object getVarnishDate() {
        return varnishDate;
    }

    public Object getLocation() {
        return location;
    }

    public Object getLocationName() {
        return locationName;
    }

    public Object getEnvironmentalLabel() {
        return environmentalLabel;
    }

    public Object getIsSpecialSubmitCheck() {
        return isSpecialSubmitCheck;
    }

    public Integer getIsExistCloseTrouble() {
        return isExistCloseTrouble;
    }

    public Object getSubmitCheckOperType() {
        return submitCheckOperType;
    }

    public String getRainResult() {
        return rainResult;
    }

    public Object getRainCount() {
        return rainCount;
    }

    public Object getRainPart() {
        return rainPart;
    }

    public Object getRainBridgeType() {
        return rainBridgeType;
    }

    public Object getRainItem() {
        return rainItem;
    }

    public String getRainOperator() {
        return rainOperator;
    }

    public Object getStartTime() {
        return startTime;
    }

    public Object getEndTime() {
        return endTime;
    }

    public Object getSearchStatus() {
        return searchStatus;
    }

    public QmsManufactureProductionplanBean getQmsManufactureProductionplan() {
        return qmsManufactureProductionplan;
    }

    public Object getQmsZcproject() {
        return qmsZcproject;
    }

    public Object getSpecialSubmitRemark() {
        return specialSubmitRemark;
    }

    public Object getProblemSource() {
        return problemSource;
    }

    public Object getFileName() {
        return fileName;
    }

    public Object getFilePath() {
        return filePath;
    }

    public Object getQmsRainPart() {
        return qmsRainPart;
    }

    public Object getDistinguishType() {
        return distinguishType;
    }

    public Object getAccordingDateType() {
        return accordingDateType;
    }

    public Boolean getConfigChange() {
        return configChange;
    }

    public static class QmsManufactureProductionplanBean implements Parcelable {
        /**
         * id : null
         * isNewRecord : true
         * remarks : null
         * createDate : null
         * updateDate : null
         * supcodes : null
         * menuid : null
         * flowCarNo : null
         * carFrameNo : null
         * productionDate : null
         * productionDateStringIn : null
         * productionDateStringOut : null
         * carModelNo : null
         * basicDevices : null
         * orderNo : ABJK20080006
         * planOnlineDate : null
         * planOnlineDateStringIn : null
         * planOnlineDateStringOut : null
         * configDesc : null
         * status : null
         * beginPlanOnlineDate : null
         * endPlanOnlineDate : null
         * workShop : null
         * productModel : null
         * productOrder : null
         * operType : null
         */

        private Object id;
        private Boolean isNewRecord;
        private Object remarks;
        private Object createDate;
        private Object updateDate;
        private Object supcodes;
        private Object menuid;
        private Object flowCarNo;
        private Object carFrameNo;
        private Object productionDate;
        private Object productionDateStringIn;
        private Object productionDateStringOut;
        private Object carModelNo;
        private Object basicDevices;
        private String orderNo;
        private Object planOnlineDate;
        private Object planOnlineDateStringIn;
        private Object planOnlineDateStringOut;
        private Object configDesc;
        private Object status;
        private Object beginPlanOnlineDate;
        private Object endPlanOnlineDate;
        private Object workShop;
        private Object productModel;
        private Object productOrder;
        private Object operType;

        protected QmsManufactureProductionplanBean(Parcel in) {
            byte tmpIsNewRecord = in.readByte();
            isNewRecord = tmpIsNewRecord == 0 ? null : tmpIsNewRecord == 1;
            orderNo = in.readString();
        }

        public static final Creator<QmsManufactureProductionplanBean> CREATOR = new Creator<QmsManufactureProductionplanBean>() {
            @Override
            public QmsManufactureProductionplanBean createFromParcel(Parcel in) {
                return new QmsManufactureProductionplanBean(in);
            }

            @Override
            public QmsManufactureProductionplanBean[] newArray(int size) {
                return new QmsManufactureProductionplanBean[size];
            }
        };

        public void setId(Object id) {
            this.id = id;
        }

        public void setNewRecord(Boolean newRecord) {
            isNewRecord = newRecord;
        }

        public void setRemarks(Object remarks) {
            this.remarks = remarks;
        }

        public void setCreateDate(Object createDate) {
            this.createDate = createDate;
        }

        public void setUpdateDate(Object updateDate) {
            this.updateDate = updateDate;
        }

        public void setSupcodes(Object supcodes) {
            this.supcodes = supcodes;
        }

        public void setMenuid(Object menuid) {
            this.menuid = menuid;
        }

        public void setFlowCarNo(Object flowCarNo) {
            this.flowCarNo = flowCarNo;
        }

        public void setCarFrameNo(Object carFrameNo) {
            this.carFrameNo = carFrameNo;
        }

        public void setProductionDate(Object productionDate) {
            this.productionDate = productionDate;
        }

        public void setProductionDateStringIn(Object productionDateStringIn) {
            this.productionDateStringIn = productionDateStringIn;
        }

        public void setProductionDateStringOut(Object productionDateStringOut) {
            this.productionDateStringOut = productionDateStringOut;
        }

        public void setCarModelNo(Object carModelNo) {
            this.carModelNo = carModelNo;
        }

        public void setBasicDevices(Object basicDevices) {
            this.basicDevices = basicDevices;
        }

        public void setOrderNo(String orderNo) {
            this.orderNo = orderNo;
        }

        public void setPlanOnlineDate(Object planOnlineDate) {
            this.planOnlineDate = planOnlineDate;
        }

        public void setPlanOnlineDateStringIn(Object planOnlineDateStringIn) {
            this.planOnlineDateStringIn = planOnlineDateStringIn;
        }

        public void setPlanOnlineDateStringOut(Object planOnlineDateStringOut) {
            this.planOnlineDateStringOut = planOnlineDateStringOut;
        }

        public void setConfigDesc(Object configDesc) {
            this.configDesc = configDesc;
        }

        public void setStatus(Object status) {
            this.status = status;
        }

        public void setBeginPlanOnlineDate(Object beginPlanOnlineDate) {
            this.beginPlanOnlineDate = beginPlanOnlineDate;
        }

        public void setEndPlanOnlineDate(Object endPlanOnlineDate) {
            this.endPlanOnlineDate = endPlanOnlineDate;
        }

        public void setWorkShop(Object workShop) {
            this.workShop = workShop;
        }

        public void setProductModel(Object productModel) {
            this.productModel = productModel;
        }

        public void setProductOrder(Object productOrder) {
            this.productOrder = productOrder;
        }

        public void setOperType(Object operType) {
            this.operType = operType;
        }

        public Object getId() {
            return id;
        }

        public Boolean getNewRecord() {
            return isNewRecord;
        }

        public Object getRemarks() {
            return remarks;
        }

        public Object getCreateDate() {
            return createDate;
        }

        public Object getUpdateDate() {
            return updateDate;
        }

        public Object getSupcodes() {
            return supcodes;
        }

        public Object getMenuid() {
            return menuid;
        }

        public Object getFlowCarNo() {
            return flowCarNo;
        }

        public Object getCarFrameNo() {
            return carFrameNo;
        }

        public Object getProductionDate() {
            return productionDate;
        }

        public Object getProductionDateStringIn() {
            return productionDateStringIn;
        }

        public Object getProductionDateStringOut() {
            return productionDateStringOut;
        }

        public Object getCarModelNo() {
            return carModelNo;
        }

        public Object getBasicDevices() {
            return basicDevices;
        }

        public String getOrderNo() {
            return orderNo;
        }

        public Object getPlanOnlineDate() {
            return planOnlineDate;
        }

        public Object getPlanOnlineDateStringIn() {
            return planOnlineDateStringIn;
        }

        public Object getPlanOnlineDateStringOut() {
            return planOnlineDateStringOut;
        }

        public Object getConfigDesc() {
            return configDesc;
        }

        public Object getStatus() {
            return status;
        }

        public Object getBeginPlanOnlineDate() {
            return beginPlanOnlineDate;
        }

        public Object getEndPlanOnlineDate() {
            return endPlanOnlineDate;
        }

        public Object getWorkShop() {
            return workShop;
        }

        public Object getProductModel() {
            return productModel;
        }

        public Object getProductOrder() {
            return productOrder;
        }

        public Object getOperType() {
            return operType;
        }

        @Override
        public int describeContents() {
            return 0;
        }

        @Override
        public void writeToParcel(Parcel dest, int flags) {
            dest.writeByte((byte) (isNewRecord == null ? 0 : isNewRecord ? 1 : 2));
            dest.writeString(orderNo);
        }
    }


}
