package com.zhuisu.fastdev.beans;

/**
 * @author cxh
 * @description
 * @date 2020/10/21.
 */

public class RegisterCarConfigChangeBean {

    /**
     * msg : 获取变更记录成功！
     * data : {"pageNo":1,"pageSize":30,"count":1,"list":[{"id":"9ee54477b8574b1ebeca37abf78a569f","isNewRecord":false,"remarks":null,"createDate":"2020-10-21 01:01:08","updateDate":"2020-10-21 01:01:08","supcodes":null,"menuid":null,"orderNo":"JHZJ20080008","num":"2","flowcarNo":"JHZJ20080008/0010-0003,JHZJ20080008/0010-0004,JHZJ20080008/0010-0005,JHZJ20080008/0010-0006,JHZJ20080008/0010-0001","changeDesc":"萨达撒多","operType":null}],"maxResults":30,"firstResult":0}
     * status : 0
     */

        /**
         * pageNo : 1
         * pageSize : 30
         * count : 1
         * list : [{"id":"9ee54477b8574b1ebeca37abf78a569f","isNewRecord":false,"remarks":null,"createDate":"2020-10-21 01:01:08","updateDate":"2020-10-21 01:01:08","supcodes":null,"menuid":null,"orderNo":"JHZJ20080008","num":"2","flowcarNo":"JHZJ20080008/0010-0003,JHZJ20080008/0010-0004,JHZJ20080008/0010-0005,JHZJ20080008/0010-0006,JHZJ20080008/0010-0001","changeDesc":"萨达撒多","operType":null}]
         * maxResults : 30
         * firstResult : 0
         */


            /**
             * id : 9ee54477b8574b1ebeca37abf78a569f
             * isNewRecord : false
             * remarks : null
             * createDate : 2020-10-21 01:01:08
             * updateDate : 2020-10-21 01:01:08
             * supcodes : null
             * menuid : null
             * orderNo : JHZJ20080008
             * num : 2
             * flowcarNo : JHZJ20080008/0010-0003,JHZJ20080008/0010-0004,JHZJ20080008/0010-0005,JHZJ20080008/0010-0006,JHZJ20080008/0010-0001
             * changeDesc : 萨达撒多
             * operType : null
             */

            private String id;
            private Boolean isNewRecord;
            private Object remarks;
            private String createDate;
            private String updateDate;
            private Object supcodes;
            private Object menuid;
            private String orderNo;
            private String num;
            private String flowcarNo;
            private String changeDesc;
            private Object operType;

    public void setId(String id) {
        this.id = id;
    }

    public void setNewRecord(Boolean newRecord) {
        isNewRecord = newRecord;
    }

    public void setRemarks(Object remarks) {
        this.remarks = remarks;
    }

    public void setCreateDate(String createDate) {
        this.createDate = createDate;
    }

    public void setUpdateDate(String updateDate) {
        this.updateDate = updateDate;
    }

    public void setSupcodes(Object supcodes) {
        this.supcodes = supcodes;
    }

    public void setMenuid(Object menuid) {
        this.menuid = menuid;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    public void setNum(String num) {
        this.num = num;
    }

    public void setFlowcarNo(String flowcarNo) {
        this.flowcarNo = flowcarNo;
    }

    public void setChangeDesc(String changeDesc) {
        this.changeDesc = changeDesc;
    }

    public void setOperType(Object operType) {
        this.operType = operType;
    }

    public String getId() {
        return id;
    }

    public Boolean getNewRecord() {
        return isNewRecord;
    }

    public Object getRemarks() {
        return remarks;
    }

    public String getCreateDate() {
        return createDate;
    }

    public String getUpdateDate() {
        return updateDate;
    }

    public Object getSupcodes() {
        return supcodes;
    }

    public Object getMenuid() {
        return menuid;
    }

    public String getOrderNo() {
        return orderNo;
    }

    public String getNum() {
        return num;
    }

    public String getFlowcarNo() {
        return flowcarNo;
    }

    public String getChangeDesc() {
        return changeDesc;
    }

    public Object getOperType() {
        return operType;
    }
}
