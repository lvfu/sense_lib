package com.zhuisu.fastdev.beans.xunjian;

/**
 * @author cxh
 * @description
 * @date 2020/10/12.
 */
public class XunJianWeiJianXiangQingGongYingShangList {
    private String id;
    private String text;
    private String isNewRecord;

    public String getId() {
        return id;
    }

    public String getText() {
        return text;
    }

    public String getIsNewRecord() {
        return isNewRecord;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setText(String text) {
        this.text = text;
    }

    public void setIsNewRecord(String isNewRecord) {
        this.isNewRecord = isNewRecord;
    }

    @Override
    public String toString() {
        return text;
    }
}
