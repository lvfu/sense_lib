package com.zhuisu.fastdev.beans.zhiliangmen;

/**
 * @author cxh
 * @description
 * @date 2020/10/12.
 */
public class ZhiLiangMenWeiJianGuZhangXinxiBean {
    private String malfunctionLevel;
    private String malfunctionNo;
    private String malfunctionName;

    public void setMalfunctionLevel(String malfunctionLevel) {
        this.malfunctionLevel = malfunctionLevel;
    }

    public void setMalfunctionNo(String malfunctionNo) {
        this.malfunctionNo = malfunctionNo;
    }

    public void setMalfunctionName(String malfunctionName) {
        this.malfunctionName = malfunctionName;
    }

    public String getMalfunctionLevel() {
        return malfunctionLevel;
    }

    public String getMalfunctionNo() {
        return malfunctionNo;
    }

    public String getMalfunctionName() {
        return malfunctionName;
    }

    @Override
    public String toString() {
        return malfunctionName+"-"+malfunctionLevel;
    }
}
