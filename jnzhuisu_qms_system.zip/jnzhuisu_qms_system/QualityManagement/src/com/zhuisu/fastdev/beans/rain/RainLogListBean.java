package com.zhuisu.fastdev.beans.rain;

/**
 * @author cxh
 * @description
 * @date 2020/10/26.
 */

public class RainLogListBean {


        /**
         * id : null
         * isNewRecord : true
         * remarks : null
         * createDate : null
         * updateDate : null
         * supcodes : null
         * menuid : null
         * operType : null
         * carFarmeNo : null
         * part : 驾驶室
         * partNo : JSSBW
         * remark : null
         * filePath : null
         * fileName : null
         * yesNo : null
         * imgStr : null
         * rainRecordId : null
         */

        private String id;
        private Boolean isNewRecord;
        private String remarks;
        private String createDate;
        private String updateDate;
        private String supcodes;
        private String menuid;
        private String operType;
        private String carFarmeNo;
        private String part;
        private String partNo;
        private String remark;
        private String filePath;
        private String fileName;
        private String yesNo;
        private String imgStr;
        private String rainRecordId;

    public void setId(String id) {
        this.id = id;
    }

    public void setNewRecord(Boolean newRecord) {
        isNewRecord = newRecord;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public void setCreateDate(String createDate) {
        this.createDate = createDate;
    }

    public void setUpdateDate(String updateDate) {
        this.updateDate = updateDate;
    }

    public void setSupcodes(String supcodes) {
        this.supcodes = supcodes;
    }

    public void setMenuid(String menuid) {
        this.menuid = menuid;
    }

    public void setOperType(String operType) {
        this.operType = operType;
    }

    public void setCarFarmeNo(String carFarmeNo) {
        this.carFarmeNo = carFarmeNo;
    }

    public void setPart(String part) {
        this.part = part;
    }

    public void setPartNo(String partNo) {
        this.partNo = partNo;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public void setYesNo(String yesNo) {
        this.yesNo = yesNo;
    }

    public void setImgStr(String imgStr) {
        this.imgStr = imgStr;
    }

    public void setRainRecordId(String rainRecordId) {
        this.rainRecordId = rainRecordId;
    }

    public Boolean getNewRecord() {
        return isNewRecord;
    }

    public String getRemarks() {
        return remarks;
    }

    public String getCreateDate() {
        return createDate;
    }

    public String getUpdateDate() {
        return updateDate;
    }

    public String getSupcodes() {
        return supcodes;
    }

    public String getMenuid() {
        return menuid;
    }

    public String getOperType() {
        return operType;
    }

    public String getCarFarmeNo() {
        return carFarmeNo;
    }

    public String getPart() {
        return part;
    }

    public String getPartNo() {
        return partNo;
    }

    public String getRemark() {
        return remark;
    }

    public String getFilePath() {
        return filePath;
    }

    public String getFileName() {
        return fileName;
    }

    public String getYesNo() {
        return yesNo;
    }

    public String getImgStr() {
        return imgStr;
    }

    public String getRainRecordId() {
        return rainRecordId;
    }

    public String getId() {
        return id;
    }
}
