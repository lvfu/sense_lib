package com.zhuisu.fastdev.beans.consolework

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.support.design.widget.Snackbar
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.text.TextUtils
import android.util.ArrayMap
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.TextView
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.zhuisu.fastdev.BaseActivity
import com.zhuisu.fastdev.adapter.consolework.ConsoleProjectAdapter
import com.zhuisu.fastdev.beans.registercar.RegisterCarDetails
import com.zhuisu.fastdev.dialog.BasePopupWindowDialog
import com.zhuisu.fastdev.ui.jieche.RegisterCarConfigChangeActivity
import com.zhuisu.fastdev.ui.problem.ProblemCloseActivity
import com.zhuisu.qualityManagement.R
import com.zhuisu.suppliermanagement.util.GlobalVar
import com.zhuisu.suppliermanagement.util.ToastUtils
import okhttp3.*
import org.json.JSONException
import org.json.JSONObject
import java.io.IOException

/**
 * @author cxh
 * @description 作业项目
 * @date 2020/11/16.
 */

class ConsoleProjectActivity : BaseActivity(), ConsoleProjectAdapter.OnItemClickListener {

    var firstData: ConsoleWorkList? = null
    var list: ArrayList<ConsoleProjectList>? = null
    var adapter: ConsoleProjectAdapter? = null
    var tvChange: TextView? = null
    var index = 0

    companion object {
        const val ACTION_VALUE = "action_value"
    }

    @SuppressLint("SetTextI18n")
    override fun initViews() {
        list = ArrayList()
        adapter = ConsoleProjectAdapter(list!!, context)

        if ((intent != null) && (intent.getParcelableExtra<ConsoleWorkList>(ACTION_VALUE) != null)) {
            firstData = intent.getParcelableExtra(ACTION_VALUE)
            val tvFlowNumber: TextView = findViewById(R.id.tv_flow_number)
            val tvCarFrameNumber: TextView = findViewById(R.id.tv_car_frame_number)

            queryDetail()


            tvFlowNumber.text = firstData!!.flowCarNo
            tvCarFrameNumber.text = firstData!!.carFarmeNo

            tvChange = findViewById(R.id.tv_config_change)

            val manager = LinearLayoutManager(context)
            manager.orientation = LinearLayoutManager.VERTICAL
            val rvList: RecyclerView = findViewById(R.id.rv_list)
            rvList.layoutManager = manager
            rvList.adapter = adapter
            adapter!!.onItenClick = this
            val tvUserName: TextView = findViewById(R.id.tv_user_name)
            tvUserName.text = "\t" + GlobalVar.realname

        }

        findViewById<Button>(R.id.btn_problem_list).setOnClickListener {
            val notCloseIntent = Intent(context, ProblemCloseActivity::class.java)
            notCloseIntent.putExtra(ProblemCloseActivity.ACTION_PARAMS, firstData!!.carFarmeNo)
            notCloseIntent.putExtra(ProblemCloseActivity.ACTION_FORM_FINISH_CHECK, false)
            context!!.startActivity(notCloseIntent)
        }

        findViewById<Button>(R.id.btn_all_successful).setOnClickListener {
            if (list == null || list!!.isEmpty())
                ToastUtils.show("暂无数据")
            else {
                val dialog = BasePopupWindowDialog()
                val arguments = Bundle()
                arguments.putString(BasePopupWindowDialog.ACTION_VALUE_TITLE, "提示")
                arguments.putString(BasePopupWindowDialog.ACTION_VALUE_MESSAGE, "将待检状态全部改为合格,是否确认")
                dialog.arguments = arguments

                dialog.setOnConfirmClickListener {
                    dialog.dismiss()
                    index = 0;
                    for (i in list!!.indices) {
                        val state =
                            if (list!![i].status == "passed") "合格" else if (list!![i].status == "failed") "不合格" else if (list!![i].status == "noCheck") "免检" else "待检验"
                        if (TextUtils.equals("待检验", state)) {
                            index++
                        }
                    }

                    for (i in list!!.indices) {
                        val state =
                            if (list!![i].status == "passed") "合格" else if (list!![i].status == "failed") "不合格" else if (list!![i].status == "noCheck") "免检" else "待检验"
                        if (TextUtils.equals("待检验", state)) {
                            checkSuccess(list!![i].id!!, index)
                        }

                    }
                }
                dialog.show(supportFragmentManager, "")

            }

        }
    }


    /**
     * 查询详情
     * */
    fun queryDetail() {
        val map = ArrayMap<String, String>()
        map["carFarmeNo"] = firstData!!.carFarmeNo
        val param = gson.toJson(map)
        Log.e("获取详情", param)
        val client = OkHttpClient()
        val requestBody = RequestBody.create(JSON, param)
        val request = Request.Builder()
            .post(requestBody)
            .url(GlobalVar.url + "a/offlinedebuggingstatus/qmsOfflineStatus/api/carFrameInfo")
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread {
                    Log.d(TAG, "onFailure: 失败")
                }
            }

            override fun onResponse(call: Call, response: Response) {
                val result = response.body()!!.string()
                runOnUiThread {
                    try {
                        Log.e("--->获取详情", result)
                        val jsonObject = JSONObject(result)
                        if (jsonObject.optString("status") == "-1") {
                            ToastUtils.show(jsonObject.optString("msg"))
                        } else {
                            val current: RegisterCarDetails = gson.fromJson(
                                jsonObject.optString("data"),
                                RegisterCarDetails::class.java
                            )
                            val tvConfig: TextView = findViewById(R.id.tv_config)
                            tvConfig.text =
                                "配置: " + current.qmsManufactureProductionplan?.configDesc //配置


                            val tvNumber: TextView = findViewById(R.id.tv_number)
                            tvNumber.text =
                                "发动机号: " + current.engineNumber + "\n" + "气瓶号: " + current.cylinderNumber//配置


                            val tvModel: TextView = findViewById(R.id.tv_car_model)
                            tvModel.text =
                                "车型号: ${current!!.qmsManufactureProductionplan.carModelNo}"

                            tvChange!!.visibility =
                                if (current.configChange) View.VISIBLE else View.GONE
                            tvChange!!.setOnClickListener {
                                val configChangeIntent =
                                    Intent(context, RegisterCarConfigChangeActivity::class.java)
                                val data = RegisterCarDetails()
                                data.flowCarNo = firstData!!.flowCarNo
                                configChangeIntent.putExtra(
                                    RegisterCarConfigChangeActivity.ACTION_DATA,
                                    data
                                )
                                startActivity(configChangeIntent)
                            }
                        }

                    } catch (jsonException: JSONException) {
                        jsonException.printStackTrace()
                    }
                }
            }
        })
    }

    /**
     * 检查合格
     */
    var temp = 0
    private fun checkSuccess(id: String, position: Int) {
        val map = ArrayMap<String, String>()
        map["id"] = id
        map["checkedBy"] = GlobalVar.username
        val param = gson.toJson(map)
        val client = OkHttpClient()
        val requestBody = RequestBody.create(JSON, param)
        val request = Request.Builder()
            .post(requestBody)
            .url(GlobalVar.url + "a/prduictionrelation/qmsManufactureProductionplanrelation/api/checkPassed")
            .build()
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread { ToastUtils.show("请求失败") }
            }

            @Throws(IOException::class)
            override fun onResponse(call: Call, response: Response) {
                val result = response.body()!!.string()
                Log.d(TAG, "onResponse: $result")
                runOnUiThread {
                    try {
                        val jsonObject = JSONObject(result)
                        if (TextUtils.equals("0", jsonObject.optString("retCode"))) {

                            Log.e("--->", "index=" + index + "pos=" + position)
                            if (position == -1) {
                                query()
                            } else {
                                Log.e("--->", "temp=" + temp + "pos=" + position)
                                temp++
                                if (temp == position) {
                                    ToastUtils.show("成功")
//                                    finish()
                                    Handler().postDelayed({ query() }, 1000)
                                }
                            }
                        } else {
                            ToastUtils.show(jsonObject.optString("retMessage"))

                        }
                    } catch (e: JSONException) {
                        e.printStackTrace()
                    }
                }
            }
        })
    }

    override fun onResume() {
        super.onResume()
        query()
    }

    fun query() {
        list!!.clear()
        adapter?.notifyDataSetChanged()
        val map = ArrayMap<String, String>()

        map["carframeNo"] = firstData!!.carFarmeNo
        map["loginName"] = GlobalVar.username
        map["flowcarNo"] = firstData!!.flowCarNo

        val param = gson.toJson(map)
        Log.e("参数", param)
        val client = OkHttpClient()
        val requestBody = RequestBody.create(JSON, param)
        val request = Request.Builder()
            .post(requestBody)
            .url(GlobalVar.url + "a/prduictionrelation/qmsManufactureProductionplanrelation/api/qryCheckItems")
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread {
                    Log.d(TAG, "onFailure: 失败")
                }
            }

            override fun onResponse(call: Call, response: Response) {
                val result = response.body()!!.string()
                runOnUiThread {
                    try {
                        Log.e("--->", result)
                        val jsonObject = JSONObject(result)
                        if (TextUtils.equals(
                                jsonObject.optString("retCode"),
                                "0"
                            ) && jsonObject.optString("data") != null && !jsonObject.optString("data")
                                .isBlank()
                        ) {
                            val listType =
                                object : TypeToken<ArrayList<ConsoleProjectList>>() {}.type
                            val temp: ArrayList<ConsoleProjectList> =
                                Gson().fromJson(jsonObject.optString("data"), listType)
                            list!!.addAll(temp)
                            adapter!!.notifyDataSetChanged()

                        } else
                            showEmptyMessage()

                    } catch (jsonException: JSONException) {
                        jsonException.printStackTrace()
                    }
                }
            }
        })
    }

    override fun getResId(): Int {
        return R.layout.activity_console_project
    }

    /**
     * 检查不合格
     */
    override fun onItemClickListener(position: Int) {
        val intent = Intent(context, ConsoleProjectInputActivity::class.java)
        intent.putExtra(ConsoleProjectInputActivity.ACTION_DATA, list!![position])
        intent.putExtra(ConsoleProjectInputActivity.ACTION_FIRST_DATA, firstData?.status)

        startActivity(intent)

    }

    override fun onSuccessClick(position: Int) {
        checkSuccess(list!![position].id!!, -1)
    }

    //免检
    override fun onNotCheckClick(position: Int) {
        val map = ArrayMap<String, String>()
        map["id"] = list!![position].id
        map["checkedBy"] = GlobalVar.username
        val param = gson.toJson(map)
        Log.e("-->", param)
        Log.e(
            "url:",
            GlobalVar.url + "a/prduictionrelation/qmsManufactureProductionplanrelation/api/noCheck"
        )
        val client = OkHttpClient()
        val requestBody = RequestBody.create(JSON, param)
        val request = Request.Builder()
            .post(requestBody)
            .url(GlobalVar.url + "a/prduictionrelation/qmsManufactureProductionplanrelation/api/noCheck")
            .build()
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread { ToastUtils.show("请求失败") }
            }

            @Throws(IOException::class)
            override fun onResponse(call: Call, response: Response) {
                val result = response.body()!!.string()
                Log.d(TAG, "onResponse: $result")
                runOnUiThread {
                    try {
                        val jsonObject = JSONObject(result)
                        if (TextUtils.equals("0", jsonObject.optString("retCode"))) {
                            ToastUtils.show("成功")
                            query()
                        } else {
                            ToastUtils.show(jsonObject.optString("retMessage"))
                        }
                    } catch (e: JSONException) {
                        e.printStackTrace()
                    }
                }
            }
        })
    }

}
