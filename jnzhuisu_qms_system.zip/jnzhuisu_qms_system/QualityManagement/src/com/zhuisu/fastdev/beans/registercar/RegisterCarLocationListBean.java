package com.zhuisu.fastdev.beans.registercar;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * @author cxh
 * @description
 * @date 2020/10/20.
 */

public class RegisterCarLocationListBean  implements Parcelable {
    /**
     * retCode : 0
     * data : [{"id":"3975be3c11b04402b081eccf632c3fdd","isNewRecord":false,"remarks":"整车下线接收库位","createDate":"2020-09-04 10:58:17","updateDate":"2020-09-04 10:58:17","value":"1","label":"调试区","type":"CAR_LOCATION","description":"整车下线接收库位","sort":10,"parentId":"0"},{"id":"cfa9acc9371e4eebbdac03cfa00e1268","isNewRecord":false,"remarks":"整车下线接收库位","createDate":"2020-09-04 10:58:47","updateDate":"2020-09-04 10:58:47","value":"2","label":"检测线南","type":"CAR_LOCATION","description":"整车下线接收库位","sort":20,"parentId":"0"},{"id":"fe5e5fed786b41dcb24b274ad2b84870","isNewRecord":false,"remarks":"整车下线接收库位","createDate":"2020-09-04 10:59:22","updateDate":"2020-09-04 10:59:22","value":"3","label":"新库区","type":"CAR_LOCATION","description":"整车下线接收库位","sort":30,"parentId":"0"},{"id":"58a59c8a86524400b9665382ca142a06","isNewRecord":false,"remarks":"整车下线接收库位","createDate":"2020-09-04 11:00:18","updateDate":"2020-09-04 11:00:58","value":"4","label":"检测线西","type":"CAR_LOCATION","description":"整车下线接收库位","sort":40,"parentId":"0"},{"id":"3a5acfffa44748658d3d5c9860be0b4f","isNewRecord":false,"remarks":"整车下线接收库位","createDate":"2020-09-04 11:06:33","updateDate":"2020-09-04 11:06:33","value":"5","label":"新东区","type":"CAR_LOCATION","description":"整车下线接收库位","sort":50,"parentId":"0"},{"id":"1543403ddd164c91a7549b43e851e375","isNewRecord":false,"remarks":"整车下线接收库位","createDate":"2020-09-04 11:07:26","updateDate":"2020-09-04 11:07:26","value":"6","label":"总装下线广场","type":"CAR_LOCATION","description":"整车下线接收库位","sort":60,"parentId":"0"}]
     */


        /**
         * id : 3975be3c11b04402b081eccf632c3fdd
         * isNewRecord : false
         * remarks : 整车下线接收库位
         * createDate : 2020-09-04 10:58:17
         * updateDate : 2020-09-04 10:58:17
         * value : 1
         * label : 调试区
         * type : CAR_LOCATION
         * description : 整车下线接收库位
         * sort : 10
         * parentId : 0
         */

        private String id;
        private Boolean isNewRecord;
        private String remarks;
        private String createDate;
        private String updateDate;
        private String value;
        private String label;
        private String type;
        private String description;
        private Integer sort;

    protected RegisterCarLocationListBean(Parcel in) {
        id = in.readString();
        byte tmpIsNewRecord = in.readByte();
        isNewRecord = tmpIsNewRecord == 0 ? null : tmpIsNewRecord == 1;
        remarks = in.readString();
        createDate = in.readString();
        updateDate = in.readString();
        value = in.readString();
        label = in.readString();
        type = in.readString();
        description = in.readString();
        if (in.readByte() == 0) {
            sort = null;
        } else {
            sort = in.readInt();
        }
    }

    public static final Creator<RegisterCarLocationListBean> CREATOR = new Creator<RegisterCarLocationListBean>() {
        @Override
        public RegisterCarLocationListBean createFromParcel(Parcel in) {
            return new RegisterCarLocationListBean(in);
        }

        @Override
        public RegisterCarLocationListBean[] newArray(int size) {
            return new RegisterCarLocationListBean[size];
        }
    };

    public void setId(String id) {
        this.id = id;
    }

    public void setNewRecord(Boolean newRecord) {
        isNewRecord = newRecord;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public void setCreateDate(String createDate) {
        this.createDate = createDate;
    }

    public void setUpdateDate(String updateDate) {
        this.updateDate = updateDate;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public void setType(String type) {
        this.type = type;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setSort(Integer sort) {
        this.sort = sort;
    }

    public String getId() {
        return id;
    }

    public Boolean getNewRecord() {
        return isNewRecord;
    }

    public String getRemarks() {
        return remarks;
    }

    public String getCreateDate() {
        return createDate;
    }

    public String getUpdateDate() {
        return updateDate;
    }

    public String getValue() {
        return value;
    }

    public String getLabel() {
        return label;
    }

    public String getType() {
        return type;
    }

    public String getDescription() {
        return description;
    }

    public Integer getSort() {
        return sort;
    }

    @Override
    public String toString() {
       return label;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(id);
        dest.writeByte((byte) (isNewRecord == null ? 0 : isNewRecord ? 1 : 2));
        dest.writeString(remarks);
        dest.writeString(createDate);
        dest.writeString(updateDate);
        dest.writeString(value);
        dest.writeString(label);
        dest.writeString(type);
        dest.writeString(description);
        if (sort == null) {
            dest.writeByte((byte) 0);
        } else {
            dest.writeByte((byte) 1);
            dest.writeInt(sort);
        }
    }
}
