package com.zhuisu.fastdev.beans.consolework

import android.os.Parcel
import android.os.Parcelable

/**
 * @author cxh
 * @description
 * @date 2020/11/16.
 */
data class ConsoleWorkList(var flowCarNo : String?,var carFarmeNo : String?,var id : String?,var configChange : Boolean,var qmsManufactureProductionplan : Detail?,var status : String?,var carModelNo: String?) : Parcelable {


    constructor(parcel: Parcel) : this(
            parcel.readString(),
            parcel.readString(),
            parcel.readString(),
            parcel.readByte() != 0.toByte(),
            parcel.readParcelable(Detail::class.java.classLoader),parcel.readString(),parcel.readString()) {
    }

    data class Detail(var configDesc : String?) : Parcelable {
        constructor(parcel: Parcel) : this(parcel.readString()) {
        }

        override fun writeToParcel(parcel: Parcel, flags: Int) {
            parcel.writeString(configDesc)
        }

        override fun describeContents(): Int {
            return 0
        }

        companion object CREATOR : Parcelable.Creator<Detail> {
            override fun createFromParcel(parcel: Parcel): Detail {
                return Detail(parcel)
            }

            override fun newArray(size: Int): Array<Detail?> {
                return arrayOfNulls(size)
            }
        }

    }

    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeString(flowCarNo)
        parcel.writeString(carFarmeNo)
        parcel.writeString(id)
        parcel.writeByte(if (configChange) 1 else 0)
        parcel.writeParcelable(qmsManufactureProductionplan, flags)
        parcel.writeString(status)
        parcel.writeString(carModelNo)
    }

    override fun describeContents(): Int {
        return 0
    }

    companion object CREATOR : Parcelable.Creator<ConsoleWorkList> {
        override fun createFromParcel(parcel: Parcel): ConsoleWorkList {
            return ConsoleWorkList(parcel)
        }

        override fun newArray(size: Int): Array<ConsoleWorkList?> {
            return arrayOfNulls(size)
        }
    }


}