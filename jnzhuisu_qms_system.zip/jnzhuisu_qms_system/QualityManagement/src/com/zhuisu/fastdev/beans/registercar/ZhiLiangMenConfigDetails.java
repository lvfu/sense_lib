package com.zhuisu.fastdev.beans.registercar;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * @author cxh
 * @description
 * @date 2020/10/20.
 */


public class ZhiLiangMenConfigDetails implements Parcelable
{

    /**
     * msg : 获取车架号信息成功！
     * data : {"id":"557EA069BC1D4A0880E4C4F88698B39F","isNewRecord":false,"remarks":null,"createDate":"2020-10-19 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"ASSJ20080005/0010-0003","carFarmeNo":"LJ177025","status":"debug","submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":"2","environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185H3613E1/J7V7M36-标运质赢","basicDevices":null,"orderNo":"ASSJ20080005","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲豪瀚N：玛瑙红,;豪瀚 N5；牵引车；豪瀚H78B驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；MC07.24-50发动机；8JS95TE-C变速箱；H653自调臂前轴(鼓)；MCJ09BG自调臂单后桥(鼓)；速比4.63；单层车架(7/250)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；295/80R22.5；50#JOST鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false}
     * status : 0
     */


        /**
         * id : 557EA069BC1D4A0880E4C4F88698B39F
         * isNewRecord : false
         * remarks : null
         * createDate : 2020-10-19 16:00:00
         * updateDate : null
         * supcodes : null
         * menuid : null
         * flowCarNo : ASSJ20080005/0010-0003
         * carFarmeNo : LJ177025
         * status : debug
         * submitCheckStatus : null
         * varnishStatus : null
         * varnishOperator : null
         * varnishDate : null
         * location : 2
         * environmentalLabel : null
         * isSpecialSubmitCheck : null
         * isExistCloseTrouble : 0
         * submitCheckOperType : null
         * rainResult : null
         * rainPart : null
         * rainBridgeType : null
         * rainItem : null
         * startTime : null
         * endTime : null
         * searchStatus : null
         * qmsManufactureProductionplan : {"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185H3613E1/J7V7M36-标运质赢","basicDevices":null,"orderNo":"ASSJ20080005","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲豪瀚N：玛瑙红,;豪瀚 N5；牵引车；豪瀚H78B驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；MC07.24-50发动机；8JS95TE-C变速箱；H653自调臂前轴(鼓)；MCJ09BG自调臂单后桥(鼓)；速比4.63；单层车架(7/250)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；295/80R22.5；50#JOST鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null}
         * qmsZcproject : null
         * specialSubmitRemark : null
         * fileName : null
         * filePath : null
         * configChange : false
         */

        private String id;
        private Boolean isNewRecord;
        private Object remarks;
        private String createDate;
        private Object updateDate;
        private Object supcodes;
        private Object menuid;
        private String flowCarNo;
        private String carFarmeNo;
        private String status;
        private Object submitCheckStatus;
        private Object varnishStatus;
        private Object varnishOperator;
        private Object varnishDate;
        private String location;
        private String environmentalLabel;
        private Object isSpecialSubmitCheck;
        private Integer isExistCloseTrouble;
        private Object submitCheckOperType;
        private Object rainResult;
        private Object rainPart;
        private Object rainBridgeType;
        private Object rainItem;
        private Object startTime;
        private Object endTime;
        private Object searchStatus;
        private QmsManufactureProductionplanBean qmsManufactureProductionplan;
        private Object qmsZcproject;
        private Object specialSubmitRemark;
        private Object fileName;
        private Object filePath;
        private Boolean configChange;
        private String configDesc;

    public void setConfigDesc(String configDesc) {
        this.configDesc = configDesc;
    }

    public String getConfigDesc() {
        return configDesc;
    }

    public ZhiLiangMenConfigDetails() {
    }

    protected ZhiLiangMenConfigDetails(Parcel in) {
        id = in.readString();
        byte tmpIsNewRecord = in.readByte();
        isNewRecord = tmpIsNewRecord == 0 ? null : tmpIsNewRecord == 1;
        createDate = in.readString();
        flowCarNo = in.readString();
        carFarmeNo = in.readString();
        status = in.readString();
        location = in.readString();
        if (in.readByte() == 0) {
            isExistCloseTrouble = null;
        } else {
            isExistCloseTrouble = in.readInt();
        }
        byte tmpConfigChange = in.readByte();
        configChange = tmpConfigChange == 0 ? null : tmpConfigChange == 1;
    }

    public static final Creator<ZhiLiangMenConfigDetails> CREATOR = new Creator<ZhiLiangMenConfigDetails>() {
        @Override
        public ZhiLiangMenConfigDetails createFromParcel(Parcel in) {
            return new ZhiLiangMenConfigDetails(in);
        }

        @Override
        public ZhiLiangMenConfigDetails[] newArray(int size) {
            return new ZhiLiangMenConfigDetails[size];
        }
    };

    public void setId(String id) {
        this.id = id;
    }

    public void setNewRecord(Boolean newRecord) {
        isNewRecord = newRecord;
    }

    public void setRemarks(Object remarks) {
        this.remarks = remarks;
    }

    public void setCreateDate(String createDate) {
        this.createDate = createDate;
    }

    public void setUpdateDate(Object updateDate) {
        this.updateDate = updateDate;
    }

    public void setSupcodes(Object supcodes) {
        this.supcodes = supcodes;
    }

    public void setMenuid(Object menuid) {
        this.menuid = menuid;
    }

    public void setFlowCarNo(String flowCarNo) {
        this.flowCarNo = flowCarNo;
    }

    public void setCarFarmeNo(String carFarmeNo) {
        this.carFarmeNo = carFarmeNo;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public void setSubmitCheckStatus(Object submitCheckStatus) {
        this.submitCheckStatus = submitCheckStatus;
    }

    public void setVarnishStatus(Object varnishStatus) {
        this.varnishStatus = varnishStatus;
    }

    public void setVarnishOperator(Object varnishOperator) {
        this.varnishOperator = varnishOperator;
    }

    public void setVarnishDate(Object varnishDate) {
        this.varnishDate = varnishDate;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public void setEnvironmentalLabel(String environmentalLabel) {
        this.environmentalLabel = environmentalLabel;
    }

    public void setIsSpecialSubmitCheck(Object isSpecialSubmitCheck) {
        this.isSpecialSubmitCheck = isSpecialSubmitCheck;
    }

    public void setIsExistCloseTrouble(Integer isExistCloseTrouble) {
        this.isExistCloseTrouble = isExistCloseTrouble;
    }

    public void setSubmitCheckOperType(Object submitCheckOperType) {
        this.submitCheckOperType = submitCheckOperType;
    }

    public void setRainResult(Object rainResult) {
        this.rainResult = rainResult;
    }

    public void setRainPart(Object rainPart) {
        this.rainPart = rainPart;
    }

    public void setRainBridgeType(Object rainBridgeType) {
        this.rainBridgeType = rainBridgeType;
    }

    public void setRainItem(Object rainItem) {
        this.rainItem = rainItem;
    }

    public void setStartTime(Object startTime) {
        this.startTime = startTime;
    }

    public void setEndTime(Object endTime) {
        this.endTime = endTime;
    }

    public void setSearchStatus(Object searchStatus) {
        this.searchStatus = searchStatus;
    }

    public void setQmsManufactureProductionplan(QmsManufactureProductionplanBean qmsManufactureProductionplan) {
        this.qmsManufactureProductionplan = qmsManufactureProductionplan;
    }

    public void setQmsZcproject(Object qmsZcproject) {
        this.qmsZcproject = qmsZcproject;
    }

    public void setSpecialSubmitRemark(Object specialSubmitRemark) {
        this.specialSubmitRemark = specialSubmitRemark;
    }

    public void setFileName(Object fileName) {
        this.fileName = fileName;
    }

    public void setFilePath(Object filePath) {
        this.filePath = filePath;
    }

    public void setConfigChange(Boolean configChange) {
        this.configChange = configChange;
    }

    public String getId() {
        return id;
    }

    public Boolean getNewRecord() {
        return isNewRecord;
    }

    public Object getRemarks() {
        return remarks;
    }

    public String getCreateDate() {
        return createDate;
    }

    public Object getUpdateDate() {
        return updateDate;
    }

    public Object getSupcodes() {
        return supcodes;
    }

    public Object getMenuid() {
        return menuid;
    }

    public String getFlowCarNo() {
        return flowCarNo;
    }

    public String getCarFarmeNo() {
        return carFarmeNo;
    }

    public String getStatus() {
        return status;
    }

    public Object getSubmitCheckStatus() {
        return submitCheckStatus;
    }

    public Object getVarnishStatus() {
        return varnishStatus;
    }

    public Object getVarnishOperator() {
        return varnishOperator;
    }

    public Object getVarnishDate() {
        return varnishDate;
    }

    public String getLocation() {
        return location;
    }

    public String getEnvironmentalLabel() {
        return environmentalLabel;
    }

    public Object getIsSpecialSubmitCheck() {
        return isSpecialSubmitCheck;
    }

    public Integer getIsExistCloseTrouble() {
        return isExistCloseTrouble;
    }

    public Object getSubmitCheckOperType() {
        return submitCheckOperType;
    }

    public Object getRainResult() {
        return rainResult;
    }

    public Object getRainPart() {
        return rainPart;
    }

    public Object getRainBridgeType() {
        return rainBridgeType;
    }

    public Object getRainItem() {
        return rainItem;
    }

    public Object getStartTime() {
        return startTime;
    }

    public Object getEndTime() {
        return endTime;
    }

    public Object getSearchStatus() {
        return searchStatus;
    }

    public QmsManufactureProductionplanBean getQmsManufactureProductionplan() {
        return qmsManufactureProductionplan;
    }

    public Object getQmsZcproject() {
        return qmsZcproject;
    }

    public Object getSpecialSubmitRemark() {
        return specialSubmitRemark;
    }

    public Object getFileName() {
        return fileName;
    }

    public Object getFilePath() {
        return filePath;
    }

    public Boolean getConfigChange() {
        return configChange;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(id);
        dest.writeByte((byte) (isNewRecord == null ? 0 : isNewRecord ? 1 : 2));
        dest.writeString(createDate);
        dest.writeString(flowCarNo);
        dest.writeString(carFarmeNo);
        dest.writeString(status);
        dest.writeString(location);
        if (isExistCloseTrouble == null) {
            dest.writeByte((byte) 0);
        } else {
            dest.writeByte((byte) 1);
            dest.writeInt(isExistCloseTrouble);
        }
        dest.writeByte((byte) (configChange == null ? 0 : configChange ? 1 : 2));
    }

    public static class QmsManufactureProductionplanBean implements Parcelable{
            /**
             * id : null
             * isNewRecord : true
             * remarks : null
             * createDate : null
             * updateDate : null
             * supcodes : null
             * menuid : null
             * flowCarNo : null
             * carFrameNo : null
             * productionDate : null
             * productionDateStringIn : null
             * productionDateStringOut : null
             * carModelNo : ZZ4185H3613E1/J7V7M36-标运质赢
             * basicDevices : null
             * orderNo : ASSJ20080005
             * planOnlineDate : 2020-10-09 16:00:00
             * planOnlineDateStringIn : null
             * planOnlineDateStringOut : null
             * configDesc : ▲豪瀚N：玛瑙红,;豪瀚 N5；牵引车；豪瀚H78B驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；MC07.24-50发动机；8JS95TE-C变速箱；H653自调臂前轴(鼓)；MCJ09BG自调臂单后桥(鼓)；速比4.63；单层车架(7/250)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；295/80R22.5；50#JOST鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；。,送车
             * status : null
             * beginPlanOnlineDate : null
             * endPlanOnlineDate : null
             * workShop : null
             * productModel : null
             * productOrder : null
             * operType : null
             */

            private Object id;
            private Boolean isNewRecord;
            private Object remarks;
            private Object createDate;
            private Object updateDate;
            private Object supcodes;
            private Object menuid;
            private Object flowCarNo;
            private String carFrameNo;
            private Object productionDate;
            private Object productionDateStringIn;
            private Object productionDateStringOut;
            private String carModelNo;
            private Object basicDevices;
            private String orderNo;
            private String planOnlineDate;
            private Object planOnlineDateStringIn;
            private Object planOnlineDateStringOut;
            private String configDesc;
            private Object status;
            private Object beginPlanOnlineDate;
            private Object endPlanOnlineDate;
            private Object workShop;
            private Object productModel;
            private Object productOrder;
            private Object operType;

        protected QmsManufactureProductionplanBean(Parcel in) {
            byte tmpIsNewRecord = in.readByte();
            isNewRecord = tmpIsNewRecord == 0 ? null : tmpIsNewRecord == 1;
            carModelNo = in.readString();
            orderNo = in.readString();
            planOnlineDate = in.readString();
            configDesc = in.readString();
        }

        public static final Creator<QmsManufactureProductionplanBean> CREATOR = new Creator<QmsManufactureProductionplanBean>() {
            @Override
            public QmsManufactureProductionplanBean createFromParcel(Parcel in) {
                return new QmsManufactureProductionplanBean(in);
            }

            @Override
            public QmsManufactureProductionplanBean[] newArray(int size) {
                return new QmsManufactureProductionplanBean[size];
            }
        };

        public void setId(Object id) {
                this.id = id;
            }

            public void setNewRecord(Boolean newRecord) {
                isNewRecord = newRecord;
            }

            public void setRemarks(Object remarks) {
                this.remarks = remarks;
            }

            public void setCreateDate(Object createDate) {
                this.createDate = createDate;
            }

            public void setUpdateDate(Object updateDate) {
                this.updateDate = updateDate;
            }

            public void setSupcodes(Object supcodes) {
                this.supcodes = supcodes;
            }

            public void setMenuid(Object menuid) {
                this.menuid = menuid;
            }

            public void setFlowCarNo(Object flowCarNo) {
                this.flowCarNo = flowCarNo;
            }

            public void setCarFrameNo(String carFrameNo) {
                this.carFrameNo = carFrameNo;
            }

            public void setProductionDate(Object productionDate) {
                this.productionDate = productionDate;
            }

            public void setProductionDateStringIn(Object productionDateStringIn) {
                this.productionDateStringIn = productionDateStringIn;
            }

            public void setProductionDateStringOut(Object productionDateStringOut) {
                this.productionDateStringOut = productionDateStringOut;
            }

            public void setCarModelNo(String carModelNo) {
                this.carModelNo = carModelNo;
            }

            public void setBasicDevices(Object basicDevices) {
                this.basicDevices = basicDevices;
            }

            public void setOrderNo(String orderNo) {
                this.orderNo = orderNo;
            }

            public void setPlanOnlineDate(String planOnlineDate) {
                this.planOnlineDate = planOnlineDate;
            }

            public void setPlanOnlineDateStringIn(Object planOnlineDateStringIn) {
                this.planOnlineDateStringIn = planOnlineDateStringIn;
            }

            public void setPlanOnlineDateStringOut(Object planOnlineDateStringOut) {
                this.planOnlineDateStringOut = planOnlineDateStringOut;
            }

            public void setConfigDesc(String configDesc) {
                this.configDesc = configDesc;
            }

            public void setStatus(Object status) {
                this.status = status;
            }

            public void setBeginPlanOnlineDate(Object beginPlanOnlineDate) {
                this.beginPlanOnlineDate = beginPlanOnlineDate;
            }

            public void setEndPlanOnlineDate(Object endPlanOnlineDate) {
                this.endPlanOnlineDate = endPlanOnlineDate;
            }

            public void setWorkShop(Object workShop) {
                this.workShop = workShop;
            }

            public void setProductModel(Object productModel) {
                this.productModel = productModel;
            }

            public void setProductOrder(Object productOrder) {
                this.productOrder = productOrder;
            }

            public void setOperType(Object operType) {
                this.operType = operType;
            }

            public Object getId() {
                return id;
            }

            public Boolean getNewRecord() {
                return isNewRecord;
            }

            public Object getRemarks() {
                return remarks;
            }

            public Object getCreateDate() {
                return createDate;
            }

            public Object getUpdateDate() {
                return updateDate;
            }

            public Object getSupcodes() {
                return supcodes;
            }

            public Object getMenuid() {
                return menuid;
            }

            public Object getFlowCarNo() {
                return flowCarNo;
            }

            public String getCarFrameNo() {
                return carFrameNo;
            }

            public Object getProductionDate() {
                return productionDate;
            }

            public Object getProductionDateStringIn() {
                return productionDateStringIn;
            }

            public Object getProductionDateStringOut() {
                return productionDateStringOut;
            }

            public String getCarModelNo() {
                return carModelNo;
            }

            public Object getBasicDevices() {
                return basicDevices;
            }

            public String getOrderNo() {
                return orderNo;
            }

            public String getPlanOnlineDate() {
                return planOnlineDate;
            }

            public Object getPlanOnlineDateStringIn() {
                return planOnlineDateStringIn;
            }

            public Object getPlanOnlineDateStringOut() {
                return planOnlineDateStringOut;
            }

            public String getConfigDesc() {
                return configDesc;
            }

            public Object getStatus() {
                return status;
            }

            public Object getBeginPlanOnlineDate() {
                return beginPlanOnlineDate;
            }

            public Object getEndPlanOnlineDate() {
                return endPlanOnlineDate;
            }

            public Object getWorkShop() {
                return workShop;
            }

            public Object getProductModel() {
                return productModel;
            }

            public Object getProductOrder() {
                return productOrder;
            }

            public Object getOperType() {
                return operType;
            }

        @Override
        public int describeContents() {
            return 0;
        }

        @Override
        public void writeToParcel(Parcel dest, int flags) {
            dest.writeByte((byte) (isNewRecord == null ? 0 : isNewRecord ? 1 : 2));
            dest.writeString(carModelNo);
            dest.writeString(orderNo);
            dest.writeString(planOnlineDate);
            dest.writeString(configDesc);
        }
    }

}
