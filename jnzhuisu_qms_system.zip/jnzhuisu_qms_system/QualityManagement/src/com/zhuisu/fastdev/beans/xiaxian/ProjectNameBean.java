package com.zhuisu.fastdev.beans.xiaxian;

import java.io.Serializable;
import java.util.List;

public class ProjectNameBean implements Serializable {

    /**
     * retCode : 0
     * data : [{"id":"cdddc090a6b0438abfc7f9869523d0b4","isNewRecord":false,"createDate":"2021-05-08 11:19:04","updateDate":"2021-05-08 11:19:04","reviewProjectNo":"20210508001","reviewProjectName":"豪 沃 N 驾 驶 室 涂 装 质 量 审 核 报 告","reviewType":"problem_source_11_05","auditTime":"2021-05-08 00:00:00","auditPurposes":"为了规范驾驶室本体质量评审，做到质量水平可评价、可对比，不断改进和提升驾驶室本体装调质量水平。","auditUsers":"170572,170353,","auditUserNames":"孟耀峰,戴永宁,","samplingLocation":"车身部","samplingMethod":"随机","samplingNum":"5","prototypeCarDes":"豪沃N系驾驶室","prototypeCarFrames":"M78L16652,,,,,","fileName":"新版2021年4月份驾驶室涂装评审报告.docx","filePath":"Q:/userfiles/qmsImprovementReviewProject/210508/新版2021年4月份驾驶室涂装评审报告_20210508111858573.docx","auditConclusion":"","remark":"","prototypeCarModels":",,,,,","auditUserDepartments":"[NC.06.5060004]质量检验室,[NC.11.51100002001]涂装上线班组,","onLineTimes":",,,,,","engineNos":",,,,,","engineModelNos":",,,,,","engineFactorys":",,,,,","deletenum":0}]
     */

    private String retCode;
    private List<DataBean> data;

    public static class DataBean implements Serializable {
        /**
         * id : cdddc090a6b0438abfc7f9869523d0b4
         * isNewRecord : false
         * createDate : 2021-05-08 11:19:04
         * updateDate : 2021-05-08 11:19:04
         * reviewProjectNo : 20210508001
         * reviewProjectName : 豪 沃 N 驾 驶 室 涂 装 质 量 审 核 报 告
         * reviewType : problem_source_11_05
         * auditTime : 2021-05-08 00:00:00
         * auditPurposes : 为了规范驾驶室本体质量评审，做到质量水平可评价、可对比，不断改进和提升驾驶室本体装调质量水平。
         * auditUsers : 170572,170353,
         * auditUserNames : 孟耀峰,戴永宁,
         * samplingLocation : 车身部
         * samplingMethod : 随机
         * samplingNum : 5
         * prototypeCarDes : 豪沃N系驾驶室
         * prototypeCarFrames : M78L16652,,,,,
         * fileName : 新版2021年4月份驾驶室涂装评审报告.docx
         * filePath : Q:/userfiles/qmsImprovementReviewProject/210508/新版2021年4月份驾驶室涂装评审报告_20210508111858573.docx
         * auditConclusion :
         * remark :
         * prototypeCarModels : ,,,,,
         * auditUserDepartments : [NC.06.5060004]质量检验室,[NC.11.51100002001]涂装上线班组,
         * onLineTimes : ,,,,,
         * engineNos : ,,,,,
         * engineModelNos : ,,,,,
         * engineFactorys : ,,,,,
         * deletenum : 0
         */

        private String id;
        private Boolean isNewRecord;
        private String createDate;
        private String updateDate;
        private String reviewProjectNo;
        private String reviewProjectName;
        private String reviewType;
        private String auditTime;
        private String auditPurposes;
        private String auditUsers;
        private String auditUserNames;
        private String samplingLocation;
        private String samplingMethod;
        private String samplingNum;
        private String prototypeCarDes;
        private String prototypeCarFrames;
        private String fileName;
        private String filePath;
        private String auditConclusion;
        private String remark;
        private String prototypeCarModels;
        private String auditUserDepartments;
        private String onLineTimes;
        private String engineNos;
        private String engineModelNos;
        private String engineFactorys;
        private Integer deletenum;

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public Boolean getNewRecord() {
            return isNewRecord;
        }

        public void setNewRecord(Boolean newRecord) {
            isNewRecord = newRecord;
        }

        public String getCreateDate() {
            return createDate;
        }

        public void setCreateDate(String createDate) {
            this.createDate = createDate;
        }

        public String getUpdateDate() {
            return updateDate;
        }

        public void setUpdateDate(String updateDate) {
            this.updateDate = updateDate;
        }

        public String getReviewProjectNo() {
            return reviewProjectNo;
        }

        public void setReviewProjectNo(String reviewProjectNo) {
            this.reviewProjectNo = reviewProjectNo;
        }

        public String getReviewProjectName() {
            return reviewProjectName;
        }

        public void setReviewProjectName(String reviewProjectName) {
            this.reviewProjectName = reviewProjectName;
        }

        public String getReviewType() {
            return reviewType;
        }

        public void setReviewType(String reviewType) {
            this.reviewType = reviewType;
        }

        public String getAuditTime() {
            return auditTime;
        }

        public void setAuditTime(String auditTime) {
            this.auditTime = auditTime;
        }

        public String getAuditPurposes() {
            return auditPurposes;
        }

        public void setAuditPurposes(String auditPurposes) {
            this.auditPurposes = auditPurposes;
        }

        public String getAuditUsers() {
            return auditUsers;
        }

        public void setAuditUsers(String auditUsers) {
            this.auditUsers = auditUsers;
        }

        public String getAuditUserNames() {
            return auditUserNames;
        }

        public void setAuditUserNames(String auditUserNames) {
            this.auditUserNames = auditUserNames;
        }

        public String getSamplingLocation() {
            return samplingLocation;
        }

        public void setSamplingLocation(String samplingLocation) {
            this.samplingLocation = samplingLocation;
        }

        public String getSamplingMethod() {
            return samplingMethod;
        }

        public void setSamplingMethod(String samplingMethod) {
            this.samplingMethod = samplingMethod;
        }

        public String getSamplingNum() {
            return samplingNum;
        }

        public void setSamplingNum(String samplingNum) {
            this.samplingNum = samplingNum;
        }

        public String getPrototypeCarDes() {
            return prototypeCarDes;
        }

        public void setPrototypeCarDes(String prototypeCarDes) {
            this.prototypeCarDes = prototypeCarDes;
        }

        public String getPrototypeCarFrames() {
            return prototypeCarFrames;
        }

        public void setPrototypeCarFrames(String prototypeCarFrames) {
            this.prototypeCarFrames = prototypeCarFrames;
        }

        public String getFileName() {
            return fileName;
        }

        public void setFileName(String fileName) {
            this.fileName = fileName;
        }

        public String getFilePath() {
            return filePath;
        }

        public void setFilePath(String filePath) {
            this.filePath = filePath;
        }

        public String getAuditConclusion() {
            return auditConclusion;
        }

        public void setAuditConclusion(String auditConclusion) {
            this.auditConclusion = auditConclusion;
        }

        public String getRemark() {
            return remark;
        }

        public void setRemark(String remark) {
            this.remark = remark;
        }

        public String getPrototypeCarModels() {
            return prototypeCarModels;
        }

        public void setPrototypeCarModels(String prototypeCarModels) {
            this.prototypeCarModels = prototypeCarModels;
        }

        public String getAuditUserDepartments() {
            return auditUserDepartments;
        }

        public void setAuditUserDepartments(String auditUserDepartments) {
            this.auditUserDepartments = auditUserDepartments;
        }

        public String getOnLineTimes() {
            return onLineTimes;
        }

        public void setOnLineTimes(String onLineTimes) {
            this.onLineTimes = onLineTimes;
        }

        public String getEngineNos() {
            return engineNos;
        }

        public void setEngineNos(String engineNos) {
            this.engineNos = engineNos;
        }

        public String getEngineModelNos() {
            return engineModelNos;
        }

        public void setEngineModelNos(String engineModelNos) {
            this.engineModelNos = engineModelNos;
        }

        public String getEngineFactorys() {
            return engineFactorys;
        }

        public void setEngineFactorys(String engineFactorys) {
            this.engineFactorys = engineFactorys;
        }

        public Integer getDeletenum() {
            return deletenum;
        }

        public void setDeletenum(Integer deletenum) {
            this.deletenum = deletenum;
        }

        @Override
        public String toString() {
            return reviewProjectName;
        }
    }
}
