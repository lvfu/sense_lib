package com.zhuisu.fastdev.beans.xiaxian;

import java.io.Serializable;
import java.util.List;

public class ProjectbianhaoBean implements Serializable {

    /**
     * retCode : 0
     * data : [{"isNewRecord":true,"prototypeCarFrames":"LJ191676"}]
     */

    private String retCode;
    private List<DataBean> data;

    public static class DataBean implements Serializable {
        /**
         * isNewRecord : true
         * prototypeCarFrames : LJ191676
         */

        private Boolean isNewRecord;
        private String prototypeCarFrames;

        public Boolean getNewRecord() {
            return isNewRecord;
        }

        public void setNewRecord(Boolean newRecord) {
            isNewRecord = newRecord;
        }

        public String getPrototypeCarFrames() {
            return prototypeCarFrames;
        }

        public void setPrototypeCarFrames(String prototypeCarFrames) {
            this.prototypeCarFrames = prototypeCarFrames;
        }

        @Override
        public String toString() {
            return prototypeCarFrames;
        }
    }
}
