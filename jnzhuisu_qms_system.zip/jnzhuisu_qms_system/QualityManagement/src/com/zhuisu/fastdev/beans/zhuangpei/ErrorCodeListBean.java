package com.zhuisu.fastdev.beans.zhuangpei;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * @author cxh
 * @description
 * @date 2020/10/12.
 */
public class ErrorCodeListBean implements Parcelable {
    private String errorCode;
    private String projectTypeCode;
    private String projectTypeName;
    private String faultCode;
    private String faultName;
    private String faultDesc;
    private String faultLevel;

    public void setFaultLevel(String faultLevel) {
        this.faultLevel = faultLevel;
    }

    public String getFaultLevel() {
        return faultLevel;
    }

    public void setFaultDesc(String faultDesc) {
        this.faultDesc = faultDesc;
    }

    public String getFaultDesc() {
        return faultDesc;
    }

    public void setFaultName(String faultName) {
        this.faultName = faultName;
    }

    public String getFaultName() {
        return faultName;
    }

    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }

    public void setProjectTypeCode(String projectTypeCode) {
        this.projectTypeCode = projectTypeCode;
    }

    public void setProjectTypeName(String projectTypeName) {
        this.projectTypeName = projectTypeName;
    }

    public void setFaultCode(String faultCode) {
        this.faultCode = faultCode;
    }

    public String getErrorCode() {
        return errorCode;
    }

    public String getProjectTypeCode() {
        return projectTypeCode;
    }

    public String getProjectTypeName() {
        return projectTypeName;
    }

    public String getFaultCode() {
        return faultCode;
    }

    public static Creator<ErrorCodeListBean> getCREATOR() {
        return CREATOR;
    }

    protected ErrorCodeListBean(Parcel in) {
        errorCode = in.readString();
        projectTypeCode = in.readString();
        projectTypeName = in.readString();
        faultCode = in.readString();
        faultName = in.readString();
        faultDesc = in.readString();
        faultLevel = in.readString();
    }

    public static final Creator<ErrorCodeListBean> CREATOR = new Creator<ErrorCodeListBean>() {
        @Override
        public ErrorCodeListBean createFromParcel(Parcel in) {
            return new ErrorCodeListBean(in);
        }

        @Override
        public ErrorCodeListBean[] newArray(int size) {
            return new ErrorCodeListBean[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(errorCode);
        dest.writeString(projectTypeCode);
        dest.writeString(projectTypeName);
        dest.writeString(faultCode);
        dest.writeString(faultName);
        dest.writeString(faultDesc);
        dest.writeString(faultLevel);
    }
}
