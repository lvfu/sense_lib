package com.zhuisu.fastdev.beans

import java.io.Serializable

/**
 * @author cxh
 * @description
 * @date 2020/11/20.
 */
data class FinishCheckList (var id : String? ,var createDate: String?, var flowCarNo: String?, var carFarmeNo: String?, var status: String,var opno : String?,
                           var configChange: Boolean?, var submitCheckCount: String? ,var flags: String?,
                           var qmsManufactureProductionplan : qmsManufactureProductionplan?,
                           var listZcproject : List<listZcproject>?,
                           var orderNo : String?,var location : String?,var cylinderNumber : String,var engineNumber : String,var environmentalLabel : String?,var recheckDate : String?,var recheckUser : String) : Serializable

data class qmsManufactureProductionplan(var carModelNo : String?,var configDesc : String,var orderNo : String?) : Serializable
data class listZcproject(var id : String?,
                         var isNewRecord : Boolean?,
                         var remarks : String?,
                         var createDate : String?,
                         var supcodes : String?,
                         var menuid : String?,
                         var classid : String?,
                         var opno : String?,
                         var opnm : String?,
                         var sortorder : String?,
                         var mation : String?,
                         var isusin : String?,
                         var st : String?,
                         var projectCode : String?,
                         var remark : String?,
                         var text : String?,
                         var opnos : String?,
                         var opnms : String?,
                         var classids : String?,
                         var classidnm : String?,
                         var qmsCarModelItemShift : String?,
                         var rootNode : String?,
                         var node : String?,
                         var gb : String?,
                         var isView : String?,
                         var checkPosition : String?,
                         var faultCodes : String?,
                         var faultCodeNames : String?,
                         var team : String?,
                         var parentCode : String?,
                         var model : String?,
                         var qryUserLoginName : String?,
                         var checkStatus : String?,
                         var startTime : String?,
                         var endTime : String?,
                         var checkedCount : String?,
                         var jianyan : String?) : Serializable
