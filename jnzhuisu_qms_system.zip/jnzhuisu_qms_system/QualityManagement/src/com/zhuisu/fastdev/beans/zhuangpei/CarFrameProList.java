package com.zhuisu.fastdev.beans.zhuangpei;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * @author cxh
 * @description
 * @date 2021/1/29.
 */
public class CarFrameProList implements Parcelable {
    private String createBy;
    private String problemTitle;
    private String problemId;
    private String problemDesc;
    private String flowStatus;
    private String isClose;
    private String problemSource;
    private String faultDesc;


    public void setFaultDesc(String faultDesc) {
        this.faultDesc = faultDesc;
    }

    public String getFaultDesc() {
        return faultDesc;
    }

    public void setProblemSource(String problemSource) {
        this.problemSource = problemSource;
    }

    public String getProblemSource() {
        return problemSource;
    }

    public void setIsClose(String isClose) {
        this.isClose = isClose;
    }

    public String getIsClose() {
        return isClose;
    }


    public CarFrameProList(){}

    protected CarFrameProList(Parcel in) {
        createBy = in.readString();
        problemTitle = in.readString();
        problemId = in.readString();
        problemDesc = in.readString();
        flowStatus = in.readString();
        isClose = in.readString();
        problemSource = in.readString();
        faultDesc = in.readString();
    }

    public static final Creator<CarFrameProList> CREATOR = new Creator<CarFrameProList>() {
        @Override
        public CarFrameProList createFromParcel(Parcel in) {
            return new CarFrameProList(in);
        }

        @Override
        public CarFrameProList[] newArray(int size) {
            return new CarFrameProList[size];
        }
    };

    public void setCreateBy(String createBy) {
        this.createBy = createBy;
    }

    public void setProblemTitle(String problemTitle) {
        this.problemTitle = problemTitle;
    }

    public void setProblemId(String problemId) {
        this.problemId = problemId;
    }

    public void setProblemDesc(String problemDesc) {
        this.problemDesc = problemDesc;
    }

    public void setFlowStatus(String flowStatus) {
        this.flowStatus = flowStatus;
    }

    public String getCreateBy() {
        return createBy;
    }

    public String getProblemTitle() {
        return problemTitle;
    }

    public String getProblemId() {
        return problemId;
    }

    public String getProblemDesc() {
        return problemDesc;
    }

    public String getFlowStatus() {
        return flowStatus;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(createBy);
        dest.writeString(problemTitle);
        dest.writeString(problemId);
        dest.writeString(problemDesc);
        dest.writeString(flowStatus);
        dest.writeString(isClose);
        dest.writeString(problemSource);
        dest.writeString(faultDesc);
    }
}
