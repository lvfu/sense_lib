package com.zhuisu.fastdev.beans;

import java.util.List;

/**
 * @author cxh
 * @description
 * @date 2020/11/2.
 */

public class ProelemDetailBean {

    /**
     * retCode : 0
     * data : {"id":"776DF90A2E23472983A80D0616BF1FEB","isNewRecord":false,"createDate":"2020-10-26 13:34:00","problemDesc":"张莉莉下线测试","peoblemTitle":"dddd","malfunctionCode":"q111","flowCarNo":"ABJK20080006/0030-0026","carFrameNo":"LA644780","assembleStation":"","carModelNo":"ZZ1317N306GE1/N7W8V30-标重","checkItemNo":"GXMC_2495","checkItemName":"安装空气悬架中后桥减震器","functionModel":"","occurTime":"2020-10-26 13:33:19","problemLevel":"","materiel":"","supplier":"","actualizeDept":"","problemRemarks":"","solution":"","fileName":"","filePath":"","problemSource":"offLineCheck","depts":"NC.00.5009001003","offLineStatus":"submitcheck"}
     * <p>
     * <p>
     * <p>
     * id : 776DF90A2E23472983A80D0616BF1FEB
     * isNewRecord : false
     * createDate : 2020-10-26 13:34:00
     * problemDesc : 张莉莉下线测试
     * peoblemTitle : dddd
     * malfunctionCode : q111
     * flowCarNo : ABJK20080006/0030-0026
     * carFrameNo : LA644780
     * assembleStation :
     * carModelNo : ZZ1317N306GE1/N7W8V30-标重
     * checkItemNo : GXMC_2495
     * checkItemName : 安装空气悬架中后桥减震器
     * functionModel :
     * occurTime : 2020-10-26 13:33:19
     * problemLevel :
     * materiel :
     * supplier :
     * actualizeDept :
     * problemRemarks :
     * solution :
     * fileName :
     * filePath :
     * problemSource : offLineCheck
     * depts : NC.00.5009001003
     * offLineStatus : submitcheck
     */

    private String id;
    private Boolean isNewRecord;
    private String createDate;
    private String problemDesc;
    private String peoblemTitle;
    private String faultDesc;
    private String malfunctionCode;
    private String flowCarNo;
    private String carFrameNo;
    private String assembleStation;
    private String carModelNo;
    private String checkItemNo;
    private String checkItemName;
    private String functionModel;
    private String occurTime;
    private String problemLevel;
    private String materiel;
    private String supplier;
    private String actualizeDept;
    private String problemRemarks;
    private String solution;
    private String fileName;
    private String filePath;
    private String problemSource;
    private String depts;
    private String offLineStatus;
    private String procInsId;
    private String imgStr;
    private String isClose;
    private String closeUser; //关闭人
    private String createBy; //录入人
    private String createByName;//录入人中文名
    private String closeDateStr;
    private String closeRemark;
    private String closeDate;
    private String status;
    private String addRemarks;

    private String closeFileImgStr;

    private List<ProgressTrackBean> qmsManufacturingProblemTrackingList;


    public List<ProgressTrackBean> getQmsManufacturingProblemTrackingList() {
        return qmsManufacturingProblemTrackingList;
    }

    public void setQmsManufacturingProblemTrackingList(List<ProgressTrackBean> qmsManufacturingProblemTrackingList) {
        this.qmsManufacturingProblemTrackingList = qmsManufacturingProblemTrackingList;
    }

    public String getCloseFileImgStr() {
        return closeFileImgStr;
    }

    public void setCloseFileImgStr(String closeFileImgStr) {
        this.closeFileImgStr = closeFileImgStr;
    }

    public void setAddRemarks(String addRemarks) {
        this.addRemarks = addRemarks;
    }

    public String getAddRemarks() {
        return addRemarks;
    }

    public void setFaultDesc(String faultDesc) {
        this.faultDesc = faultDesc;
    }

    public String getFaultDesc() {
        return faultDesc;
    }

    public void setCloseDate(String closeDate) {
        this.closeDate = closeDate;
    }

    public String getCloseDate() {
        return closeDate;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getStatus() {
        return status;
    }

    public void setCloseRemark(String closeRemark) {
        this.closeRemark = closeRemark;
    }

    public String getCloseRemark() {
        return closeRemark;
    }

    public void setCloseDateStr(String closeDateStr) {
        this.closeDateStr = closeDateStr;
    }

    public String getCloseDateStr() {
        return closeDateStr;
    }

    public void setCreateByName(String createByName) {
        this.createByName = createByName;
    }

    public String getCreateByName() {
        return createByName;
    }

    public void setCreateBy(String createBy) {
        this.createBy = createBy;
    }

    public String getCreateBy() {
        return createBy;
    }

    public void setCloseUser(String closeUser) {
        this.closeUser = closeUser;
    }

    public String getCloseUser() {
        return closeUser;
    }

    public void setIsClose(String isClose) {
        this.isClose = isClose;
    }

    public String getIsClose() {
        return isClose;
    }

    public void setImgStr(String imgStr) {
        this.imgStr = imgStr;
    }

    public String getImgStr() {
        return imgStr;
    }

    public void setProcInsId(String procInsId) {
        this.procInsId = procInsId;
    }

    public String getProcInsId() {
        return procInsId;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setNewRecord(Boolean newRecord) {
        isNewRecord = newRecord;
    }

    public void setCreateDate(String createDate) {
        this.createDate = createDate;
    }

    public void setProblemDesc(String problemDesc) {
        this.problemDesc = problemDesc;
    }

    public void setPeoblemTitle(String peoblemTitle) {
        this.peoblemTitle = peoblemTitle;
    }

    public void setMalfunctionCode(String malfunctionCode) {
        this.malfunctionCode = malfunctionCode;
    }

    public void setFlowCarNo(String flowCarNo) {
        this.flowCarNo = flowCarNo;
    }

    public void setCarFrameNo(String carFrameNo) {
        this.carFrameNo = carFrameNo;
    }

    public void setAssembleStation(String assembleStation) {
        this.assembleStation = assembleStation;
    }

    public void setCarModelNo(String carModelNo) {
        this.carModelNo = carModelNo;
    }

    public void setCheckItemNo(String checkItemNo) {
        this.checkItemNo = checkItemNo;
    }

    public void setCheckItemName(String checkItemName) {
        this.checkItemName = checkItemName;
    }

    public void setFunctionModel(String functionModel) {
        this.functionModel = functionModel;
    }

    public void setOccurTime(String occurTime) {
        this.occurTime = occurTime;
    }

    public void setProblemLevel(String problemLevel) {
        this.problemLevel = problemLevel;
    }

    public void setMateriel(String materiel) {
        this.materiel = materiel;
    }

    public void setSupplier(String supplier) {
        this.supplier = supplier;
    }

    public void setActualizeDept(String actualizeDept) {
        this.actualizeDept = actualizeDept;
    }

    public void setProblemRemarks(String problemRemarks) {
        this.problemRemarks = problemRemarks;
    }

    public void setSolution(String solution) {
        this.solution = solution;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }

    public void setProblemSource(String problemSource) {
        this.problemSource = problemSource;
    }

    public void setDepts(String depts) {
        this.depts = depts;
    }

    public void setOffLineStatus(String offLineStatus) {
        this.offLineStatus = offLineStatus;
    }

    public String getId() {
        return id;
    }

    public Boolean getNewRecord() {
        return isNewRecord;
    }

    public String getCreateDate() {
        return createDate;
    }

    public String getProblemDesc() {
        return problemDesc;
    }

    public String getPeoblemTitle() {
        return peoblemTitle;
    }

    public String getMalfunctionCode() {
        return malfunctionCode;
    }

    public String getFlowCarNo() {
        return flowCarNo;
    }

    public String getCarFrameNo() {
        return carFrameNo;
    }

    public String getAssembleStation() {
        return assembleStation;
    }

    public String getCarModelNo() {
        return carModelNo;
    }

    public String getCheckItemNo() {
        return checkItemNo;
    }

    public String getCheckItemName() {
        return checkItemName;
    }

    public String getFunctionModel() {
        return functionModel;
    }

    public String getOccurTime() {
        return occurTime;
    }

    public String getProblemLevel() {
        return problemLevel;
    }

    public String getMateriel() {
        return materiel;
    }

    public String getSupplier() {
        return supplier;
    }

    public String getActualizeDept() {
        return actualizeDept;
    }

    public String getProblemRemarks() {
        return problemRemarks;
    }

    public String getSolution() {
        return solution;
    }

    public String getFileName() {
        return fileName;
    }

    public String getFilePath() {
        return filePath;
    }

    public String getProblemSource() {
        return problemSource;
    }

    public String getDepts() {
        return depts;
    }

    public String getOffLineStatus() {
        return offLineStatus;
    }

}
