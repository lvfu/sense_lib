package com.zhuisu.fastdev.beans.zhuangpei;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * @author cxh
 * @description
 * @date 2020/10/12.
 */
public class ZhuangPeiWeiJianFirstBean implements Parcelable {


    /**
     * retCode : 0
     * data : [{"id":"d19c9917b3b6442fa967518d3f16753d","isNewRecord":false,"createDate":"2020-08-24 18:34:54","updateDate":"2020-10-12 16:24:26","operType":"assemblingProcess","checkItemId":"ae759198ae094cde901132efd9740ca9","carframeNo":"CJ-082401","productModel":"zc","flowcarNo":"SC-082401","carModelNo":"[zc]整车","status":"failed","checkedBy":"sense","checkedDate":"2020-10-12 16:24:26","planFinishDate":"2020-08-24 00:00:00","orderNo":"ORDER-082401","productOrder":"PRODUCTORDER-082401","classid":"ZPGW140","opno":"GXMC_2650","opnm":"安装氮氧传感器","mation":"M=35±5N.m","projectCode":"1","parentCode":"[CJ00105]底盘分装线","isKeyCheck":"1","dayShiftSpecial":"sense,","checkValue":"123","checkRemarks":"合格","fileName":"QmsManufactureProductionplanCheckitemsService.java","filePath":"D:/userfiles/qmsManufactureProductionPlanCheckItem/200831/QmsManufactureProductionplanCheckitemsService_20200831163628748.java","configChange":false},{"id":"bd958a5acc7441bab189bdb9bfc23ede","isNewRecord":false,"createDate":"2020-08-24 18:34:54","updateDate":"2020-10-10 09:31:16","operType":"routingCheck","checkItemId":"ae759198ae094cde901132efd9740ca9","carframeNo":"CJ-082401","productModel":"zc","flowcarNo":"SC-082401","carModelNo":"[zc]整车","status":"failed","checkedBy":"sense","checkedDate":"2020-10-10 09:31:16","planFinishDate":"2020-08-24 00:00:00","orderNo":"ORDER-082401","productOrder":"PRODUCTORDER-082401","classid":"ZPGW140","opno":"GXMC_5370","opnm":"安装取力器总成","mation":"螺栓力矩值：M10=45±6N.m","projectCode":"1","parentCode":"[CJ00105]底盘分装线","dayShiftSpecial":"sense,","configChange":false},{"id":"af0788d436014102bd12980b9fc4d0aa","isNewRecord":false,"createDate":"2020-08-24 18:34:54","updateDate":"2020-10-10 09:52:18","operType":"routingCheck","checkItemId":"ae759198ae094cde901132efd9740ca9","carframeNo":"CJ-082401","productModel":"zc","flowcarNo":"SC-082401","carModelNo":"[zc]整车","status":"failed","checkedBy":"sense","checkedDate":"2020-10-10 09:52:18","planFinishDate":"2020-08-24 00:00:00","orderNo":"ORDER-082401","productOrder":"PRODUCTORDER-082401","classid":"ZPGW140","opno":"GXMC_2810","opnm":"铺设燃油管路","mation":"1、管接头防护膜不得去除或损坏，保持街头及管路清洁；2、管路两端预留足够余量，方便后续管路连接；3、燃油管路附着在制动管路上，每隔150-200mm（约一扎距离）使用拉带固定","projectCode":"1","parentCode":"[CJ00105]底盘分装线","dayShiftSpecial":"sense,","checkValue":"1","checkRemarks":"2","fileName":"undefined","filePath":"D:/userfiles/qmsManufactureProductionPlanCheckItem/200831/QmsManufactureProductionplanCheckitems_20200831161510367.java","configChange":false}]
     */


        /**
         * id : d19c9917b3b6442fa967518d3f16753d
         * isNewRecord : false
         * createDate : 2020-08-24 18:34:54
         * updateDate : 2020-10-12 16:24:26
         * operType : assemblingProcess
         * checkItemId : ae759198ae094cde901132efd9740ca9
         * carframeNo : CJ-082401
         * productModel : zc
         * flowcarNo : SC-082401
         * carModelNo : [zc]整车
         * status : failed
         * checkedBy : sense
         * checkedDate : 2020-10-12 16:24:26
         * planFinishDate : 2020-08-24 00:00:00
         * orderNo : ORDER-082401
         * productOrder : PRODUCTORDER-082401
         * classid : ZPGW140
         * opno : GXMC_2650
         * opnm : 安装氮氧传感器
         * mation : M=35±5N.m
         * projectCode : 1
         * parentCode : [CJ00105]底盘分装线
         * isKeyCheck : 1
         * dayShiftSpecial : sense,
         * checkValue : 123
         * checkRemarks : 合格
         * fileName : QmsManufactureProductionplanCheckitemsService.java
         * filePath : D:/userfiles/qmsManufactureProductionPlanCheckItem/200831/QmsManufactureProductionplanCheckitemsService_20200831163628748.java
         * configChange : false
         */

        private String id;
        private boolean isNewRecord;
        private String createDate;
        private String updateDate;
        private String operType;
        private String checkItemId;
        private String carframeNo;
        private String productModel;
        private String flowcarNo;
        private String carModelNo;
        private String status;
        private String checkedBy;
        private String checkedDate;
        private String planFinishDate;
        private String orderNo;
        private String productOrder;
        private String classid;
        private String opno;
        private String opnm;
        private String mation;
        private String projectCode;
        private String parentCode;
        private String isKeyCheck;
        private String dayShiftSpecial;
        private String checkValue;
        private String checkRemarks;
        private String fileName;
        private String filePath;
        private boolean configChange;

    protected ZhuangPeiWeiJianFirstBean(Parcel in) {
        id = in.readString();
        isNewRecord = in.readByte() != 0;
        createDate = in.readString();
        updateDate = in.readString();
        operType = in.readString();
        checkItemId = in.readString();
        carframeNo = in.readString();
        productModel = in.readString();
        flowcarNo = in.readString();
        carModelNo = in.readString();
        status = in.readString();
        checkedBy = in.readString();
        checkedDate = in.readString();
        planFinishDate = in.readString();
        orderNo = in.readString();
        productOrder = in.readString();
        classid = in.readString();
        opno = in.readString();
        opnm = in.readString();
        mation = in.readString();
        projectCode = in.readString();
        parentCode = in.readString();
        isKeyCheck = in.readString();
        dayShiftSpecial = in.readString();
        checkValue = in.readString();
        checkRemarks = in.readString();
        fileName = in.readString();
        filePath = in.readString();
        configChange = in.readByte() != 0;
    }

    public static final Creator<ZhuangPeiWeiJianFirstBean> CREATOR = new Creator<ZhuangPeiWeiJianFirstBean>() {
        @Override
        public ZhuangPeiWeiJianFirstBean createFromParcel(Parcel in) {
            return new ZhuangPeiWeiJianFirstBean(in);
        }

        @Override
        public ZhuangPeiWeiJianFirstBean[] newArray(int size) {
            return new ZhuangPeiWeiJianFirstBean[size];
        }
    };

    public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public boolean isIsNewRecord() {
            return isNewRecord;
        }

        public void setIsNewRecord(boolean isNewRecord) {
            this.isNewRecord = isNewRecord;
        }

        public String getCreateDate() {
            return createDate;
        }

        public void setCreateDate(String createDate) {
            this.createDate = createDate;
        }

        public String getUpdateDate() {
            return updateDate;
        }

        public void setUpdateDate(String updateDate) {
            this.updateDate = updateDate;
        }

        public String getOperType() {
            return operType;
        }

        public void setOperType(String operType) {
            this.operType = operType;
        }

        public String getCheckItemId() {
            return checkItemId;
        }

        public void setCheckItemId(String checkItemId) {
            this.checkItemId = checkItemId;
        }

        public String getCarframeNo() {
            return carframeNo;
        }

        public void setCarframeNo(String carframeNo) {
            this.carframeNo = carframeNo;
        }

        public String getProductModel() {
            return productModel;
        }

        public void setProductModel(String productModel) {
            this.productModel = productModel;
        }

        public String getFlowcarNo() {
            return flowcarNo;
        }

        public void setFlowcarNo(String flowcarNo) {
            this.flowcarNo = flowcarNo;
        }

        public String getCarModelNo() {
            return carModelNo;
        }

        public void setCarModelNo(String carModelNo) {
            this.carModelNo = carModelNo;
        }

        public String getStatus() {
            return status;
        }

        public void setStatus(String status) {
            this.status = status;
        }

        public String getCheckedBy() {
            return checkedBy;
        }

        public void setCheckedBy(String checkedBy) {
            this.checkedBy = checkedBy;
        }

        public String getCheckedDate() {
            return checkedDate;
        }

        public void setCheckedDate(String checkedDate) {
            this.checkedDate = checkedDate;
        }

        public String getPlanFinishDate() {
            return planFinishDate;
        }

        public void setPlanFinishDate(String planFinishDate) {
            this.planFinishDate = planFinishDate;
        }

        public String getOrderNo() {
            return orderNo;
        }

        public void setOrderNo(String orderNo) {
            this.orderNo = orderNo;
        }

        public String getProductOrder() {
            return productOrder;
        }

        public void setProductOrder(String productOrder) {
            this.productOrder = productOrder;
        }

        public String getClassid() {
            return classid;
        }

        public void setClassid(String classid) {
            this.classid = classid;
        }

        public String getOpno() {
            return opno;
        }

        public void setOpno(String opno) {
            this.opno = opno;
        }

        public String getOpnm() {
            return opnm;
        }

        public void setOpnm(String opnm) {
            this.opnm = opnm;
        }

        public String getMation() {
            return mation;
        }

        public void setMation(String mation) {
            this.mation = mation;
        }

        public String getProjectCode() {
            return projectCode;
        }

        public void setProjectCode(String projectCode) {
            this.projectCode = projectCode;
        }

        public String getParentCode() {
            return parentCode;
        }

        public void setParentCode(String parentCode) {
            this.parentCode = parentCode;
        }

        public String getIsKeyCheck() {
            return isKeyCheck;
        }

        public void setIsKeyCheck(String isKeyCheck) {
            this.isKeyCheck = isKeyCheck;
        }

        public String getDayShiftSpecial() {
            return dayShiftSpecial;
        }

        public void setDayShiftSpecial(String dayShiftSpecial) {
            this.dayShiftSpecial = dayShiftSpecial;
        }

        public String getCheckValue() {
            return checkValue;
        }

        public void setCheckValue(String checkValue) {
            this.checkValue = checkValue;
        }

        public String getCheckRemarks() {
            return checkRemarks;
        }

        public void setCheckRemarks(String checkRemarks) {
            this.checkRemarks = checkRemarks;
        }

        public String getFileName() {
            return fileName;
        }

        public void setFileName(String fileName) {
            this.fileName = fileName;
        }

        public String getFilePath() {
            return filePath;
        }

        public void setFilePath(String filePath) {
            this.filePath = filePath;
        }

        public boolean isConfigChange() {
            return configChange;
        }

        public void setConfigChange(boolean configChange) {
            this.configChange = configChange;
        }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(id);
        parcel.writeByte((byte) (isNewRecord ? 1 : 0));
        parcel.writeString(createDate);
        parcel.writeString(updateDate);
        parcel.writeString(operType);
        parcel.writeString(checkItemId);
        parcel.writeString(carframeNo);
        parcel.writeString(productModel);
        parcel.writeString(flowcarNo);
        parcel.writeString(carModelNo);
        parcel.writeString(status);
        parcel.writeString(checkedBy);
        parcel.writeString(checkedDate);
        parcel.writeString(planFinishDate);
        parcel.writeString(orderNo);
        parcel.writeString(productOrder);
        parcel.writeString(classid);
        parcel.writeString(opno);
        parcel.writeString(opnm);
        parcel.writeString(mation);
        parcel.writeString(projectCode);
        parcel.writeString(parentCode);
        parcel.writeString(isKeyCheck);
        parcel.writeString(dayShiftSpecial);
        parcel.writeString(checkValue);
        parcel.writeString(checkRemarks);
        parcel.writeString(fileName);
        parcel.writeString(filePath);
        parcel.writeByte((byte) (configChange ? 1 : 0));
    }
}
