package com.zhuisu.fastdev.beans.zhiliangmen;

/**
 * @author cxh
 * @description
 * @date 2020/10/12.
 */
public class ZhiLiangMenWeiJianXiangQingBuMenList {
    private String value;
    private String label;

    public void setValue(String value) {
        this.value = value;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public String getValue() {
        return value;
    }

    public String getLabel() {
        return label;
    }

    @Override
    public String toString() {
        return label;
    }
}
