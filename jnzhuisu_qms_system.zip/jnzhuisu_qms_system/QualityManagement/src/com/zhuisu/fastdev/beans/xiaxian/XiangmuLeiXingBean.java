package com.zhuisu.fastdev.beans.xiaxian;

import java.io.Serializable;
import java.util.List;

public class XiangmuLeiXingBean implements Serializable {

    /**
     * retCode : 0
     * data : [{"isNewRecord":true,"value":"problem_source_14_01","label":"零公里质量信息","sort":10},{"isNewRecord":true,"value":"problem_source_13_01","label":"体系内部审核","sort":10},{"isNewRecord":true,"value":"problem_source_12_01","label":"过程审核","sort":10},{"isNewRecord":true,"value":"problem_source_11_01","label":"整车Audit评审","sort":10},{"isNewRecord":true,"value":"problem_source_04_01","label":"售后反馈","sort":10},{"isNewRecord":true,"value":"problem_source_11_07","label":"问题反馈","sort":20},{"isNewRecord":true,"value":"problem_source_11_02","label":"整车专项评审","sort":20},{"isNewRecord":true,"value":"problem_source_04_02","label":"主动走访","sort":20},{"isNewRecord":true,"value":"problem_source_13_02","label":"体系外部审核","sort":20},{"isNewRecord":true,"value":"problem_source_12_02","label":"专项过程审核","sort":20},{"isNewRecord":true,"value":"problem_source_04_03","label":"PDI检查","sort":30},{"isNewRecord":true,"value":"problem_source_11_03","label":"整车可靠性试验","sort":30},{"isNewRecord":true,"value":"problem_source_11_04","label":"驾驶室本体质量审核","sort":40},{"isNewRecord":true,"value":"problem_source_11_05","label":"驾驶室涂装质量审核","sort":50},{"isNewRecord":true,"value":"problem_source_11_06","label":"车架总成质量审核","sort":60}]
     */

    private String retCode;
    private List<DataBean> data;

    public String getRetCode() {
        return retCode;
    }

    public void setRetCode(String retCode) {
        this.retCode = retCode;
    }

    public List<DataBean> getData() {
        return data;
    }

    public void setData(List<DataBean> data) {
        this.data = data;
    }

    public static class DataBean implements Serializable {
        /**
         * isNewRecord : true
         * value : problem_source_14_01
         * label : 零公里质量信息
         * sort : 10
         */

        private Boolean isNewRecord;
        private String value;
        private String label;
        private Integer sort;

        public Boolean getNewRecord() {
            return isNewRecord;
        }

        public void setNewRecord(Boolean newRecord) {
            isNewRecord = newRecord;
        }

        public String getValue() {
            return value;
        }

        public void setValue(String value) {
            this.value = value;
        }

        public String getLabel() {
            return label;
        }

        public void setLabel(String label) {
            this.label = label;
        }

        public Integer getSort() {
            return sort;
        }

        public void setSort(Integer sort) {
            this.sort = sort;
        }

        @Override
        public String toString() {
            return label;
        }
    }
}
