package com.zhuisu.fastdev.beans.registercar

/**
 * @author cxh
 * @description
 * @date 2020/11/12.
 */
data class ReCheckCarList(var id : String,var peoblemTitle: String?,var problemDesc : String? ,var malfunctionCode : String?,var problemLevel : String?,var result : String?,var createByUser  : String?,var imgStr : String?,var recheckOperator : String?)