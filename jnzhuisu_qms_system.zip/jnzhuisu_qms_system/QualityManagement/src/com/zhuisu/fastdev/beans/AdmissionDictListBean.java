package com.zhuisu.fastdev.beans;

import java.util.List;

/**
 * @author cxh
 * @description
 * @date 2020/11/6.
 */

public class AdmissionDictListBean {

    /**
     * retCode : 0
     * data : [{"id":"003226fa24604bfcafb708da11c6fcbc","isNewRecord":false,"remarks":"","createDate":"2020-08-31 11:45:44","updateDate":"2020-10-19 17:58:32","value":"外观类","label":"外观类","type":"qms_purchasecheck_checkitemtype","description":"检验项目类别","sort":10,"parentId":"0"},{"id":"4601f78dae5144c1866f4fb4b6d4f2e2","isNewRecord":false,"remarks":"","createDate":"2020-10-19 17:57:17","updateDate":"2020-10-19 17:59:13","value":"尺寸类","label":"尺寸类","type":"qms_purchasecheck_checkitemtype","description":"检验项目类别","sort":15,"parentId":"0"},{"id":"2757fda16b0e4f87a0f0a63ebf0b6121","isNewRecord":false,"remarks":"","createDate":"2020-10-19 17:57:49","updateDate":"2020-10-19 17:57:49","value":"标识类","label":"标识类","type":"qms_purchasecheck_checkitemtype","description":"检验项目类别","sort":20,"parentId":"0"},{"id":"b601b64f6c4a4ccbb24209e5ee79d2af","isNewRecord":false,"remarks":"","createDate":"2020-10-19 17:57:33","updateDate":"2020-10-19 17:58:22","value":"报告类","label":"报告类","type":"qms_purchasecheck_checkitemtype","description":"检验项目类别","sort":30,"parentId":"0"},{"id":"959c106b087e44f880d19149b5a72ca1","isNewRecord":false,"remarks":"","createDate":"2020-10-19 17:58:59","updateDate":"2020-10-19 17:58:59","value":"其他类","label":"其他类","type":"qms_purchasecheck_checkitemtype","description":"检验项目类别","sort":50,"parentId":"0"}]
     */


    /**
     * id : 003226fa24604bfcafb708da11c6fcbc
     * isNewRecord : false
     * remarks :
     * createDate : 2020-08-31 11:45:44
     * updateDate : 2020-10-19 17:58:32
     * value : 外观类
     * label : 外观类
     * type : qms_purchasecheck_checkitemtype
     * description : 检验项目类别
     * sort : 10
     * parentId : 0
     */

    private String id;
    private Boolean isNewRecord;
    private String remarks;
    private String createDate;
    private String updateDate;
    private String value;
    private String label;
    private String type;
    private String description;
    private Integer sort;
    private String parentId;

    public void setId(String id) {
        this.id = id;
    }

    public void setNewRecord(Boolean newRecord) {
        isNewRecord = newRecord;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public void setCreateDate(String createDate) {
        this.createDate = createDate;
    }

    public void setUpdateDate(String updateDate) {
        this.updateDate = updateDate;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public void setType(String type) {
        this.type = type;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setSort(Integer sort) {
        this.sort = sort;
    }

    public void setParentId(String parentId) {
        this.parentId = parentId;
    }

    public String getId() {
        return id;
    }

    public Boolean getNewRecord() {
        return isNewRecord;
    }

    public String getRemarks() {
        return remarks;
    }

    public String getCreateDate() {
        return createDate;
    }

    public String getUpdateDate() {
        return updateDate;
    }

    public String getValue() {
        return value;
    }

    public String getLabel() {
        return label;
    }

    public String getType() {
        return type;
    }

    public String getDescription() {
        return description;
    }

    public Integer getSort() {
        return sort;
    }

    public String getParentId() {
        return parentId;
    }

    @Override
    public String toString() {
       return label;
    }
}
