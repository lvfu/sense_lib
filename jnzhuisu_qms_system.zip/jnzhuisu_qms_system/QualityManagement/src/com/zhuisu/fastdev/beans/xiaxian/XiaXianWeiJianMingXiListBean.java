package com.zhuisu.fastdev.beans.xiaxian;

import java.util.List;

/**
 * @author cxh
 * @description
 * @date 2020/10/13.
 */
public class XiaXianWeiJianMingXiListBean {

    /**
     * retCode : 0
     * data : {"id":"d19c9917b3b6442fa967518d3f16753d","isNewRecord":false,"createDate":"2020-08-24 18:34:54","updateDate":"2020-10-12 16:24:26","operType":"assemblingProcess","checkItemId":"ae759198ae094cde901132efd9740ca9","carframeNo":"CJ-082401","productModel":"zc","flowcarNo":"SC-082401","carModelNo":"[zc]整车","status":"failed","checkedBy":"sense","checkedDate":"2020-10-12 16:24:26","planFinishDate":"2020-08-24 00:00:00","orderNo":"ORDER-082401","productOrder":"PRODUCTORDER-082401","classid":"ZPGW140","opno":"GXMC_2650","opnm":"安装氮氧传感器","mation":"M=35±5N.m","projectCode":"1","parentCode":"ZPGW140","isKeyCheck":"1","dayShiftSpecial":"sense,","checkValue":"123","checkRemarks":"合格","fileName":"QmsManufactureProductionplanCheckitemsService.java","filePath":"D:/userfiles/qmsManufactureProductionPlanCheckItem/200831/QmsManufactureProductionplanCheckitemsService_20200831163628748.java","flowInfos":[{"flowInsId":"e4291a6f3599489cb8fd68a65c34067f","problemTitle":"巡检测试2020101001","flowStatus":"finish","createDate":"2020-10-10 08:58:21"},{"flowInsId":"773ad6d564864874a7db2674f4f1d347","problemTitle":"测试20201009006","flowStatus":"finish","createDate":"2020-10-09 17:36:13"},{"flowInsId":"a274afaba93f4bd0beeb8d081f454247","problemTitle":"测试20201009005","flowStatus":"finish","createDate":"2020-10-09 17:01:50"},{"flowInsId":"318da78ca784419491a5ccae005e39f1","problemTitle":"测试20201009004","flowStatus":"finish","createDate":"2020-10-09 16:58:49"},{"flowInsId":"43cf7e58a2b145acad8975312270d1f1","problemTitle":"测试20201009003","flowStatus":"finish","createDate":"2020-10-09 13:47:31"},{"flowInsId":"62d4366e470b4e98be183c2d82cef01d","currentHandler":"系统管理员,null,姚建成","currentNode":"责任部门","problemTitle":"测试20201009002","flowStatus":"claim","createDate":"2020-10-09 11:12:54"},{"problemTitle":"制动踏板自由行程不符合要求20201009","flowStatus":"finish","createDate":"2020-10-09 11:01:38"},{"flowInsId":"b2fc62b1a7fb4f7eb58868bcaf91622c","currentHandler":"系统管理员,姚建成","currentNode":"责任部门","problemTitle":"制动踏板自由行程不符合要求20201009","flowStatus":"claim","createDate":"2020-10-09 10:08:26"}],"configChange":false}
     */


    /**
     * id : d19c9917b3b6442fa967518d3f16753d
     * isNewRecord : false
     * createDate : 2020-08-24 18:34:54
     * updateDate : 2020-10-12 16:24:26
     * operType : assemblingProcess
     * checkItemId : ae759198ae094cde901132efd9740ca9
     * carframeNo : CJ-082401
     * productModel : zc
     * flowcarNo : SC-082401
     * carModelNo : [zc]整车
     * status : failed
     * checkedBy : sense
     * checkedDate : 2020-10-12 16:24:26
     * planFinishDate : 2020-08-24 00:00:00
     * orderNo : ORDER-082401
     * productOrder : PRODUCTORDER-082401
     * classid : ZPGW140
     * opno : GXMC_2650
     * opnm : 安装氮氧传感器
     * mation : M=35±5N.m
     * projectCode : 1
     * parentCode : ZPGW140
     * isKeyCheck : 1
     * dayShiftSpecial : sense,
     * checkValue : 123
     * checkRemarks : 合格
     * fileName : QmsManufactureProductionplanCheckitemsService.java
     * filePath : D:/userfiles/qmsManufactureProductionPlanCheckItem/200831/QmsManufactureProductionplanCheckitemsService_20200831163628748.java
     * flowInfos : [{"flowInsId":"e4291a6f3599489cb8fd68a65c34067f","problemTitle":"巡检测试2020101001","flowStatus":"finish","createDate":"2020-10-10 08:58:21"},{"flowInsId":"773ad6d564864874a7db2674f4f1d347","problemTitle":"测试20201009006","flowStatus":"finish","createDate":"2020-10-09 17:36:13"},{"flowInsId":"a274afaba93f4bd0beeb8d081f454247","problemTitle":"测试20201009005","flowStatus":"finish","createDate":"2020-10-09 17:01:50"},{"flowInsId":"318da78ca784419491a5ccae005e39f1","problemTitle":"测试20201009004","flowStatus":"finish","createDate":"2020-10-09 16:58:49"},{"flowInsId":"43cf7e58a2b145acad8975312270d1f1","problemTitle":"测试20201009003","flowStatus":"finish","createDate":"2020-10-09 13:47:31"},{"flowInsId":"62d4366e470b4e98be183c2d82cef01d","currentHandler":"系统管理员,null,姚建成","currentNode":"责任部门","problemTitle":"测试20201009002","flowStatus":"claim","createDate":"2020-10-09 11:12:54"},{"problemTitle":"制动踏板自由行程不符合要求20201009","flowStatus":"finish","createDate":"2020-10-09 11:01:38"},{"flowInsId":"b2fc62b1a7fb4f7eb58868bcaf91622c","currentHandler":"系统管理员,姚建成","currentNode":"责任部门","problemTitle":"制动踏板自由行程不符合要求20201009","flowStatus":"claim","createDate":"2020-10-09 10:08:26"}]
     * configChange : false
     */

    private String id;
    private boolean isNewRecord;
    private String createDate;
    private String updateDate;
    private String operType;
    private String checkItemId;
    private String carframeNo;
    private String productModel;
    private String flowcarNo;
    private String carModelNo;
    private String status;
    private String checkedBy;
    private String checkedDate;
    private String planFinishDate;
    private String orderNo;
    private String productOrder;
    private String classid;
    private String opno;
    private String opnm;
    private String mation;
    private String projectCode;
    private String parentCode;
    private String isKeyCheck;
    private String dayShiftSpecial;
    private String checkValue;
    private String checkRemarks;
    private String fileName;
    private String filePath;
    private boolean configChange;
    private List<FlowInfosBean> flowInfos;
    private String imgStr;

    public void setNewRecord(boolean newRecord) {
        isNewRecord = newRecord;
    }

    public void setImgStr(String imgStr) {
        this.imgStr = imgStr;
    }

    public boolean isNewRecord() {
        return isNewRecord;
    }

    public String getImgStr() {
        return imgStr;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public boolean isIsNewRecord() {
        return isNewRecord;
    }

    public void setIsNewRecord(boolean isNewRecord) {
        this.isNewRecord = isNewRecord;
    }

    public String getCreateDate() {
        return createDate;
    }

    public void setCreateDate(String createDate) {
        this.createDate = createDate;
    }

    public String getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(String updateDate) {
        this.updateDate = updateDate;
    }

    public String getOperType() {
        return operType;
    }

    public void setOperType(String operType) {
        this.operType = operType;
    }

    public String getCheckItemId() {
        return checkItemId;
    }

    public void setCheckItemId(String checkItemId) {
        this.checkItemId = checkItemId;
    }

    public String getCarframeNo() {
        return carframeNo;
    }

    public void setCarframeNo(String carframeNo) {
        this.carframeNo = carframeNo;
    }

    public String getProductModel() {
        return productModel;
    }

    public void setProductModel(String productModel) {
        this.productModel = productModel;
    }

    public String getFlowcarNo() {
        return flowcarNo;
    }

    public void setFlowcarNo(String flowcarNo) {
        this.flowcarNo = flowcarNo;
    }

    public String getCarModelNo() {
        return carModelNo;
    }

    public void setCarModelNo(String carModelNo) {
        this.carModelNo = carModelNo;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getCheckedBy() {
        return checkedBy;
    }

    public void setCheckedBy(String checkedBy) {
        this.checkedBy = checkedBy;
    }

    public String getCheckedDate() {
        return checkedDate;
    }

    public void setCheckedDate(String checkedDate) {
        this.checkedDate = checkedDate;
    }

    public String getPlanFinishDate() {
        return planFinishDate;
    }

    public void setPlanFinishDate(String planFinishDate) {
        this.planFinishDate = planFinishDate;
    }

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    public String getProductOrder() {
        return productOrder;
    }

    public void setProductOrder(String productOrder) {
        this.productOrder = productOrder;
    }

    public String getClassid() {
        return classid;
    }

    public void setClassid(String classid) {
        this.classid = classid;
    }

    public String getOpno() {
        return opno;
    }

    public void setOpno(String opno) {
        this.opno = opno;
    }

    public String getOpnm() {
        return opnm;
    }

    public void setOpnm(String opnm) {
        this.opnm = opnm;
    }

    public String getMation() {
        return mation;
    }

    public void setMation(String mation) {
        this.mation = mation;
    }

    public String getProjectCode() {
        return projectCode;
    }

    public void setProjectCode(String projectCode) {
        this.projectCode = projectCode;
    }

    public String getParentCode() {
        return parentCode;
    }

    public void setParentCode(String parentCode) {
        this.parentCode = parentCode;
    }

    public String getIsKeyCheck() {
        return isKeyCheck;
    }

    public void setIsKeyCheck(String isKeyCheck) {
        this.isKeyCheck = isKeyCheck;
    }

    public String getDayShiftSpecial() {
        return dayShiftSpecial;
    }

    public void setDayShiftSpecial(String dayShiftSpecial) {
        this.dayShiftSpecial = dayShiftSpecial;
    }

    public String getCheckValue() {
        return checkValue;
    }

    public void setCheckValue(String checkValue) {
        this.checkValue = checkValue;
    }

    public String getCheckRemarks() {
        return checkRemarks;
    }

    public void setCheckRemarks(String checkRemarks) {
        this.checkRemarks = checkRemarks;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getFilePath() {
        return filePath;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }

    public boolean isConfigChange() {
        return configChange;
    }

    public void setConfigChange(boolean configChange) {
        this.configChange = configChange;
    }

    public List<FlowInfosBean> getFlowInfos() {
        return flowInfos;
    }

    public void setFlowInfos(List<FlowInfosBean> flowInfos) {
        this.flowInfos = flowInfos;
    }

    public static class FlowInfosBean {
        /**
         * flowInsId : e4291a6f3599489cb8fd68a65c34067f
         * problemTitle : 巡检测试2020101001
         * flowStatus : finish
         * createDate : 2020-10-10 08:58:21
         * currentHandler : 系统管理员,null,姚建成
         * currentNode : 责任部门
         */

        private String flowInsId;
        private String problemTitle;
        private String flowStatus;
        private String createDate;
        private String currentHandler;
        private String currentNode;
        private String problemLevel;
        private String problemDesc;
        private String imgStr;


        public void setImgStr(String imgStr) {
            this.imgStr = imgStr;
        }

        public String getImgStr() {
            return imgStr;
        }

        public void setProblemDesc(String problemDesc) {
            this.problemDesc = problemDesc;
        }

        public String getProblemDesc() {
            return problemDesc;
        }

        public void setProblemLevel(String problemLevel) {
            this.problemLevel = problemLevel;
        }

        public String getProblemLevel() {
            return problemLevel;
        }

        public String getFlowInsId() {
            return flowInsId;
        }

        public void setFlowInsId(String flowInsId) {
            this.flowInsId = flowInsId;
        }

        public String getProblemTitle() {
            return problemTitle;
        }

        public void setProblemTitle(String problemTitle) {
            this.problemTitle = problemTitle;
        }

        public String getFlowStatus() {
            return flowStatus;
        }

        public void setFlowStatus(String flowStatus) {
            this.flowStatus = flowStatus;
        }

        public String getCreateDate() {
            return createDate;
        }

        public void setCreateDate(String createDate) {
            this.createDate = createDate;
        }

        public String getCurrentHandler() {
            return currentHandler;
        }

        public void setCurrentHandler(String currentHandler) {
            this.currentHandler = currentHandler;
        }

        public String getCurrentNode() {
            return currentNode;
        }

        public void setCurrentNode(String currentNode) {
            this.currentNode = currentNode;
        }
    }
}
