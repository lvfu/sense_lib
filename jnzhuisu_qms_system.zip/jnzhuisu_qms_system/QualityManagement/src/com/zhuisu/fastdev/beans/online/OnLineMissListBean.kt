package com.zhuisu.fastdev.beans.online

/**
 * @author cxh
 * @description
 * @date 2020/11/10.
 */
data class OnLineMissListBean(var bomId : String?,var bomName : String? ,var quantity : String? ,var status : String?)