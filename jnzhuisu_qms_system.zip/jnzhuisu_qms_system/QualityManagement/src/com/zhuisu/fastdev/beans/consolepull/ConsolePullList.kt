package com.zhuisu.fastdev.beans.consolepull

import android.os.Parcel
import android.os.Parcelable

/**
 * @author cxh
 * @description
 * @date 2020/11/18.
 */
data class ConsolePullList(var flowCarNo : String?,var id : String?,var carFarmeNo : String?,var location : String?,var status : String?) : Parcelable {
    constructor(parcel: Parcel) : this(
            parcel.readString(),
            parcel.readString(),
            parcel.readString(),
            parcel.readString(),parcel.readString()) {
    }

    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeString(flowCarNo)
        parcel.writeString(id)
        parcel.writeString(carFarmeNo)
        parcel.writeString(location)
        parcel.writeString(status)
    }

    override fun describeContents(): Int {
        return 0
    }

    companion object CREATOR : Parcelable.Creator<ConsolePullList> {
        override fun createFromParcel(parcel: Parcel): ConsolePullList {
            return ConsolePullList(parcel)
        }

        override fun newArray(size: Int): Array<ConsolePullList?> {
            return arrayOfNulls(size)
        }
    }
}