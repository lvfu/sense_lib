package com.zhuisu.fastdev.beans.xiaxian;

import java.io.Serializable;
import java.util.List;

public class BuHeGeFenLei implements Serializable {

    /**
     * retCode : 0
     * data : [{"id":"012518ef474e4b188978a566b27f1053","isNewRecord":false,"remarks":"","createDate":"2021-05-26 14:23:24","updateDate":"2021-05-26 14:23:24","value":"不合格项分类","label":"不合格项分类","type":"unqualifiedSort","description":"评审不合格项分类","sort":10,"parentId":"0"},{"id":"740e8eaa3b734822afcb724f0862b8f1","isNewRecord":false,"remarks":"","createDate":"2021-06-01 10:56:43","updateDate":"2021-06-01 10:56:58","value":"涂装类","label":"涂装类","type":"unqualifiedSort","description":"评审不合格项分类","sort":20,"parentId":"0"},{"id":"c1e4a25da3544893839838fdf790e76d","isNewRecord":false,"remarks":"","createDate":"2021-06-01 10:58:12","updateDate":"2021-06-01 10:58:12","value":"表面质量","label":"表面质量","type":"unqualifiedSort","description":"评审不合格项分类","sort":30,"parentId":"0"},{"id":"8c89eb41f7fd4833bf12a859dc227bc1","isNewRecord":false,"remarks":"","createDate":"2021-06-01 10:57:41","updateDate":"2021-06-01 10:57:41","value":"间隙类","label":"间隙类","type":"unqualifiedSort","description":"评审不合格项分类","sort":30,"parentId":"0"},{"id":"3b4ee2f86b8b415a86c5edd7dec5918d","isNewRecord":false,"remarks":"","createDate":"2021-06-01 10:58:27","updateDate":"2021-06-01 10:58:27","value":"功能类","label":"功能类","type":"unqualifiedSort","description":"评审不合格项分类","sort":40,"parentId":"0"},{"id":"9fc58b793dea42099e02384348d2356c","isNewRecord":false,"remarks":"","createDate":"2021-06-01 10:58:50","updateDate":"2021-06-01 10:58:50","value":"拧紧力矩类","label":"拧紧力矩类","type":"unqualifiedSort","description":"评审不合格项分类","sort":50,"parentId":"0"},{"id":"32e93501241241af85804946b3f263e9","isNewRecord":false,"remarks":"","createDate":"2021-06-01 10:59:45","updateDate":"2021-06-01 10:59:45","value":"电器线束安装类","label":"电器线束安装类","type":"unqualifiedSort","description":"评审不合格项分类","sort":60,"parentId":"0"},{"id":"fc8d99412658456aa1f260c547c004b8","isNewRecord":false,"remarks":"","createDate":"2021-06-01 10:59:19","updateDate":"2021-06-01 10:59:51","value":"三漏及油液加注类","label":"三漏及油液加注类","type":"unqualifiedSort","description":"评审不合格项分类","sort":70,"parentId":"0"},{"id":"1ed1beff7ba44aeb8e1b4371e6d9c186","isNewRecord":false,"remarks":"","createDate":"2021-06-01 11:00:32","updateDate":"2021-06-01 11:00:32","value":"水管安装类","label":"水管安装类","type":"unqualifiedSort","description":"评审不合格项分类","sort":80,"parentId":"0"},{"id":"b8c643afb19d4f6d8c743f7013d46eab","isNewRecord":false,"remarks":"","createDate":"2021-06-01 11:00:13","updateDate":"2021-06-01 11:00:38","value":"制动管路安装类","label":"制动管路安装类","type":"unqualifiedSort","description":"评审不合格项分类","sort":90,"parentId":"0"},{"id":"1142253f5b194c3f9a20043b8a0ff60b","isNewRecord":false,"remarks":"","createDate":"2021-06-01 11:00:59","updateDate":"2021-06-01 11:00:59","value":"油管安装类","label":"油管安装类","type":"unqualifiedSort","description":"评审不合格项分类","sort":100,"parentId":"0"},{"id":"e961cb8817874a5c89a76c92e867e44c","isNewRecord":false,"remarks":"","createDate":"2021-06-01 11:01:24","updateDate":"2021-06-01 11:01:24","value":"错漏装类","label":"错漏装类","type":"unqualifiedSort","description":"评审不合格项分类","sort":110,"parentId":"0"},{"id":"c0f138e18271487fb33fdcc9df1ff32e","isNewRecord":false,"remarks":"","createDate":"2021-06-01 11:01:45","updateDate":"2021-06-01 11:01:45","value":"环保一致性类","label":"环保一致性类","type":"unqualifiedSort","description":"评审不合格项分类","sort":120,"parentId":"0"},{"id":"d8fcf44646cb43fc9674861a2c949e0d","isNewRecord":false,"remarks":"","createDate":"2021-06-01 11:02:07","updateDate":"2021-06-01 11:02:07","value":"公告一致性类","label":"公告一致性类","type":"unqualifiedSort","description":"评审不合格项分类","sort":130,"parentId":"0"},{"id":"6c3373f9d42b44e781122f1c4ca11c37","isNewRecord":false,"remarks":"","createDate":"2021-06-01 11:02:27","updateDate":"2021-06-01 11:02:27","value":"3C一致性类","label":"3C一致性类","type":"unqualifiedSort","description":"评审不合格项分类","sort":140,"parentId":"0"},{"id":"f7edd574af684ef0bbddf17bc48a23c7","isNewRecord":false,"remarks":"","createDate":"2021-06-01 11:02:56","updateDate":"2021-06-01 11:02:56","value":"质量档案一致性类","label":"质量档案一致性类","type":"unqualifiedSort","description":"评审不合格项分类","sort":150,"parentId":"0"},{"id":"c095a35450204ad783d3f939f628ba49","isNewRecord":false,"remarks":"","createDate":"2021-06-01 11:03:28","updateDate":"2021-06-01 11:03:28","value":"早期可靠性类","label":"早期可靠性类","type":"unqualifiedSort","description":"评审不合格项分类","sort":160,"parentId":"0"},{"id":"bc11392cab51440bbb9ffc037a1aa714","isNewRecord":false,"remarks":"","createDate":"2021-06-01 11:03:43","updateDate":"2021-06-01 11:03:43","value":"性能类","label":"性能类","type":"unqualifiedSort","description":"评审不合格项分类","sort":170,"parentId":"0"},{"id":"c06e30c4beee4e4390ab71e280b79cce","isNewRecord":false,"remarks":"","createDate":"2021-06-01 11:04:11","updateDate":"2021-06-01 11:04:11","value":"用户体验类","label":"用户体验类","type":"unqualifiedSort","description":"评审不合格项分类","sort":180,"parentId":"0"}]
     */

    private String retCode;
    private List<DataBean> data;

    public String getRetCode() {
        return retCode;
    }

    public void setRetCode(String retCode) {
        this.retCode = retCode;
    }

    public List<DataBean> getData() {
        return data;
    }

    public void setData(List<DataBean> data) {
        this.data = data;
    }

    public static class DataBean implements Serializable {
        /**
         * id : 012518ef474e4b188978a566b27f1053
         * isNewRecord : false
         * remarks :
         * createDate : 2021-05-26 14:23:24
         * updateDate : 2021-05-26 14:23:24
         * value : 不合格项分类
         * label : 不合格项分类
         * type : unqualifiedSort
         * description : 评审不合格项分类
         * sort : 10
         * parentId : 0
         */

        private String id;
        private Boolean isNewRecord;
        private String remarks;
        private String createDate;
        private String updateDate;
        private String value;
        private String label;
        private String type;
        private String description;
        private Integer sort;
        private String parentId;

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public Boolean getNewRecord() {
            return isNewRecord;
        }

        public void setNewRecord(Boolean newRecord) {
            isNewRecord = newRecord;
        }

        public String getRemarks() {
            return remarks;
        }

        public void setRemarks(String remarks) {
            this.remarks = remarks;
        }

        public String getCreateDate() {
            return createDate;
        }

        public void setCreateDate(String createDate) {
            this.createDate = createDate;
        }

        public String getUpdateDate() {
            return updateDate;
        }

        public void setUpdateDate(String updateDate) {
            this.updateDate = updateDate;
        }

        public String getValue() {
            return value;
        }

        public void setValue(String value) {
            this.value = value;
        }

        public String getLabel() {
            return label;
        }

        public void setLabel(String label) {
            this.label = label;
        }

        public String getType() {
            return type;
        }

        public void setType(String type) {
            this.type = type;
        }

        public String getDescription() {
            return description;
        }

        public void setDescription(String description) {
            this.description = description;
        }

        public Integer getSort() {
            return sort;
        }

        public void setSort(Integer sort) {
            this.sort = sort;
        }

        public String getParentId() {
            return parentId;
        }

        public void setParentId(String parentId) {
            this.parentId = parentId;
        }

        @Override
        public String toString() {
            return value;
        }
    }
}
