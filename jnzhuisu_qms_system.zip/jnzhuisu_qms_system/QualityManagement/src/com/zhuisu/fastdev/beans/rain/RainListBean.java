package com.zhuisu.fastdev.beans.rain;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * @author cxh
 * @description
 * @date 2020/10/23.
 */

public class RainListBean implements Parcelable {
    /**
     * msg : 获取成功！
     * data : {"pageNo":1,"pageSize":30,"count":211,"list":[{"id":"73524392-f0ed-42ba-b02b-8a99fdeda5c7","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"ASSJ20080005/0010-0004","carFarmeNo":"LJ177026","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185H3613E1/J7V7M36-标运质赢","basicDevices":null,"orderNo":"ASSJ20080005","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲豪瀚N：玛瑙红,;豪瀚 N5；牵引车；豪瀚H78B驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；MC07.24-50发动机；8JS95TE-C变速箱；H653自调臂前轴(鼓)；MCJ09BG自调臂单后桥(鼓)；速比4.63；单层车架(7/250)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；295/80R22.5；50#JOST鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"69c2c291-a30d-4ac9-bb80-49276beace2b","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"ASSJ20080005/0010-0005","carFarmeNo":"LJ177027","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185H3613E1/J7V7M36-标运质赢","basicDevices":null,"orderNo":"ASSJ20080005","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲豪瀚N：玛瑙红,;豪瀚 N5；牵引车；豪瀚H78B驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；MC07.24-50发动机；8JS95TE-C变速箱；H653自调臂前轴(鼓)；MCJ09BG自调臂单后桥(鼓)；速比4.63；单层车架(7/250)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；295/80R22.5；50#JOST鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"9b989e34-abf7-4dcb-8d32-c5dde96f3733","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"ASSJ20080005/0010-0006","carFarmeNo":"LJ177028","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185H3613E1/J7V7M36-标运质赢","basicDevices":null,"orderNo":"ASSJ20080005","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲豪瀚N：玛瑙红,;豪瀚 N5；牵引车；豪瀚H78B驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；MC07.24-50发动机；8JS95TE-C变速箱；H653自调臂前轴(鼓)；MCJ09BG自调臂单后桥(鼓)；速比4.63；单层车架(7/250)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；295/80R22.5；50#JOST鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"bb89c0db-73ad-4b94-8fbe-da7661c74ed8","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"ASSJ20080005/0010-0008","carFarmeNo":"LJ177030","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185H3613E1/J7V7M36-标运质赢","basicDevices":null,"orderNo":"ASSJ20080005","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲豪瀚N：玛瑙红,;豪瀚 N5；牵引车；豪瀚H78B驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；MC07.24-50发动机；8JS95TE-C变速箱；H653自调臂前轴(鼓)；MCJ09BG自调臂单后桥(鼓)；速比4.63；单层车架(7/250)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；295/80R22.5；50#JOST鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"8a90d468-e2e2-4435-b30d-30c68a718ed2","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"ASSJ20080005/0010-0009","carFarmeNo":"LJ177031","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185H3613E1/J7V7M36-标运质赢","basicDevices":null,"orderNo":"ASSJ20080005","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲豪瀚N：玛瑙红,;豪瀚 N5；牵引车；豪瀚H78B驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；MC07.24-50发动机；8JS95TE-C变速箱；H653自调臂前轴(鼓)；MCJ09BG自调臂单后桥(鼓)；速比4.63；单层车架(7/250)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；295/80R22.5；50#JOST鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"6c13b4dd-ba9d-4891-a367-8915c4f2d3ff","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"ASSJ20080005/0010-0010","carFarmeNo":"LJ177032","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185H3613E1/J7V7M36-标运质赢","basicDevices":null,"orderNo":"ASSJ20080005","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲豪瀚N：玛瑙红,;豪瀚 N5；牵引车；豪瀚H78B驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；MC07.24-50发动机；8JS95TE-C变速箱；H653自调臂前轴(鼓)；MCJ09BG自调臂单后桥(鼓)；速比4.63；单层车架(7/250)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；295/80R22.5；50#JOST鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"f5c7d5b9-e31a-49aa-becb-47a63d8befa8","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"ASSJ20080008/0010-0001","carFarmeNo":"LJ177033","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185H3613E1/J7V7M36-标运质赢","basicDevices":null,"orderNo":"ASSJ20080008","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲豪瀚N：玛瑙红,;豪瀚 N5；牵引车；豪瀚H78B驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；MC07.24-50发动机；8JS95TE-C变速箱；H653自调臂前轴(鼓)；MCJ09BG自调臂单后桥(鼓)；速比4.63；单层车架(7/250)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；295/80R22.5；50#JOST鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"0594a265-2467-4249-b410-50852862d6c3","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"ASSJ20080008/0010-0002","carFarmeNo":"LJ177034","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185H3613E1/J7V7M36-标运质赢","basicDevices":null,"orderNo":"ASSJ20080008","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲豪瀚N：玛瑙红,;豪瀚 N5；牵引车；豪瀚H78B驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；MC07.24-50发动机；8JS95TE-C变速箱；H653自调臂前轴(鼓)；MCJ09BG自调臂单后桥(鼓)；速比4.63；单层车架(7/250)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；295/80R22.5；50#JOST鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"6dd7b279-2f7c-4dd2-8c58-0b2f3e61853d","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"ASSJ20080008/0010-0003","carFarmeNo":"LJ177035","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185H3613E1/J7V7M36-标运质赢","basicDevices":null,"orderNo":"ASSJ20080008","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲豪瀚N：玛瑙红,;豪瀚 N5；牵引车；豪瀚H78B驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；MC07.24-50发动机；8JS95TE-C变速箱；H653自调臂前轴(鼓)；MCJ09BG自调臂单后桥(鼓)；速比4.63；单层车架(7/250)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；295/80R22.5；50#JOST鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"a77831d3-7cc4-4ba4-a81d-4aecc117de6f","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"ASSJ20080008/0010-0004","carFarmeNo":"LJ177036","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185H3613E1/J7V7M36-标运质赢","basicDevices":null,"orderNo":"ASSJ20080008","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲豪瀚N：玛瑙红,;豪瀚 N5；牵引车；豪瀚H78B驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；MC07.24-50发动机；8JS95TE-C变速箱；H653自调臂前轴(鼓)；MCJ09BG自调臂单后桥(鼓)；速比4.63；单层车架(7/250)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；295/80R22.5；50#JOST鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"91481cda-81d5-44da-b5ba-ae0ff128ea2c","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"ASSJ20080008/0010-0005","carFarmeNo":"LJ177037","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185H3613E1/J7V7M36-标运质赢","basicDevices":null,"orderNo":"ASSJ20080008","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲豪瀚N：玛瑙红,;豪瀚 N5；牵引车；豪瀚H78B驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；MC07.24-50发动机；8JS95TE-C变速箱；H653自调臂前轴(鼓)；MCJ09BG自调臂单后桥(鼓)；速比4.63；单层车架(7/250)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；295/80R22.5；50#JOST鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"921f8c53-102e-465a-83fb-1796115f3aaa","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"ASSJ20080008/0010-0006","carFarmeNo":"LJ177038","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185H3613E1/J7V7M36-标运质赢","basicDevices":null,"orderNo":"ASSJ20080008","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲豪瀚N：玛瑙红,;豪瀚 N5；牵引车；豪瀚H78B驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；MC07.24-50发动机；8JS95TE-C变速箱；H653自调臂前轴(鼓)；MCJ09BG自调臂单后桥(鼓)；速比4.63；单层车架(7/250)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；295/80R22.5；50#JOST鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"a9140916-9398-4cc4-9109-74041d819f5f","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"ASSJ20080008/0010-0007","carFarmeNo":"LJ177039","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185H3613E1/J7V7M36-标运质赢","basicDevices":null,"orderNo":"ASSJ20080008","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲豪瀚N：玛瑙红,;豪瀚 N5；牵引车；豪瀚H78B驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；MC07.24-50发动机；8JS95TE-C变速箱；H653自调臂前轴(鼓)；MCJ09BG自调臂单后桥(鼓)；速比4.63；单层车架(7/250)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；295/80R22.5；50#JOST鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"a26d8006-1bde-4a71-b433-155dc5ce827d","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"ASSJ20080008/0010-0008","carFarmeNo":"LJ177040","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185H3613E1/J7V7M36-标运质赢","basicDevices":null,"orderNo":"ASSJ20080008","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲豪瀚N：玛瑙红,;豪瀚 N5；牵引车；豪瀚H78B驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；MC07.24-50发动机；8JS95TE-C变速箱；H653自调臂前轴(鼓)；MCJ09BG自调臂单后桥(鼓)；速比4.63；单层车架(7/250)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；295/80R22.5；50#JOST鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"08548963-0663-4db2-80ec-2bff7077d5e2","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"ASSJ20080008/0010-0009","carFarmeNo":"LJ177041","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185H3613E1/J7V7M36-标运质赢","basicDevices":null,"orderNo":"ASSJ20080008","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲豪瀚N：玛瑙红,;豪瀚 N5；牵引车；豪瀚H78B驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；MC07.24-50发动机；8JS95TE-C变速箱；H653自调臂前轴(鼓)；MCJ09BG自调臂单后桥(鼓)；速比4.63；单层车架(7/250)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；295/80R22.5；50#JOST鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"41d58274-9267-4b54-a27e-61175fe3cd43","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"ASSJ20080008/0010-0010","carFarmeNo":"LJ177042","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185H3613E1/J7V7M36-标运质赢","basicDevices":null,"orderNo":"ASSJ20080008","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲豪瀚N：玛瑙红,;豪瀚 N5；牵引车；豪瀚H78B驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；MC07.24-50发动机；8JS95TE-C变速箱；H653自调臂前轴(鼓)；MCJ09BG自调臂单后桥(鼓)；速比4.63；单层车架(7/250)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；295/80R22.5；50#JOST鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"2a7cee20-082f-4705-92ad-2527c545dd2d","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"ASSJ20080006/0010-0001","carFarmeNo":"LJ177043","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185H3613E1/J7V7M36-标运质赢","basicDevices":null,"orderNo":"ASSJ20080006","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲豪瀚N：新曼白,;豪瀚 N5；牵引车；豪瀚H78B驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；MC07.24-50发动机；8JS95TE-C变速箱；H653自调臂前轴(鼓)；MCJ09BG自调臂单后桥(鼓)；速比4.63；单层车架(7/250)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；295/80R22.5；50#JOST鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"ea8a618b-7bd0-4000-8b4c-3253e8c626ce","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"ASSJ20080006/0010-0002","carFarmeNo":"LJ177044","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185H3613E1/J7V7M36-标运质赢","basicDevices":null,"orderNo":"ASSJ20080006","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲豪瀚N：新曼白,;豪瀚 N5；牵引车；豪瀚H78B驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；MC07.24-50发动机；8JS95TE-C变速箱；H653自调臂前轴(鼓)；MCJ09BG自调臂单后桥(鼓)；速比4.63；单层车架(7/250)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；295/80R22.5；50#JOST鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"3f5cf6d3-c59f-47f3-8064-58782d7badf6","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"ASSJ20080006/0010-0003","carFarmeNo":"LJ177045","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185H3613E1/J7V7M36-标运质赢","basicDevices":null,"orderNo":"ASSJ20080006","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲豪瀚N：新曼白,;豪瀚 N5；牵引车；豪瀚H78B驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；MC07.24-50发动机；8JS95TE-C变速箱；H653自调臂前轴(鼓)；MCJ09BG自调臂单后桥(鼓)；速比4.63；单层车架(7/250)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；295/80R22.5；50#JOST鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"ca44e604-ecdd-4663-9e6c-5c1ed575d8d1","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"ASSJ20080006/0010-0004","carFarmeNo":"LJ177046","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185H3613E1/J7V7M36-标运质赢","basicDevices":null,"orderNo":"ASSJ20080006","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲豪瀚N：新曼白,;豪瀚 N5；牵引车；豪瀚H78B驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；MC07.24-50发动机；8JS95TE-C变速箱；H653自调臂前轴(鼓)；MCJ09BG自调臂单后桥(鼓)；速比4.63；单层车架(7/250)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；295/80R22.5；50#JOST鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"e161344a-a58a-405f-bc5d-123f962ccb18","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"ASSJ20080006/0010-0005","carFarmeNo":"LJ177047","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185H3613E1/J7V7M36-标运质赢","basicDevices":null,"orderNo":"ASSJ20080006","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲豪瀚N：新曼白,;豪瀚 N5；牵引车；豪瀚H78B驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；MC07.24-50发动机；8JS95TE-C变速箱；H653自调臂前轴(鼓)；MCJ09BG自调臂单后桥(鼓)；速比4.63；单层车架(7/250)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；295/80R22.5；50#JOST鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"5b02feb4-b37e-458b-8301-673c70bee718","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"ASSJ20080006/0010-0006","carFarmeNo":"LJ177048","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185H3613E1/J7V7M36-标运质赢","basicDevices":null,"orderNo":"ASSJ20080006","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲豪瀚N：新曼白,;豪瀚 N5；牵引车；豪瀚H78B驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；MC07.24-50发动机；8JS95TE-C变速箱；H653自调臂前轴(鼓)；MCJ09BG自调臂单后桥(鼓)；速比4.63；单层车架(7/250)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；295/80R22.5；50#JOST鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"293d6029-3e36-4016-9a94-1da4baf8e2c8","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"ASSJ20080006/0010-0007","carFarmeNo":"LJ177049","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185H3613E1/J7V7M36-标运质赢","basicDevices":null,"orderNo":"ASSJ20080006","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲豪瀚N：新曼白,;豪瀚 N5；牵引车；豪瀚H78B驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；MC07.24-50发动机；8JS95TE-C变速箱；H653自调臂前轴(鼓)；MCJ09BG自调臂单后桥(鼓)；速比4.63；单层车架(7/250)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；295/80R22.5；50#JOST鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"cdfb6903-8c23-443f-a3f0-d0d1c3d5a233","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"ASSJ20080006/0010-0008","carFarmeNo":"LJ177050","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185H3613E1/J7V7M36-标运质赢","basicDevices":null,"orderNo":"ASSJ20080006","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲豪瀚N：新曼白,;豪瀚 N5；牵引车；豪瀚H78B驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；MC07.24-50发动机；8JS95TE-C变速箱；H653自调臂前轴(鼓)；MCJ09BG自调臂单后桥(鼓)；速比4.63；单层车架(7/250)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；295/80R22.5；50#JOST鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"562e1b2e-383e-4402-a943-6026c59661bf","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"ASSJ20080006/0010-0009","carFarmeNo":"LJ177051","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185H3613E1/J7V7M36-标运质赢","basicDevices":null,"orderNo":"ASSJ20080006","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲豪瀚N：新曼白,;豪瀚 N5；牵引车；豪瀚H78B驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；MC07.24-50发动机；8JS95TE-C变速箱；H653自调臂前轴(鼓)；MCJ09BG自调臂单后桥(鼓)；速比4.63；单层车架(7/250)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；295/80R22.5；50#JOST鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"cd45ea9e-39cf-4b48-91b2-4056223603bf","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"ASSJ20080006/0010-0010","carFarmeNo":"LJ177052","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185H3613E1/J7V7M36-标运质赢","basicDevices":null,"orderNo":"ASSJ20080006","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲豪瀚N：新曼白,;豪瀚 N5；牵引车；豪瀚H78B驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；MC07.24-50发动机；8JS95TE-C变速箱；H653自调臂前轴(鼓)；MCJ09BG自调臂单后桥(鼓)；速比4.63；单层车架(7/250)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；295/80R22.5；50#JOST鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"b3f2ddc2-c4fb-4dc3-95da-0df86ec2ef01","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"ASHJ20080023/0001-0001","carFarmeNo":"LJ177053","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185N3613E1/N7V7M36-标运","basicDevices":null,"orderNo":"ASHJ20080023","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲加急订单,豪瀚N：玛瑙红,双星轮胎；;豪瀚 N5；牵引车；豪瀚H78L驾驶室 轻奢版；导流罩和侧导风板；多功能方向盘；电动电加热后视镜；主气囊+副简易型座椅；220V-1000W逆变电源；MC07.34-50(A)发动机；HW15710L变速箱；H653K自调臂前轴(鼓)；MCY12JGK自调臂单后桥(鼓)；速比3.7；单层车架(8/280)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；12R22.5；50#JOST鞍座；整体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通B版；钢制储气筒；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"151673d0-8b05-479b-bf17-f9ccbc647851","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"JJNJ20080053/0001-0001","carFarmeNo":"LJ177054","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185N3613E1/N7V7M36-标运","basicDevices":null,"orderNo":"JJNJ20080053","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲豪瀚N：白金灰,;豪瀚 N5；牵引车；豪瀚H78L驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；220V-1000W逆变电源；MC07.34-50(A)发动机；HW15710CL变速箱；H653K自调臂前轴(鼓)；MCY12JGK自调臂单后桥(鼓)；速比3.7；单层车架(8/280)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；12R22.5；90#金刚鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；钢制储气筒；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"070772de-64d5-44d9-a475-2f6deaa90b6d","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"JTYJ20080010/0010-0001","carFarmeNo":"LJ177055","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4255V3846F1L/U9VDM38-标运","basicDevices":null,"orderNo":"JTYJ20080010","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"豪瀚N：玛瑙红,;豪瀚 N7；牵引车；豪瀚H78L驾驶室 轻奢版；多功能方向盘；电动电加热后视镜；主气囊+副简易型座椅；220V-1000W逆变电源；MT13.44-60发动机；HW25712XSTL变速箱；H653K自调臂前轴(鼓)；MCY12BGS自调臂双后桥(鼓)；速比3.08；单层车架(8/280)；前后少片簧(2/3)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；ABS(4S/4M)；低位保险杠(非金属)；前铝合金车轮(国产)+后轻量化车轮；12R22.5；90#金刚鞍座；手电一体电动举升；分体式挡泥板；后置1000L气瓶；LDWS+FCWS(带雷达)；中国重汽智能通B版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"9246a743-763f-46e3-a1fb-6a9dddee254c","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"JTYJ20080010/0010-0002","carFarmeNo":"LJ177056","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4255V3846F1L/U9VDM38-标运","basicDevices":null,"orderNo":"JTYJ20080010","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"豪瀚N：玛瑙红,;豪瀚 N7；牵引车；豪瀚H78L驾驶室 轻奢版；多功能方向盘；电动电加热后视镜；主气囊+副简易型座椅；220V-1000W逆变电源；MT13.44-60发动机；HW25712XSTL变速箱；H653K自调臂前轴(鼓)；MCY12BGS自调臂双后桥(鼓)；速比3.08；单层车架(8/280)；前后少片簧(2/3)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；ABS(4S/4M)；低位保险杠(非金属)；前铝合金车轮(国产)+后轻量化车轮；12R22.5；90#金刚鞍座；手电一体电动举升；分体式挡泥板；后置1000L气瓶；LDWS+FCWS(带雷达)；中国重汽智能通B版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false}],"firstResult":0,"maxResults":30}
     * status : 0
     */


    /**
     * pageNo : 1
     * pageSize : 30
     * count : 211
     * list : [{"id":"73524392-f0ed-42ba-b02b-8a99fdeda5c7","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"ASSJ20080005/0010-0004","carFarmeNo":"LJ177026","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185H3613E1/J7V7M36-标运质赢","basicDevices":null,"orderNo":"ASSJ20080005","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲豪瀚N：玛瑙红,;豪瀚 N5；牵引车；豪瀚H78B驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；MC07.24-50发动机；8JS95TE-C变速箱；H653自调臂前轴(鼓)；MCJ09BG自调臂单后桥(鼓)；速比4.63；单层车架(7/250)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；295/80R22.5；50#JOST鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"69c2c291-a30d-4ac9-bb80-49276beace2b","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"ASSJ20080005/0010-0005","carFarmeNo":"LJ177027","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185H3613E1/J7V7M36-标运质赢","basicDevices":null,"orderNo":"ASSJ20080005","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲豪瀚N：玛瑙红,;豪瀚 N5；牵引车；豪瀚H78B驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；MC07.24-50发动机；8JS95TE-C变速箱；H653自调臂前轴(鼓)；MCJ09BG自调臂单后桥(鼓)；速比4.63；单层车架(7/250)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；295/80R22.5；50#JOST鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"9b989e34-abf7-4dcb-8d32-c5dde96f3733","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"ASSJ20080005/0010-0006","carFarmeNo":"LJ177028","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185H3613E1/J7V7M36-标运质赢","basicDevices":null,"orderNo":"ASSJ20080005","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲豪瀚N：玛瑙红,;豪瀚 N5；牵引车；豪瀚H78B驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；MC07.24-50发动机；8JS95TE-C变速箱；H653自调臂前轴(鼓)；MCJ09BG自调臂单后桥(鼓)；速比4.63；单层车架(7/250)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；295/80R22.5；50#JOST鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"bb89c0db-73ad-4b94-8fbe-da7661c74ed8","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"ASSJ20080005/0010-0008","carFarmeNo":"LJ177030","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185H3613E1/J7V7M36-标运质赢","basicDevices":null,"orderNo":"ASSJ20080005","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲豪瀚N：玛瑙红,;豪瀚 N5；牵引车；豪瀚H78B驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；MC07.24-50发动机；8JS95TE-C变速箱；H653自调臂前轴(鼓)；MCJ09BG自调臂单后桥(鼓)；速比4.63；单层车架(7/250)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；295/80R22.5；50#JOST鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"8a90d468-e2e2-4435-b30d-30c68a718ed2","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"ASSJ20080005/0010-0009","carFarmeNo":"LJ177031","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185H3613E1/J7V7M36-标运质赢","basicDevices":null,"orderNo":"ASSJ20080005","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲豪瀚N：玛瑙红,;豪瀚 N5；牵引车；豪瀚H78B驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；MC07.24-50发动机；8JS95TE-C变速箱；H653自调臂前轴(鼓)；MCJ09BG自调臂单后桥(鼓)；速比4.63；单层车架(7/250)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；295/80R22.5；50#JOST鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"6c13b4dd-ba9d-4891-a367-8915c4f2d3ff","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"ASSJ20080005/0010-0010","carFarmeNo":"LJ177032","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185H3613E1/J7V7M36-标运质赢","basicDevices":null,"orderNo":"ASSJ20080005","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲豪瀚N：玛瑙红,;豪瀚 N5；牵引车；豪瀚H78B驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；MC07.24-50发动机；8JS95TE-C变速箱；H653自调臂前轴(鼓)；MCJ09BG自调臂单后桥(鼓)；速比4.63；单层车架(7/250)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；295/80R22.5；50#JOST鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"f5c7d5b9-e31a-49aa-becb-47a63d8befa8","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"ASSJ20080008/0010-0001","carFarmeNo":"LJ177033","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185H3613E1/J7V7M36-标运质赢","basicDevices":null,"orderNo":"ASSJ20080008","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲豪瀚N：玛瑙红,;豪瀚 N5；牵引车；豪瀚H78B驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；MC07.24-50发动机；8JS95TE-C变速箱；H653自调臂前轴(鼓)；MCJ09BG自调臂单后桥(鼓)；速比4.63；单层车架(7/250)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；295/80R22.5；50#JOST鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"0594a265-2467-4249-b410-50852862d6c3","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"ASSJ20080008/0010-0002","carFarmeNo":"LJ177034","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185H3613E1/J7V7M36-标运质赢","basicDevices":null,"orderNo":"ASSJ20080008","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲豪瀚N：玛瑙红,;豪瀚 N5；牵引车；豪瀚H78B驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；MC07.24-50发动机；8JS95TE-C变速箱；H653自调臂前轴(鼓)；MCJ09BG自调臂单后桥(鼓)；速比4.63；单层车架(7/250)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；295/80R22.5；50#JOST鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"6dd7b279-2f7c-4dd2-8c58-0b2f3e61853d","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"ASSJ20080008/0010-0003","carFarmeNo":"LJ177035","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185H3613E1/J7V7M36-标运质赢","basicDevices":null,"orderNo":"ASSJ20080008","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲豪瀚N：玛瑙红,;豪瀚 N5；牵引车；豪瀚H78B驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；MC07.24-50发动机；8JS95TE-C变速箱；H653自调臂前轴(鼓)；MCJ09BG自调臂单后桥(鼓)；速比4.63；单层车架(7/250)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；295/80R22.5；50#JOST鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"a77831d3-7cc4-4ba4-a81d-4aecc117de6f","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"ASSJ20080008/0010-0004","carFarmeNo":"LJ177036","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185H3613E1/J7V7M36-标运质赢","basicDevices":null,"orderNo":"ASSJ20080008","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲豪瀚N：玛瑙红,;豪瀚 N5；牵引车；豪瀚H78B驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；MC07.24-50发动机；8JS95TE-C变速箱；H653自调臂前轴(鼓)；MCJ09BG自调臂单后桥(鼓)；速比4.63；单层车架(7/250)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；295/80R22.5；50#JOST鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"91481cda-81d5-44da-b5ba-ae0ff128ea2c","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"ASSJ20080008/0010-0005","carFarmeNo":"LJ177037","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185H3613E1/J7V7M36-标运质赢","basicDevices":null,"orderNo":"ASSJ20080008","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲豪瀚N：玛瑙红,;豪瀚 N5；牵引车；豪瀚H78B驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；MC07.24-50发动机；8JS95TE-C变速箱；H653自调臂前轴(鼓)；MCJ09BG自调臂单后桥(鼓)；速比4.63；单层车架(7/250)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；295/80R22.5；50#JOST鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"921f8c53-102e-465a-83fb-1796115f3aaa","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"ASSJ20080008/0010-0006","carFarmeNo":"LJ177038","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185H3613E1/J7V7M36-标运质赢","basicDevices":null,"orderNo":"ASSJ20080008","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲豪瀚N：玛瑙红,;豪瀚 N5；牵引车；豪瀚H78B驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；MC07.24-50发动机；8JS95TE-C变速箱；H653自调臂前轴(鼓)；MCJ09BG自调臂单后桥(鼓)；速比4.63；单层车架(7/250)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；295/80R22.5；50#JOST鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"a9140916-9398-4cc4-9109-74041d819f5f","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"ASSJ20080008/0010-0007","carFarmeNo":"LJ177039","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185H3613E1/J7V7M36-标运质赢","basicDevices":null,"orderNo":"ASSJ20080008","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲豪瀚N：玛瑙红,;豪瀚 N5；牵引车；豪瀚H78B驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；MC07.24-50发动机；8JS95TE-C变速箱；H653自调臂前轴(鼓)；MCJ09BG自调臂单后桥(鼓)；速比4.63；单层车架(7/250)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；295/80R22.5；50#JOST鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"a26d8006-1bde-4a71-b433-155dc5ce827d","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"ASSJ20080008/0010-0008","carFarmeNo":"LJ177040","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185H3613E1/J7V7M36-标运质赢","basicDevices":null,"orderNo":"ASSJ20080008","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲豪瀚N：玛瑙红,;豪瀚 N5；牵引车；豪瀚H78B驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；MC07.24-50发动机；8JS95TE-C变速箱；H653自调臂前轴(鼓)；MCJ09BG自调臂单后桥(鼓)；速比4.63；单层车架(7/250)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；295/80R22.5；50#JOST鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"08548963-0663-4db2-80ec-2bff7077d5e2","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"ASSJ20080008/0010-0009","carFarmeNo":"LJ177041","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185H3613E1/J7V7M36-标运质赢","basicDevices":null,"orderNo":"ASSJ20080008","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲豪瀚N：玛瑙红,;豪瀚 N5；牵引车；豪瀚H78B驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；MC07.24-50发动机；8JS95TE-C变速箱；H653自调臂前轴(鼓)；MCJ09BG自调臂单后桥(鼓)；速比4.63；单层车架(7/250)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；295/80R22.5；50#JOST鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"41d58274-9267-4b54-a27e-61175fe3cd43","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"ASSJ20080008/0010-0010","carFarmeNo":"LJ177042","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185H3613E1/J7V7M36-标运质赢","basicDevices":null,"orderNo":"ASSJ20080008","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲豪瀚N：玛瑙红,;豪瀚 N5；牵引车；豪瀚H78B驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；MC07.24-50发动机；8JS95TE-C变速箱；H653自调臂前轴(鼓)；MCJ09BG自调臂单后桥(鼓)；速比4.63；单层车架(7/250)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；295/80R22.5；50#JOST鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"2a7cee20-082f-4705-92ad-2527c545dd2d","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"ASSJ20080006/0010-0001","carFarmeNo":"LJ177043","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185H3613E1/J7V7M36-标运质赢","basicDevices":null,"orderNo":"ASSJ20080006","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲豪瀚N：新曼白,;豪瀚 N5；牵引车；豪瀚H78B驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；MC07.24-50发动机；8JS95TE-C变速箱；H653自调臂前轴(鼓)；MCJ09BG自调臂单后桥(鼓)；速比4.63；单层车架(7/250)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；295/80R22.5；50#JOST鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"ea8a618b-7bd0-4000-8b4c-3253e8c626ce","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"ASSJ20080006/0010-0002","carFarmeNo":"LJ177044","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185H3613E1/J7V7M36-标运质赢","basicDevices":null,"orderNo":"ASSJ20080006","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲豪瀚N：新曼白,;豪瀚 N5；牵引车；豪瀚H78B驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；MC07.24-50发动机；8JS95TE-C变速箱；H653自调臂前轴(鼓)；MCJ09BG自调臂单后桥(鼓)；速比4.63；单层车架(7/250)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；295/80R22.5；50#JOST鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"3f5cf6d3-c59f-47f3-8064-58782d7badf6","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"ASSJ20080006/0010-0003","carFarmeNo":"LJ177045","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185H3613E1/J7V7M36-标运质赢","basicDevices":null,"orderNo":"ASSJ20080006","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲豪瀚N：新曼白,;豪瀚 N5；牵引车；豪瀚H78B驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；MC07.24-50发动机；8JS95TE-C变速箱；H653自调臂前轴(鼓)；MCJ09BG自调臂单后桥(鼓)；速比4.63；单层车架(7/250)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；295/80R22.5；50#JOST鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"ca44e604-ecdd-4663-9e6c-5c1ed575d8d1","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"ASSJ20080006/0010-0004","carFarmeNo":"LJ177046","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185H3613E1/J7V7M36-标运质赢","basicDevices":null,"orderNo":"ASSJ20080006","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲豪瀚N：新曼白,;豪瀚 N5；牵引车；豪瀚H78B驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；MC07.24-50发动机；8JS95TE-C变速箱；H653自调臂前轴(鼓)；MCJ09BG自调臂单后桥(鼓)；速比4.63；单层车架(7/250)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；295/80R22.5；50#JOST鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"e161344a-a58a-405f-bc5d-123f962ccb18","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"ASSJ20080006/0010-0005","carFarmeNo":"LJ177047","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185H3613E1/J7V7M36-标运质赢","basicDevices":null,"orderNo":"ASSJ20080006","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲豪瀚N：新曼白,;豪瀚 N5；牵引车；豪瀚H78B驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；MC07.24-50发动机；8JS95TE-C变速箱；H653自调臂前轴(鼓)；MCJ09BG自调臂单后桥(鼓)；速比4.63；单层车架(7/250)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；295/80R22.5；50#JOST鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"5b02feb4-b37e-458b-8301-673c70bee718","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"ASSJ20080006/0010-0006","carFarmeNo":"LJ177048","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185H3613E1/J7V7M36-标运质赢","basicDevices":null,"orderNo":"ASSJ20080006","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲豪瀚N：新曼白,;豪瀚 N5；牵引车；豪瀚H78B驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；MC07.24-50发动机；8JS95TE-C变速箱；H653自调臂前轴(鼓)；MCJ09BG自调臂单后桥(鼓)；速比4.63；单层车架(7/250)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；295/80R22.5；50#JOST鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"293d6029-3e36-4016-9a94-1da4baf8e2c8","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"ASSJ20080006/0010-0007","carFarmeNo":"LJ177049","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185H3613E1/J7V7M36-标运质赢","basicDevices":null,"orderNo":"ASSJ20080006","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲豪瀚N：新曼白,;豪瀚 N5；牵引车；豪瀚H78B驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；MC07.24-50发动机；8JS95TE-C变速箱；H653自调臂前轴(鼓)；MCJ09BG自调臂单后桥(鼓)；速比4.63；单层车架(7/250)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；295/80R22.5；50#JOST鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"cdfb6903-8c23-443f-a3f0-d0d1c3d5a233","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"ASSJ20080006/0010-0008","carFarmeNo":"LJ177050","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185H3613E1/J7V7M36-标运质赢","basicDevices":null,"orderNo":"ASSJ20080006","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲豪瀚N：新曼白,;豪瀚 N5；牵引车；豪瀚H78B驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；MC07.24-50发动机；8JS95TE-C变速箱；H653自调臂前轴(鼓)；MCJ09BG自调臂单后桥(鼓)；速比4.63；单层车架(7/250)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；295/80R22.5；50#JOST鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"562e1b2e-383e-4402-a943-6026c59661bf","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"ASSJ20080006/0010-0009","carFarmeNo":"LJ177051","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185H3613E1/J7V7M36-标运质赢","basicDevices":null,"orderNo":"ASSJ20080006","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲豪瀚N：新曼白,;豪瀚 N5；牵引车；豪瀚H78B驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；MC07.24-50发动机；8JS95TE-C变速箱；H653自调臂前轴(鼓)；MCJ09BG自调臂单后桥(鼓)；速比4.63；单层车架(7/250)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；295/80R22.5；50#JOST鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"cd45ea9e-39cf-4b48-91b2-4056223603bf","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"ASSJ20080006/0010-0010","carFarmeNo":"LJ177052","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185H3613E1/J7V7M36-标运质赢","basicDevices":null,"orderNo":"ASSJ20080006","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲豪瀚N：新曼白,;豪瀚 N5；牵引车；豪瀚H78B驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；MC07.24-50发动机；8JS95TE-C变速箱；H653自调臂前轴(鼓)；MCJ09BG自调臂单后桥(鼓)；速比4.63；单层车架(7/250)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；295/80R22.5；50#JOST鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"b3f2ddc2-c4fb-4dc3-95da-0df86ec2ef01","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"ASHJ20080023/0001-0001","carFarmeNo":"LJ177053","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185N3613E1/N7V7M36-标运","basicDevices":null,"orderNo":"ASHJ20080023","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲加急订单,豪瀚N：玛瑙红,双星轮胎；;豪瀚 N5；牵引车；豪瀚H78L驾驶室 轻奢版；导流罩和侧导风板；多功能方向盘；电动电加热后视镜；主气囊+副简易型座椅；220V-1000W逆变电源；MC07.34-50(A)发动机；HW15710L变速箱；H653K自调臂前轴(鼓)；MCY12JGK自调臂单后桥(鼓)；速比3.7；单层车架(8/280)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；12R22.5；50#JOST鞍座；整体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通B版；钢制储气筒；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"151673d0-8b05-479b-bf17-f9ccbc647851","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"JJNJ20080053/0001-0001","carFarmeNo":"LJ177054","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185N3613E1/N7V7M36-标运","basicDevices":null,"orderNo":"JJNJ20080053","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲豪瀚N：白金灰,;豪瀚 N5；牵引车；豪瀚H78L驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；220V-1000W逆变电源；MC07.34-50(A)发动机；HW15710CL变速箱；H653K自调臂前轴(鼓)；MCY12JGK自调臂单后桥(鼓)；速比3.7；单层车架(8/280)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；12R22.5；90#金刚鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；钢制储气筒；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"070772de-64d5-44d9-a475-2f6deaa90b6d","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"JTYJ20080010/0010-0001","carFarmeNo":"LJ177055","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4255V3846F1L/U9VDM38-标运","basicDevices":null,"orderNo":"JTYJ20080010","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"豪瀚N：玛瑙红,;豪瀚 N7；牵引车；豪瀚H78L驾驶室 轻奢版；多功能方向盘；电动电加热后视镜；主气囊+副简易型座椅；220V-1000W逆变电源；MT13.44-60发动机；HW25712XSTL变速箱；H653K自调臂前轴(鼓)；MCY12BGS自调臂双后桥(鼓)；速比3.08；单层车架(8/280)；前后少片簧(2/3)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；ABS(4S/4M)；低位保险杠(非金属)；前铝合金车轮(国产)+后轻量化车轮；12R22.5；90#金刚鞍座；手电一体电动举升；分体式挡泥板；后置1000L气瓶；LDWS+FCWS(带雷达)；中国重汽智能通B版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false},{"id":"9246a743-763f-46e3-a1fb-6a9dddee254c","isNewRecord":false,"remarks":null,"createDate":"2020-10-15 16:00:00","updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":"JTYJ20080010/0010-0002","carFarmeNo":"LJ177056","status":null,"submitCheckStatus":null,"varnishStatus":null,"varnishOperator":null,"varnishDate":null,"location":null,"environmentalLabel":null,"isSpecialSubmitCheck":null,"isExistCloseTrouble":0,"submitCheckOperType":null,"rainResult":null,"rainCount":null,"rainPart":null,"rainBridgeType":null,"rainItem":null,"startTime":null,"endTime":null,"searchStatus":null,"qmsManufactureProductionplan":{"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4255V3846F1L/U9VDM38-标运","basicDevices":null,"orderNo":"JTYJ20080010","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"豪瀚N：玛瑙红,;豪瀚 N7；牵引车；豪瀚H78L驾驶室 轻奢版；多功能方向盘；电动电加热后视镜；主气囊+副简易型座椅；220V-1000W逆变电源；MT13.44-60发动机；HW25712XSTL变速箱；H653K自调臂前轴(鼓)；MCY12BGS自调臂双后桥(鼓)；速比3.08；单层车架(8/280)；前后少片簧(2/3)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；ABS(4S/4M)；低位保险杠(非金属)；前铝合金车轮(国产)+后轻量化车轮；12R22.5；90#金刚鞍座；手电一体电动举升；分体式挡泥板；后置1000L气瓶；LDWS+FCWS(带雷达)；中国重汽智能通B版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null},"qmsZcproject":null,"specialSubmitRemark":null,"fileName":null,"filePath":null,"configChange":false}]
     * firstResult : 0
     * maxResults : 30
     */

    /**
     * id : 73524392-f0ed-42ba-b02b-8a99fdeda5c7
     * isNewRecord : false
     * remarks : null
     * createDate : 2020-10-15 16:00:00
     * updateDate : null
     * supcodes : null
     * menuid : null
     * flowCarNo : ASSJ20080005/0010-0004
     * carFarmeNo : LJ177026
     * status : null
     * submitCheckStatus : null
     * varnishStatus : null
     * varnishOperator : null
     * varnishDate : null
     * location : null
     * environmentalLabel : null
     * isSpecialSubmitCheck : null
     * isExistCloseTrouble : 0
     * submitCheckOperType : null
     * rainResult : null
     * rainCount : null
     * rainPart : null
     * rainBridgeType : null
     * rainItem : null
     * startTime : null
     * endTime : null
     * searchStatus : null
     * qmsManufactureProductionplan : {"id":null,"isNewRecord":true,"remarks":null,"createDate":null,"updateDate":null,"supcodes":null,"menuid":null,"flowCarNo":null,"carFrameNo":null,"productionDate":null,"productionDateStringIn":null,"productionDateStringOut":null,"carModelNo":"ZZ4185H3613E1/J7V7M36-标运质赢","basicDevices":null,"orderNo":"ASSJ20080005","planOnlineDate":"2020-10-09 16:00:00","planOnlineDateStringIn":null,"planOnlineDateStringOut":null,"configDesc":"▲豪瀚N：玛瑙红,;豪瀚 N5；牵引车；豪瀚H78B驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；MC07.24-50发动机；8JS95TE-C变速箱；H653自调臂前轴(鼓)；MCJ09BG自调臂单后桥(鼓)；速比4.63；单层车架(7/250)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；295/80R22.5；50#JOST鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；。,送车","status":null,"beginPlanOnlineDate":null,"endPlanOnlineDate":null,"workShop":null,"productModel":null,"productOrder":null,"operType":null}
     * qmsZcproject : null
     * specialSubmitRemark : null
     * fileName : null
     * filePath : null
     * configChange : false
     */

    private String id;
    private Boolean isNewRecord;
    private String remarks;
    private String createDate;
    private String updateDate;
    private String supcodes;
    private String menuid;
    private String flowCarNo;
    private String carFarmeNo;
    private String status;
    private String submitCheckStatus;
    private String varnishStatus;
    private String varnishOperator;
    private Long varnishDate;
    private String location;
    private String environmentalLabel;
    private String isSpecialSubmitCheck;
    private Integer isExistCloseTrouble;
    private String submitCheckOperType;
    private String rainResult;
    private String rainCount;
    private String rainPart;
    private String rainBridgeType;
    private String rainItem;
    private String startTime;
    private String endTime;
    private String searchStatus;
    private QmsManufactureProductionplanBean qmsManufactureProductionplan;
    private String qmsZcproject;
    private String specialSubmitRemark;
    private String fileName;
    private String filePath;
    private Boolean configChange;

    protected RainListBean(Parcel in) {
        id = in.readString();
        byte tmpIsNewRecord = in.readByte();
        isNewRecord = tmpIsNewRecord == 0 ? null : tmpIsNewRecord == 1;
        remarks = in.readString();
        createDate = in.readString();
        updateDate = in.readString();
        supcodes = in.readString();
        menuid = in.readString();
        flowCarNo = in.readString();
        carFarmeNo = in.readString();
        status = in.readString();
        submitCheckStatus = in.readString();
        varnishStatus = in.readString();
        varnishOperator = in.readString();
        varnishDate = in.readLong();
        location = in.readString();
        environmentalLabel = in.readString();
        isSpecialSubmitCheck = in.readString();
        if (in.readByte() == 0) {
            isExistCloseTrouble = null;
        } else {
            isExistCloseTrouble = in.readInt();
        }
        submitCheckOperType = in.readString();
        rainResult = in.readString();
        rainCount = in.readString();
        rainPart = in.readString();
        rainBridgeType = in.readString();
        rainItem = in.readString();
        startTime = in.readString();
        endTime = in.readString();
        searchStatus = in.readString();
       try{
           qmsManufactureProductionplan = in.readParcelable(QmsManufactureProductionplanBean.class.getClassLoader());
       }catch (Exception e){
           qmsManufactureProductionplan = null;
           e.printStackTrace();
       }
        qmsZcproject = in.readString();
        specialSubmitRemark = in.readString();
        fileName = in.readString();
        filePath = in.readString();
        byte tmpConfigChange = in.readByte();
        configChange = tmpConfigChange == 0 ? null : tmpConfigChange == 1;
    }

    public static final Creator<RainListBean> CREATOR = new Creator<RainListBean>() {
        @Override
        public RainListBean createFromParcel(Parcel in) {
            return new RainListBean(in);
        }

        @Override
        public RainListBean[] newArray(int size) {
            return new RainListBean[size];
        }
    };

    public void setId(String id) {
        this.id = id;
    }

    public void setNewRecord(Boolean newRecord) {
        isNewRecord = newRecord;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public void setCreateDate(String createDate) {
        this.createDate = createDate;
    }

    public void setUpdateDate(String updateDate) {
        this.updateDate = updateDate;
    }

    public void setSupcodes(String supcodes) {
        this.supcodes = supcodes;
    }

    public void setMenuid(String menuid) {
        this.menuid = menuid;
    }

    public void setFlowCarNo(String flowCarNo) {
        this.flowCarNo = flowCarNo;
    }

    public void setCarFarmeNo(String carFarmeNo) {
        this.carFarmeNo = carFarmeNo;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public void setSubmitCheckStatus(String submitCheckStatus) {
        this.submitCheckStatus = submitCheckStatus;
    }

    public void setVarnishStatus(String varnishStatus) {
        this.varnishStatus = varnishStatus;
    }

    public void setVarnishOperator(String varnishOperator) {
        this.varnishOperator = varnishOperator;
    }

    public void setVarnishDate(Long varnishDate) {
        this.varnishDate = varnishDate;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public void setEnvironmentalLabel(String environmentalLabel) {
        this.environmentalLabel = environmentalLabel;
    }

    public void setIsSpecialSubmitCheck(String isSpecialSubmitCheck) {
        this.isSpecialSubmitCheck = isSpecialSubmitCheck;
    }

    public void setIsExistCloseTrouble(Integer isExistCloseTrouble) {
        this.isExistCloseTrouble = isExistCloseTrouble;
    }

    public void setSubmitCheckOperType(String submitCheckOperType) {
        this.submitCheckOperType = submitCheckOperType;
    }

    public void setRainResult(String rainResult) {
        this.rainResult = rainResult;
    }

    public void setRainCount(String rainCount) {
        this.rainCount = rainCount;
    }

    public void setRainPart(String rainPart) {
        this.rainPart = rainPart;
    }

    public void setRainBridgeType(String rainBridgeType) {
        this.rainBridgeType = rainBridgeType;
    }

    public void setRainItem(String rainItem) {
        this.rainItem = rainItem;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    public void setSearchStatus(String searchStatus) {
        this.searchStatus = searchStatus;
    }

    public void setQmsManufactureProductionplan(QmsManufactureProductionplanBean qmsManufactureProductionplan) {
        this.qmsManufactureProductionplan = qmsManufactureProductionplan;
    }

    public void setQmsZcproject(String qmsZcproject) {
        this.qmsZcproject = qmsZcproject;
    }

    public void setSpecialSubmitRemark(String specialSubmitRemark) {
        this.specialSubmitRemark = specialSubmitRemark;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }

    public void setConfigChange(Boolean configChange) {
        this.configChange = configChange;
    }

    public String getId() {
        return id;
    }

    public Boolean getNewRecord() {
        return isNewRecord;
    }

    public String getRemarks() {
        return remarks;
    }

    public String getCreateDate() {
        return createDate;
    }

    public String getUpdateDate() {
        return updateDate;
    }

    public String getSupcodes() {
        return supcodes;
    }

    public String getMenuid() {
        return menuid;
    }

    public String getFlowCarNo() {
        return flowCarNo;
    }

    public String getCarFarmeNo() {
        return carFarmeNo;
    }

    public String getStatus() {
        return status;
    }

    public String getSubmitCheckStatus() {
        return submitCheckStatus;
    }

    public String getVarnishStatus() {
        return varnishStatus;
    }

    public String getVarnishOperator() {
        return varnishOperator;
    }

    public Long getVarnishDate() {
        return varnishDate;
    }

    public String getLocation() {
        return location;
    }

    public String getEnvironmentalLabel() {
        return environmentalLabel;
    }

    public String getIsSpecialSubmitCheck() {
        return isSpecialSubmitCheck;
    }

    public Integer getIsExistCloseTrouble() {
        return isExistCloseTrouble;
    }

    public String getSubmitCheckOperType() {
        return submitCheckOperType;
    }

    public String getRainResult() {
        return rainResult;
    }

    public String getRainCount() {
        return rainCount;
    }

    public String getRainPart() {
        return rainPart;
    }

    public String getRainBridgeType() {
        return rainBridgeType;
    }

    public String getRainItem() {
        return rainItem;
    }

    public String getStartTime() {
        return startTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public String getSearchStatus() {
        return searchStatus;
    }

    public QmsManufactureProductionplanBean getQmsManufactureProductionplan() {
        return qmsManufactureProductionplan;
    }

    public String getQmsZcproject() {
        return qmsZcproject;
    }

    public String getSpecialSubmitRemark() {
        return specialSubmitRemark;
    }

    public String getFileName() {
        return fileName;
    }

    public String getFilePath() {
        return filePath;
    }

    public Boolean getConfigChange() {
        return configChange;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {

        dest.writeString(id);
        dest.writeByte((byte) (isNewRecord == null ? 0 : isNewRecord ? 1 : 2));
        dest.writeString(remarks);
        dest.writeString(createDate);
        dest.writeString(updateDate);
        dest.writeString(supcodes);
        dest.writeString(menuid);
        dest.writeString(flowCarNo);
        dest.writeString(carFarmeNo);
        dest.writeString(status);
        dest.writeString(submitCheckStatus);
        dest.writeString(varnishStatus);
        dest.writeString(varnishOperator);
        try{
            dest.writeLong(varnishDate);
        }catch (NullPointerException e){
            e.printStackTrace();
        }
        dest.writeString(location);
        dest.writeString(environmentalLabel);
        dest.writeString(isSpecialSubmitCheck);
        if (isExistCloseTrouble == null) {
            dest.writeByte((byte) 0);
        } else {
            dest.writeByte((byte) 1);
            dest.writeInt(isExistCloseTrouble);
        }
        dest.writeString(submitCheckOperType);
        dest.writeString(rainResult);
        dest.writeString(rainCount);
        dest.writeString(rainPart);
        dest.writeString(rainBridgeType);
        dest.writeString(rainItem);
        dest.writeString(startTime);
        dest.writeString(endTime);
        dest.writeString(searchStatus);
        dest.writeParcelable(qmsManufactureProductionplan, flags);
        dest.writeString(qmsZcproject);
        dest.writeString(specialSubmitRemark);
        dest.writeString(fileName);
        dest.writeString(filePath);
        dest.writeByte((byte) (configChange == null ? 0 : configChange ? 1 : 2));
    }


    public static class QmsManufactureProductionplanBean implements Parcelable {
        /**
         * id : null
         * isNewRecord : true
         * remarks : null
         * createDate : null
         * updateDate : null
         * supcodes : null
         * menuid : null
         * flowCarNo : null
         * carFrameNo : null
         * productionDate : null
         * productionDateStringIn : null
         * productionDateStringOut : null
         * carModelNo : ZZ4185H3613E1/J7V7M36-标运质赢
         * basicDevices : null
         * orderNo : ASSJ20080005
         * planOnlineDate : 2020-10-09 16:00:00
         * planOnlineDateStringIn : null
         * planOnlineDateStringOut : null
         * configDesc : ▲豪瀚N：玛瑙红,;豪瀚 N5；牵引车；豪瀚H78B驾驶室 轻奢版；手动后视镜；主气囊+副简易型座椅；MC07.24-50发动机；8JS95TE-C变速箱；H653自调臂前轴(鼓)；MCJ09BG自调臂单后桥(鼓)；速比4.63；单层车架(7/250)；前后少片簧(2/4)；国产方向机；公路版进气系统；限速89km/h；标准版排气系统；长效燃油粗滤器；ABS(4S/4M)；低位保险杠(非金属)；普通车轮；295/80R22.5；50#JOST鞍座；分体式挡泥板；600L油箱；LDWS+FCWS(带雷达)；中国重汽智能通D版；。,送车
         * status : null
         * beginPlanOnlineDate : null
         * endPlanOnlineDate : null
         * workShop : null
         * productModel : null
         * productOrder : null
         * operType : null
         */

        private String id;
        private Boolean isNewRecord;
        private String remarks;
        private String createDate;
        private String updateDate;
        private String supcodes;
        private String menuid;
        private String flowCarNo;
        private String carFrameNo;
        private String productionDate;
        private String productionDateStringIn;
        private String productionDateStringOut;
        private String carModelNo;
        private String basicDevices;
        private String orderNo;
        private String planOnlineDate;
        private String planOnlineDateStringIn;
        private String planOnlineDateStringOut;
        private String configDesc;
        private String status;
        private String beginPlanOnlineDate;
        private String endPlanOnlineDate;
        private String workShop;
        private String productModel;
        private String productOrder;
        private String operType;


        protected QmsManufactureProductionplanBean(Parcel in) {
            id = in.readString();
            byte tmpIsNewRecord = in.readByte();
            isNewRecord = tmpIsNewRecord == 0 ? null : tmpIsNewRecord == 1;
            remarks = in.readString();
            createDate = in.readString();
            updateDate = in.readString();
            supcodes = in.readString();
            menuid = in.readString();
            flowCarNo = in.readString();
            carFrameNo = in.readString();
            productionDate = in.readString();
            productionDateStringIn = in.readString();
            productionDateStringOut = in.readString();
            carModelNo = in.readString();
            basicDevices = in.readString();
            orderNo = in.readString();
            planOnlineDate = in.readString();
            planOnlineDateStringIn = in.readString();
            planOnlineDateStringOut = in.readString();
            configDesc = in.readString();
            status = in.readString();
            beginPlanOnlineDate = in.readString();
            endPlanOnlineDate = in.readString();
            workShop = in.readString();
            productModel = in.readString();
            productOrder = in.readString();
            operType = in.readString();
        }

        @Override
        public void writeToParcel(Parcel dest, int flags) {
            dest.writeString(id);
            dest.writeByte((byte) (isNewRecord == null ? 0 : isNewRecord ? 1 : 2));
            dest.writeString(remarks);
            dest.writeString(createDate);
            dest.writeString(updateDate);
            dest.writeString(supcodes);
            dest.writeString(menuid);
            dest.writeString(flowCarNo);
            dest.writeString(carFrameNo);
            dest.writeString(productionDate);
            dest.writeString(productionDateStringIn);
            dest.writeString(productionDateStringOut);
            dest.writeString(carModelNo);
            dest.writeString(basicDevices);
            dest.writeString(orderNo);
            dest.writeString(planOnlineDate);
            dest.writeString(planOnlineDateStringIn);
            dest.writeString(planOnlineDateStringOut);
            dest.writeString(configDesc);
            dest.writeString(status);
            dest.writeString(beginPlanOnlineDate);
            dest.writeString(endPlanOnlineDate);
            dest.writeString(workShop);
            dest.writeString(productModel);
            dest.writeString(productOrder);
            dest.writeString(operType);
        }

        public static final Creator<QmsManufactureProductionplanBean> CREATOR = new Creator<QmsManufactureProductionplanBean>() {
            @Override
            public QmsManufactureProductionplanBean createFromParcel(Parcel in) {
                return new QmsManufactureProductionplanBean(in);
            }

            @Override
            public QmsManufactureProductionplanBean[] newArray(int size) {
                return new QmsManufactureProductionplanBean[size];
            }
        };

        public void setId(String id) {
            this.id = id;
        }

        public void setNewRecord(Boolean newRecord) {
            isNewRecord = newRecord;
        }

        public void setRemarks(String remarks) {
            this.remarks = remarks;
        }

        public void setCreateDate(String createDate) {
            this.createDate = createDate;
        }

        public void setUpdateDate(String updateDate) {
            this.updateDate = updateDate;
        }

        public void setSupcodes(String supcodes) {
            this.supcodes = supcodes;
        }

        public void setMenuid(String menuid) {
            this.menuid = menuid;
        }

        public void setFlowCarNo(String flowCarNo) {
            this.flowCarNo = flowCarNo;
        }

        public void setCarFrameNo(String carFrameNo) {
            this.carFrameNo = carFrameNo;
        }

        public void setProductionDate(String productionDate) {
            this.productionDate = productionDate;
        }

        public void setProductionDateStringIn(String productionDateStringIn) {
            this.productionDateStringIn = productionDateStringIn;
        }

        public void setProductionDateStringOut(String productionDateStringOut) {
            this.productionDateStringOut = productionDateStringOut;
        }

        public void setCarModelNo(String carModelNo) {
            this.carModelNo = carModelNo;
        }

        public void setBasicDevices(String basicDevices) {
            this.basicDevices = basicDevices;
        }

        public void setOrderNo(String orderNo) {
            this.orderNo = orderNo;
        }

        public void setPlanOnlineDate(String planOnlineDate) {
            this.planOnlineDate = planOnlineDate;
        }

        public void setPlanOnlineDateStringIn(String planOnlineDateStringIn) {
            this.planOnlineDateStringIn = planOnlineDateStringIn;
        }

        public void setPlanOnlineDateStringOut(String planOnlineDateStringOut) {
            this.planOnlineDateStringOut = planOnlineDateStringOut;
        }

        public void setConfigDesc(String configDesc) {
            this.configDesc = configDesc;
        }

        public void setStatus(String status) {
            this.status = status;
        }

        public void setBeginPlanOnlineDate(String beginPlanOnlineDate) {
            this.beginPlanOnlineDate = beginPlanOnlineDate;
        }

        public void setEndPlanOnlineDate(String endPlanOnlineDate) {
            this.endPlanOnlineDate = endPlanOnlineDate;
        }

        public void setWorkShop(String workShop) {
            this.workShop = workShop;
        }

        public void setProductModel(String productModel) {
            this.productModel = productModel;
        }

        public void setProductOrder(String productOrder) {
            this.productOrder = productOrder;
        }

        public void setOperType(String operType) {
            this.operType = operType;
        }

        public String getId() {
            return id;
        }

        public Boolean getNewRecord() {
            return isNewRecord;
        }

        public String getRemarks() {
            return remarks;
        }

        public String getCreateDate() {
            return createDate;
        }

        public String getUpdateDate() {
            return updateDate;
        }

        public String getSupcodes() {
            return supcodes;
        }

        public String getMenuid() {
            return menuid;
        }

        public String getFlowCarNo() {
            return flowCarNo;
        }

        public String getCarFrameNo() {
            return carFrameNo;
        }

        public String getProductionDate() {
            return productionDate;
        }

        public String getProductionDateStringIn() {
            return productionDateStringIn;
        }

        public String getProductionDateStringOut() {
            return productionDateStringOut;
        }

        public String getCarModelNo() {
            return carModelNo;
        }

        public String getBasicDevices() {
            return basicDevices;
        }

        public String getOrderNo() {
            return orderNo;
        }

        public String getPlanOnlineDate() {
            return planOnlineDate;
        }

        public String getPlanOnlineDateStringIn() {
            return planOnlineDateStringIn;
        }

        public String getPlanOnlineDateStringOut() {
            return planOnlineDateStringOut;
        }

        public String getConfigDesc() {
            return configDesc;
        }

        public String getStatus() {
            return status;
        }

        public String getBeginPlanOnlineDate() {
            return beginPlanOnlineDate;
        }

        public String getEndPlanOnlineDate() {
            return endPlanOnlineDate;
        }

        public String getWorkShop() {
            return workShop;
        }

        public String getProductModel() {
            return productModel;
        }

        public String getProductOrder() {
            return productOrder;
        }

        public String getOperType() {
            return operType;
        }

        @Override
        public int describeContents() {
            return 0;
        }


    }


}
