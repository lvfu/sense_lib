package com.zhuisu.fastdev.beans.lack;

import java.util.List;

/**
 * @author cxh
 * @description
 * @date 2020/10/28.
 */
public class LackCommitBean {
    private String addSource;
    private String recordUser;
    private String reqData;

    public void setReqData(String reqData) {
        this.reqData = reqData;
    }

    public String getReqData() {
        return reqData;
    }

    public void setRecordUser(String recordUser) {
        this.recordUser = recordUser;
    }

    public String getRecordUser() {
        return recordUser;
    }

    private List<InnerBean> qmsManufactureMissingPartsList;

    public void setAddSource(String addSource) {
        this.addSource = addSource;
    }

    public void setQmsManufactureMissingPartsList(List<InnerBean> qmsManufactureMissingPartsList) {
        this.qmsManufactureMissingPartsList = qmsManufactureMissingPartsList;
    }

    public String getAddSource() {
        return addSource;
    }

    public List<InnerBean> getQmsManufactureMissingPartsList() {
        return qmsManufactureMissingPartsList;
    }

    public static class InnerBean {
        private String productOrder;
        private String carFrameNo;
        private String orderNo;
        private String status;
        private String quantity;
        private String bomId;
        private String bomName;
        private String productModel;
        private String addRemarks;

        private String missReason;


        public String getMissReason() {
            return missReason;
        }

        public void setMissReason(String missReason) {
            this.missReason = missReason;
        }

        public void setAddRemarks(String addRemarks) {
            this.addRemarks = addRemarks;
        }

        public String getAddRemarks() {
            return addRemarks;
        }

        public String getProductModel() {
            return productModel;
        }

        public void setProductModel(String productModel) {
            this.productModel = productModel;
        }

        public void setProductOrder(String productOrder) {
            this.productOrder = productOrder;
        }

        public void setCarFrameNo(String carFrameNo) {
            this.carFrameNo = carFrameNo;
        }

        public void setOrderNo(String orderNo) {
            this.orderNo = orderNo;
        }

        public void setStatus(String status) {
            this.status = status;
        }

        public void setQuantity(String quantity) {
            this.quantity = quantity;
        }

        public void setBomId(String bomId) {
            this.bomId = bomId;
        }

        public void setBomName(String bomName) {
            this.bomName = bomName;
        }

        public String getProductOrder() {
            return productOrder;
        }

        public String getCarFrameNo() {
            return carFrameNo;
        }

        public String getOrderNo() {
            return orderNo;
        }

        public String getStatus() {
            return status;
        }

        public String getQuantity() {
            return quantity;
        }

        public String getBomId() {
            return bomId;
        }

        public String getBomName() {
            return bomName;
        }
    }
}
