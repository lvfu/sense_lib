package com.zhuisu.fastdev.dialog;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.DialogFragment;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;

import com.zhuisu.qualityManagement.R;

import java.util.List;


/**
 * 选择弹框
 * */
public class BasePopupWindowSelectDialog extends DialogFragment {

    private View rootView;
    private TextView tvTitle;
    private Spinner sp_select;
    private OnConfirmClickListener onConfirmClickListener;
    private List<? extends Parcelable> data;
    private Context context;
    private int currentPosition = 0;


    public void setOnConfirmClickListener(OnConfirmClickListener onConfirmClickListener) {
        this.onConfirmClickListener = onConfirmClickListener;
    }

    public static final String ACTION_VALUE_TITLE = "action_value_title";
    public interface OnConfirmClickListener {
        void onConfirmClickListener(int position);
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        this.context = context;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setStyle(DialogFragment.STYLE_NO_TITLE, android.R.style.Theme_Holo_Light_Dialog_MinWidth);
    }

    @Override
    public void onStart() {
        super.onStart();
        Dialog dialog = getDialog();
        if (dialog != null) {
            DisplayMetrics dm = new DisplayMetrics();
            getActivity().getWindowManager().getDefaultDisplay().getMetrics(dm);
            dialog.getWindow().setLayout((int) (dm.widthPixels * 0.85), ViewGroup.LayoutParams.WRAP_CONTENT);
        }
    }

    public void setData(List<? extends Parcelable> data){
        this.data = data;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        rootView = super.onCreateView(inflater, container, savedInstanceState);
        getDialog().requestWindowFeature(Window.FEATURE_NO_TITLE);
        if (rootView == null) {
            rootView = inflater.inflate(R.layout.dialog_confirm_select, container, false);
        }
        tvTitle = rootView.findViewById(R.id.tv_dialog_title);
        TextView tvCancel = rootView.findViewById(R.id.tv_dialog_cancel);
        sp_select = rootView.findViewById(R.id.sp_select);
        ArrayAdapter<? extends Parcelable> adapter = new ArrayAdapter<>(context,R.layout.simple_textview1,data);
        sp_select.setAdapter(adapter);
        sp_select.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                currentPosition = position;
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        tvCancel.setOnClickListener(v -> dismiss());
        if (getArguments() != null && getArguments().getString(ACTION_VALUE_TITLE) != null){
            tvTitle.setText(getArguments().getString(ACTION_VALUE_TITLE));
        }

        TextView tvOk = rootView.findViewById(R.id.tv_confirm);
        tvOk.setOnClickListener(v -> {
            if (onConfirmClickListener != null) {
                onConfirmClickListener.onConfirmClickListener(currentPosition);
            }
        });
        return rootView;
    }

    @Override
    public void onResume() {
        super.onResume();
    }
}
