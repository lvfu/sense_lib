package com.zhuisu.fastdev.dialog;

import android.app.Dialog;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.DialogFragment;
import android.text.method.ScrollingMovementMethod;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.ImageView;
import android.widget.TextView;

import com.zhuisu.qualityManagement.R;


public class BasePopupWindowDialog extends DialogFragment {

    private OnConfirmClickListener onConfirmClickListener;
    private boolean isShowImage = true;

    public void setShowImage(boolean showImage) {
        isShowImage = showImage;
    }

    public boolean isShowImage() {
        return isShowImage;
    }

    public void setOnConfirmClickListener(OnConfirmClickListener onConfirmClickListener) {
        this.onConfirmClickListener = onConfirmClickListener;
    }

    public static final String ACTION_VALUE_TITLE = "action_value_title";
    public static final String ACTION_VALUE_MESSAGE = "action_value_message";
    public static final String ACTION_SHOW_IMAGE = "action_show_image";

    public interface OnConfirmClickListener {
        void onOkClickListener();
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setStyle(DialogFragment.STYLE_NO_TITLE, android.R.style.Theme_Holo_Light_Dialog_MinWidth);
    }

    @Override
    public void onStart() {
        super.onStart();
        Dialog dialog = getDialog();
        if (dialog != null) {
            DisplayMetrics dm = new DisplayMetrics();
            getActivity().getWindowManager().getDefaultDisplay().getMetrics(dm);
            dialog.getWindow().setLayout((int) (dm.widthPixels * 0.85), ViewGroup.LayoutParams.WRAP_CONTENT);
        }
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View rootView = super.onCreateView(inflater, container, savedInstanceState);
        getDialog().requestWindowFeature(Window.FEATURE_NO_TITLE);
        if (rootView == null) {
            rootView = inflater.inflate(R.layout.dialog_confirm, container, false);
        }
        TextView tvTitle = rootView.findViewById(R.id.tv_dialog_title);
        TextView tvMessage = rootView.findViewById(R.id.tv_message);
        ImageView ivImage = rootView.findViewById(R.id.iv_image);

        if (getArguments() != null && getArguments().getString(ACTION_SHOW_IMAGE) != null){
            ivImage.setVisibility(View.GONE);
        }

        tvMessage.setMovementMethod(ScrollingMovementMethod.getInstance());
        TextView tvCancel = rootView.findViewById(R.id.tv_dialog_cancel);
        tvCancel.setOnClickListener(v -> dismiss());
        if (getArguments() != null && getArguments().getString(ACTION_VALUE_TITLE) != null){
            tvTitle.setText(getArguments().getString(ACTION_VALUE_TITLE));
        }

        if (getArguments() != null && getArguments().getString(ACTION_VALUE_MESSAGE) != null){
            tvMessage.setText(getArguments().getString(ACTION_VALUE_MESSAGE));
        }

        TextView tvOk = rootView.findViewById(R.id.tv_confirm);
        tvOk.setOnClickListener(v -> {
            if (onConfirmClickListener != null) {
                onConfirmClickListener.onOkClickListener();
            }
        });
        return rootView;
    }

    @Override
    public void onResume() {
        super.onResume();
    }

//    @Override
//    public void onStart() {
//        super.onStart();
//        Dialog dialog = getDialog();
//        if (dialog != null )
//        {
//            //如果宽高都为MATCH_PARENT,内容外的背景色就会失效，所以只设置宽全屏
//            int width = ViewGroup.LayoutParams.MATCH_PARENT;
//            int height = ViewGroup.LayoutParams.WRAP_CONTENT;
//            dialog.getWindow().setLayout(width, height);//全屏
//            dialog.getWindow().setGravity(Gravity.CENTER);//内容设置在底部
//            //内容的背景色.系统的内容宽度是不全屏的，替换为自己的后宽度可以全屏
//            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
//        }
//    }
}
