package com.zhuisu.fastdev.dialog;


import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.Context;
import android.support.annotation.NonNull;
import android.text.TextUtils;
import android.view.View;
import android.widget.DatePicker;
import android.widget.TextView;

import com.blankj.utilcode.util.ScreenUtils;
import com.blankj.utilcode.util.ToastUtils;
import com.zhuisu.qualityManagement.R;

import java.util.Calendar;
import java.util.Date;
import java.util.Locale;


/**
 * @author xs
 * @Description: 添加跟踪流程
 * @CreateDate: 2022/3/21 9:05
 */
public class ProgressTrackAddDialog extends BGDialogBase implements View.OnClickListener {


    private Context context;
    private TextView progressTrackTimeTv;
    private TextView progressTrackDetailTv;

    public ProgressTrackAddDialog(@NonNull Context context) {
        super(context, R.style.dialogBlackBg);
        this.context = context;

        init();
    }

    private void init() {
        setContentView(R.layout.dialog_input_progress_track_layout);
        setWidth((int) (ScreenUtils.getScreenWidth() * 1));
        setHeight((int) (ScreenUtils.getScreenHeight() * 0.6));
        paddings(0);

        setCancelable(true);
        setCanceledOnTouchOutside(true);

        initView();
        initData();
    }

    private void initData() {
    }


    private void initView() {

        progressTrackTimeTv = findViewById(R.id.progress_track_time_tv);
        progressTrackDetailTv = findViewById(R.id.et_progress_track_detail_et);
        findViewById(R.id.progress_track_finish_tv).setOnClickListener(this);
        progressTrackTimeTv.setOnClickListener(new DateClickListener(progressTrackTimeTv));

    }

    //设置日期
    class DateClickListener implements View.OnClickListener {
        TextView dateTv;

        public DateClickListener(TextView dateTv) {
            this.dateTv = dateTv;
        }

        @Override
        public void onClick(View v) {
            Date mydate = new Date(); // 获取当前日期Date对象
            Calendar mycalendar = Calendar.getInstance(Locale.CHINA);
            mycalendar.setTime(mydate);// //为Calendar对象设置时间为当前日期

            int year = mycalendar.get(Calendar.YEAR); // 获取Calendar对象中的年
            int month = mycalendar.get(Calendar.MONTH);// 获取Calendar对象中的月
            int day = mycalendar.get(Calendar.DAY_OF_MONTH);// 获取这个月的第几天

            Dialog d1 = new DatePickerDialog(context, mDateSetListener, year, month, day);
            d1.show();
        }

        DatePickerDialog.OnDateSetListener mDateSetListener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker arg0, int year, int month,
                                  int day) {
                dateTv.setText(year + "-" + ((month + 1) < 10 ? ("0" + (month + 1)) : ((month + 1) + "")) + "-"
                        + (day < 10 ? ("0" + day) : (day + "")));
            }
        };
    }


    @Override
    public void onClick(View view) {

        switch (view.getId()) {

            case R.id.progress_track_finish_tv:
                String content = progressTrackDetailTv.getText().toString().trim();
                if (TextUtils.isEmpty(content)) {
                    ToastUtils.showShort("请添加进度跟踪内容");
                    return;
                }

                if (progressTrackFinishListener != null) {
                    dismiss();
                    progressTrackFinishListener.onProgressTrackFinishListener(content);
                }


                break;

            case R.id.progress_track_time_tv:

                break;


            default:
                break;
        }
    }


    /**
     * 回调
     */
    private ProgressTrackFinishListener progressTrackFinishListener;

    public void setProgressTrackFinishListener(ProgressTrackFinishListener progressTrackFinishListener) {
        this.progressTrackFinishListener = progressTrackFinishListener;
    }

    public interface ProgressTrackFinishListener {
        void onProgressTrackFinishListener(String content);
    }


}
