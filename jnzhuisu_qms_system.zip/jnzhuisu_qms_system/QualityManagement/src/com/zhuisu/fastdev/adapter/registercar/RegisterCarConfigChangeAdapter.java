package com.zhuisu.fastdev.adapter.registercar;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.text.method.ScrollingMovementMethod;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.zhuisu.fastdev.beans.RegisterCarConfigChangeBean;
import com.zhuisu.fastdev.view.SmartTextView;
import com.zhuisu.qualityManagement.R;

import java.util.List;

/**
 * @author cxh
 * @description
 * @date 2020/10/21.
 */
public class  RegisterCarConfigChangeAdapter extends RecyclerView.Adapter<RegisterCarConfigChangeAdapter.VH> {

    private Context context;
    private List<RegisterCarConfigChangeBean> list;


    public RegisterCarConfigChangeAdapter(Context context, List<RegisterCarConfigChangeBean> list) {
        this.context = context;
        this.list = list;
    }

    @Override
    public VH onCreateViewHolder(ViewGroup parent, int viewType) {

        View view = ((LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE))
                .inflate(R.layout.item_register_car_config_change_list,parent,false);
        return new VH(view);
    }

    @Override
    public void onBindViewHolder(VH holder, int position) {
        RegisterCarConfigChangeBean data = list.get(position);

        //set
        holder.tv_suichedanhao.setText(data.getFlowcarNo());

        holder.tv_car_number.setText(data.getNum());
        holder.tv_car_type.setText(data.getCreateDate());
        holder.tv_info.setText(data.getOrderNo());
        holder.tv_up_time.setText(data.getChangeDesc());
    }

    @Override
    public int getItemCount() {
        return list == null ? 0 : list.size();
    }

    static class VH extends RecyclerView.ViewHolder{
        TextView tv_suichedanhao;//随车单号
        SmartTextView tv_car_number;//车架号
        SmartTextView tv_car_type;//车型号
        SmartTextView tv_info;//配置
        SmartTextView tv_up_time;//上线时间
        Button btn_register_car;//接车

        public VH(View itemView) {
            super(itemView);
            tv_suichedanhao= itemView.findViewById(R.id.tv_suichedanhao);
            tv_car_number = itemView.findViewById(R.id.tv_car_number);
            tv_car_type = itemView.findViewById(R.id.tv_car_type);
            tv_info = itemView.findViewById(R.id.tv_info);
            tv_up_time = itemView.findViewById(R.id.tv_up_time);
            btn_register_car = itemView.findViewById(R.id.btn_register_car);

        }
    }
}
