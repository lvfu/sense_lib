package com.zhuisu.fastdev.adapter.lackhistoryge;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.zhuisu.fastdev.beans.ProblemCloseBean;
import com.zhuisu.fastdev.ui.problem.ProblemDetailActivity;
import com.zhuisu.fastdev.view.SmartTextView;
import com.zhuisu.qualityManagement.R;

import java.util.List;

/**
 * @author cxh
 * @description
 * @date 2020/10/30.
 */
public class QualityCheckedProblemAdapter extends RecyclerView.Adapter<QualityCheckedProblemAdapter.VH> {

    private List<ProblemCloseBean> listBeans;
    private Context context;

    public QualityCheckedProblemAdapter(List<ProblemCloseBean> listBeans, Context context) {
        this.listBeans = listBeans;
        this.context = context;
    }

    @Override
    public VH onCreateViewHolder(ViewGroup parent, int viewType) {

        View view = ((LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE))
                .inflate(R.layout.item_quality_problem_list, parent, false);
        return new VH(view);
    }

    @Override
    public void onBindViewHolder(VH holder, int position) {
        ProblemCloseBean data = listBeans.get(position);
        holder.tv_create_number.setText(data.getPeoblemTitle());
        holder.tv_remark_lack.setText(data.getProblemDesc());
        holder.group.setOnClickListener(v -> {
            Intent intent = new Intent(context, ProblemDetailActivity.class);
            intent.putExtra(ProblemDetailActivity.REQUEST_DATA, listBeans.get(position));
            intent.putExtra(ProblemDetailActivity.DORM_QUERY,true);
            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return listBeans == null ? 0 : listBeans.size();
    }

    static class VH extends RecyclerView.ViewHolder {

        SmartTextView tv_create_number;
        SmartTextView tv_remark_lack;
        LinearLayout group;

        public VH(View itemView) {
            super(itemView);
            tv_create_number = itemView.findViewById(R.id.tv_confirm_number);
            tv_remark_lack = itemView.findViewById(R.id.tv_remark_lack);
            group = itemView.findViewById(R.id.ll_bottom);
        }
    }
}
