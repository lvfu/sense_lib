package com.zhuisu.fastdev.adapter.online

import android.content.Context
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.zhuisu.fastdev.beans.online.OnLineDeHistoryBean
import com.zhuisu.fastdev.view.SmartTextView
import com.zhuisu.qualityManagement.R

/**
 * @author cxh
 * @description
 * @date 2020/11/10.
 */
class OnLineDeAdapter(list: ArrayList<OnLineDeHistoryBean>, context: Context) : RecyclerView.Adapter<OnLineDeAdapter.VH>() {

    var list: ArrayList<OnLineDeHistoryBean>? = null
    var context: Context? = null

    init {
        this.list = list
        this.context = context
    }

    override fun onCreateViewHolder(parent: ViewGroup, p1: Int): VH {
        val view: View = (context!!.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater)
                .inflate(R.layout.item_online_detail_debug, parent, false)
        return VH(view)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {

        var result = ""
        when (list!![position].status) {
            "debug" -> result = "调试"
            "troubleshooting" -> result = "故障排除"
            "troubleshootingpassed" -> result = "故障排除完成"
            "submitcheck" -> result = "送验"
            "varnish" -> result = "喷清漆"
            "submitcheckpassed" -> result = "初验完成"
            "recheck" -> result = "送复验"
        }

        result += "\t" + list!![position].operator + "   \t   " + list!![position].createDate
//        result.plus(list!![position].operator).plus("\t").plus("\t").plus(list!![position].createDate)
        holder.tvResult.text = result

    }

    override fun getItemCount(): Int {
        return list!!.size
    }

    class VH(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvResult: SmartTextView = itemView.findViewById(R.id.stv_result)
    }
}