package com.zhuisu.fastdev.adapter.printhard;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.zhuisu.fastdev.beans.printhard.PrintHardListBean;
import com.zhuisu.fastdev.view.SmartTextView;
import com.zhuisu.qualityManagement.R;

import java.util.ArrayList;
import java.util.List;

/**
 * @author cxh
 * @description
 * @date 2020/10/23.
 */
public class PrintHardAdapter extends RecyclerView.Adapter<PrintHardAdapter.VH> {
    private List<PrintHardListBean> list;
    private Context context;
    private OnPrintCommitClickListener onPrintCommitClickListener;

    public void setOnPrintCommitClickListener(OnPrintCommitClickListener onPrintCommitClickListener) {
        this.onPrintCommitClickListener = onPrintCommitClickListener;
    }

    public interface OnPrintCommitClickListener{
        void onPrintCommit(int position);
    }

    public PrintHardAdapter(List<PrintHardListBean> list, Context context) {
        this.list = list;
        this.context = context;
    }

    @Override
    public VH onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = ((LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE))
                .inflate(R.layout.item_print_hard_list,parent,false);

        return new VH(view);
    }

    @Override
    public void onBindViewHolder(VH holder, int position) {
        PrintHardListBean data = list.get(position);

        //set
        if (data.getQmsManufactureProductionplan() != null){
            holder.tv_dingdanhao.setText(data.getQmsManufactureProductionplan().getOrderNo(), TextView.BufferType.NORMAL);
        }

        holder.tv_suichedanhao.setText(data.getFlowCarNo(),TextView.BufferType.NORMAL);
        holder.tv_car_number.setText(data.getCarFarmeNo(),TextView.BufferType.NORMAL);
        if (data.getQmsManufactureProductionplan() != null){
            holder.tv_car_type.setText(data.getQmsManufactureProductionplan().getCarModelNo(),TextView.BufferType.NORMAL);
        }

        if (data.getQmsManufactureProductionplan() != null){
            holder.tv_info.setText(data.getQmsManufactureProductionplan().getConfigDesc(),TextView.BufferType.NORMAL);
        }

        if (data.getEnvironmentalLabel() != null){
            holder.tv_recyable.setText(data.getEnvironmentalLabel().equals("1") ? "是" : "否");
        }
        holder.tv_up_time.setText(data.getCreateDate(),TextView.BufferType.NORMAL);
        holder.btn_print_commit.setOnClickListener(v -> {
            if (null != onPrintCommitClickListener){
                onPrintCommitClickListener.onPrintCommit(position);
            }
        });
    }

    @Override
    public int getItemCount() {
        return list == null ? 0 : list.size();
    }

    static class VH extends RecyclerView.ViewHolder{

        SmartTextView tv_dingdanhao;//订单号
        SmartTextView tv_suichedanhao;//随车单号
        SmartTextView tv_car_number;//车架号
        SmartTextView tv_car_type;//车型号
        SmartTextView tv_info;//配置
        SmartTextView tv_up_time,tv_recyable;//上线时间
        Button btn_print_commit;//接车

        public VH(View itemView) {
            super(itemView);
            tv_dingdanhao = itemView.findViewById(R.id.tv_dingdanhao);
            tv_suichedanhao= itemView.findViewById(R.id.tv_suichedanhao);
            tv_car_number = itemView.findViewById(R.id.tv_car_number);
            tv_car_type = itemView.findViewById(R.id.tv_car_type);
            tv_info = itemView.findViewById(R.id.tv_info);
            tv_up_time = itemView.findViewById(R.id.tv_up_time);
            btn_print_commit = itemView.findViewById(R.id.btn_print_commit);
            tv_recyable = itemView.findViewById(R.id.tv_recyable);
        }
    }
}
