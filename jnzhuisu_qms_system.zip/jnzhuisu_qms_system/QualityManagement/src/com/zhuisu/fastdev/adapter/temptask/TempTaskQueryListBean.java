package com.zhuisu.fastdev.adapter.temptask;

import java.util.List;

/**
 * @author cxh
 * @description
 * @date 2021/2/20.
 */

public class TempTaskQueryListBean {

    /**
     * retCode : 0
     * retMessage :
     * data : [{"id":"70c6663ccbeb43d59137f43caaff2687","isNewRecord":false,"createDate":"2021-02-20 14:32:44","updateDate":"2021-02-20 14:32:44","plancode":"JN10210220101","plantype":"标准件","reason":"0202","senddepartmentcode":"NC.00.50000","senddepartmentname":"济宁商用车有限公司","receivedepartmentcode":"NC.00.50000","receivedepartmentname":"济宁商用车有限公司","requiredate":"2021-02-20 00:00:00","receivestockcode":"NC.12.CNC68","receivestockname":"纵梁库1（非托管）","materialcode":"900005556","materialname":"同步件","unit":"10","requireqty":12,"orderno":"wrt","status":"0","remark":""},{"id":"1210600f3a0048a294ea38884724406a","isNewRecord":false,"createDate":"2021-02-19 16:04:50","updateDate":"2021-02-19 16:04:50","plancode":"JN10210219101","plantype":"标准件","reason":"0202","senddepartmentcode":"NC.00.50000","senddepartmentname":"济宁商用车有限公司","receivedepartmentcode":"NC.00.50000","receivedepartmentname":"济宁商用车有限公司","requiredate":"2021-02-19 00:00:00","receivestockcode":"NC.12.CNC68","receivestockname":"纵梁库1（非托管）","materialcode":"YG7115500031","materialname":"440B冲焊单后桥(4.875,ABS,xsφ180,1030/1832,158X158X14,自调","unit":"10","suppliercode":"","suppliername":"","requireqty":2,"orderno":"2021021901","status":"0","remark":""}]
     */

    /**
     * id : 70c6663ccbeb43d59137f43caaff2687
     * isNewRecord : false
     * createDate : 2021-02-20 14:32:44
     * updateDate : 2021-02-20 14:32:44
     * plancode : JN10210220101
     * plantype : 标准件
     * reason : 0202
     * senddepartmentcode : NC.00.50000
     * senddepartmentname : 济宁商用车有限公司
     * receivedepartmentcode : NC.00.50000
     * receivedepartmentname : 济宁商用车有限公司
     * requiredate : 2021-02-20 00:00:00
     * receivestockcode : NC.12.CNC68
     * receivestockname : 纵梁库1（非托管）
     * materialcode : 900005556
     * materialname : 同步件
     * unit : 10
     * requireqty : 12.0
     * orderno : wrt
     * status : 0
     * remark :
     * suppliercode :
     * suppliername :
     */

    private String id;
    private Boolean isNewRecord;
    private String createDate;
    private String updateDate;
    private String plancode;
    private String plantype;
    private String reason;
    private String senddepartmentcode;
    private String senddepartmentname;
    private String receivedepartmentcode;
    private String receivedepartmentname;
    private String requiredate;
    private String receivestockcode;
    private String receivestockname;
    private String materialcode;
    private String materialname;
    private String unit;
    private Double requireqty;
    private String orderno;
    private String status;
    private String remark;
    private String suppliercode;
    private String suppliername;

    public void setId(String id) {
        this.id = id;
    }

    public void setNewRecord(Boolean newRecord) {
        isNewRecord = newRecord;
    }

    public void setCreateDate(String createDate) {
        this.createDate = createDate;
    }

    public void setUpdateDate(String updateDate) {
        this.updateDate = updateDate;
    }

    public void setPlancode(String plancode) {
        this.plancode = plancode;
    }

    public void setPlantype(String plantype) {
        this.plantype = plantype;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public void setSenddepartmentcode(String senddepartmentcode) {
        this.senddepartmentcode = senddepartmentcode;
    }

    public void setSenddepartmentname(String senddepartmentname) {
        this.senddepartmentname = senddepartmentname;
    }

    public void setReceivedepartmentcode(String receivedepartmentcode) {
        this.receivedepartmentcode = receivedepartmentcode;
    }

    public void setReceivedepartmentname(String receivedepartmentname) {
        this.receivedepartmentname = receivedepartmentname;
    }

    public void setRequiredate(String requiredate) {
        this.requiredate = requiredate;
    }

    public void setReceivestockcode(String receivestockcode) {
        this.receivestockcode = receivestockcode;
    }

    public void setReceivestockname(String receivestockname) {
        this.receivestockname = receivestockname;
    }

    public void setMaterialcode(String materialcode) {
        this.materialcode = materialcode;
    }

    public void setMaterialname(String materialname) {
        this.materialname = materialname;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    public void setRequireqty(Double requireqty) {
        this.requireqty = requireqty;
    }

    public void setOrderno(String orderno) {
        this.orderno = orderno;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public void setSuppliercode(String suppliercode) {
        this.suppliercode = suppliercode;
    }

    public void setSuppliername(String suppliername) {
        this.suppliername = suppliername;
    }

    public String getId() {
        return id;
    }

    public Boolean getNewRecord() {
        return isNewRecord;
    }

    public String getCreateDate() {
        return createDate;
    }

    public String getUpdateDate() {
        return updateDate;
    }

    public String getPlancode() {
        return plancode;
    }

    public String getPlantype() {
        return plantype;
    }

    public String getReason() {
        return reason;
    }

    public String getSenddepartmentcode() {
        return senddepartmentcode;
    }

    public String getSenddepartmentname() {
        return senddepartmentname;
    }

    public String getReceivedepartmentcode() {
        return receivedepartmentcode;
    }

    public String getReceivedepartmentname() {
        return receivedepartmentname;
    }

    public String getRequiredate() {
        return requiredate;
    }

    public String getReceivestockcode() {
        return receivestockcode;
    }

    public String getReceivestockname() {
        return receivestockname;
    }

    public String getMaterialcode() {
        return materialcode;
    }

    public String getMaterialname() {
        return materialname;
    }

    public String getUnit() {
        return unit;
    }

    public Double getRequireqty() {
        return requireqty;
    }

    public String getOrderno() {
        return orderno;
    }

    public String getStatus() {
        return status;
    }

    public String getRemark() {
        return remark;
    }

    public String getSuppliercode() {
        return suppliercode;
    }

    public String getSuppliername() {
        return suppliername;
    }
}
