package com.zhuisu.fastdev.adapter.online

import android.content.Context
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import com.zhuisu.fastdev.beans.online.OnLineCarListBean
import com.zhuisu.fastdev.view.SmartTextView
import com.zhuisu.qualityManagement.R

/**
 * @author cxh
 * @description
 * @date 2020/11/9.
 */
class OnLineListAdapter constructor(dataList: List<OnLineCarListBean>, context: Context) : RecyclerView.Adapter<OnLineListAdapter.VH>() {

    var dataList: List<OnLineCarListBean>? = null
    var context: Context? = null
    var onItemClickListener: OnItemClickListener? = null

    init {
        this.dataList = dataList
        this.context = context
    }

    interface OnItemClickListener {
        fun onItemClickListener(position: Int)
    }

    override fun onCreateViewHolder(parent: ViewGroup, p1: Int): VH {
        val view: View = (context!!.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater)
                .inflate(R.layout.item_online_list, parent, false)
        return VH(view)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
//        var result = ""
//        when (dataList!![position].status) {
//            "debug" -> result = "调试"
//            "troubleshooting" -> result = "故障排除"
//            "troubleshootingpassed" -> result = "故障排除完成"
//            "submitcheck" -> result = "送验"
//            "varnish" -> result = "喷清漆"
//            "submitcheckpassed" -> result = "送验完成"
//            "recheck" -> result = "查询复验阶段"
//        }

        holder.tvResult.text = (String().plus("(").plus(position + 1).plus(")") + dataList!![position].carFrameNo + "|" + dataList!![position].flowCarNo + "|" + dataList!![position].offLineStatus)
        holder.llClick.setOnClickListener {
            if (onItemClickListener != null) onItemClickListener!!.onItemClickListener(position)
        }
    }

    override fun getItemCount(): Int {
        return dataList!!.size
    }


    class VH(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var tvResult: SmartTextView = itemView.findViewById(R.id.tv_dingdanhao)
        var llClick: LinearLayout = itemView.findViewById(R.id.ll_click_view)

    }
}