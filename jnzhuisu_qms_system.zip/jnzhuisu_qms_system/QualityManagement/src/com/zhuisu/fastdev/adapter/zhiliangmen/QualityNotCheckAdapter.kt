package com.zhuisu.fastdev.adapter.zhiliangmen

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color
import android.support.v7.widget.RecyclerView
import android.text.TextUtils
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import com.zhuisu.fastdev.beans.consolework.ConsoleProjectList
import com.zhuisu.qualityManagement.R

/**
 * @author cxh
 * @description
 * @date 2020/11/16.
 */
class QualityNotCheckAdapter(list: ArrayList<ConsoleProjectList>, context: Context) : RecyclerView.Adapter<QualityNotCheckAdapter.Holder>() {

    var list : ArrayList<ConsoleProjectList>? = null
    var context : Context? = null
    var onItenClick : OnItemClickListener? = null
    var isNotChecked = true

    init {
        this.list = list
        this.context = context
    }

    interface OnItemClickListener{
        fun onItemClickListener(position : Int)
//        fun onSuccessClick(position: Int)
    }

    class Holder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvName : TextView = itemView.findViewById(R.id.tv_name)
        val tvState : TextView = itemView.findViewById(R.id.tv_state)
        val llParent : LinearLayout = itemView.findViewById(R.id.ll_parent)
        val tvRight : TextView = itemView.findViewById(R.id.tv_right_light)
        val tvLine1 : TextView = itemView.findViewById(R.id.tv_line111);
    }

    override fun onCreateViewHolder(p0: ViewGroup, p1: Int): Holder {
        return Holder(((context!!.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater).inflate(R.layout.item_quality_not_check, p0, false)))
    }

    @SuppressLint("SetTextI18n")
    override fun onBindViewHolder(p0: Holder, p1: Int) {
        p0.tvName.text = list!![p1].carframeNo
        if (isNotChecked){
            p0.tvState.text = list!![p1].orderNo+" (应${list!![p1].checkItemsTotal} 已${list!![p1].checkedItemsTotal} 未${list!![p1].notCheckedItemsTotal})"
            if (list!![p1].notCheckedItemsTotal != null && TextUtils.equals("0",list!![p1].notCheckedItemsTotal)){
                p0.tvName.setTextColor(Color.GREEN)
                p0.tvState.setTextColor(Color.GREEN)
                p0.tvRight.setTextColor(Color.GREEN)
                p0.tvLine1.setTextColor(Color.GREEN)
            }else{
                p0.tvName.setTextColor(Color.parseColor("#4A4A4A"))
                p0.tvState.setTextColor(Color.parseColor("#4A4A4A"))
                p0.tvRight.setTextColor(Color.parseColor("#4A4A4A"))
                p0.tvLine1.setTextColor(Color.parseColor("#4A4A4A"))
            }
        }else{
            p0.tvState.text = list!![p1].orderNo
            if (list!![p1].hasProblem != null && TextUtils.equals("yes",list!![p1].hasProblem)){
                p0.tvName.setTextColor(Color.RED)
                p0.tvState.setTextColor(Color.RED)
                p0.tvRight.setTextColor(Color.RED)
                p0.tvLine1.setTextColor(Color.RED)
            }else{
                p0.tvName.setTextColor(Color.parseColor("#4A4A4A"))
                p0.tvState.setTextColor(Color.parseColor("#4A4A4A"))
                p0.tvRight.setTextColor(Color.parseColor("#4A4A4A"))
                p0.tvLine1.setTextColor(Color.parseColor("#4A4A4A"))
            }
        }

        p0.llParent.setOnClickListener{
            if (onItenClick != null){
                onItenClick!!.onItemClickListener(p1)
            }
        }
    }

    override fun getItemCount(): Int {
        return list!!.size
    }
}