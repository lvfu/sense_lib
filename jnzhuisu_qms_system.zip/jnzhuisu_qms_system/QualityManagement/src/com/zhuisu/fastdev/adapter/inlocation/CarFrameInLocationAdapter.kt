package com.zhuisu.fastdev.adapter.inlocation

import android.annotation.SuppressLint
import android.content.Context
import android.support.v7.widget.RecyclerView
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import com.zhuisu.fastdev.beans.consolepull.ConsolePullList
import com.zhuisu.fastdev.ui.inlocation.CarFrameInLocationListEn
import com.zhuisu.qualityManagement.R

/**
 * @author cxh
 * @description
 * @date 2020/11/18.
 */
class CarFrameInLocationAdapter(list: ArrayList<CarFrameInLocationListEn>, context: Context) : RecyclerView.Adapter<CarFrameInLocationAdapter.Holder>() {
    var context: Context? = null
    var list: ArrayList<CarFrameInLocationListEn>? = null
    var onItemCLick : OnItemClickListener? = null

    init {
        this.list = list
        this.context = context
    }


    interface OnItemClickListener {
        fun onItemCLicked(position: Int)
    }

    class Holder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvNumber : TextView = itemView.findViewById(R.id.tv_number) //单号

        val tvFlowNumber: TextView = itemView.findViewById(R.id.tv_flow_number) //物料号
        val tvCarFrameNumber: TextView = itemView.findViewById(R.id.tv_car_frame_number) //物料名称
        val tvComp : TextView = itemView.findViewById(R.id.tv_create_comp)
        val tvCanNumber : TextView = itemView.findViewById(R.id.tv_can_number)
        val tvRegisterNumber : TextView = itemView.findViewById(R.id.tv_register_number)
        val etRegisterNumber : EditText = itemView.findViewById(R.id.et_jssl)
        val btnSave : Button = itemView.findViewById(R.id.btn_save)
        val root: LinearLayout = itemView.findViewById(R.id.ll_parent)
    }

    override fun onCreateViewHolder(p0: ViewGroup, p1: Int): Holder {
        return Holder(((context!!.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater).inflate(R.layout.item_car_frame_location, p0, false)))
    }

    @SuppressLint("SetTextI18n")
    override fun onBindViewHolder(p0: Holder, @SuppressLint("RecyclerView") p1: Int) {
        p0.tvNumber.text = "单号: ${ list!![p1].outDh}"
        p0.tvFlowNumber.text =  "物料号: ${ list!![p1].fldWlBh}"
        p0.tvCarFrameNumber.text = "物料名称: ${ list!![p1].fldWlMc}"
        p0.tvComp.text = "供应商: ${ list!![p1].scdw}"
        p0.tvCanNumber.text = "应接收数量: ${ list!![p1].outSfsl}"
        p0.tvRegisterNumber.text = "已接收数量: ${ list!![p1].outJssl}"
        p0.etRegisterNumber.setText("")
        p0.etRegisterNumber.addTextChangedListener(object : TextWatcher{
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {

            }

            override fun afterTextChanged(s: Editable?) {
                list!![p1].jssl = s.toString()
            }

        })
        p0.btnSave.setOnClickListener {
            if (onItemCLick != null) {
                onItemCLick!!.onItemCLicked(p1)
            }
        }

        p0.root.setOnClickListener {

        }
    }

    override fun getItemCount(): Int {
        return list!!.size
    }
}