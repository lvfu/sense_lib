package com.zhuisu.fastdev.adapter.lack;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import com.zhuisu.fastdev.beans.LackCommitDetailListBean;
import com.zhuisu.fastdev.view.SmartTextView;
import com.zhuisu.qualityManagement.R;

import java.util.List;

/**
 * @author cxh
 * @description
 * @date 2020/10/27.
 */
public class LackCommitDetailAdapter extends RecyclerView.Adapter<LackCommitDetailAdapter.VH> {

    private List<LackCommitDetailListBean> listBeans;
    private Context context;
    private OnItemSelectListener onItemSelectListener;

    public void setOnItemSelectListener(OnItemSelectListener onItemSelectListener) {
        this.onItemSelectListener = onItemSelectListener;
    }

    public LackCommitDetailAdapter(List<LackCommitDetailListBean> listBeans, Context context) {
        this.listBeans = listBeans;
        this.context = context;
    }

    public interface OnItemSelectListener{
        void onItemSelect(int position);
    }

    @Override
    public VH onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = ((LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE))
                .inflate(R.layout.item_lack_detail_list,parent,false);
        return new VH(view);
    }

    @Override
    public void onBindViewHolder(VH holder, int position) {
        LackCommitDetailListBean data = listBeans.get(position);
        holder.tv_dingdanhao.setText(data.getMaterielId());
        holder.tv_suichedanhao.setText(data.getMaterielName());
        holder.ll_nood.setOnClickListener(v -> {
            if (onItemSelectListener != null){
                onItemSelectListener.onItemSelect(position);
            }
        });
    }

    @Override
    public int getItemCount() {
        return listBeans == null ? 0 : listBeans.size();
    }

    static class VH extends RecyclerView.ViewHolder{

        SmartTextView  tv_dingdanhao;//物料号
        SmartTextView tv_suichedanhao;//物料名称
        LinearLayout ll_nood;
        public VH(View itemView) {
            super(itemView);
            tv_dingdanhao = itemView.findViewById(R.id.tv_dingdanhao);
            tv_suichedanhao = itemView.findViewById(R.id.tv_suichedanhao);
            ll_nood = itemView.findViewById(R.id.ll_nood);

        }
    }
}
