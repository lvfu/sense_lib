package com.zhuisu.fastdev.adapter.finishcheck

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.support.v7.widget.RecyclerView
import android.text.TextUtils
import android.util.Base64
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import com.zhuisu.fastdev.beans.consolework.ConsoleProjectList
import com.zhuisu.qualityManagement.R
import com.zhuisu.suppliermanagement.ui.ShowImageDisplayActivity
import com.zhuisu.suppliermanagement.util.GlobalVar

/**
 * @author cxh
 * @description
 * @date 2020/11/16.
 */
class FinishProjectAdapter(list: ArrayList<ConsoleProjectList>, context: Context) :
    RecyclerView.Adapter<FinishProjectAdapter.Holder>() {

    var list: ArrayList<ConsoleProjectList>? = null
    var context: Context? = null
    var onItenClick: OnItemClickListener? = null

    init {
        this.list = list
        this.context = context
    }

    interface OnItemClickListener {
        fun onItemClickListener(position: Int)
    }

    class Holder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvName: TextView = itemView.findViewById(R.id.tv_name)
        val tvState: TextView = itemView.findViewById(R.id.tv_state)
        val llParent: LinearLayout = itemView.findViewById(R.id.ll_parent)
        val tvCode: TextView = itemView.findViewById(R.id.tv_code)
        val tvUser: TextView = itemView.findViewById(R.id.tv_user)
        val tvDate: TextView = itemView.findViewById(R.id.tv_checkdate)
        val tvValue: TextView = itemView.findViewById(R.id.tv_value)
        val tvRemark: TextView = itemView.findViewById(R.id.tv_value_remark)
        val image: ImageView = itemView.findViewById(R.id.iv_image)
    }

    override fun onCreateViewHolder(p0: ViewGroup, p1: Int): Holder {
        return Holder(
            ((context!!.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater).inflate(
                R.layout.item_finished_project,
                p0,
                false
            ))
        )
    }

    override fun onBindViewHolder(p0: Holder, p1: Int) {
        p0.tvName.text = list!![p1].opnm
        p0.tvState.text =
            if (list!![p1].status == "passed") "合格" else if (list!![p1].status == "failed") "不合格" else if (list!![p1].status == "noCheck") "免检" else "待检验"
        p0.llParent.setOnClickListener {
            if (onItenClick != null) {
                onItenClick!!.onItemClickListener(p1)
            }
        }

        p0.tvCode.text = list!![p1].opno
        p0.tvUser.text = list!![p1].checkedBy
        p0.tvDate.text = list!![p1].checkedDate
        p0.tvValue.text = list!![p1].checkValue
        p0.tvRemark.text = list!![p1].checkRemarks
        if (list!![p1].imgStr != null && !TextUtils.isEmpty(list!![p1].imgStr)) {
            p0.image.setImageBitmap(base64ToBitmap(list!![p1].imgStr))
            p0.image.setOnClickListener {
                val intent = Intent(context, ShowImageDisplayActivity::class.java)
                GlobalVar.IMGBASE64 = list!![p1].imgStr
                context!!.startActivity(intent)
            }
        }

    }

    override fun getItemCount(): Int {
        return list!!.size
    }

    fun base64ToBitmap(string: String?): Bitmap? {
        val bitmap: Bitmap
        bitmap = try {
            val bitmapArray = Base64.decode(string, Base64.DEFAULT)
            BitmapFactory.decodeByteArray(bitmapArray, 0, bitmapArray.size)
        } catch (e: Exception) {
            e.printStackTrace()
            return null
        }
        return bitmap
    }
}