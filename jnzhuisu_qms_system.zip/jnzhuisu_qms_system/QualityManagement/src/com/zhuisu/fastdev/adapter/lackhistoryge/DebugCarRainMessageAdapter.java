package com.zhuisu.fastdev.adapter.lackhistoryge;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.zhuisu.fastdev.view.SmartTextView;
import com.zhuisu.qualityManagement.R;

import java.util.List;

/**
 * @author cxh
 * @description
 * @date 2021/3/10.
 */
public class DebugCarRainMessageAdapter extends RecyclerView.Adapter<DebugCarRainMessageAdapter.VH> {

    private Context context;
    private List<DebugCarRainMessageBean> list;

    public DebugCarRainMessageAdapter(Context context, List<DebugCarRainMessageBean> list) {
        this.context = context;
        this.list = list;
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        return new VH(((LayoutInflater) (context.getSystemService(Context.LAYOUT_INFLATER_SERVICE)))
                .inflate(R.layout.item_debug_car_rain_message, viewGroup, false));
    }

    @Override
    public void onBindViewHolder(@NonNull VH vh, int position) {
        DebugCarRainMessageBean data = list.get(position);
        if (data.getUpdateDate() == null || TextUtils.isEmpty(data.getUpdateDate())) {
            //没有检验
            vh.stvOne.setText("淋雨操作者"+(data.getRainOperator() == null ? "" : data.getRainOperator()) + "    \t    " + (data.getCreateDate() == null ? "" : data.getCreateDate()));
        } else {
            vh.stvOne.setText("淋雨操作者"+(data.getOperator() == null ? "" : data.getOperator()) + "    \t    " + (data.getUpdateDate() == null ? "" : data.getUpdateDate()));
        }

    }

    @Override
    public int getItemCount() {
        return list == null ? 0 : list.size();
    }

    static class VH extends RecyclerView.ViewHolder {

        SmartTextView stvOne;

        public VH(@NonNull View itemView) {
            super(itemView);
            stvOne = itemView.findViewById(R.id.stv_one);

        }
    }
}
