package com.zhuisu.fastdev.adapter.lackhistoryge;

/**
 * @author cxh
 * @description
 * @date 2021/3/10.
 */
public class DebugCarRainMessageBean {
    private String id;
    private String createDate;
    private String rainOperator;
    private String updateDate;
    private String operator;

    public void setId(String id) {
        this.id = id;
    }

    public void setCreateDate(String createDate) {
        this.createDate = createDate;
    }

    public void setRainOperator(String rainOperator) {
        this.rainOperator = rainOperator;
    }

    public void setUpdateDate(String updateDate) {
        this.updateDate = updateDate;
    }

    public void setOperator(String operator) {
        this.operator = operator;
    }

    public String getId() {
        return id;
    }

    public String getCreateDate() {
        return createDate;
    }

    public String getRainOperator() {
        return rainOperator;
    }

    public String getUpdateDate() {
        return updateDate;
    }

    public String getOperator() {
        return operator;
    }
}
