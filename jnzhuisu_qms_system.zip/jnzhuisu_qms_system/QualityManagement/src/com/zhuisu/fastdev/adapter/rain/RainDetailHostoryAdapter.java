package com.zhuisu.fastdev.adapter.rain;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.util.ArrayMap;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;

import com.google.gson.Gson;
import com.zhuisu.fastdev.beans.rain.RainHistoryListBean;
import com.zhuisu.fastdev.ui.rain.RainLogActivity;
import com.zhuisu.fastdev.view.SmartTextView;
import com.zhuisu.qualityManagement.R;
import com.zhuisu.suppliermanagement.util.GlobalVar;
import com.zhuisu.suppliermanagement.util.ToastUtils;

import java.io.IOException;
import java.util.List;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 * @author cxh
 * @description
 * @date 2020/10/23.
 */
public class RainDetailHostoryAdapter extends RecyclerView.Adapter<RainDetailHostoryAdapter.VH> {

    private List<RainHistoryListBean> list;
    private Context context;
    private OnDetailsClickListener onDetailsClickListener;


    public void setOnDetailsClickListener(OnDetailsClickListener onDetailsClickListener) {
        this.onDetailsClickListener = onDetailsClickListener;
    }

    public RainDetailHostoryAdapter(List<RainHistoryListBean> listBeans, Context context) {
        this.list = listBeans;
        this.context = context;
    }

    public interface OnDetailsClickListener{
        void onDetailsClickListener(int position);
    }

    @Override
    public RainDetailHostoryAdapter.VH onCreateViewHolder(ViewGroup parent, int viewType) {

        View view = ((LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE))
                .inflate(R.layout.item_rain_history_list, parent, false);

        return new VH(view);
    }

    @Override
    public void onBindViewHolder(RainDetailHostoryAdapter.VH holder, int position) {
        RainHistoryListBean data = list.get(position);

//        set
        holder.tv_car_number.setText(data.getCarFarmeNo());
        holder.tv_car_type.setText(data.getRainOperator());
        holder.tv_info.setText(data.getCreateDate());

        holder.tv_up_time.setText(data.getRainResult() == null ? "" : data.getRainResult().equals("0") ? "失败" : "成功"); //淋雨结果

//        if (data.getRainResult() == null){
//            holder.btn_ok.setVisibility(View.VISIBLE);
//            holder.btn_false.setVisibility(View.VISIBLE);
//        }else{
            holder.btn_ok.setVisibility(View.GONE);
            holder.btn_false.setVisibility(View.GONE);
//        }

        holder.btn_ok.setOnClickListener(v -> {
            ArrayMap<String, String> map = new ArrayMap<>();
            map.put("id", data.getId());
            map.put("rainResult", "1");
            map.put("carFarmeNo",data.getCarFarmeNo());
            map.put("userName",GlobalVar.username);
            String param = new Gson().toJson(map);
            OkHttpClient client = new OkHttpClient();
            RequestBody requestBody = RequestBody.create(MediaType.parse("application/json; charset=utf-8"), param);
            Request request = new Request.Builder()
                    .post(requestBody)
                    .url(GlobalVar.url + "a/offlinedebuggingstatus/qmsOfflineStatus/api/updateRainTestResult")
                    .build();

            client.newCall(request).enqueue(new Callback() {
                @Override
                public void onFailure(Call call, IOException e) {
                    Log.d("保存淋雨状态", "onFailure: 失败"+e.getMessage());
                }

                @Override
                public void onResponse(Call call, Response response) throws IOException {
                    final String result = response.body().string();
                    Log.e("保存淋雨状态", result);
                   holder.btn_ok.post(()->{
                       if (context instanceof Activity){
                           ToastUtils.show("成功");
                           ((Activity)context).finish();
                       }
                   });
                }
            });
        });

        holder.btn_false.setOnClickListener(v -> {
            Intent intent = new Intent(context, RainLogActivity.class);
            intent.putExtra(RainLogActivity.ACTION_RAIN,list.get(position));
            context.startActivity(intent);
        });

        holder.cvDetails.setOnClickListener(v -> {
            if (onDetailsClickListener != null){
                if (TextUtils.equals( holder.tv_up_time.getText().toString(),"失败")){
                    onDetailsClickListener.onDetailsClickListener(position);
                }

            }
        });
    }

    @Override
    public int getItemCount() {
        return list == null ? 0 : list.size();
    }

    static class VH extends RecyclerView.ViewHolder {

        SmartTextView tv_car_number;//车架号
        SmartTextView tv_car_type;//车型号
        SmartTextView tv_info;//配置
        SmartTextView tv_up_time;//上线时间
        Button btn_ok;//接车
        Button btn_false;
        LinearLayout linearLayout;
        CardView cvDetails;

        public VH(View itemView) {
            super(itemView);
            tv_car_number = itemView.findViewById(R.id.tv_car_number);
            tv_car_type = itemView.findViewById(R.id.tv_car_type);
            tv_info = itemView.findViewById(R.id.tv_info);
            tv_up_time = itemView.findViewById(R.id.tv_up_time);
            btn_ok = itemView.findViewById(R.id.btn_ok);
            btn_false = itemView.findViewById(R.id.btn_false);
            linearLayout = itemView.findViewById(R.id.ll_control);
            cvDetails = itemView.findViewById(R.id.cv_details);
        }
    }
}
