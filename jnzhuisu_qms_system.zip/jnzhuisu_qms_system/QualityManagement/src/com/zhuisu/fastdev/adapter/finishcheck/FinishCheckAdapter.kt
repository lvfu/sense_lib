package com.zhuisu.fastdev.adapter.finishcheck

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import com.zhuisu.fastdev.beans.FinishCheckList
import com.zhuisu.fastdev.beans.consolework.ConsoleWorkList
import com.zhuisu.fastdev.beans.listZcproject
import com.zhuisu.fastdev.beans.registercar.RegisterCarDetails
import com.zhuisu.fastdev.ui.finishcheck.FinishCheckAskInputActivity
import com.zhuisu.fastdev.ui.finishcheck.FinishProjectActivity
import com.zhuisu.fastdev.ui.jieche.RegisterCarConfigChangeActivity
import com.zhuisu.fastdev.ui.problem.ProblemCloseActivity
import com.zhuisu.fastdev.view.SmartTextView
import com.zhuisu.qualityManagement.R

/**
 * @author cxh
 * @description
 * @date 2020/11/20.
 */
class FinishCheckAdapter(list: ArrayList<FinishCheckList>,context: Context) : RecyclerView.Adapter<FinishCheckAdapter.Holder>() {
    private var list : ArrayList<FinishCheckList>? = null
    private var context : Context? = null
     var firstSuccess : FirstSuccess? = null

    init {
        this.list = list
        this.context = context
    }

    public interface FirstSuccess{
        fun firstSuccess(position : Int)
    }

    class Holder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val btnAskList: Button = itemView.findViewById(R.id.btn_ask_list)
        val tvTitle : SmartTextView = itemView.findViewById(R.id.tv_pro_title)
        val tvDesc : SmartTextView = itemView.findViewById(R.id.tv_pro_desc)
        val tvErrCode : SmartTextView = itemView.findViewById(R.id.tv_error_code)
        val tvLevel : SmartTextView = itemView.findViewById(R.id.tv_pro_level)
        val btnFailure : Button = itemView.findViewById(R.id.btn_failure)
        val btnFirst : Button = itemView.findViewById(R.id.btn_first_ok)
        val tvLookWorkPro : SmartTextView = itemView.findViewById(R.id.tv_look_work_project)
        val tvHoNumber : SmartTextView = itemView.findViewById(R.id.tv_ho_number)
        val tvEngine : SmartTextView = itemView.findViewById(R.id.tv_engine)
        val tvRecyable : SmartTextView = itemView.findViewById(R.id.tv_recycler)
        val tv_chexinghao : SmartTextView = itemView.findViewById(R.id.tv_chexinghao)
        val llConfigChange : LinearLayout = itemView.findViewById(R.id.ll_config_change)
        val rv_jiancha : RecyclerView = itemView.findViewById(R.id.rv_jiancha)

    }

    override fun onCreateViewHolder(p0: ViewGroup, p1: Int): Holder {
        return Holder(((context!!.getSystemService(Context.LAYOUT_INFLATER_SERVICE)) as LayoutInflater)
                .inflate(R.layout.item_finish_checkt,p0,false))
    }

    override fun onBindViewHolder(p0: Holder, p1: Int) {
        val data = list!![p1]
        p0.tvTitle.text = data.carFarmeNo
        p0.tvDesc.text = data.qmsManufactureProductionplan?.orderNo
        if(data.flags.equals("0")){
            p0.tvErrCode.text =data.flowCarNo
        }else{
            p0.tvErrCode.setTextColor(Color.parseColor("#FF00FF00"))
            p0.tvErrCode.text =data.flowCarNo
        }

        p0.tvLevel.text = data.qmsManufactureProductionplan?.configDesc
        p0.tv_chexinghao.text = data.qmsManufactureProductionplan?.carModelNo
        val manager = LinearLayoutManager(context)
        manager.orientation = LinearLayoutManager.VERTICAL
        p0.rv_jiancha!!.layoutManager = manager
        var adapter = JianchaAdapter(list!![p1].listZcproject as ArrayList<listZcproject>,list!![p1] as FinishCheckList, context!!)
        p0.rv_jiancha!!.adapter = adapter
        adapter!!.notifyDataSetChanged()
        p0.btnAskList.setOnClickListener{
            //问题列表
            val notCloseIntent = Intent(context, ProblemCloseActivity::class.java)
            notCloseIntent.putExtra(ProblemCloseActivity.ACTION_PARAMS, data.carFarmeNo)
            notCloseIntent.putExtra(ProblemCloseActivity.ACTION_FORM_FINISH_CHECK,true)
            context!!.startActivity(notCloseIntent)
        }

        p0.btnFailure.setOnClickListener{
            //问题录入
            val intent = Intent(context, FinishCheckAskInputActivity::class.java)
            intent.putExtra(FinishCheckAskInputActivity.ACTION_CAR_NUMBER,data.carFarmeNo)
            intent.putExtra(FinishCheckAskInputActivity.ACTION_OPNO,data.opno)
            intent.putExtra(FinishCheckAskInputActivity.ACTION_STATUS,data.status)
            intent.addCategory(FinishCheckAskInputActivity.ACTION_CAR_NUMBER)
            context!!.startActivity(intent)
        }

        p0.btnFirst.setOnClickListener {
            if (firstSuccess != null){
                firstSuccess?.firstSuccess(p1)
            }
        }

        //查看作业项目
        p0.tvLookWorkPro.setOnClickListener{
            val currentIntent = Intent(context, FinishProjectActivity::class.java)
            val data = ConsoleWorkList(list!![p1].flowCarNo,list!![p1].carFarmeNo,null,false,null,"","")
            currentIntent.putExtra(FinishProjectActivity.ACTION_VALUE,data)
            context!!.startActivity(currentIntent)
        }

        p0.tvHoNumber.text = list!![p1].cylinderNumber
        p0.tvEngine.text = list!![p1].engineNumber
        if (list!![p1].environmentalLabel != null){
            when(list!![p1].environmentalLabel){
                "1" -> {
                    p0.tvRecyable.text = "是"
                }

                "0" ->{
                    p0.tvRecyable.text = "否"
                }
            }
        }

        if (list!![p1].configChange!!){
            p0.llConfigChange.visibility = View.VISIBLE
            p0.llConfigChange.setOnClickListener{
                val configChangeIntent = Intent(context, RegisterCarConfigChangeActivity::class.java)
                val changeData = RegisterCarDetails()
                changeData.flowCarNo = list!![p1].flowCarNo
                configChangeIntent.putExtra(RegisterCarConfigChangeActivity.ACTION_DATA, changeData)
                context?.startActivity(configChangeIntent)
            }
        }else{
            p0.llConfigChange.visibility = View.GONE
        }

    }

    override fun getItemCount(): Int {
       return list!!.size
    }
}