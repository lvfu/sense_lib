package com.zhuisu.fastdev.adapter.consolereturn

import android.content.Context
import android.content.Intent
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import com.zhuisu.fastdev.beans.consolepull.ConsolePullList
import com.zhuisu.fastdev.beans.consolework.ConsoleWorkList
import com.zhuisu.fastdev.ui.finishcheck.FinishProjectActivity
import com.zhuisu.fastdev.view.SmartTextView
import com.zhuisu.qualityManagement.R

/**
 * @author cxh
 * @description
 * @date 2020/11/18.
 */
class ConsoleReturnAdapter(list: ArrayList<ConsolePullList>, context: Context) : RecyclerView.Adapter<ConsoleReturnAdapter.Holder>() {
    var context: Context? = null
    var list: ArrayList<ConsolePullList>? = null
    var onItemCLick : OnItemClickListener? = null

    init {
        this.list = list
        this.context = context
    }


    interface OnItemClickListener {
        fun onItemCLicked(position: Int)
    }

    class Holder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvFlowNumber: TextView = itemView.findViewById(R.id.tv_flow_number)
        val tvCarFrameNumber: TextView = itemView.findViewById(R.id.tv_car_frame_number)
        val root: LinearLayout = itemView.findViewById(R.id.ll_parent)
    }

    override fun onCreateViewHolder(p0: ViewGroup, p1: Int): Holder {
        return Holder(((context!!.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater).inflate(R.layout.item_console_return, p0, false)))
    }

    override fun onBindViewHolder(p0: Holder, p1: Int) {
        p0.tvFlowNumber.text = list!![p1].flowCarNo
        p0.tvCarFrameNumber.text = list!![p1].carFarmeNo
        p0.root.setOnClickListener {
            if (onItemCLick != null) {
                onItemCLick!!.onItemCLicked(p1)
            }
        }

    }

    override fun getItemCount(): Int {
        return list!!.size
    }
}