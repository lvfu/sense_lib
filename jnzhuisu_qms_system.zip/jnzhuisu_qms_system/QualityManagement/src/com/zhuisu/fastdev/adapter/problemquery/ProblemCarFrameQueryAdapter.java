package com.zhuisu.fastdev.adapter.problemquery;

import android.content.Context;
import android.graphics.Color;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.zhuisu.fastdev.beans.ProblemCloseBean;
import com.zhuisu.fastdev.beans.zhuangpei.CarFrameProList;
import com.zhuisu.fastdev.view.SmartTextView;
import com.zhuisu.qualityManagement.R;

import java.util.List;

/**
 * @author cxh
 * @description
 * @date 2020/10/30.
 */
public class ProblemCarFrameQueryAdapter extends RecyclerView.Adapter<ProblemCarFrameQueryAdapter.VH> {

    private List<CarFrameProList> listBeans;
    private Context context;
    private OnCloseMenuClickListener onCloseMenuClickListener;
    private boolean isShowBottom = true;
    private boolean isShowClose = false;

    public void setShowClose(boolean showClose) {
        isShowClose = showClose;
    }

    public void setShowBottom(boolean showBottom) {
        isShowBottom = showBottom;
    }

    public void setOnCloseMenuClickListener(OnCloseMenuClickListener onCloseMenuClickListener) {
        this.onCloseMenuClickListener = onCloseMenuClickListener;
    }

    public interface OnCloseMenuClickListener {
        void onCloseClickListener(int position);
    }

    public ProblemCarFrameQueryAdapter(List<CarFrameProList> listBeans, Context context) {
        this.listBeans = listBeans;
        this.context = context;
    }

    @Override
    public VH onCreateViewHolder(ViewGroup parent, int viewType) {

        View view = ((LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE))
                .inflate(R.layout.item_car_frame_problem_query_list, parent, false);

        return new VH(view);
    }

    @Override
    public void onBindViewHolder(VH holder, int position) {
        CarFrameProList data = listBeans.get(position);
//        if (data.getProblemTitle().contains(" ")){
//            String title = data.getProblemTitle().substring(0,data.getProblemTitle().indexOf(" "));
//            holder.tv_create_number.setText(title+(data.getFaultDesc() == null? "" : data.getFaultDesc()));
//        }else{
            holder.tv_create_number.setText(data.getProblemTitle());
//        }

        holder.tv_remark_lack.setText(data.getProblemDesc());
        holder.btn_close_lack.setOnClickListener(v -> {
            if (onCloseMenuClickListener != null) {
                onCloseMenuClickListener.onCloseClickListener(position);
            }
        });

            holder.tv_close.setVisibility(View.VISIBLE);
            if (data.getFlowStatus() != null && TextUtils.equals(data.getIsClose(),"9")){
               //关闭
                holder.tv_create_number.setTextColor(Color.GREEN);
                holder.tv_confirm_number.setTextColor(Color.GREEN);
                holder.tv_wl_name.setTextColor(Color.GREEN);
                holder.tv_duct_number.setTextColor(Color.GREEN);
                holder.tv_remark_lack.setTextColor(Color.GREEN);
                holder.tv_level.setTextColor(Color.GREEN);
                holder.btn_close_lack.setTextColor(Color.GREEN);

            }else{
                //空= 未关闭
                holder.tv_create_number.setTextColor(Color.RED);
                holder.tv_confirm_number.setTextColor(Color.RED);
                holder.tv_wl_name.setTextColor(Color.RED);
                holder.tv_duct_number.setTextColor(Color.RED);
                holder.tv_remark_lack.setTextColor(Color.RED);
                holder.tv_level.setTextColor(Color.RED);
                holder.btn_close_lack.setTextColor(Color.RED);
            }

            if (data.getFlowStatus().equals("finish")) {
                holder.group.setVisibility(View.GONE);
            }

        holder.group.setVisibility(isShowBottom ? View.VISIBLE : View.GONE);
    }

    @Override
    public int getItemCount() {
        return listBeans == null ? 0 : listBeans.size();
    }

    static class VH extends RecyclerView.ViewHolder {

        SmartTextView tv_create_number;
        SmartTextView tv_confirm_number;
        SmartTextView tv_wl_name;
        SmartTextView tv_duct_number;
        SmartTextView tv_remark_lack;
        SmartTextView tv_level, tv_close;
        TextView btn_close_lack;
        LinearLayout group;

        public VH(View itemView) {
            super(itemView);
            tv_create_number = itemView.findViewById(R.id.tv_create_number);
            tv_confirm_number = itemView.findViewById(R.id.tv_confirm_number);
            tv_wl_name = itemView.findViewById(R.id.tv_wl_name);
            tv_duct_number = itemView.findViewById(R.id.tv_duct_number);
            tv_remark_lack = itemView.findViewById(R.id.tv_remark_lack);
            btn_close_lack = itemView.findViewById(R.id.btn_close_lack);
            tv_level = itemView.findViewById(R.id.tv_level);
            group = itemView.findViewById(R.id.ll_bottom);
            tv_close = itemView.findViewById(R.id.tv_close);


        }
    }
}
