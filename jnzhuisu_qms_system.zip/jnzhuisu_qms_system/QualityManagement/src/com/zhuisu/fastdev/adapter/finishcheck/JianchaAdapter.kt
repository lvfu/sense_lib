package com.zhuisu.fastdev.adapter.finishcheck

import android.content.Context
import android.content.Intent
import android.os.Parcelable
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Spinner
import android.widget.TextView
import com.zhuisu.fastdev.beans.FinishCheckList
import com.zhuisu.fastdev.beans.listZcproject
import com.zhuisu.fastdev.beans.registercar.RegisterCarLocationListBean
import com.zhuisu.fastdev.ui.finishcheck.CarPartsAskInputActivity
import com.zhuisu.fastdev.ui.finishcheck.FinishCheckAskInputActivity
import com.zhuisu.qualityManagement.R

class JianchaAdapter(list: ArrayList<listZcproject>,finishCheckList : FinishCheckList, context: Context) : RecyclerView.Adapter<JianchaAdapter.Holder>(){
    private var list : ArrayList<listZcproject>? = null
    private var finishCheckList : FinishCheckList? = null
    private var context : Context? = null
    private var choose_List : ArrayList<String>? = ArrayList()

    init {
        this.list = list
        this.finishCheckList = finishCheckList
        this.context = context
        choose_List?.add("合格")
        choose_List?.add("不合格")
    }

    fun setList(list: ArrayList<listZcproject>){
        this.list = list
        this.notifyDataSetChanged()
    }

    public interface FirstSuccess{
        fun firstSuccess(position: Int)
    }

    class Holder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tv_opnm : TextView = itemView.findViewById(R.id.tv_opnm)
        val spinner_opnm : Spinner = itemView.findViewById(R.id.spinner_opnm)
    }

    override fun onCreateViewHolder(p0: ViewGroup, p1: Int): Holder {
        return Holder(((context!!.getSystemService(Context.LAYOUT_INFLATER_SERVICE)) as LayoutInflater)
                .inflate(R.layout.item_jiancha, p0, false))
    }

    override fun onBindViewHolder(p0: Holder, p1: Int) {
        val data = list!![p1]
        p0.tv_opnm.text = data.opnm

        val adapter: ArrayAdapter<String> = ArrayAdapter<String>(context, R.layout.simple_textview1, choose_List)
        p0.spinner_opnm.adapter = adapter
        if(data.jianyan.equals("1")){
            p0.spinner_opnm.setSelection(1,true)
        }
        p0.spinner_opnm!!.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                if(choose_List?.get(position).equals("合格")){
                    data.jianyan = "0"
                }
                if(choose_List?.get(position).equals("不合格")){
                    data.jianyan = "1"
                    val intent = Intent(context, CarPartsAskInputActivity::class.java)
                    intent.putExtra(FinishCheckAskInputActivity.ACTION_CAR_NUMBER,finishCheckList!!.carFarmeNo)
                    intent.putExtra(FinishCheckAskInputActivity.ACTION_FINISHCHECKLIST,finishCheckList)
                    intent.putExtra(FinishCheckAskInputActivity.ACTION_OPNO,data.opno)
                    intent.putExtra(FinishCheckAskInputActivity.ACTION_STATUS,finishCheckList!!.status)
                    intent.addCategory(FinishCheckAskInputActivity.ACTION_CAR_NUMBER)
                    context!!.startActivity(intent)
                }
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {
            }
        }


    }

    override fun getItemCount(): Int {
        return list!!.size
    }
}

