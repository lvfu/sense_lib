package com.zhuisu.fastdev.adapter.lackhistoryge;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.zhuisu.fastdev.beans.ProblemCloseBean;
import com.zhuisu.fastdev.beans.zhuangpei.CarFrameProList;
import com.zhuisu.fastdev.view.SmartTextView;
import com.zhuisu.qualityManagement.R;

import java.util.List;

/**
 * @author cxh
 * @description
 * @date 2020/10/30.
 */
public class CarFrameProblemCloseAdapter extends RecyclerView.Adapter<CarFrameProblemCloseAdapter.VH> {

    private List<CarFrameProList> listBeans;
    private Context context;
    private OnCloseMenuClickListener onCloseMenuClickListener;
    private boolean isShowBottom = true;
    private boolean isShowClose = false;

    public void setShowClose(boolean showClose) {
        isShowClose = showClose;
    }

    public void setShowBottom(boolean showBottom) {
        isShowBottom = showBottom;
    }

    public void setOnCloseMenuClickListener(OnCloseMenuClickListener onCloseMenuClickListener) {
        this.onCloseMenuClickListener = onCloseMenuClickListener;
    }

    public interface OnCloseMenuClickListener {
        void onCloseClickListener(int position);
    }

    public CarFrameProblemCloseAdapter(List<CarFrameProList> listBeans, Context context) {
        this.listBeans = listBeans;
        this.context = context;
    }

    @Override
    public VH onCreateViewHolder(ViewGroup parent, int viewType) {

        View view = ((LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE))
                .inflate(R.layout.item_problem_car_frame_close_list, parent, false);
        return new VH(view);
    }

    @Override
    public void onBindViewHolder(VH holder, int position) {
        CarFrameProList data = listBeans.get(position);
        holder.tv_create_number.setText(data.getProblemTitle());
        holder.tv_duct_number.setText(String.valueOf(data.getProblemDesc()));
        holder.tv_remark_lack.setText(data.getProblemDesc());
        holder.btn_close_lack.setOnClickListener(v -> {
            if (onCloseMenuClickListener != null) {
                onCloseMenuClickListener.onCloseClickListener(position);
            }
        });

        if (isShowClose) {
            holder.tv_close.setVisibility(View.VISIBLE);
            holder.tv_close.setText(data.getIsClose().equals("1") ? "未关闭" : "已关闭");
            if (data.getFlowStatus().equals("finish")) {
                holder.group.setVisibility(View.GONE);
            }
        }
        holder.group.setVisibility(isShowBottom ? View.VISIBLE : View.GONE);
    }

    @Override
    public int getItemCount() {
        return listBeans == null ? 0 : listBeans.size();
    }

    static class VH extends RecyclerView.ViewHolder {

        SmartTextView tv_create_number;
        SmartTextView tv_confirm_number;
        SmartTextView tv_wl_name;
        SmartTextView tv_duct_number;
        SmartTextView tv_remark_lack;
        SmartTextView tv_level, tv_close;
        TextView btn_close_lack;
        LinearLayout group;

        public VH(View itemView) {
            super(itemView);
            tv_create_number = itemView.findViewById(R.id.tv_create_number);
            tv_confirm_number = itemView.findViewById(R.id.tv_confirm_number);
            tv_wl_name = itemView.findViewById(R.id.tv_wl_name);
            tv_duct_number = itemView.findViewById(R.id.tv_duct_number);
            tv_remark_lack = itemView.findViewById(R.id.tv_remark_lack);
            btn_close_lack = itemView.findViewById(R.id.btn_close_lack);
            tv_level = itemView.findViewById(R.id.tv_level);
            group = itemView.findViewById(R.id.ll_bottom);
            tv_close = itemView.findViewById(R.id.tv_close);


        }
    }
}
