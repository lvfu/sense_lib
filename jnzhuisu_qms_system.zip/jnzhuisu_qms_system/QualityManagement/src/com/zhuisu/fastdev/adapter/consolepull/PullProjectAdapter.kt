package com.zhuisu.fastdev.adapter.consolepull

import android.content.Context
import android.graphics.Color
import android.support.v7.widget.RecyclerView
import android.text.TextUtils
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import com.zhuisu.fastdev.beans.ProelemDetailBean
import com.zhuisu.fastdev.view.SmartTextView
import com.zhuisu.qualityManagement.R

/**
 * @author cxh
 * @description
 * @date 2020/11/11.
 */
class PullProjectAdapter(list: ArrayList<ProelemDetailBean>, context: Context) : RecyclerView.Adapter<PullProjectAdapter.Holder>() {
    var list: ArrayList<ProelemDetailBean>? = null
    var context: Context? = null
    var onClicklistener: OnClickListener? = null

    init {
        this.list = list
        this.context = context
    }

    interface OnClickListener {
        fun onItemCLickListener(position: Int)
    }

    class Holder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvTitle: TextView = itemView.findViewById(R.id.tv_pro_title)
        val tvCarNumber: TextView = itemView.findViewById(R.id.tv_car_number)
        val llNood: LinearLayout = itemView.findViewById(R.id.ll_nood)
        val tvStatus : SmartTextView = itemView.findViewById(R.id.tv_status)
        val tvRight : SmartTextView = itemView.findViewById(R.id.stv_right)
    }

    override fun onCreateViewHolder(parent: ViewGroup, position: Int): Holder {
        return Holder(((context!!.getSystemService(Context.LAYOUT_INFLATER_SERVICE)) as LayoutInflater)
                .inflate(R.layout.item_pull_project_list, parent, false))
    }

    override fun onBindViewHolder(holder: Holder, position: Int) {
        val data = list!![position]
        holder.tvTitle.text = data.peoblemTitle
        holder.tvCarNumber.text = data.carFrameNo
        holder.llNood.setOnClickListener {
            if (onClicklistener != null) {
                onClicklistener!!.onItemCLickListener(position)
            }
        }
        var result = ""
        when (data.offLineStatus) {
            "debug" -> {
                result = "调试"
            }
            "troubleshooting" -> {
                result = "故障排除"
            }
            "troubleshootingpassed" -> {
                result = "故障排除确认"
            }
            "submitcheck" -> {
                result = "送验"
            }
            "varnish" -> {
                result = "喷清漆"
            }
            "submitcheckpassed" -> {
                result = "送验完成"
            }
            "recheck" -> {
                result = "复验阶段"
            }
        }
        holder.tvStatus.text = result

        if (data.isClose != null && !TextUtils.isEmpty(data.isClose)){
            //已关闭
            holder.tvTitle.setTextColor(Color.GREEN)
            holder.tvCarNumber.setTextColor(Color.GREEN)
            holder.tvStatus.setTextColor(Color.GREEN)
            holder.tvRight.setTextColor(Color.GREEN)
        }else{
            holder.tvTitle.setTextColor(Color.parseColor("#4A4A4A"))
            holder.tvCarNumber.setTextColor(Color.parseColor("#4A4A4A"))
            holder.tvStatus.setTextColor(Color.parseColor("#4A4A4A"))
            holder.tvRight.setTextColor(Color.parseColor("#4A4A4A"))
        }
    }

    override fun getItemCount(): Int {
        return list!!.size
    }
}