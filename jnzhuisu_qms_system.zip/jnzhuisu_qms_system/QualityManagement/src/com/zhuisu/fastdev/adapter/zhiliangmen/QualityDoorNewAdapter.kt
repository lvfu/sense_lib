package com.zhuisu.fastdev.adapter.zhiliangmen

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color
import android.support.v7.widget.RecyclerView
import android.text.TextUtils
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import com.zhuisu.fastdev.beans.consolework.ConsoleProjectList
import com.zhuisu.fastdev.beans.consolework.QualityDoorBean
import com.zhuisu.qualityManagement.R

/**
 * @author cxh
 * @description
 * @date 2020/11/16.
 */
class QualityDoorNewAdapter(list: ArrayList<QualityDoorBean>, context: Context) : RecyclerView.Adapter<QualityDoorNewAdapter.Holder>() {

    var list : ArrayList<QualityDoorBean>? = null
    var context : Context? = null

    init {
        this.list = list
        this.context = context
    }


    class Holder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tv_fadongji : TextView = itemView.findViewById(R.id.tv_fadongji)
        val tv_niaosu : TextView = itemView.findViewById(R.id.tv_niaosu)
        val tv_huochuli : TextView = itemView.findViewById(R.id.tv_huochuli);
    }

    override fun onCreateViewHolder(p0: ViewGroup, p1: Int): Holder {
        return Holder(((context!!.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater).inflate(R.layout.item_quality_door_new_check, p0, false)))
    }

    @SuppressLint("SetTextI18n")
    override fun onBindViewHolder(p0: Holder, p1: Int) {
        p0.tv_fadongji.text = "发动机号: "+list!![p1].fdjh
        p0.tv_niaosu.text = "尿素箱号: "+list!![p1].nsxh
        p0.tv_huochuli.text = "货处理器号: "+list!![p1].hclqh

    }

    override fun getItemCount(): Int {
        return list!!.size
    }
}