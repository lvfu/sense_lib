package com.zhuisu.fastdev.adapter.inlocation

import android.annotation.SuppressLint
import android.content.Context
import android.support.v7.widget.RecyclerView
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import com.zhuisu.fastdev.ui.inlocation.GiveInLocationEnt
import com.zhuisu.qualityManagement.R

/**
 * @author cxh
 * @description
 * @date 2020/11/18.
 */
class GiveInLocationAdapter(list: ArrayList<GiveInLocationEnt>, context: Context) : RecyclerView.Adapter<GiveInLocationAdapter.Holder>() {
    var context: Context? = null
    var list: ArrayList<GiveInLocationEnt>? = null
    var onItemCLick: OnItemClickListener? = null

    init {
        this.list = list
        this.context = context
    }


    interface OnItemClickListener {
        fun onItemCLicked(position: Int)
    }

    class Holder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvFlowNumber: TextView = itemView.findViewById(R.id.tv_flow_number) //物料号
        val tvCarFrameNumber: TextView = itemView.findViewById(R.id.tv_car_frame_number)
        val tvComp: TextView = itemView.findViewById(R.id.tv_create_comp)
        val etInLocation: EditText = itemView.findViewById(R.id.et_in_location_number)
        val btnSave: Button = itemView.findViewById(R.id.btn_save)

        val root: LinearLayout = itemView.findViewById(R.id.ll_parent)
    }

    override fun onCreateViewHolder(p0: ViewGroup, p1: Int): Holder {
        return Holder(((context!!.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater).inflate(R.layout.item_give_in_location, p0, false)))
    }

    @SuppressLint("SetTextI18n")
    override fun onBindViewHolder(p0: Holder,  p1: Int) {
        p0.tvFlowNumber.text = "物料号: ${list!![p0.adapterPosition].fldWlBh}"
        p0.tvCarFrameNumber.text = "物料名称: ${list!![p0.adapterPosition].fldWlMc}"
        p0.tvComp.text = "供应商: ${list!![p0.adapterPosition].fldWlLy} ${list!![p0.adapterPosition].supplierName}"
        p0.etInLocation.setText("")
        p0.etInLocation.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {

            }

            override fun afterTextChanged(s: Editable?) {
                list!![p0.adapterPosition].quantity = s.toString()
            }

        })
        p0.btnSave.setOnClickListener {
            if (onItemCLick != null) {
                onItemCLick!!.onItemCLicked(p1)
            }
        }

        p0.root.setOnClickListener {

        }
    }

    override fun getItemCount(): Int {
        return list!!.size
    }
}