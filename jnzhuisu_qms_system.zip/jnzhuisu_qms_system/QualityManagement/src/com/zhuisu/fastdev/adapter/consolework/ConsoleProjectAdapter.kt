package com.zhuisu.fastdev.adapter.consolework

import android.content.Context
import android.graphics.Color
import android.support.v7.widget.RecyclerView
import android.text.TextUtils
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import com.zhuisu.fastdev.beans.consolework.ConsoleProjectList
import com.zhuisu.qualityManagement.R

/**
 * @author cxh
 * @description
 * @date 2020/11/16.
 */
class ConsoleProjectAdapter(list: ArrayList<ConsoleProjectList>, context: Context) :
    RecyclerView.Adapter<ConsoleProjectAdapter.Holder>() {

    var list: ArrayList<ConsoleProjectList>? = null
    var context: Context? = null
    var onItenClick: OnItemClickListener? = null

    init {
        this.list = list
        this.context = context
    }

    interface OnItemClickListener {
        fun onItemClickListener(position: Int)
        fun onSuccessClick(position: Int)
        fun onNotCheckClick(position: Int)

    }

    class Holder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvName: TextView = itemView.findViewById(R.id.tv_name)
        val tvState: TextView = itemView.findViewById(R.id.tv_state)
        val llParent: LinearLayout = itemView.findViewById(R.id.ll_parent)
        val tvSuccess: TextView = itemView.findViewById(R.id.tv_success)
        val tvNotCheck: TextView = itemView.findViewById(R.id.tv_not_check)
    }

    override fun onCreateViewHolder(p0: ViewGroup, p1: Int): Holder {
        return Holder(
            ((context!!.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater).inflate(
                R.layout.item_console_project,
                p0,
                false
            ))
        )
    }

    override fun onBindViewHolder(p0: Holder, p1: Int) {
        p0.tvName.text = list!![p1].opnm

        if (list!![p1].gljybz == "1") {
            p0.tvName.setTextColor(Color.parseColor("#FF0000"))
        } else {
            p0.tvName.setTextColor(Color.parseColor("#4A4A4A"))
        }


        p0.tvState.text =
            if (list!![p1].status == "passed") "合格" else if (list!![p1].status == "failed") "不合格" else if (list!![p1].status == "noCheck") "免检" else "待检验"
        if (TextUtils.equals("合格", p0.tvState.text.toString()) || TextUtils.equals(
                "免检",
                p0.tvState.text.toString()
            )
        ) {
            p0.tvSuccess.visibility = View.GONE
            p0.tvNotCheck.visibility = View.GONE
        } else {
            p0.tvSuccess.visibility = View.VISIBLE
            p0.tvNotCheck.visibility = View.VISIBLE
        }
        p0.llParent.setOnClickListener {
            if (onItenClick != null) {
                onItenClick!!.onItemClickListener(p1)
            }
        }

        p0.tvSuccess.setOnClickListener {
            if (onItenClick != null) {
                onItenClick!!.onSuccessClick(p1)
            }
        }
        p0.tvNotCheck.setOnClickListener {
            if (onItenClick != null) {
                onItenClick!!.onNotCheckClick(p1)
            }
        }
    }

    override fun getItemCount(): Int {
        return list!!.size
    }
}