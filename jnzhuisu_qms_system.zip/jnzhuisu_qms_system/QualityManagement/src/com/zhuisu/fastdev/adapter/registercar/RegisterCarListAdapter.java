package com.zhuisu.fastdev.adapter.registercar;

import android.content.Context;
import android.content.Intent;
import android.os.Parcelable;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Spinner;

import com.zhuisu.fastdev.beans.registercar.RegisterCarListBean;
import com.zhuisu.fastdev.beans.registercar.RegisterCarLocationListBean;
import com.zhuisu.fastdev.ui.jieche.RegisterCarConfigChangeActivity;
import com.zhuisu.fastdev.view.SmartTextView;
import com.zhuisu.qualityManagement.R;

import java.util.List;

/**
 * @author cxh
 * @description
 * @date 2020/10/19.
 */
public class RegisterCarListAdapter extends RecyclerView.Adapter<RegisterCarListAdapter.VH> {

    private List<RegisterCarListBean> list;
    private Context context;
    private OnRegisterCarClicked registerCarClicked;
    private List<RegisterCarLocationListBean> locationListBeanList;

    public void setLocationListBeanList(List<RegisterCarLocationListBean> locationListBeanList) {
        this.locationListBeanList = locationListBeanList;
    }

    public List<RegisterCarLocationListBean> getLocationListBeanList() {
        return locationListBeanList;
    }

    public void setRegisterCarClicked(OnRegisterCarClicked registerCarClicked) {
        this.registerCarClicked = registerCarClicked;
    }

    public interface OnRegisterCarClicked {
        void registerCarClicked(int position);
    }

    public RegisterCarListAdapter(List<RegisterCarListBean> list, Context context) {
        this.list = list;
        this.context = context;
    }

    @Override
    public VH onCreateViewHolder(ViewGroup parent, int viewType) {

        View view = ((LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE))
                .inflate(R.layout.item_register_car_list, parent, false);
        return new VH(view);
    }

    @Override
    public void onBindViewHolder(VH holder, int position) {
        RegisterCarListBean data = list.get(position);

        //set
        if (data != null && data.getQmsManufactureProductionplan() != null) {
            holder.tv_dingdanhao.setText(data.getQmsManufactureProductionplan().getOrderNo());
            holder.tv_suichedanhao.setText(data.getFlowCarNo());
            holder.tv_car_type.setText(data.getQmsManufactureProductionplan().getCarModelNo());
            holder.tv_info.setText(data.getQmsManufactureProductionplan().getConfigDesc());
            holder.tv_up_time.setText(data.getCreateDate());
        }

        holder.tv_car_number.setText(data.getCarFarmeNo());

        ArrayAdapter<? extends Parcelable> adapter = new ArrayAdapter<>(context, R.layout.simple_textview1, locationListBeanList);
        holder.sp_select.setAdapter(adapter);


        if (locationListBeanList != null && !locationListBeanList.isEmpty()) {
            data.setValue(locationListBeanList.get(0).getValue());
        }

        holder.sp_select.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                RegisterCarLocationListBean registerCarLocationListBean = locationListBeanList.get(position);
                data.setValue(registerCarLocationListBean.getValue());
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        holder.btn_register_car.setOnClickListener(view -> {
            if (registerCarClicked != null) {
                registerCarClicked.registerCarClicked(position);
            }
        });

        if (data.getConfigChange()) {
            holder.ll_show_config_change.setVisibility(View.VISIBLE);
            holder.ll_show_config_change.setOnClickListener(v -> {
                Intent intent = new Intent(context, RegisterCarConfigChangeActivity.class);
                intent.putExtra(RegisterCarConfigChangeActivity.ACTION_DATA, data);
                context.startActivity(intent);
            });
        } else {
            holder.ll_show_config_change.setVisibility(View.GONE);
        }
    }

    @Override
    public int getItemCount() {
        return list == null ? 0 : list.size();
    }

    static class VH extends RecyclerView.ViewHolder {

        SmartTextView tv_dingdanhao;//订单号
        SmartTextView tv_suichedanhao;//随车单号
        SmartTextView tv_car_number;//车架号
        SmartTextView tv_car_type;//车型号
        SmartTextView tv_info;//配置
        SmartTextView tv_up_time;//上线时间
        Button btn_register_car;//接车
        LinearLayout ll_show_config_change;
        private Spinner sp_select;


        public VH(View itemView) {
            super(itemView);
            tv_dingdanhao = itemView.findViewById(R.id.tv_dingdanhao);
            tv_suichedanhao = itemView.findViewById(R.id.tv_suichedanhao);
            tv_car_number = itemView.findViewById(R.id.tv_car_number);
            tv_car_type = itemView.findViewById(R.id.tv_car_type);
            tv_info = itemView.findViewById(R.id.tv_info);
            tv_up_time = itemView.findViewById(R.id.tv_up_time);
            btn_register_car = itemView.findViewById(R.id.btn_register_car);
            ll_show_config_change = itemView.findViewById(R.id.ll_show_config_change);
            sp_select = itemView.findViewById(R.id.sp_select);
        }
    }
}
