package com.zhuisu.fastdev.adapter.problemquery;

import android.content.Context;
import android.graphics.Color;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.zhuisu.fastdev.beans.ProblemCloseBean;
import com.zhuisu.fastdev.view.SmartTextView;
import com.zhuisu.qualityManagement.R;

import java.util.List;

/**
 * @author cxh
 * @description
 * @date 2020/10/30.
 */
public class ProblemQueryQualityAdapter extends RecyclerView.Adapter<ProblemQueryQualityAdapter.VH> {

    private List<ProblemCloseBean> listBeans;
    private Context context;
    private OnCloseMenuClickListener onCloseMenuClickListener;


    public void setOnCloseMenuClickListener(OnCloseMenuClickListener onCloseMenuClickListener) {
        this.onCloseMenuClickListener = onCloseMenuClickListener;
    }

    public interface OnCloseMenuClickListener {
        void onCloseClickListener(int position);
    }

    public ProblemQueryQualityAdapter(List<ProblemCloseBean> listBeans, Context context) {
        this.listBeans = listBeans;
        this.context = context;
    }

    @Override
    public VH onCreateViewHolder(ViewGroup parent, int viewType) {

        View view = ((LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE))
                .inflate(R.layout.item_problem_query_quality_list, parent, false);

        return new VH(view);
    }

    @Override
    public void onBindViewHolder(VH holder, int position) {
        ProblemCloseBean data = listBeans.get(position);

        holder.tv_confirm_number.setText("问题标题: " + data.getPeoblemTitle());
        holder.tv_create_number.setText("问题描述: " + data.getProblemDesc());
        holder.tv_close.setText("录入人: " + data.getCreateBy() == null ? "录入人: " : "录入人: " + data.getCreateBy());

        if (data.getIsClose() != null && !TextUtils.isEmpty(data.getIsClose()) && (TextUtils.equals("finish", data.getIsClose()) || TextUtils.equals("9", data.getIsClose()))) {
            holder.tv_level.setText("已关闭");
            holder.tv_level.setTextColor(Color.GREEN);
        } else {
            holder.tv_level.setText("未关闭");
            holder.tv_level.setTextColor(Color.RED);
        }

        holder.cv_detail.setOnClickListener(v -> {
            if (onCloseMenuClickListener != null) {
                onCloseMenuClickListener.onCloseClickListener(position);
            }
        });

    }

    @Override
    public int getItemCount() {
        return listBeans == null ? 0 : listBeans.size();
    }

    static class VH extends RecyclerView.ViewHolder {

        SmartTextView tv_create_number;
        SmartTextView tv_confirm_number;
        SmartTextView tv_level, tv_close;
        CardView cv_detail;

        public VH(View itemView) {
            super(itemView);
            tv_create_number = itemView.findViewById(R.id.tv_create_number);
            tv_confirm_number = itemView.findViewById(R.id.tv_confirm_number);
            cv_detail = itemView.findViewById(R.id.cv_detail);
            tv_level = itemView.findViewById(R.id.tv_level);
            tv_close = itemView.findViewById(R.id.tv_close);


        }
    }
}
