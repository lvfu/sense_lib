package com.zhuisu.fastdev.adapter.payask

import android.annotation.SuppressLint
import android.content.Context
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import com.zhuisu.fastdev.beans.PayAskQueryListBean
import com.zhuisu.qualityManagement.R

/**
 * @author cxh
 * @description
 * @date 2021/4/13.
 */
class PayAskQueryAdapter(list : ArrayList<PayAskQueryListBean>,context : Context) : RecyclerView.Adapter<PayAskQueryAdapter.Holder>() {
    private var list : ArrayList<PayAskQueryListBean>? = null
    private var context : Context? = null
    public var onItemclick : OnItemClickListener? = null

    public interface OnItemClickListener{
        fun onItemClick(position : Int)
    }
    init {
        this.list = list
        this.context = context
    }
    inner class Holder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val textView : TextView = itemView.findViewById(R.id.tv_textview)
    }

    override fun onCreateViewHolder(p0: ViewGroup, p1: Int): Holder {
        return Holder(((context!!.getSystemService(Context.LAYOUT_INFLATER_SERVICE)as LayoutInflater)
                .inflate(R.layout.item_pay_task_query_list,p0,false)))
    }

    @SuppressLint("SetTextI18n")
    override fun onBindViewHolder(p0: Holder, p1: Int) {
        val data = list!![p0.adapterPosition]
        p0.textView.setText(data.billCode+"${data.billCode}|${data.materialCode}|\t\t${data.submitCheckNum}\t >>")
        if (onItemclick != null){
            p0.textView.setOnClickListener {
                onItemclick!!.onItemClick(p0.adapterPosition)
            }
        }
    }

    override fun getItemCount(): Int {
       return if (list == null) 0 else list!!.size
    }
}