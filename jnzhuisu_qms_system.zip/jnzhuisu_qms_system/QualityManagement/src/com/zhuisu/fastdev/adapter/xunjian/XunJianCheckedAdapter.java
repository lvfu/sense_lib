package com.zhuisu.fastdev.adapter.xunjian;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.zhuisu.fastdev.ui.xunjian.OnSiteCheckedListBean;
import com.zhuisu.fastdev.ui.xunjian.OnSiteInspectionTypeListBean;
import com.zhuisu.qualityManagement.R;

import java.util.List;

/**
 * @author cxh
 * @description 装配未检
 * @date 2020/10/12.
 */
public class XunJianCheckedAdapter extends BaseAdapter {

    private List<OnSiteCheckedListBean> list;
    private Context context;
    public OnItemClick onItemClick;
    private boolean canCheck = false;

    public void setCanCheck(boolean canCheck) {
        this.canCheck = canCheck;
    }

    public void setOnItemClick(OnItemClick onItemClick) {
        this.onItemClick = onItemClick;
    }

    public XunJianCheckedAdapter(List<OnSiteCheckedListBean> list, Context context) {
        this.list = list;
        this.context = context;
    }

    @Override
    public int getCount() {
        return list == null ? 0 : list.size();
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        Cache cache;
        if (convertView == null) {
            cache = new Cache();
            convertView = View.inflate(context, R.layout.item_xunjian_checked_first, null);
            cache.tv_jianyanbianma = convertView.findViewById(R.id.tv_jianyanbianma);
            cache.tv_jianyanmingcheng = convertView.findViewById(R.id.tv_jianyanmingcheng);
            cache.tv_state = convertView.findViewById(R.id.tv_state);

            cache.tv_flow_number = convertView.findViewById(R.id.tv_flow_number);
            cache.tv_jianyanjishuyaoqiu = convertView.findViewById(R.id.tv_jianyanjishuyaoqiu);
            cache.tv_jianyanji_state = convertView.findViewById(R.id.tv_jianyanji_state);
            cache.check_ok = convertView.findViewById(R.id.check_ok);
            cache.ll_details = convertView.findViewById(R.id.ll_details);
            cache.check_nook = convertView.findViewById(R.id.check_nook);
            cache.ll_check_control = convertView.findViewById(R.id.ll_check_control);
            convertView.setTag(cache);
        }
        cache = (Cache) convertView.getTag();

        cache.tv_jianyanmingcheng.setText(list.get(position).getCarframeNo() == null ? "" : list.get(position).getCarframeNo());
        cache.tv_flow_number.setText(list.get(position).getFlowcarNo() == null ? "" : list.get(position).getFlowcarNo());
        cache.tv_state.setText(list.get(position).getStatus().equals("passed") ? "合格" : "不合格");

        cache.check_ok.setOnClickListener(v -> {
            if (onItemClick != null) {
                onItemClick.onOkClick(position);
            }
        });

        cache.check_nook.setOnClickListener(v -> {
            if (onItemClick != null) {
                onItemClick.onNoClick(position);
            }
        });
        cache.ll_details.setOnClickListener(view -> {
            if (onItemClick != null) {
                onItemClick.onDetailClickLisen(position);
            }
        });
        return convertView;
    }

    static class Cache {
        TextView tv_jianyanbianma;
        TextView tv_jianyanmingcheng,tv_flow_number,tv_state;
        TextView tv_jianyanjishuyaoqiu;
        TextView tv_jianyanji_state;
        Button check_ok;
        Button check_nook;
        LinearLayout ll_details;
        LinearLayout ll_check_control;
    }

    public interface OnItemClick {
        void onOkClick(int position);

        void onNoClick(int position);

        void onDetailClickLisen(int position);
    }
}
