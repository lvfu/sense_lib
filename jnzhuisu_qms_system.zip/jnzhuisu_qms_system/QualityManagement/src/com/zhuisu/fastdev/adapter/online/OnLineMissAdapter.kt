package com.zhuisu.fastdev.adapter.online

import android.content.Context
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.zhuisu.fastdev.beans.online.OnLineMissListBean
import com.zhuisu.fastdev.view.SmartTextView
import com.zhuisu.qualityManagement.R

/**
 * @author cxh
 * @description
 * @date 2020/11/10.
 */
class OnLineMissAdapter(list: ArrayList<OnLineMissListBean>, context: Context) : RecyclerView.Adapter<OnLineMissAdapter.VH>() {

    var list: ArrayList<OnLineMissListBean>? = null
    var context: Context? = null

    init {
        this.list = list
        this.context = context
    }

    override fun onCreateViewHolder(parent: ViewGroup, p1: Int): VH {
        val view: View = (context!!.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater)
                .inflate(R.layout.item_online_detail_miss, parent, false)
        return VH(view)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        holder.tv_create_number.text = list!![position].bomId
        holder.tv_level.text = list!![position].bomName
    }

    override fun getItemCount(): Int {
        return list!!.size
    }

    class VH(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tv_create_number: SmartTextView = itemView.findViewById(R.id.tv_create_number) //编号
        val tv_level : SmartTextView = itemView.findViewById(R.id.tv_level)//名称

    }
}