package com.zhuisu.fastdev.adapter.rain;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Switch;

import com.bumptech.glide.Glide;
import com.zhuisu.fastdev.beans.rain.RainLogListBean;
import com.zhuisu.fastdev.view.SmartTextView;
import com.zhuisu.qualityManagement.R;

import java.util.List;

/**
 * @author cxh
 * @description
 * @date 2020/10/26.
 */
public class RainLogAdapter extends RecyclerView.Adapter<RainLogAdapter.VH> {


    private List<RainLogListBean> list;
    private Context context;
    private OnImageSelectListener onImageSelectListener;
    private OnCommitClickListener onCommitClickListener;

    public interface OnCommitClickListener{
        void onCommitClicked(int position);
    }

    public void setOnCommitClickListener(OnCommitClickListener onCommitClickListener) {
        this.onCommitClickListener = onCommitClickListener;
    }

    public void setOnImageSelectListener(OnImageSelectListener onImageSelectListener) {
        this.onImageSelectListener = onImageSelectListener;
    }

    public interface OnImageSelectListener{
        void onSelectImage(int position);
    }


    public RainLogAdapter(List<RainLogListBean> list, Context context) {
        this.list = list;
        this.context = context;
    }

    @Override
    public VH onCreateViewHolder(ViewGroup parent, int viewType) {

        View view = ((LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE))
                .inflate(R.layout.item_rain_log_list,parent,false);
        return new VH(view);
    }

    @Override
    public void onBindViewHolder(VH holder, int position) {

        holder.iv_select_image.setOnClickListener(view -> {
            if (onImageSelectListener != null){
                onImageSelectListener.onSelectImage(position);
            }
        });

        holder.tv_car_number.setTag(list.get(position));
        holder.tv_car_number.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                RainLogListBean temp = (RainLogListBean) holder.tv_car_number.getTag();
                temp.setRemark(s.toString());
            }
        });


        list.get(position).setYesNo("0");
        //1 合格
        holder.switch1.setOnCheckedChangeListener((buttonView, isChecked) -> {
            list.get(position).setYesNo(isChecked ? "1" : "0");
        });
        holder.btn_print_commit.setOnClickListener(v -> {
            if (null != onCommitClickListener){
                onCommitClickListener.onCommitClicked(position);
            }
        });

        holder.tv_dingdanhao.setText(list.get(position).getPart());
        holder.tv_suichedanhao.setText(list.get(position).getPartNo());
        holder.switch1.setChecked(false);

        if (list.get(position).getImgStr() != null){
            Glide.with(context).load(list.get(position).getImgStr()).into(holder.showimage);
        }

    }


    @Override
    public int getItemCount() {
        return list == null ? 0 : list.size();
    }

    static class VH extends RecyclerView.ViewHolder{
        SmartTextView tv_dingdanhao;//淋雨部位
        SmartTextView tv_suichedanhao;//淋雨部位编号
        EditText tv_car_number;//备注
        Button btn_print_commit;
        Switch switch1;

        private ImageView iv_select_image;//选择照片
        private ImageView showimage;//显示的照片

        public VH(View itemView) {
            super(itemView);
            tv_dingdanhao = itemView.findViewById(R.id.tv_dingdanhao);
            tv_suichedanhao= itemView.findViewById(R.id.tv_suichedanhao);
            tv_car_number = itemView.findViewById(R.id.tv_car_number);
            switch1 = itemView.findViewById(R.id.switch1);
            iv_select_image = itemView.findViewById(R.id.iv_select_image);
            showimage = itemView.findViewById(R.id.showimage);
            btn_print_commit = itemView.findViewById(R.id.btn_print_commit);
        }
    }

}
