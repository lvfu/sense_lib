package com.zhuisu.fastdev.adapter.carframe;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.util.ArrayMap;
import android.util.Log;
import android.view.View;
import android.widget.ListView;
import android.widget.TextView;

//import com.google.gson.reflect.TypeToken;
import com.google.gson.reflect.TypeToken;
import com.zhuisu.fastdev.BaseActivity;
import com.zhuisu.fastdev.beans.consolework.ConsoleProjectList;
import com.zhuisu.fastdev.beans.zhiliangmen.ZhiLiangMenWeiJianFirstBean;
import com.zhuisu.fastdev.dialog.BasePopupWindowDialog;
import com.zhuisu.fastdev.ui.problemquery.ProblemQueryForDoorLJHTQualityActivity;
import com.zhuisu.fastdev.ui.zhiliangmen.CarFrameWorkDetailActivity;
import com.zhuisu.fastdev.ui.zhiliangmen.QualityDoorNotEnterProblemActivity;
import com.zhuisu.fastdev.view.FastTitleLayout;
import com.zhuisu.qualityManagement.R;
import com.zhuisu.suppliermanagement.base.CaptureActivity;
import com.zhuisu.suppliermanagement.util.GlobalVar;
import com.zhuisu.suppliermanagement.util.ToastUtils;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.List;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 * 质量门未检
 */
public class CarFrameDoorCheckItemAndProblemListActivity extends BaseActivity {

    private List<ZhiLiangMenWeiJianFirstBean> list;
    private ListView listview;
    private CarFrameNotCheckFirAdapter adapter;
    public static final String ACTION_DATA = "action";
    private ConsoleProjectList data;
    private TextView tvConfig;
    private String url;

    @SuppressLint("SetTextI18n")
    @Override
    protected void initViews() {
        listview = findViewById(R.id.listview);
        TextView tv_user_name = findViewById(R.id.tv_user_name);
        tv_user_name.setText("\t" + GlobalVar.realname);
        tvConfig = findViewById(R.id.tv_config);
        if (getIntent() != null && getIntent().hasExtra("url")) {
            FastTitleLayout fa = findViewById(R.id.fast);
            url = getIntent().getStringExtra("url");
            fa.setTitle(url);
        }

        if (getIntent() != null && getIntent().getParcelableExtra(ACTION_DATA) != null) {
            data = getIntent().getParcelableExtra(ACTION_DATA);
            TextView tvCarFrame = findViewById(R.id.tv_carnumber);
            tvCarFrame.setText(data.getCarframeNo());

            findViewById(R.id.btn_ask).setOnClickListener(v -> {
                //问题列表
                Intent notCloseIntent = new Intent(context, ProblemQueryForDoorLJHTQualityActivity.class);
                notCloseIntent.putExtra("data", data.getCarframeNo());
                startActivity(notCloseIntent);
            });
        }


        findViewById(R.id.tv_scanf).setOnClickListener(arg0 -> {
            Intent intent = new Intent();
            intent.setClass(context, CaptureActivity.class);
            startActivityForResult(intent, 1073);
        });

//
//        if (isFinished) {
//            findViewById(R.id.btn_all_success).setVisibility(View.GONE);
//        } else {
            findViewById(R.id.btn_all_success).setOnClickListener(v -> {
                if (list == null || list.isEmpty()) {
                    ToastUtils.show("暂无数据");
                    return;
                }
                BasePopupWindowDialog dialog = new BasePopupWindowDialog();
                Bundle bundle = new Bundle();
                bundle.putString(BasePopupWindowDialog.ACTION_VALUE_TITLE, "确定要执行该操作吗?");
                dialog.setArguments(bundle);
                dialog.show(getSupportFragmentManager(), "");
                dialog.setOnConfirmClickListener(() -> {
                    dialog.dismiss();
                    for (int i = 0; i < list.size(); i++) {
                        checkSuccess(list.get(i).getId(), true, i);
                    }
                });
            });
//        }


    }


    @Override
    protected void onResume() {
        super.onResume();

        queryData();
        queryUnCloseAsk();
    }

    /**
     * 查询详情
     */
    private void queryUnCloseAsk() {

        ArrayMap<String, Object> map = new ArrayMap<>();
        map.put("carFrameNo", data.getCarframeNo());
        String param = gson.toJson(map);

        Log.e("查询详情", param);
        OkHttpClient client = new OkHttpClient();
        RequestBody requestBody = RequestBody.create(JSON, param);
        Request request = new Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/assemblyprocess/qmsManufactureProductionplan/api/getFlowCarNoByCarFramno")
                .build();


        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                Log.d(TAG, "onFailure: 失败");
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                String result = response.body().string();
                runOnUiThread(() -> {
                    try {
                        Log.e("详情", result);

                        JSONObject jsonObject = new JSONObject(result);
                        if (jsonObject.optString("retCode").equals("0")) {
                            if (jsonObject.optString("data") != null && !jsonObject.optString("data").isEmpty()) {
                                tvConfig.setText(jsonObject.optJSONObject("data").optString("configDesc"));
                                TextView tvOrder = findViewById(R.id.tv_dingdan);
                                tvOrder.setText(jsonObject.optJSONObject("data").optString("orderNo"));
                                TextView tvType = findViewById(R.id.tv_car_type);
                                tvType.setText(jsonObject.optJSONObject("data").optString("carModelNo"));
                            }
                        } else {
                            ToastUtils.show(jsonObject.optString("retMessage"));
                        }
                    } catch (Exception jsonException) {
                        jsonException.printStackTrace();
                    }
                });
            }
        });
    }

    @Override
    protected int getResId() {
        return R.layout.activity_car_frame_not_check;
    }

    private void queryData() {
        if (list != null) {
            list.clear();
            if (adapter != null){
                adapter.notifyDataSetChanged();
            }
        }
        ArrayMap<String, String> map = new ArrayMap<>();
        map.put("carframeNo", data.getCarframeNo());
        map.put("loginName", GlobalVar.username);
        map.put("checkedType", "");//未检 checked 检验
        String param = gson.toJson(map);
        Log.e("-->", param);
        OkHttpClient client = new OkHttpClient();
        RequestBody requestBody = RequestBody.create(JSON, param);
        Request request = new Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/prduictionrelation/qmsManufactureProductionplanrelation/api/qryCheckItems")
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
               runOnUiThread(()->{
                   Log.d(TAG, "onFailure: 失败");
               });
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                final String result = response.body().string();
                Log.d(TAG, "onResponse: " + result);
                runOnUiThread(() -> showData(result));
            }
        });

    }


    private void showData(String result) {
        try {

            Log.e("--->", result);
            JSONObject jsonObject = new JSONObject(result);

            if (jsonObject.optString("data") != null) {
                list = gson.fromJson(jsonObject.optString("data"), new TypeToken<List<ZhiLiangMenWeiJianFirstBean>>() {
                }.getType());
                adapter = new CarFrameNotCheckFirAdapter(list, context);
//                adapter.setCanCheck(isFinished);
                listview.setAdapter(adapter);
                adapter.notifyDataSetChanged();

                if (list == null || list.isEmpty()) {
                    ToastUtils.show("暂无数据");
                }

                adapter.setOnItemClick(new CarFrameNotCheckFirAdapter.OnItemClick() {
                    @Override
                    public void onOkClick(int position) {
                        BasePopupWindowDialog dialog = new BasePopupWindowDialog();
                        Bundle bundle = new Bundle();
                        bundle.putString(BasePopupWindowDialog.ACTION_VALUE_TITLE, "确定要执行该操作吗?");
                        dialog.setArguments(bundle);
                        dialog.show(getSupportFragmentManager(), "");
                        dialog.setOnConfirmClickListener(() -> {
                            dialog.dismiss();
                            checkSuccess(list.get(position).getId(), false, position);
                        });
                    }

                    @Override
                    public void onNoClick(int position) {
                        checkFailure(position);
                    }

                    @Override
                    public void onDetailClickLisen(int position) {
                        //点击明细
                        Intent intent = new Intent(context, CarFrameWorkDetailActivity.class);
                        intent.putExtra(CarFrameWorkDetailActivity.ACTION_DETAIL_DATA, list.get(position));
                        intent.putExtra(CarFrameWorkDetailActivity.ACTION_CHECKSUCCESS, false);
                        startActivity(intent);
                    }

                    @Override
                    public void onNotCheckClickListener(int position) {
                        notCheck(list.get(position).getId(),  position);
                    }
                });
            } else {
                ToastUtils.show("暂无数据");
            }


        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    /**
     * 检查不合格
     */
    private void checkFailure(int position) {
        Intent intent = new Intent(context, QualityDoorNotEnterProblemActivity.class);
        intent.putExtra(QualityDoorNotEnterProblemActivity.URL,url);
        intent.putExtra(QualityDoorNotEnterProblemActivity.ACTION_DATA, list.get(position));
        startActivity(intent);
    }


    /**
     * 检查合格
     */
    private void checkSuccess(String id, boolean isAll, int position) {
        ArrayMap<String, String> map = new ArrayMap<>();
        map.put("id", id);
        map.put("checkedBy", GlobalVar.username);
        String param = gson.toJson(map);
        OkHttpClient client = new OkHttpClient();
        RequestBody requestBody = RequestBody.create(JSON, param);
        Request request = new Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/prduictionrelation/qmsManufactureProductionplanrelation/api/checkPassed")
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                runOnUiThread(() -> ToastUtils.show("请求失败"));
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                final String result = response.body().string();
                Log.d(TAG, "onResponse: " + result);
                runOnUiThread(() -> {
                    try {
                        JSONObject jsonObject = new JSONObject(result);
                        if (TextUtils.equals("0", jsonObject.optString("retCode"))) {
                            ToastUtils.show("成功");
                            if (!isAll) {
                                queryData();
                                return;
                            }

                        } else {
                            ToastUtils.show(jsonObject.optString("retMessage"));
                        }

                        if (isAll){
                            if (list.size() - 1 == position) {
                                new Handler().postDelayed(() -> queryData(),1500);
                            }
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                });
            }
        });

    }


    /**
     * 免检
     * */

    private void notCheck(String id, int position) {
        ArrayMap<String, String> map = new ArrayMap<>();
        map.put("id", id);
        map.put("checkedBy", GlobalVar.username);
        String param = gson.toJson(map);
        Log.e("--->",param);
        OkHttpClient client = new OkHttpClient();
        RequestBody requestBody = RequestBody.create(JSON, param);
        Request request = new Request.Builder()
                .post(requestBody)
                .url(GlobalVar.url + "a/prduictionrelation/qmsManufactureProductionplanrelation/api/noCheck")
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                runOnUiThread(() -> ToastUtils.show("请求失败"));
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                final String result = response.body().string();

                runOnUiThread(() -> {
                    try {
                        Log.d(TAG, "onResponse: " + result);
                        JSONObject jsonObject = new JSONObject(result);
                        if (TextUtils.equals("0", jsonObject.optString("retCode"))) {
                            ToastUtils.show("成功");
                                queryData();
                        } else {
                            ToastUtils.show(jsonObject.optString("retMessage"));
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                });
            }
        });

    }
}