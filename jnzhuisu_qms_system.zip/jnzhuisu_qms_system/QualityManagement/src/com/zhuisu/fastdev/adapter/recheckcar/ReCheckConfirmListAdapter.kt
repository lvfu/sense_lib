package com.zhuisu.fastdev.adapter.recheckcar

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.support.v7.widget.RecyclerView
import android.text.TextUtils
import android.util.Base64
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import com.zhuisu.fastdev.beans.registercar.ReCheckCarList
import com.zhuisu.qualityManagement.R
import com.zhuisu.suppliermanagement.ui.ShowImageDisplayActivity
import com.zhuisu.suppliermanagement.util.GlobalVar

/**
 * @author lxf
 * @description
 * @date 2020/11/11.
 */
class ReCheckConfirmListAdapter(list: ArrayList<ReCheckCarList>, context: Context) : RecyclerView.Adapter<ReCheckConfirmListAdapter.Holder>() {
    var list : ArrayList<ReCheckCarList>? = null
    var context : Context? = null
    var onClicklistener : OnClickListener? = null
    init {
        this.list = list
        this.context = context
    }

    interface OnClickListener{
        fun onSuccessClick(position: Int)
        fun onFailureClick(position: Int)
    }

    class Holder(itemView: View) : RecyclerView.ViewHolder(itemView){
        val btnSuccess: Button = itemView.findViewById(R.id.btn_success)
        val tvTitle : TextView = itemView.findViewById(R.id.tv_pro_title)
        val tvDesc : TextView = itemView.findViewById(R.id.tv_pro_desc)
        val tvErrCode : TextView = itemView.findViewById(R.id.tv_error_code)
        val tvLevel : TextView = itemView.findViewById(R.id.tv_pro_level)
        val tvResult : TextView = itemView.findViewById(R.id.tv_result)
        val btnFailure : Button = itemView.findViewById(R.id.btn_failure)
        val tvCreate : TextView = itemView.findViewById(R.id.tv_create_user)
        val ivImage : ImageView = itemView.findViewById(R.id.iv_images)

    }

    override fun onCreateViewHolder(parent: ViewGroup, position: Int): Holder {
        return Holder(((context!!.getSystemService(Context.LAYOUT_INFLATER_SERVICE)) as LayoutInflater)
                .inflate(R.layout.item_re_check_list_abc, parent, false))
    }

    override fun onBindViewHolder(holder: Holder, position: Int) {
        val data = list!![position]
        holder.tvTitle.text = data.peoblemTitle
        holder.tvDesc.text = data.problemDesc
        holder.tvErrCode.text = data.malfunctionCode
        if (data.recheckOperator != null){
            when(data.recheckOperator){
                "0" -> {
                    holder.tvResult.text = "不合格"
                }

                "1" -> {
                    holder.tvResult.text = "合格"
                }
            }
        }else{
            holder.tvResult.text = ""
        }


        if ( data.problemLevel != null){
            holder.tvLevel.text = data.problemLevel
        }


        holder.btnSuccess.setOnClickListener{
            if (onClicklistener != null){
                data.result = "合格"
                data.recheckOperator = "1"
                notifyDataSetChanged()
                onClicklistener!!.onSuccessClick(position)
            }
        }

        holder.btnFailure.setOnClickListener{
            if (onClicklistener != null){
                holder.tvResult.text = "不合格"
                data.recheckOperator = "0"
                data.result = "不合格"
                notifyDataSetChanged()
                onClicklistener!!.onFailureClick(position)
            }
        }

        if (data.createByUser != null){
            holder.tvCreate.text = data.createByUser
        }


        if (data.imgStr != null && !TextUtils.isEmpty(data.imgStr)){
            holder.ivImage.setImageBitmap(base64ToBitmap(data.imgStr))
            holder.ivImage.setOnClickListener{
                val intent = Intent(context, ShowImageDisplayActivity::class.java)
                GlobalVar.IMGBASE64 = data.imgStr
                context?.startActivity(intent)
            }
        }


    }

    fun base64ToBitmap(string: String?): Bitmap? {
        var bitmap: Bitmap? = null
        bitmap = try {
            val bitmapArray = Base64.decode(string, Base64.DEFAULT)
            BitmapFactory.decodeByteArray(bitmapArray, 0, bitmapArray.size)
        } catch (e: Exception) {
            e.printStackTrace()
            return null
        }
        return bitmap
    }

    override fun getItemCount(): Int {
        return list!!.size
    }
}