package com.zhuisu.fastdev.adapter.lackhistoryge;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.zhuisu.fastdev.beans.lack.LackHistoryListBean;
import com.zhuisu.fastdev.view.SmartTextView;
import com.zhuisu.qualityManagement.R;

import java.util.List;

/**
 * @author cxh
 * @description
 * @date 2020/10/30.
 */
public class CarFrameLackHistoryAdapter extends RecyclerView.Adapter<CarFrameLackHistoryAdapter.VH> {

    private List<LackHistoryListBean> listBeans;
    private Context context;
    private OnCloseMenuClickListener onCloseMenuClickListener;

    public void setOnCloseMenuClickListener(OnCloseMenuClickListener onCloseMenuClickListener) {
        this.onCloseMenuClickListener = onCloseMenuClickListener;
    }

    public interface OnCloseMenuClickListener {
        void onCloseClickListener(int position);
    }

    public CarFrameLackHistoryAdapter(List<LackHistoryListBean> listBeans, Context context) {
        this.listBeans = listBeans;
        this.context = context;
    }

    @Override
    public VH onCreateViewHolder(ViewGroup parent, int viewType) {

        View view = ((LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE))
                .inflate(R.layout.item_lack_history_list, parent, false);

        return new VH(view);
    }

    @Override
    public void onBindViewHolder(VH holder, int position) {
        LackHistoryListBean data = listBeans.get(position);
        holder.tv_create_number.setText(data.getProductOrder());
        holder.tv_confirm_number.setText(data.getOrderNo());
        holder.tv_wl_name.setText(data.getBomName());
        holder.tv_duct_number.setText(String.valueOf(data.getQuantity()));

        holder.tv_remark_lack.setText(data.getStatus().equals("confirmed") ? "已登记" : "已关闭");


        if (holder.tv_remark_lack.getText().toString().equals("已关闭")) {
            holder.btn_close_lack.setVisibility(View.GONE);
        } else {
            holder.btn_close_lack.setVisibility(View.VISIBLE);
        }

        holder.tv_wuliaohao.setText(data.getBomId());
        holder.tv_car_num.setText(data.getCarFrameNo());
        holder.btn_close_lack.setOnClickListener(v -> {
            if (onCloseMenuClickListener != null) {
                onCloseMenuClickListener.onCloseClickListener(position);
            }
        });
    }

    @Override
    public int getItemCount() {
        return listBeans == null ? 0 : listBeans.size();
    }

    static class VH extends RecyclerView.ViewHolder {

        SmartTextView tv_create_number;
        SmartTextView tv_confirm_number;
        SmartTextView tv_wl_name;
        SmartTextView tv_duct_number;
        SmartTextView tv_remark_lack;
        SmartTextView tv_wuliaohao;
        SmartTextView tv_car_num;
        Button btn_close_lack;


        public VH(View itemView) {
            super(itemView);
            tv_create_number = itemView.findViewById(R.id.tv_create_number);
            tv_confirm_number = itemView.findViewById(R.id.tv_confirm_number);
            tv_wl_name = itemView.findViewById(R.id.tv_wl_name);
            tv_duct_number = itemView.findViewById(R.id.tv_duct_number);
            tv_remark_lack = itemView.findViewById(R.id.tv_remark_lack);
            btn_close_lack = itemView.findViewById(R.id.btn_close_lack);
            tv_wuliaohao = itemView.findViewById(R.id.tv_wuliaohao);
            tv_car_num = itemView.findViewById(R.id.tv_car_num);

        }
    }
}
