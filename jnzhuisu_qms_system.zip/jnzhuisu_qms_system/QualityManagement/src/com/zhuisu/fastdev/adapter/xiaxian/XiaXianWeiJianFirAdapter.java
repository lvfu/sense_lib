package com.zhuisu.fastdev.adapter.xiaxian;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.zhuisu.fastdev.beans.xiaxian.XiaXianWeiJianFirstBean;
import com.zhuisu.qualityManagement.R;

import java.util.List;

/**
 * @author cxh
 * @description 装配未检
 * @date 2020/10/12.
 */
public class XiaXianWeiJianFirAdapter extends BaseAdapter {

    private List<XiaXianWeiJianFirstBean> list;
    private Context context;
    public OnItemClick onItemClick;
    private boolean canCheck = false;

    public void setCanCheck(boolean canCheck) {
        this.canCheck = canCheck;
    }

    public void setOnItemClick(OnItemClick onItemClick) {
        this.onItemClick = onItemClick;
    }

    public XiaXianWeiJianFirAdapter(List<XiaXianWeiJianFirstBean> list, Context context) {
        this.list = list;
        this.context = context;
    }

    @Override
    public int getCount() {
        return list == null ? 0 : list.size();
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        Cache cache;
        if (convertView == null) {
            cache = new Cache();
            convertView = View.inflate(context, R.layout.item_xiaxian_weijian_first, null);
            cache.tv_jianyanbianma = convertView.findViewById(R.id.tv_jianyanbianma);
            cache.tv_jianyanmingcheng = convertView.findViewById(R.id.tv_jianyanmingcheng);
            cache.tv_jianyanjishuyaoqiu = convertView.findViewById(R.id.tv_jianyanjishuyaoqiu);
            cache.tv_jianyanji_state = convertView.findViewById(R.id.tv_jianyanji_state);
            cache.check_ok = convertView.findViewById(R.id.check_ok);
            cache.ll_details = convertView.findViewById(R.id.ll_details);
            cache.check_nook = convertView.findViewById(R.id.check_nook);
            cache.ll_check_control = convertView.findViewById(R.id.ll_check_control);

            cache.ll_pass = convertView.findViewById(R.id.tv_not_check);

            convertView.setTag(cache);
        }
        cache = (Cache) convertView.getTag();

        cache.tv_jianyanmingcheng.setText("(" + (position + 1) + ")" + list.get(position).getOpnm());
        cache.tv_jianyanbianma.setText("" + list.get(position).getOpno());
        cache.tv_jianyanjishuyaoqiu.setText(" " + list.get(position).getMation());
        cache.tv_jianyanji_state.setText("" + (list.get(position).getStatus().equals("passed") ? "合格" : list.get(position).getStatus().equals("failed") ? "不合格" : "待检验"));

        cache.ll_pass.setVisibility(canCheck ? View.GONE : View.VISIBLE);

        cache.check_ok.setOnClickListener(v -> {
            if (onItemClick != null) {
                onItemClick.onOkClick(position);
            }
        });

        cache.check_nook.setOnClickListener(v -> {
            if (onItemClick != null) {
                onItemClick.onNoClick(position);
            }
        });
        cache.ll_details.setOnClickListener(view -> {
            if (onItemClick != null) {
                onItemClick.onDetailClickLisen(position);
            }
        });

        cache.ll_pass.setOnClickListener(view -> {
            if (onItemClick != null) {
                onItemClick.onPass(position);
            }
        });




        if (canCheck) {
            //检测完成
            cache.ll_check_control.setVisibility(View.GONE);
        } else {
            cache.ll_check_control.setVisibility(View.VISIBLE);
        }
        return convertView;
    }

    static class Cache {
        TextView tv_jianyanbianma;
        TextView tv_jianyanmingcheng;
        TextView tv_jianyanjishuyaoqiu;
        TextView tv_jianyanji_state;
        Button check_ok;
        Button check_nook;
        LinearLayout ll_details;
        LinearLayout ll_check_control;

        Button ll_pass;
    }

    public interface OnItemClick {
        void onOkClick(int position);

        void onNoClick(int position);

        void onDetailClickLisen(int position);

        void onPass(int position);
    }
}
