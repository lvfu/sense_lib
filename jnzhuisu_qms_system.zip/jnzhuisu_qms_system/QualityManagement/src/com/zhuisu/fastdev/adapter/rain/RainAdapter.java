package com.zhuisu.fastdev.adapter.rain;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.zhuisu.fastdev.beans.rain.RainListBean;
import com.zhuisu.fastdev.view.SmartTextView;
import com.zhuisu.qualityManagement.R;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * @author cxh
 * @description
 * @date 2020/10/23.
 */
public class RainAdapter extends RecyclerView.Adapter<RainAdapter.VH> {
    private List<RainListBean> list;
    private Context context;
    private OnPrintCommitClickListener onPrintCommitClickListener;

    public void setOnPrintCommitClickListener(OnPrintCommitClickListener onPrintCommitClickListener) {
        this.onPrintCommitClickListener = onPrintCommitClickListener;
    }

    public interface OnPrintCommitClickListener{
        void onPrintCommit(int position);
    }

    public RainAdapter(List<RainListBean> list, Context context) {
        this.list = list;
        this.context = context;
    }

    @Override
    public VH onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = ((LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE))
                .inflate(R.layout.item_rain_list,parent,false);

        return new VH(view);
    }

    @Override
    public void onBindViewHolder(VH holder, int position) {
        RainListBean data = list.get(position);

        //set
        if (data.getQmsManufactureProductionplan() != null){
            holder.tv_dingdanhao.setText(data.getQmsManufactureProductionplan().getOrderNo());
        }

        holder.tv_suichedanhao.setText(data.getFlowCarNo());
        holder.tv_car_number.setText(data.getCarFarmeNo());
        if (data.getQmsManufactureProductionplan() != null){
            holder.tv_car_type.setText(data.getQmsManufactureProductionplan().getCarModelNo());
        }

        if (data.getQmsManufactureProductionplan() != null){
            holder.tv_info.setText(data.getQmsManufactureProductionplan().getConfigDesc());
        }

        holder.tv_up_time.setText(data.getCreateDate());
        holder.btn_print_commit.setOnClickListener(v -> {
            if (null != onPrintCommitClickListener){
                onPrintCommitClickListener.onPrintCommit(position);
            }
        });

        if (data.getVarnishDate() != null){
            holder.tv_print_time.setText(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.CHINA).format(new Date(data.getVarnishDate())));
        }


        if (data.getEnvironmentalLabel() != null){
            holder.tv_recyable.setText(data.getEnvironmentalLabel().equals("1") ? "是" : "否");
        }

    }

    @Override
    public int getItemCount() {
        return list == null ? 0 : list.size();
    }

    static class VH extends RecyclerView.ViewHolder{

        SmartTextView tv_dingdanhao;//订单号
        SmartTextView tv_suichedanhao;//随车单号
        SmartTextView tv_car_number;//车架号
        SmartTextView tv_car_type;//车型号
        SmartTextView tv_info;//配置
        SmartTextView tv_up_time,tv_recyable,tv_print_time;//上线时间
        Button btn_print_commit;//接车

        public VH(View itemView) {
            super(itemView);
            tv_dingdanhao = itemView.findViewById(R.id.tv_dingdanhao);
            tv_suichedanhao= itemView.findViewById(R.id.tv_suichedanhao);
            tv_car_number = itemView.findViewById(R.id.tv_car_number);
            tv_car_type = itemView.findViewById(R.id.tv_car_type);
            tv_info = itemView.findViewById(R.id.tv_info);
            tv_up_time = itemView.findViewById(R.id.tv_up_time);
            btn_print_commit = itemView.findViewById(R.id.btn_print_commit);
            tv_recyable = itemView.findViewById(R.id.tv_recyable);
            tv_print_time = itemView.findViewById(R.id.tv_print_time);
        }
    }
}
