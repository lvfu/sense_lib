package com.zhuisu.fastdev.adapter.zhiliangmen;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.zhuisu.fastdev.beans.zhiliangmen.ZhiLiangMenWeiJianFirstBean;
import com.zhuisu.qualityManagement.R;

import java.util.List;

/**
 * @author cxh
 * @description 装配未检
 * @date 2020/10/12.
 */
public class QualityCheckedAndProblemAdapter extends BaseAdapter {

    private List<ZhiLiangMenWeiJianFirstBean> list;
    private Context context;
    public OnItemClick onItemClick;

    public void setOnItemClick(OnItemClick onItemClick) {
        this.onItemClick = onItemClick;
    }

    public QualityCheckedAndProblemAdapter(List<ZhiLiangMenWeiJianFirstBean> list, Context context) {
        this.list = list;
        this.context = context;
    }

    @Override
    public int getCount() {
        return list == null ? 0: list.size();
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @SuppressLint("SetTextI18n")
    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        Cache cache;
        if (convertView == null){
            cache = new Cache();
            convertView = View.inflate(context, R.layout.item_quality_checked_problem,null);
            cache.tv_jianyanmingcheng = convertView.findViewById(R.id.tv_jianyanmingcheng);
            cache.tv_jianyanji_state = convertView.findViewById(R.id.tv_jianyanji_state);
            cache.ll_details = convertView.findViewById(R.id.ll_details);
            convertView.setTag(cache);
        }
        cache = (Cache) convertView.getTag();

        cache.tv_jianyanmingcheng.setText(list.get(position).getOpnm());
        cache.tv_jianyanji_state.setText("" + (list.get(position).getStatus().equals("passed") ? "合格" : list.get(position).getStatus().equals("failed") ? "不合格" : "待检验"));


        cache.ll_details.setOnClickListener(view -> {
            if (onItemClick != null){
                onItemClick.onDetailClickLisen(position);
            }
        });

        return convertView;
    }

    static class Cache{
        TextView tv_jianyanmingcheng;
        TextView tv_jianyanji_state;
        LinearLayout ll_details;
    }

    public interface OnItemClick{
        void onDetailClickLisen(int position);
    }
}
