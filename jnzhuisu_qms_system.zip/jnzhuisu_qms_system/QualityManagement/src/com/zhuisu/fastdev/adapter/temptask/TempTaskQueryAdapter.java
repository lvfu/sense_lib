package com.zhuisu.fastdev.adapter.temptask;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.zhuisu.qualityManagement.R;

import java.util.List;

/**
 * @author cxh
 * @description  临时计划查询 -
 * @date 2021/2/20.
 */
public class TempTaskQueryAdapter  extends RecyclerView.Adapter<TempTaskQueryAdapter.VH> {

    private Context context;
    private List<TempTaskQueryListBean> listBeans;
    public OnItemDetailClickListener onItemDetailClickListener;

    public TempTaskQueryAdapter(Context context, List<TempTaskQueryListBean> listBeans) {
        this.context = context;
        this.listBeans = listBeans;
    }

    public interface OnItemDetailClickListener{
        void onDetailClickListener(int adapterPosition);
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        return new VH(((LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE)).inflate(R.layout.item_temp_task_query,viewGroup,false));
    }

    @Override
    public void onBindViewHolder(@NonNull VH vh, int i) {
        TempTaskQueryListBean data = listBeans.get(vh.getAdapterPosition());

        vh.tvOrderNumber.setText((data.getPlancode() == null || TextUtils.isEmpty(data.getPlancode())) ? "未提交" : data.getPlancode());
        vh.tvMetaNumber.setText(data.getPlantype());
        vh.tvCount.setText(String.valueOf(data.getOrderno()));

        vh.llGroup.setOnClickListener(v -> {
            if (onItemDetailClickListener != null){
                onItemDetailClickListener.onDetailClickListener(vh.getAdapterPosition());
            }
        });
    }

    @Override
    public int getItemCount() {
        return listBeans == null ? 0 : listBeans.size();
    }

    static class VH extends RecyclerView.ViewHolder{
        TextView tvOrderNumber,tvMetaNumber,tvCount;
        LinearLayout llGroup;
        public VH(@NonNull View itemView) {
            super(itemView);
            tvOrderNumber = itemView.findViewById(R.id.tv_order_number);
            tvMetaNumber = itemView.findViewById(R.id.tv_meta_mumber);
            tvCount = itemView.findViewById(R.id.tv_count);
            llGroup = itemView.findViewById(R.id.ll_group);
        }
    }
}
