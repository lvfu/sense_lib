package com.zhuisu.fastdev.adapter.problemquery;

import android.content.Context;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.zhuisu.fastdev.beans.ProgressTrackBean;
import com.zhuisu.fastdev.view.SmartTextView;
import com.zhuisu.qualityManagement.R;

import java.util.List;


public class ProgressTrackAdaper extends RecyclerView.Adapter<ProgressTrackAdaper.VH> {

    private List<ProgressTrackBean> listBeans;
    private Context context;

    public ProgressTrackAdaper(List<ProgressTrackBean> listBeans, Context context) {
        this.listBeans = listBeans;
        this.context = context;
    }

    @Override
    public VH onCreateViewHolder(ViewGroup parent, int viewType) {

        View view = ((LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE))
                .inflate(R.layout.item_progress_track_layout, parent, false);

        return new VH(view);
    }

    @Override
    public void onBindViewHolder(VH holder, int position) {
        ProgressTrackBean data = listBeans.get(position);

        holder.trackTitleTv.setText("问题描述: " + data.getTrackingDescription());
        holder.trackTimeTv.setText("录入时间: " + data.getUpdateDate());
        holder.trackUpdateUserTv.setText("录入人: " + data.getLoginName());
    }

    @Override
    public int getItemCount() {
        return listBeans == null ? 0 : listBeans.size();
    }

    static class VH extends RecyclerView.ViewHolder {

        TextView trackTitleTv;
        TextView trackTimeTv;
        TextView trackUpdateUserTv;

        public VH(View itemView) {
            super(itemView);
            trackTitleTv = itemView.findViewById(R.id.progress_track_title_tv);
            trackTimeTv = itemView.findViewById(R.id.progress_track_time_tv);
            trackUpdateUserTv = itemView.findViewById(R.id.progress_track_update_user_tv);

        }
    }
}


